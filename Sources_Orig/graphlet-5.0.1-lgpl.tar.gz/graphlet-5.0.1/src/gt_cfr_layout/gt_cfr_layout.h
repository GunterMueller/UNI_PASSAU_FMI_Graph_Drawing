/* This software is distributed under the Lesser General Public License */
#ifndef GT_CFR_LAYOUT_H
#define GT_CFR_LAYOUT_H

//
// gt_cfr_layout.h
//
// This file initializes the module gt_cfr_layout.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_cfr_layout/gt_cfr_layout.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1998/08/27 17:19:16 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

//
// Initialization procedure
//

extern "C" {
    int Gt_cfr_layout_Init (Tcl_Interp* interp);
}

#endif
