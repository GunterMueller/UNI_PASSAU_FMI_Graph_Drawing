/* This software is distributed under the Lesser General Public License */
//
// cfr_io.h
//
// This is a dummy file. The current install scheme needs a .h file
// for each .cc file or produces an error during make install.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_cfr_layout/cfr_io.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1999/03/05 20:45:25 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1999, Graphlet Project
//








