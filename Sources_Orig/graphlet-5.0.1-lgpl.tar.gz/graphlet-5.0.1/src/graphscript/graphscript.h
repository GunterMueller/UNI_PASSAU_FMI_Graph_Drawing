/* This software is distributed under the Lesser General Public License */
#ifndef GRAPHSCRIPT_H
#define GRAPHSCRIPT_H

// ----------------------------------------------------------------------
// graphscript.h
//
// Headerfile for graphscript.h
//
// ---------------------------------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/graphscript/graphscript.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1999/03/05 20:42:45 $
// $Locker:  $
// $State: Exp $
// ----------------------------------------------------------------------
//
// (C) University of Passau 1995-1999, Graphlet Project
//

#endif
