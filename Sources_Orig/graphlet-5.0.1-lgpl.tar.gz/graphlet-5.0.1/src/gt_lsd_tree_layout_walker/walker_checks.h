/* This software is distributed under the Lesser General Public License */
// Walter: is_correct is called in check
extern  char* walker_is_correct (graph &g);
