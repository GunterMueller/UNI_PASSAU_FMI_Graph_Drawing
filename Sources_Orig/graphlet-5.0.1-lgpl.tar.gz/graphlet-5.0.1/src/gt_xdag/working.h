/* This software is distributed under the Lesser General Public License */
//
// working.h
//
// ... this is a temporary dummy file ...
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_xdag/working.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1998/08/27 17:19:31 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1997, Graphlet Project
//
//     Author: Harald Mader (mader@fmi.uni-passau.de)
//
