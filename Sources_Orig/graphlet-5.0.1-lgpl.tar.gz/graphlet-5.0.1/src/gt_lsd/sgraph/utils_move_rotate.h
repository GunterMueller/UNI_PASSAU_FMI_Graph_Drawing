/* This software is distributed under the Lesser General Public License */
extern void move_sgraph (Sgraph g, int x, int y);
extern void swap_width_and_height_in_nodes (Sgraph g);

extern void turn_left_sgraph(Sgraph g);
extern void turn_right_sgraph(Sgraph g);

// extern void call_fit_nodes_to_text(Sgraph_proc_info info);
// extern void call_set_dummy_coordinates_and_labels(Sgraph_proc_info info);
