/* This software is distributed under the Lesser General Public License */
/* Dummy-Header for LSD by Dirk Heider */

#ifndef _LSD

/*
if this dummy-header is included and _LSD is NOT defined,
then create an error to prevent illegal usage:
*/

DANGER! Including LSD-header without defining _LSD!

#endif
