/* This software is distributed under the Lesser General Public License */
/*
notice.h

taken from XView's noitic.h to fake Sgraph that XView is there...
*/

/* fake XView's Menu & Menu_item */

#ifndef xview_notice_DEFINED
#define xview_notice_DEFINED


#endif /* ~xview_notice_DEFINED */
