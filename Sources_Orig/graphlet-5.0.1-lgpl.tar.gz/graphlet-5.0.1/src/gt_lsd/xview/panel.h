/* This software is distributed under the Lesser General Public License */
 
/*
panel.h

taken from XView's panel.h to fake Sgraph that XView is there...
*/

/* fake XView's Panel_item */

#ifndef xview_panel_DEFINED
#define xview_panel_DEFINED

typedef int Panel_item;

#endif /* ~xview_panel_DEFINED */
