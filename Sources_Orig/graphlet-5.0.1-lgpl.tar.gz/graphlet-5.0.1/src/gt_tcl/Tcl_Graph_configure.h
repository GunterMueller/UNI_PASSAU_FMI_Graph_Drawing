/* This software is distributed under the Lesser General Public License */
#ifndef TCL_GRAPHICS_H
#define TCL_GRAPHICS_H

//
// GT_Tcl_Grapics.h
// 
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Graph_configure.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1999/03/05 20:46:15 $
// $Locker:  $
// $State: Exp $
// ----------------------------------------------------------------------
//
// (C) University of Passau 1995-1999, Graphlet Project
//

#endif
