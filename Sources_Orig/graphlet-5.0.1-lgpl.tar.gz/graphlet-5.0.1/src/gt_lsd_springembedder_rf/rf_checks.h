/* This software is distributed under the Lesser General Public License */
// ---------------------------------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_lsd_springembedder_rf/rf_checks.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1999/03/05 20:45:46 $
// $Locker:  $
// $State: Exp $
// ----------------------------------------------------------------------
//
// (C) University of Passau 1995-1999, Graphlet Project, Walter Bachl
//


extern char *spring_rf_is_correct (graph &g);            
