/* This software is distributed under the Lesser General Public License */
#ifndef GT_gml_parser_h
#define GT_gml_parser_h

#include "List_of_Attributes.h"
#include <GTL/gml_parser.h>

GT_List_of_Attributes* GT_GML_parser (FILE*, struct GML_stat*);

#endif




