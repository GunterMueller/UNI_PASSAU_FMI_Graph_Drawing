/* This software is distributed under the Lesser General Public License */
#ifndef GT_GRAPH_HANDLERS_H
#define GT_GRAPH_HANDLERS_H

//
// Graph_handlers.h
//
// This module implements prototypes the class GT_Graph. Currenty
// just a dummy.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Graph_handlers.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1999/03/05 20:43:48 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1999, graphlet project
//

#endif
