/* This software is distributed under the Lesser General Public License */
//
// GTL_Shuttle.cpp
//
// This file implements the class GT_GTL_Shuttle
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/GTL_Shuttle.cpp,v $
// $Author: himsolt $
// $Revision: 1.1 $
// $Date: 1999/06/24 11:13:04 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1999, graphlet Project
//

#include "Graphlet.h"
#include "Graph.h"

#include "GTL_Shuttle.h"

