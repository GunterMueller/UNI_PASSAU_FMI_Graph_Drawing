/* This software is distributed under the Lesser General Public License */
#ifndef GT_GT_BASE_H
#define GT_GT_BASE_H

//
// gt_base.h
//
// This is the initialization file for the module gt_base
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/gt_base.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1999/03/05 20:45:12 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1999, graphlet Project
//

extern "C" {
    int Gt_base_Init (void* interp);
}

#endif
