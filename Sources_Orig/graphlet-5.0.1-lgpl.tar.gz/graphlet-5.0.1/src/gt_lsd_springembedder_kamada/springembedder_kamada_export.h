/* This software is distributed under the Lesser General Public License */
extern	GraphEd_Menu_Proc springembedder_kamada_menu_proc;
extern	void	call_springembedder_kamada (Sgraph_proc_info info, int edgelength);
char* check_springembedder_kamada (Sgraph_proc_info info);
