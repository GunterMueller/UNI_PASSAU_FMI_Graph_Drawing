/* This software is distributed under the Lesser General Public License */
#include <xview/xview.h>

extern void tunkelang_layout(Menu menu, Menu_item menu_item);

extern void display_the_message(char *string);

