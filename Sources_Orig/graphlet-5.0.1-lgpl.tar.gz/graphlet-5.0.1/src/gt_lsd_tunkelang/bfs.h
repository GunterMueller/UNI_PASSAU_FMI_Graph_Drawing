/* This software is distributed under the Lesser General Public License */
extern int bfs(int i, unsigned short flag);
