/* This software is distributed under the Lesser General Public License */
extern void shake_graph(Menu menu, Menu_item menu_item);
