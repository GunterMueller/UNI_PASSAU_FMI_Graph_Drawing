/* This software is distributed under the Lesser General Public License */
extern Sgraph build_graph(void);

extern void save_image(int image_number);
