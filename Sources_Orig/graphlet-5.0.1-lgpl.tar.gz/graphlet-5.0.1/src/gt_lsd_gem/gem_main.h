/* This software is distributed under the Lesser General Public License */
#ifndef GEM_MAIN_H
#define GEM_MAIN_H

extern void call_gem(Sgraph_proc_info info);
extern void menu_gem_layout(Menu menu, Menu_item menu_item);

#endif
