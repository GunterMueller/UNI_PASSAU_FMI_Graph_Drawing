/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// graph_java.h
//
// ***************************************************************************

#ifndef GTL_JAVA_GRAPH_JAVA_H
#define GTL_JAVA_GRAPH_JAVA_H

#include <GTL_java/GTL_java.h>
#include <GTL/graph.h>

#include <jni.h>

#include <map>


class GTL_JAVA_EXTERN graph_java
{
public:

    virtual jobject convert_list(const list<node> &) = 0;
    virtual jobject convert_list(const list<edge> &) = 0;
    virtual jobject convert_list(const list<string> &) = 0;

    virtual node&   get_node(jobject obj) = 0;
    virtual edge&   get_edge(jobject obj) = 0;

    virtual jobject get_obj(const node& n) = 0;
    virtual jobject get_obj(const edge& e) = 0;

    virtual jobject get_obj() = 0;
};

#endif

