/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GTL_Java.h
//
// ***************************************************************************


#ifndef GTL_JAVA_GJAVA_GLOBAL_H
#define GTL_JAVA_GJAVA_GLOBAL_H

// this header is needed by nearly all files
// #include "jgraph.h"

// define types of iterators

#define ITT_node_list_iterator		101
#define ITT_node_list_reverse_iterator	102
#define ITT_adj_nodes_iterator		103

#define ITT_edge_list_iterator		201
#define ITT_adj_edges_iterator		202
#define ITT_inout_edges_iterator	203

#ifdef _MSC_VER
#  if _MSC_VER >= 1100
    
#    define __GTL_USE_NAMESPACES
#    define __GTL_MSVCC

#    pragma warning( disable : 4786 )
#    pragma warning( disable : 4251 )

#    ifdef GTL_JAVA_EXPORTS
#      define GTL_JAVA_EXTERN __declspec(dllexport)
#    else
#	 define GTL_JAVA_EXTERN __declspec(dllimport)
#    endif

#  else

#    error "Need at least version 5.0 of MS Visual C++ to compile GTL Java."

#  endif

#else
#   define GTL_JAVA_EXTERN 

#endif

// base class for special iterator data structure
class iterator_data
{
};

#endif

