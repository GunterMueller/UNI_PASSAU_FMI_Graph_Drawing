/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// jgraph.cpp
//
// ***************************************************************************

#ifndef __JGRAPH_H
#define __JGRAPH_H

#include "graph_java.h"

class JNI_Util;

class GTL_graph_java : public graph, public graph_java
{
public:
 
    GTL_graph_java(JNIEnv*, jobject);
    ~GTL_graph_java();

    // we need a lot of handler, for deletion, creation and so on
    // most of them just call the java-method, but some have to
    // do some real work

    // node - handler
    virtual void pre_new_node_handler();
    virtual void post_new_node_handler(node n);
    virtual void pre_del_node_handler(node n);
    virtual void post_del_node_handler();
    virtual void pre_hide_node_handler(node n);
    virtual void post_hide_node_handler(node n);
    virtual void pre_restore_node_handler(node n);
    virtual void post_restore_node_handler(node n);
    
    // edge - handler
    virtual void pre_new_edge_handler(node s, node t);
    virtual void post_new_edge_handler(edge e);
    virtual void pre_del_edge_handler(edge e);
    virtual void post_del_edge_handler(node n1, node n2);
    virtual void pre_hide_edge_handler(edge e);
    virtual void post_hide_edge_handler(edge e);
    virtual void pre_restore_edge_handler(edge e);
    virtual void post_restore_edge_handler(edge e);

    // global handlers
    virtual void pre_clear_handler();
    virtual void post_clear_handler();
    virtual void pre_make_directed_handler();
    virtual void post_make_directed_handler();
    virtual void pre_make_undirected_handler();
    virtual void post_make_undirected_handler();

    // missing :: rest of handlers - all must invoke a java-handler !!

    // common access functions and tools - needed for java interface
    jobject convert_list(const list<node> &);
    jobject convert_list(const list<edge> &);
    jobject convert_list(const list<string> &);

    node& get_node(jobject obj);
    edge& get_edge(jobject obj);

    jobject get_obj(const node& n);
    jobject get_obj(const edge& e);

    jobject get_obj();

    // Returns the jclass for the class with name className
    jclass getClass(string className);

    // Returns the jmethodID for a method
    jmethodID getMethodID(string className, string methodName, string signature);

    typedef graph baseclass;

private:
    map<node, jobject>  node_obj;    // maps to store the relation between java-node and gtl-node
    map<jobject, node> obj_node;

    map<edge, jobject>  edge_obj;
    map<jobject, edge> obj_edge;

    JNIEnv* env;	// Java-environment
    jclass cls;		// class type of class Graph
    jobject obj;	// reference to own object 

    bool status_clear_allowed;
    
    map<string, jclass> classMap;
    map<string, jmethodID> methodMap;

    jclass cls_node;
    jclass cls_edge;
    jclass cls_list;

    // init-functions
    jmethodID init_node;
    jmethodID init_edge;
    jmethodID init_list;

    // list functions
    jmethodID add_list;

    // node - handler
    jmethodID mid_pre_new_node_handler;
    jmethodID mid_post_new_node_handler;
    jmethodID mid_pre_del_node_handler;
    jmethodID mid_post_del_node_handler;
    jmethodID mid_pre_hide_node_handler;
    jmethodID mid_post_hide_node_handler;
    jmethodID mid_pre_restore_node_handler;
    jmethodID mid_post_restore_node_handler;
    
    // edge - handler
    jmethodID mid_pre_new_edge_handler;
    jmethodID mid_post_new_edge_handler;
    jmethodID mid_pre_del_edge_handler;
    jmethodID mid_post_del_edge_handler;
    jmethodID mid_pre_hide_edge_handler;
    jmethodID mid_post_hide_edge_handler;
    jmethodID mid_pre_restore_edge_handler;
    jmethodID mid_post_restore_edge_handler;

    // global handlers
    jmethodID mid_pre_clear_handler;
    jmethodID mid_post_clear_handler;
    jmethodID mid_pre_make_directed_handler;
    jmethodID mid_post_make_directed_handler;
    jmethodID mid_pre_make_undirected_handler;
    jmethodID mid_post_make_undirected_handler;

    // friends ...
    friend class JNI_Util;
};

class JNI_iterator
{
public:
    bool hasNext();

    jobject next();

private:
    JNI_iterator(JNIEnv* env, jobject it);

    jmethodID methodHasNextID;
    jmethodID methodNextID;
    jobject   iterator;
    JNIEnv*   env;

    friend class JNI_Util;
};

class JNI_Util
{
public:
    // ****************************************************************
    // method and class access methods

    // Returns the jclass for the class with name className
    /* inline */ static jclass getClass(JNIEnv* env, string className);
    /* inline */ static jclass getObjectClass(JNIEnv* env, jobject);

    // Returns the jmethodID for a method - buffering
    /* inline */ static jmethodID getMethodID(JNIEnv* env, string className, string methodName, string signature);

    // Returns the jmethodID for a method - without buffering
    /* inline */ static jmethodID getMethodID(JNIEnv* env, jclass cls, string methodName, string signature);

    // Returns the jfieldID for a method - buffering
    /* inline * / static jfieldID getFieldID(JNIEnv* env, string className, string fieldName, string signature);
    
    // Returns the jfieldID for a method - buffering
    /* inline * / static jfieldID getFieldID(JNIEnv* env, jclass cls, string fieldName, string signature);

    // ****************************************************************
    // method calls and field access

    /* inline * / static void callVoidMethod(JNIEnv* env, jobject obj, jmethodID method);
    /* inline * / static void callVoidMethod(JNIEnv* env, jobject obj, jmethodID method, 
	jobject);
    /* inline * / static void callVoidMethod(JNIEnv* env, jobject obj, jmethodID method, 
	jobject, jobject);
    /* inline * / static void callVoidMethod(JNIEnv* env, jobject obj, jmethodID method, 
	jobject, jobject, jobject);
    /* inline * / static void callVoidMethod(JNIEnv* env, jobject obj, jmethodID method,
	int);
    /* inline * / static void callVoidMethod(JNIEnv* env, jobject obj, jmethodID method,
	double, double, double, double);
    /* inline * / static jobject callObjectMethod(JNIEnv* env, jobject obj, jmethodID method);
    /* inline * / static jobject callObjectMethod(JNIEnv* env, jobject obj, jmethodID method, 
	jobject p1, int p2);
    /* inline * / static int callIntMethod(JNIEnv* env, jobject obj, jmethodID method);
    /* inline * / static double callDoubleMethod(JNIEnv* env, jobject obj, jmethodID method);

    /* inline * / static const char* getStringUTFChars(JNIEnv* env, jstring);
    /* inline * / static void releaseStringUTFChars(JNIEnv* env, jstring, const char*);
    /* inline * / static jstring newStringUTF(JNIEnv* env, const char*);

    /* inline * / static double getDoubleField(JNIEnv* env, jobject obj, jfieldID method);
    /* inline * / static jobject getObjectField(JNIEnv* env, jobject obj, jfieldID method);
    
    /* inline * / static void setDoubleField(JNIEnv* env, jobject, jfieldID, double);
    /* inline * / static void setIntField(JNIEnv* env, jobject, jfieldID, int);

    // ****************************************************************
    // iterators

    static JNI_iterator getIterator(JNIEnv* env, jobject iterator);

    // ****************************************************************
    // list

    static jobject getNewLinkedList(JNIEnv* env);
    static void addElementToList(JNIEnv* env, jobject list, jobject elem);
    static JNI_iterator getListIterator(JNIEnv* env, jobject list);

    // ****************************************************************
    // references

    static void deleteGlobalRef(JNIEnv* env, jobject);
    static void deleteLocalRef(JNIEnv* env, jobject);

    static jobject newGlobalRef(JNIEnv* env, jobject obj);
    static jobject newLocalRef(JNIEnv* env, jobject obj);
    static jobject newWeakGlobalRef(JNIEnv* env, jobject obj);

    // ****************************************************************
    // object creation

    */

    // creates an new GT_Graph
    static jobject getNewGtlNode(JNIEnv* env, jlong gtlPointer, jlong gjavaPointer);
    static jobject getNewGtlEdge(JNIEnv* env, jlong gtlPointer, jlong gjavaPointer);

    // ****************************************************************
    // utilities
/*    
    static jobject convertList(JNIEnv* env, const list<string> &);
*/
private:

    static map<string, jclass> classMap;
    static map<string, jmethodID> methodMap;
    static map<string, jfieldID> fieldMap;
    
};

#endif

