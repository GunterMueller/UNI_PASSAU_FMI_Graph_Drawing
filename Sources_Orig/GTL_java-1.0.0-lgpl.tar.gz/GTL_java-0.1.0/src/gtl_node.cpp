/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GTL_Node.cpp
//
// ***************************************************************************

#include <GTL_java/JNI/gtl_GTL_0005fNode.h>
#include <GTL_java/graph_java.h>

#include <GTL/graph.h>

// ***************************************************************************
// class Node

JNIEXPORT jint JNICALL Java_gtl_GTL_1Node_nativeExcentricity
  (JNIEnv *, jobject, jlong gid, jlong ref)
{
    return ((graph_java*)gid)->get_node((jobject)ref).excentricity();
}

JNIEXPORT jboolean JNICALL Java_gtl_GTL_1Node_nativeIsHidden
  (JNIEnv *, jobject, jlong gid, jlong ref)
{
    return ((graph_java*)gid)->get_node((jobject)ref).is_hidden();
}

JNIEXPORT jint JNICALL Java_gtl_GTL_1Node_nativeNodeDegree
  (JNIEnv*, jobject, jlong gid, jlong ref)
{
    return ((graph_java*)gid)->get_node((jobject)ref).degree();
}

JNIEXPORT jint JNICALL Java_gtl_GTL_1Node_nativeNodeId
  (JNIEnv*, jobject, jlong gid, jlong ref)
{
    return ((graph_java*)gid)->get_node((jobject)ref).id();
}

JNIEXPORT jint JNICALL Java_gtl_GTL_1Node_nativeNodeIndeg
  (JNIEnv*, jobject, jlong gid, jlong ref)
{
   return ((graph_java*)gid)->get_node((jobject)ref).indeg();
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1Node_nativeNodeOpposite
  (JNIEnv*, jobject, jlong gid, jlong ref, jlong edge)
{
    // get graph_java
    graph_java& g = *((graph_java*)gid);
    return g.get_obj( g.get_node((jobject)ref).
	opposite(g.get_edge((jobject)edge)) );
}

JNIEXPORT jint JNICALL Java_gtl_GTL_1Node_nativeNodeOutdeg
  (JNIEnv*, jobject, jlong gid, jlong ref)
{
    return ((graph_java*)gid)->get_node((jobject)ref).outdeg();
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1Node_nativeGetGraph
  (JNIEnv *, jobject, jlong gid)
{
    return ((graph_java*)gid)->get_obj();
}
