/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// graph_java_standalone.cpp
//
// ***************************************************************************

#pragma warning (disable: 4786)

#include <GTL_java/graph_java_standalone.h>

map<string, jclass> JNI_Util::classMap;
map<string, jmethodID> JNI_Util::methodMap;
map<string, jfieldID> JNI_Util::fieldMap;

jclass JNI_Util::getClass(JNIEnv* env, string className)
{
    assert (env != 0);

    jclass temp = classMap[className];

    if (temp == jclass())
    {
	temp = (jclass)env->NewGlobalRef(env->FindClass(className.c_str()));
	assert (temp != 0);
	classMap[className] = temp;
    }

    if (env->ExceptionOccurred())
    {
	env->ExceptionDescribe();
	env->ExceptionClear();
    }

    return temp;
}

jclass JNI_Util::getObjectClass(JNIEnv* env, jobject obj)
{
    assert (env != 0);
    assert (obj != 0);

    jclass cls = env->GetObjectClass(obj);
    assert (cls != 0);
    
    if (env->ExceptionOccurred())
    {
	env->ExceptionDescribe();
	env->ExceptionClear();
    }

    return cls;
}

jmethodID JNI_Util::getMethodID(JNIEnv* env, string className, string methodName, string signature)
{
    assert (env != 0);
    string sig = className+methodName+signature;
    jmethodID id = methodMap[sig];
    
    if (id == jmethodID())
    {
	id = env->GetMethodID(getClass(env, className), methodName.c_str(), signature.c_str());
	methodMap[sig] = id;
    }

    if (env->ExceptionOccurred())
    {
	env->ExceptionDescribe();
	env->ExceptionClear();
    }

    assert (id != jmethodID());
    return id;
}

jmethodID JNI_Util::getMethodID(JNIEnv* env, jclass cls, string methodName, string signature)
{
    assert (env != 0);
    assert (cls != 0);
    jmethodID id = env->GetMethodID(cls, methodName.c_str(), signature.c_str());

    if (env->ExceptionOccurred())
    {
	env->ExceptionDescribe();
	env->ExceptionClear();
    }

    assert (id != jmethodID());
    return id;
}


jobject JNI_Util::getNewGtlNode(JNIEnv* env, jlong gtlPointer, jlong gjavaPointer)
{
    assert (env != 0);
    assert (gtlPointer != 0);
    assert (gjavaPointer != 0);

    jclass cls = getClass(env, "gtl/GTL_Node");
    jmethodID init = getMethodID(env, "gtl/GTL_Node", "<init>", "(JJ)V");

    jobject jnode = env->NewGlobalRef(env->NewObject(cls, init, 
	gtlPointer, gjavaPointer));

    if (env->ExceptionOccurred())
    {
	env->ExceptionDescribe();
	env->ExceptionClear();
    }

    assert (jnode != 0);
    return jnode;
}

jobject JNI_Util::getNewGtlEdge(JNIEnv* env, jlong gtlPointer, jlong gjavaPointer)
{
    assert (env != 0);
    assert (gtlPointer != 0);
    assert (gjavaPointer != 0);

    jclass cls = getClass(env, "gtl/GTL_Edge");
    jmethodID init = getMethodID(env, "gtl/GTL_Edge", "<init>", "(JJ)V");

    jobject jedge = env->NewGlobalRef(env->NewObject(cls, init, 
	gtlPointer, gjavaPointer));

    if (env->ExceptionOccurred())
    {
	env->ExceptionDescribe();
	env->ExceptionClear();
    }

    assert (jedge != 0);
    return jedge;
}
