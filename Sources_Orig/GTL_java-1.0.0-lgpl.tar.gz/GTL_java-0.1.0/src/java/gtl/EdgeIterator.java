/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// edge_iterator.java
//
// interface
//
// ***************************************************************************

package gtl;

/**
 * Interface representing an iterator through a list of edges.
 *
 * Usage: 
 * <pre>
 * Graph g = new GTL_Graph();
 * EdgeIterator it = g.getEdgeIterator();
 * while(it.hasNext())
 * {
 *     Edge e = it.next();
 *     ...
 * }
 * </pre>
 */
public interface EdgeIterator
{
    /**
     * Checks whether a next edge exists.
     *
     * @return true iff a next edge exists
     */
    public boolean hasNext();

    /**
     * Returns next edge.
     *
     * @return next edge
     */
    public Edge next();

    /**
     * Checks whether a previous edge exists.
     *
     * @return true iff a previous edge exists
     */
    public boolean hasPrev();

    /**
     * Returns previous edge.
     *
     * @return previous edge
     */
    public Edge prev();
}
