/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GTL_Graph.java
//
// contains definition of class GTL_Graph
//
// ***************************************************************************

package gtl;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;

/**
  * Implementation of interface Graph using gtl.
  *
  * @see Graph
  */
public class GTL_Graph extends Graph
{
    // **************************************************
    //
    // constructors
    //
    // **************************************************

    /**
     * Constructs a new GTL_Graph.
     *
     * The constructor will create
     * a new C++ jgraph (jgraph extends graph). This graph can
     * be used for algorithms running under C++. Use 
     * <code>synchronized public int getGraphGTLPointer()</code> 
     * to get a c++-pointer to graph.
     *
     */
    public GTL_Graph()
    {
	nativeNewJgraph();
    }

    /**
     * Constructs a new GTL_Graph using <code>refGraph</code> as a pointer to an existing C++-GTL graph.
     *
     * <code>ref</code> must point to a valid graph
     * otherwise the constructor will crash of your program.
     *
     * NOTE: After using this constructor you must also call
     *	     <code>protected void setToolRef(int ref)</code>
     *	     where ref is a pointer to a c++-structure that
     *	     extends the c++-class graph_java. As you can see
     *	     the function is declared protected, so you have to
     *	     use a native function or a derived class for calling 
     *	     this function.
     */
    public GTL_Graph(long refGraph)
    {
	// there is nothing to do than to initialize
	nativeNewJgraph(refGraph);
    }

    // **************************************************
    //
    // destructor 
    //
    // **************************************************

    public void finalize()
	throws Throwable
    { 
	nativeRelease(ref, toolRef);
	super.finalize();
    }

    // **************************************************
    //
    // initialization
    //
    // **************************************************

    protected void setToolRef(long ref)
    {
	toolRef = ref;
    }

    // **************************************************
    //
    // Graph interface functions
    //
    // **************************************************

    // Makes graph directed
    synchronized public void makeDirected()
	{ nativeMakeDirected(ref); }

    // Makes graph undirected
    synchronized public void makeUndirected()
	{ nativeMakeUndirected(ref); }

    // Test whether the graph is directed.
    synchronized public boolean isDirected()
	{ return nativeIsDirected(ref); }

    // Test whether the graph is directed.
    synchronized public boolean isUndirected()
	{ return nativeIsUndirected(ref); }

    // Checks whether for all edges exists the reverse
    // edge - the map will contain entries of the
    // form edge e, edge r, where r is - when the 
    // reverse edge exists - the reverse egde
    synchronized public boolean isBidirected(Map rev)
	{ return nativeIsBidirected(ref, toolRef, rev); }

    // Test whether the graph is connected
    synchronized public boolean isConnected()
	{ return nativeIsConnected(ref); }

    // Test whether the graph is acyclic
    synchronized public boolean isAcyclic()
	{ return nativeIsAcyclic(ref); }

    // Returns the number of nodes in the graph
    synchronized public int getNumberOfNodes()
	{ return nativeNumberOfNodes(ref); }

    // Returns the number of edges in the graph
    synchronized public int getNumberOfEdges()
	{ return nativeNumberOfEdges(ref); }

    synchronized public Node getCenter()
	{ return nativeCenter(ref, toolRef); }

    // Adds a new node
    synchronized public Node newNode()
	{ return nativeNewNode(ref, toolRef); }

    // Adds a new edge
    synchronized public Edge newEdge(Node n1, Node n2)
	{ return nativeNewEdge(ref, toolRef, n1.getRef(), n2.getRef()); }

    // deletes node n and all incident edges
    synchronized public void delNode(Node n)
	{ nativeDelNode(ref, toolRef, n.getRef()); }
   
    // deletes all visible nodes - not yet usable
    synchronized public void delAllNodes()
	{ nativeDelAllNodes(ref); }

    // deletes edge e
    synchronized public void delEdge(Edge e)
	{ nativeDelEdge(ref, toolRef, e.getRef()); }
    
    // deletes all visible edges - not yet usable
    synchronized public void delAllEdges()
	{ nativeDelAllEdges(ref); }

    // deletes all nodes and egdes, even the hidden ones
    synchronized public void clear()
	{ nativeClear(ref); }

    synchronized public void hideEdge(Edge e)
	{ nativeHideEdge(ref, toolRef, e.getRef()); }

    synchronized public void restoreEdge(Edge e)
	{ nativeRestoreEdge(ref, toolRef, e.getRef()); }

    synchronized public List hideNode(Node n)
	{ return nativeHideNode(ref, toolRef, n.getRef()); }
    
    synchronized public void restoreNode (Node n)
	{ nativeRestoreNode(ref, toolRef, n.getRef()); }
    
    synchronized public void restoreGraph ()
	{ nativeRestoreGraph(ref); }

    synchronized public void setInducedSubgraph (List subgraphNodes)
    {
	// looks not such efficcient than in c++,
	// but converting a List to a c++-list
	// would cost much more time
	Set nodes = new HashSet();
	Iterator it = subgraphNodes.iterator();
	while (it.hasNext())
	    nodes.add(it.next());

	Set toHide = new HashSet();
	NodeIterator nodeIt = getNodeIterator();
	while (nodeIt.hasNext())
	{
	    Node n = nodeIt.next();
	    if (!nodes.contains(n))
		toHide.add(n);
	}

	Iterator hideIt = toHide.iterator();
	while (hideIt.hasNext())
	{
	    hideNode((Node)(hideIt.next()));
	}
    };

    synchronized public List insertReverseEdges()
	{ return nativeInsertReverseEdges(ref, toolRef); }

    // loads a graph given in the GML-file format
    synchronized public GML_Error load(String filename)
    {
	return nativeLoad(ref, filename);
    }

    // saves a graph in the GML-file format
    synchronized public boolean save(String filename)
    {
	return nativeSave(ref, filename);
    }

    // get Pointer of java_graph
    synchronized public long getGraphJavaPointer()
    {
	return toolRef;
    }

    // get Pointer of GTL - Graph
    synchronized public long getGraphGTLPointer()
    {
	return ref;
    }

    // **************************************************
    //
    // internal Iterator definitions
    //
    // **************************************************

    // Iterators - definitions
    class GraphNodeIterator extends GTL_NodeIterator
    {
	GraphNodeIterator(long toolPointer, long g)
	    { super(toolPointer, g, -1); }

	protected void init()
	    { nativeNodeListIterInit(this.graph); }

	// native functions - iterators
	protected native void nativeNodeListIterInit(long gid);
    };

    class GraphEdgeIterator extends GTL_EdgeIterator
    {
	GraphEdgeIterator(long toolPointer, long g)
	    { super(toolPointer, g, -1); }

	protected void init()
	    { nativeEdgeListIterInit(this.graph); }

	// native functions - iterators
	protected native void nativeEdgeListIterInit(long gid);
    };

    // Iterator - functions
    synchronized public NodeIterator getNodeIterator()
    {
	return new GraphNodeIterator(getGraphJavaPointer(), getGraphGTLPointer());
    }

    synchronized public EdgeIterator getEdgeIterator()
    {
	return new GraphEdgeIterator(getGraphJavaPointer(), getGraphGTLPointer());
    }

    // **************************************************
    //
    // handler
    //
    // **************************************************

    // node - handler
    protected void preNewNodeHandler() {}
    protected void postNewNodeHandler(Node n) {}
    protected void preDelNodeHandler(Node n) {}
    protected void postDelNodeHandler() {}
    protected void preHideNodeHandler(Node n) {}
    protected void postHideNodeHandler(Node n) {}
    protected void preRestoreNodeHandler(Node n) {}
    protected void postRestoreNodeHandler(Node n) {}
    
    // edge - handler
    protected void preNewEdgeHandler(Node s, Node t) {}
    protected void postNewEdgeHandler(Edge e) {}
    protected void preDelEdgeHandler(Edge e) {}
    protected void postDelEdgeHandler(Node n1, Node n2) {}
    protected void preHideEdgeHandler(Edge e) {}
    protected void postHideEdgeHandler(Edge e) {}
    protected void preRestoreEdgeHandler(Edge e) {}
    protected void postRestoreEdgeHandler(Edge e) {}

    // global handlers
    protected void preClearHandler() {}
    protected void postClearHandler() {}
    protected void preMakeDirectedHandler() {}
    protected void postMakeDirectedHandler() {}
    protected void preMakeUndirectedHandler() {}
    protected void postMakeUndirectedHandler() {}

    // **************************************************
    //
    // native functions - graph
    //
    // **************************************************
    
    private native void nativeNewJgraph();
    private native void nativeNewJgraph(long refGraph);
    private native Node nativeCenter(long ref, long toolRef);
    private native Node nativeNewNode(long ref, long toolRef);
    private native Edge nativeNewEdge(long ref, long toolRef, long refNode1, long refNode2);
    private native void nativeMakeUndirected(long ref);
    private native void nativeMakeDirected(long ref);
    private native int nativeNumberOfEdges(long ref);
    private native int nativeNumberOfNodes(long ref); 
    private native boolean nativeIsAcyclic(long ref);
    private native boolean nativeIsConnected(long ref);
    private native boolean nativeIsBidirected(long ref, long toolRef, Map rev);
    private native boolean nativeIsUndirected(long ref);
    private native boolean nativeIsDirected(long ref);
    private native void nativeClear(long ref);
    private native void nativeDelAllEdges(long ref);
    private native void nativeDelEdge(long ref, long toolRef, long refEdge);
    private native void nativeDelAllNodes(long ref);
    private native void nativeDelNode(long ref, long toolRef, long refNode);
    private native void nativeHideEdge(long ref, long toolRef, long refEdge);
    private native void nativeRestoreEdge(long ref, long toolRef, long refEdge);
    private native List nativeHideNode(long ref, long toolRef, long refNode);
    private native void nativeRestoreNode(long ref, long toolRef, long refNode);
    private native void nativeRestoreGraph(long ref);
    private native List nativeInsertReverseEdges(long ref, long toolRef);
    private native void nativeRelease(long ref, long toolRef);
    private native GML_Error nativeLoad(long ref, String filename);
    private native boolean nativeSave(long ref, String filename);

    // **************************************************
    //
    // variables
    //
    // **************************************************

    protected long ref;
    protected long toolRef;

    // **************************************************
    //
    // static initializing
    //
    // **************************************************
    
    static {
	boolean finished = false;
	
	try { 
	    System.loadLibrary("GTL_java");
	    finished = true;
	}
	catch (UnsatisfiedLinkError e) {};
	
	if (!finished)
	{
	    try { 
		System.loadLibrary("GTL_javaD");
	    }
	    catch (UnsatisfiedLinkError e) {};
	}
    }
}
