/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// Graph.java
//
// contains definition of class Graph
//
// ***************************************************************************

package gtl;

import java.util.List;
import java.util.Map;

/**
 * A directed or undirected graph.
 *
 * A graph <var>G=(V,E)</var> consists of a set of nodes
 * <var>V</var> and a set of edges <var>E</var>, where every
 * edge can be viewed as a (ordered) pair of nodes <var>(u,v)</var>
 * connecting source <var>u</var> with target <var>v</var>.
 * Obviously this implies a direction on the edges, which is why we 
 * call these graphs directed (this is the default). A graph can be made 
 * undirected, i.e. the direction will be ignored. 
 *
 * @see Node
 * @see Edge
 */
public abstract class Graph {

    /**
     * Constructor - cannot be invoked
     */
    protected Graph()
    {
    }

    /**
     * Returns a c++-pointer to the graph_java
     *
     * @return c++ pointer to the graph_java
     */
    abstract public long getGraphJavaPointer();

    /**
     * Returns a c++-pointer to the graph
     *
     * @return c++ pointer to the graph
     */
    abstract public long getGraphGTLPointer();
    
    /**
     * Makes graph directed. 
     */
    abstract public void makeDirected();

    /**
     * Makes graph undirected.
     */
    abstract public void makeUndirected();

    /**
     * Test whether the graph is directed.
     *
     * @return true iff the graph is directed
     */
    abstract public boolean isDirected();

    /**
     * Test whether the graph is undirected.
     *
     * @return true iff the graph is undirected
     */
    abstract public boolean isUndirected();

    /**
     * Checks if for all edges <var>(v, w)</var> the reverse edge
     * <var>(w,v)</var> is present, too. Additionally the reverse of some
     * edge <code>e</code> will be stored as <code>rev[e]</code>. If there
     * is no reverse edge of <code>e</code> <code>rev[e]</code> will be the
     * invalid edge <code>edge()</code>.
     * 
     * @param <code>rev</code> map associating every edge with its
     *                         reverse edge.
     *
     * @return true iff every edge has a reverse edge.  */
    abstract public boolean isBidirected(Map rev);

    /**
     * Test whether the graph is connected
     *
     * @return true iff the graph is connected
     */
    abstract public boolean isConnected();

    /**
     * Test whether the graph is acyclic
     *
     * @return true iff the graph contains no cycles
     */
    abstract public boolean isAcyclic();

    /**
     * Returns the number of nodes in the graph.
     *
     * @return number of nodes
     */
    abstract public int getNumberOfNodes();

    /**
     * Returns the number of (visible) edges in the graph
     *
     * @return number of edges
     */
    abstract public int getNumberOfEdges();

    /**
     * Returns a center of the graph which is defined as a node with
     * maximum excentricity.
     *
     * @return one node of the graph center
     */
    abstract public Node getCenter();

    /**
     * Adds a new node.
     *
     * @return new node.  */
    abstract public Node newNode();

    /**
     * Adds new edge from <code>s</code> to
     * <code>t</code>. 
     * 
     * <p>
     * <em>Precondition:</em> <code>s,t</code> are valid nodes in this graph.
     *
     * @param <code>s</code> source of new edge
     * @param <code>t</code> target of new edge 
     * @return new edge. 
     */
    abstract public Edge newEdge(Node n1, Node n2);

    /**
     * deletes node <code>n</code>, and thus all edges incident with
     * <code>n</code>.
     *
     * <p>
     * <em>Precondition:</em> <code>n</code> is a valid node in this graph.
     *
     * @param <code>n</code> node to be deleted 
     */
    abstract public void delNode(Node n);
   
    /**
     * deletes all visible nodes, i.w. the hidden ones stay.
     */
    abstract public void delAllNodes();

    /**
     * deletes edge <code>e</code>.
     *
     * <p>
     * <em>Precondition:</em> <code>e</code> is a valid edge in this graph.
     *
     * @param <code>e</code> edge to be deleted
     */
    abstract public void delEdge(Edge e);
    
    /**
     * deletes all visible edges, i.e. the hidden ones stay.
     */    
    abstract public void delAllEdges();

    /**
     * deletes all nodes and edges, even the hidden ones
     */
    abstract public void clear();

    /**
     * hides an edge
     *
     * <p>
     * <em>Precondition:</em> <code>e</code> is a valid edge in this graph
     *
     * @param <code>e</code> edge to be hidden
     */
    abstract public void hideEdge(Edge e);

    /**
     * restores a hidden edge
     * 
     * <p>
     * <em>Precondition:</em> <code>e</code> is a valid edge in this graph
     *
     * @param <code>e</code> hidden edge 
     */
    abstract public void restoreEdge(Edge e);

    /**
     * hides a node. Please note, that all the edges incident with this
     * node will be hidden, too. All these edges are returned in a list.
     *
     * <p>
     * <em>Precondition:</em> <code>n</code> is a valid node in this graph
     *
     * @param <code>e</code> node to be hidden
     *
     * @return list of incident edges
     */
    abstract public List hideNode(Node n);
    
    /**
     * restores a hidden node. This only restores the node itself. It
     * doesn't restore the incident edges, i.e. you will have to restore
     * all the edges you got back when calling <code>hide_node</code>
     * yourself.  
     * 
     * <p>
     * <em>Precondition:</em> <code>n</code> is a valid node in this graph
     *
     * @param <code>n</code> hidden node
     */
    abstract public void restoreNode (Node n);
    
    /**
     * restores all hidden nodes and edges
     * This means that, although the nodes
     * and edges got hidden at different times, they will be restored all
     * together.
     * 
     * @see Graph#hideEdge
     * @see Graph#hideNode
     */
    abstract public void restoreGraph ();

    /**
     * Hides all nodes <em>not</em> contained in <code>subgraph_nodes</code>, i.e.
     * (the visible part of) the graph is the induced subgraph with
     * respect to the nodes in <code>subgraph_nodes</code>. It is allowed
     * to apply this function recursively, i.e. one may call
     * <code>induced_subgraph</code> on a graph that is already a induced
     * subgraph.
     * 
     * @param <code>subgraphNodes</code> nodes of subgraph.
     * @see Graph#restoreGraph
     */
    abstract public void setInducedSubgraph (List subgraphNodes);

    /**
     * inserts for all edges of the graph a reverse edge
     * 
     * NOTE: this functions does NOT care about existing reverse edges
     *
     * @deprecated
     * @return list of inserted edges
     */
    abstract public List insertReverseEdges();

    /**
     * Iterator for the list of all nodes in the graph, pointing to the
     * beginning of the list.
     *
     * @return NodeIterator through all nodes
     */
    abstract public NodeIterator getNodeIterator();

    /**
     * Iterator for the list of all edges in the graph, pointing to the
     * beginning of the list.
     *
     * @return EdgeIterator through all edges
     */
    abstract public EdgeIterator getEdgeIterator();

    /**
     * Load graph from a file in GML-format.
     *
     * @param <code>filename</code> file in GML-format.
     * @return detailed error description (returns GML_OK iff no error occured while loading)
     */
    abstract public GML_Error load(String filename);

    /**
     * Save graph to file <code>filename</code> in GML-format, i.e.
     * <code>graph [ node [ id # ] ... edge [ source # target #] ... ]</code>
     *
     * @param <code>filename</code> name of GML-file
     * @return false on error true otherwise
     */
    abstract public boolean save(String filename);

    // **************************************************
    //
    // node-handler
    //
    // **************************************************

    /**
     * function called before a new node is created;
     * can be rewritten in a derived class for customization
     *
     * @see Graph#newNode
     */
    protected void preNewNodeHandler() {}

    /**
     * function called after a new node was created;
     * can be rewritten in a derived class for customization
     *
     * @param <code>n</code> created node
     * @see Graph#newNode
     */
    protected void postNewNodeHandler(Node n) {}

    /**
     * function called before a node is deleted;
     * can be rewritten in a derived class for customization
     *
     * @param <code>n</code> node deleted afterwards 
     * @see Graph#delNode 
     */
    protected void preDelNodeHandler(Node n) {}
    
    /**
     * function called after a node was deleted;
     * can be rewritten in a derived class for customization
     *
     * @see Graph#delNode
     */
    protected void postDelNodeHandler() {}

    /**
     * function called before a node gets hidden; 
     * can be rewritten in a derived class for customization
     * 
     * @param <code>n</code> node to be hidden
     * @see Graph#hideNode
     */
    protected void preHideNodeHandler(Node n) {}

    /**
     * function called after a node got hidden;
     * can be rewritten in a derived class for customization
     * 
     * @param <code>n</code> hidden node
     * @see Graph#hideNode
     */
    protected void postHideNodeHandler(Node n) {}

    /**
     * function called before a node is restored;
     * can be rewritten in a derived class for customization
     * 
     * @param <code>n</code> node to be restored
     * @see Graph#restoreNode
     */
    protected void preRestoreNodeHandler(Node n) {}

    /**
     * function called after a node was restored;
     * can be rewritten in a derived class for customization
     * 
     * @param <code>n</code> restored node
     * @see Graph#restoreNode
     */
    protected void postRestoreNodeHandler(Node n) {}
    
    // **************************************************
    //
    // edge - handler
    //
    // **************************************************

    /**
     * function called before a new edge is inserted;
     * can be rewritten in a derived class for customization
     *
     * @param <code>s</code> source of edge created afterwards
     * @param <code>t</code> target of edge created afterwards
     * @see Graph#newEdge
     */
    protected void preNewEdgeHandler(Node s, Node t) {}

    /**
     * function called after a new edge was inserted;
     * can be rewritten in a derived class for customization
     *
     * @param <code>e</code> created edge 
     * @see Graph#newEdge
     */
    protected void postNewEdgeHandler(Edge e) {}

    /**
     * function called before a edge is deleted;
     * can be rewritten in a derived class for customization
     * 
     * @param <code>e</code> edge to be deleted
     * @see Graph#delEdge
     */
    protected void preDelEdgeHandler(Edge e) {}

    /**
     * function called after a edge was deleted;
     * can be rewritten in a derived class for customization
     * 
     * @param <code>s</code> source of edge deleted
     * @param <code>t</code> target of edge deleted
     * @see Graph#delEdge
     */
    protected void postDelEdgeHandler(Node n1, Node n2) {}

    /**
     * function called before a edge gets hidden; 
     * can be rewritten in a derived class for customization
     * 
     * @param <code>e</code> edge to be hidden
     * @see Graph#hideEdge
     */
    protected void preHideEdgeHandler(Edge e) {}

    /**
     * function called after a edge got hidden;
     * can be rewritten in a derived class for customization
     * 
     * @param <code>e</code> hidden edge
     * @see Graph#hideEdge
     */
    protected void postHideEdgeHandler(Edge e) {}

    /**
     * function called before a edge is restored;
     * can be rewritten in a derived class for customization
     * 
     * @param <code>e</code> edge to be restored
     * @see Graph#restoreEdge
     */
    protected void preRestoreEdgeHandler(Edge e) {}

    /**
     * function called after a edge was restored;
     * can be rewritten in a derived class for customization
     * 
     * @param <code>e</code> restored edge
     * @see Graph#restoreEdge
     */
    protected void postRestoreEdgeHandler(Edge e) {}

    // **************************************************
    //
    // global handlers
    //
    // **************************************************

    /**
     * function called before performing clear;
     * can be rewritten in a derived class for customization
     *
     * @see Graph#clear
     */
    protected void preClearHandler() {}
    
    /**
     * function called after the graph was cleared;
     * can be rewritten in a derived class for customization
     *
     * @see Graph#clear
     */ 
    protected void postClearHandler() {}
    
    /**
     * function called before performing makeDirected
     * (only if Graph was undirected)
     * can be rewritten in a derived class for customization
     *
     * @see Graph#makeDirected
     */
    protected void preMakeDirectedHandler() {}

    /**
     * function called after performing makeDirected;
     * (only if graph was undirected)
     * can be rewritten in a derived class for customization
     *
     * @see Graph#makeDirected
     */
    protected void postMakeDirectedHandler() {}
    
    /**
     * function called before performing makeUndirected;
     * (only if graph was directed)
     * can be rewritten in a derived class for customization
     *
     * @see Graph#makeUndirected
     */
    protected void preMakeUndirectedHandler() {}
    
    /**
     * function called after performing makeUndirected;
     * (only if graph was directed)
     * can be rewritten in a derived class for customization
     *
     * @see Graph#makeUndirected
     */
    protected void postMakeUndirectedHandler() {}
}
