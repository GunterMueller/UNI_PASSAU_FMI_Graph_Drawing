/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GTL_Edge.java
//
// contains definition of class GTL_Edge
//
// ***************************************************************************

package gtl;

final class GTL_Edge implements Edge
{
    // **************************************************
    //
    // constructors
    //
    // **************************************************
    public GTL_Edge(long g, long toolPointer)
    { 
	graph = g;
	graphJavaPointer = toolPointer;
    }

    // **************************************************
    //
    // internal functions
    //
    // **************************************************

    /** 
     * function must be native - otherwise a ref
     * to a graph is stored ... that's a problem
     */
    private long getGraphJavaPointer()
    {
	return graphJavaPointer;
    }

    private Graph getGraph()
    {
	return nativeGetGraph(graphJavaPointer);
    }

    // **************************************************
    //
    // public functions
    //
    // **************************************************
    
    public void setSource (Node n)
    { native_edgeSource(graphJavaPointer, ref, n.getRef()); }
    
    public Node getSource()
    { return native_edgeSource(graphJavaPointer, ref); }
    
    public void setTarget (Node n)
    { native_edgeTarget(graphJavaPointer, ref, n.getRef()); }
    
    public Node getTarget()
    { return native_edgeTarget(graphJavaPointer, ref); }
    
    public void reverse()
    { native_edgeReverse(graphJavaPointer, ref); }
    
    public int getId()
    { return native_edgeID(graphJavaPointer, ref); }
    
    public long getRef() 
    { return ref; }
    
    public boolean equals (Object obj)
    {
	if (obj instanceof GTL_Edge)
	{
	    if ((graph == ((GTL_Edge)obj).graph) && (getId() == ((GTL_Edge)obj).getId()))
		return true;
	    else
		return false;
	} 
	else
	    return false;
    }
    
    public int hashCode()
    {
	// best hashcode is internal id, so use that one
	return getId();
    }
    
    public boolean isHidden ()
    {
	return nativeIsHidden(graphJavaPointer, ref);
    }
    
    // native functions
    private native boolean nativeIsHidden(long gid, long ref);
    private native void native_edgeSource(long gid, long ref, long n);
    private native Node native_edgeSource(long gid, long ref);
    private native void native_edgeTarget(long gid, long ref, long n);
    private native Node native_edgeTarget(long gid, long ref);
    private native void native_edgeReverse(long gid, long ref);
    private native int native_edgeID(long gid, long ref);
    private native Graph nativeGetGraph(long gid);
    
    // variables
    private long ref;		    // global reference
    private long graph;		    // global reference
    private long graphJavaPointer;   // global reference
}
