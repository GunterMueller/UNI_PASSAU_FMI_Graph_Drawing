/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// Edge.java
//
// contains interface of class Edge
//
// ***************************************************************************

package gtl;

/**
 * Interface representing an edge in a graph.
 */
public interface Edge
{
    // **************************************************
    //
    // access functions
    //
    // **************************************************

    /**
     * Returns the global reference of the edge. (c++)
     *
     * @return global reference
     */
    public long getRef();

    /**
     * Returns whether <code>obj</code> represents the same edge.
     *
     * @return true iff <code>obj</code> represents the same edge
     */
    public boolean equals (Object obj);

    // **************************************************
    //
    // gtl-interface functions
    //
    // **************************************************

    /**
     * Makes <code>n</code> the source of this edge. Takes O(1) time. 
     * 
     * @param <code>n</code> new source 
     */
    public void setSource (Node n);

    /**
     * Returns the source node of the edge.
     *
     * @return source node
     */
    public Node getSource();

    /**
     * Returns the target node of the edge.
     *
     * @return target node
     */
    public Node getTarget();

    /**
     * Makes <code>n</code> the target of this edge. Takes O(1) time. 
     * 
     * @param <code>n</code> new target 
     */
    void setTarget (Node n);

    /**
     * Changes the direction of this edge.
     */
    public void reverse();

    /**
     * Returns true iff edge is hidden.
     *
     * @return true iff edge is hidden
     */
    public boolean isHidden ();
}
