/* This software is distributed under the GNU Lesser General Public License */
// ************************************************************
//
// class RatioCutPartition
//
// implements the bfs-Algorithm in gtl
//
// ************************************************************

package gtl.algorithms;

import gtl.*;
import java.util.List;
import java.util.Map;


/**
 * Heuristic graph bi-partitioning algorithm (Wei-Cheng).
 *
 * This class implements a heuristic graph bi-partitioning algorithm using
 * the ratio cut method proposed by Y. C. Wei and C. K. Cheng in 1991.
 *
 * <p> In the case E is the set of edges of the graph, the algorithm needs
 * <code>O(|E|)</code> time to proceed.
 *
 * @see FMPartition
 */
public class RatioCutPartition implements GTL_Algorithm
{
    // **************************************************
    //
    // constructors
    // 
    // **************************************************

    /**
     * Default constructor.
     */
    public RatioCutPartition()
    {
	rcPartitionPointer = nativeNew();
	graph = null;
    }

    // **************************************************
    //
    // constants
    // 
    // **************************************************

    /**
     * <code>A</code> means the node is on side A.
     */
    public static final int SIDE_A	= 0;

    /**
     * <code>B</code> means the node is on side B.
     */
    public static final int SIDE_B	= 1;
    
    /**
     * <code>FIXA</code> means fix node on side <code>A</code>.
     */
    public static final int FIX_A	= 0;

    /**
     * <code>FIXB</code> means fix node on side <code>B</code>.
     */
    public static final int FIX_B	= 1;

    /**
     * <code>UNFIXED</code> means node is free.
     */
    public static final int UNFIXED	= 2;

    // **************************************************
    //
    // parameters
    //
    // **************************************************

    /**
     * Sets variables.
     * Must be executed before {@link RatioCutPartition#check}!
     * <code>source_node</code> and <code>target_node</code> will be
     * determined automatically.
     *
     * @param <code>node_weight</code> weight of each node.
     * @param <code>edge_weight</code> weight of each edge.
     * @see RatioCutPartition#check
     */
    public void setVars(Map nodeWeight, Map edgeWeight)
    {
	nativeSetVars(rcPartitionPointer, graph.getGraphGTLPointer(),
	    graph.getGraphJavaPointer(), nodeWeight, edgeWeight);
    }

    /**
     * Sets variables.
     * Must be executed before {@link RatioCutPartition#check}!
     * In order to get good results, you should take two graph
     * theoretically far away nodes as source and target.
     *
     * @param <code>G</code> undirected graph.
     * @param <code>node_weight</code> weight of each node.
     * @param <code>edge_weight</code> weight of each edge..
     * @param <code>source_node</code> start-node, remains on side
     * <code>A</code>.
     * @param <code>target_node</code> end-node, remains on side <code>B
     * </code>.
     * @see RatioCutPartition#check
     */
    public void setVars(Map nodeWeight, Map edgeWeight, Node source, Node target)
    {
	nativeSetVars(rcPartitionPointer, graph.getGraphGTLPointer(),
	    graph.getGraphJavaPointer(), nodeWeight, edgeWeight, 
	    source.getRef(), target.getRef());
    }
    
    /**
     * Sets variables.
     * Must be executed before {@link RatioCutPartition#check}!
     * In order to get good results, you should take two graph
     * theoretically far away nodes as source and target. Additionally
     * <code>init_side</code> should nearly be in balance.
     * <code>source_node</code> must be on side <code>A</code> in <code>
     * init_side</code> and <code>target_node</code> on side <code>B
     * </code> respectively.
     *
     * @param <code>G</code> undirected graph.
     * @param <code>node_weight</code> weight of each node.
     * @param <code>edge_weight</code> weight of each edge..
     * @param <code>source_node</code> start-node, remains on side
     * <code>A</code>.
     * @param <code>target_node</code> end-node, remains on side <code>B
     * </code>.
     * @param <code>init_side</code> initial bi-partitioning.
     * @see RatioCutPartition#check
     */
    public void setVarsSide(Map nodeWeight, Map edgeWeight, Node source, Node target, Map initSide)
    {
	nativeSetVarsSide(rcPartitionPointer, graph.getGraphGTLPointer(),
	    graph.getGraphJavaPointer(), nodeWeight, edgeWeight, 
	    source.getRef(), target.getRef(), initSide);
    }

    /**
     * Sets variables.
     * Must be executed before {@link RatioCutPartition#check}!
     * In order to get good results, you should take two graph
     * theoretically far away nodes as source and target.
     * <code>source_node</code> must not be fixed on side <code>B
     * </code>.
     * <code>target_node</code> must not be fixed on side <code>A
     * </code>.
     *
     * @param <code>G</code> undirected graph.
     * @param <code>node_weight</code> weight of each node.
     * @param <code>edge_weight</code> weight of each edge..
     * @param <code>source_node</code> start-node, remains on side
     * <code>A</code>.
     * @param <code>target_node</code> end-node, remains on side <code>B
     * </code>.
     * @param <code>fixed</code> fixed nodes.
     * @see RatioCutPartition#check
     */
    public void setVarsFixed(Map nodeWeight, Map edgeWeight, Node source, Node target, Map fixed)
    {
	nativeSetVarsFixed(rcPartitionPointer, graph.getGraphGTLPointer(),
	    graph.getGraphJavaPointer(), nodeWeight, edgeWeight, 
	    source.getRef(), target.getRef(), fixed);
    }

    /**
     * Sets variables.
     * Must be executed before {@link RatioCutPartition#check}!
     * In order to get good results, you should take two graph
     * theoretically far away nodes as source and target. Additionally
     * <code>init_side</code> should nearly be in balance. Fixed nodes
     * are on their fix side, their initial side is overwritten then.
     * <code>source_node</code> must be on side A in <code>init_side
     * </code> and <code>target_node</code> on side B respectively.
     * <code>source_node</code> must not be fixed on side <code>B
     * </code>.
     * <code>target_node</code> must not be fixed on side <code>A
     * </code>.
     *
     * @param <code>G</code> undirected graph.
     * @param <code>node_weight</code> weight of each node.
     * @param <code>edge_weight</code> weight of each edge..
     * @param <code>source_node</code> start-node, remains on side
     * <code>A</code>.
     * @param <code>target_node</code> end-node, remains on side <code>B
     * </code>.
     * @param <code>init_side</code> initial bi-partitioning.
     * @param <code>fixed</code> fixed nodes.
     * @see RatioCutPartition#check
     */
    public void setVarsSideFixed(Map nodeWeight, Map edgeWeight, Node source, Node target, 
	Map initSide, Map fixed)
    {
	nativeSetVars(rcPartitionPointer, graph.getGraphGTLPointer(),
	    graph.getGraphJavaPointer(), nodeWeight, edgeWeight, source.getRef(),
	    target.getRef(), initSide, fixed);
    }

    /**
     * Enables the storing of cut-edges. If enabled the list of
     * cut-edges can be traversed using {@link CutEdgesIterator}.
     *
     * @param <code>set</code> if <code>true</code> cut_edges will be
     * stored.
     * @see CutEdgesIterator
     */
    public void setStoreCutEdges(boolean set)
    {
	nativeSetStoreCut(rcPartitionPointer, set);
    }

    /**
     * Enables the storing of nodes on their side. If enabled the nodes
     * of each side can be traversed using {@link SideANodesIterator}
     * or {@link SideBNodesIterator}.
     *
     * @param <code>set</code> if <code>true</code> nodes on their side
     * will be stored.
     * @see SideANodesIterator
     * @see SideBNodesIterator
     */
    public void setStoreNodesAB(boolean set)
    {
	nativeSetStoreNodesAB(rcPartitionPointer, set);
    }

    /**
     * Gets the size of the cut after bi-partitioning.
     *
     * @return cutsize
     */
    public int getCutsize()
    {
	return nativeGetCutSize(rcPartitionPointer);
    }


    /**
     * Gets the ratio of the cut after bi-partitioning as defined in
     * [WeiChe91].
     *
     * @return cutratio
     */
    public int getCutratio()
    {
	return nativeGetCutRatio(rcPartitionPointer);
    }

    /**
     * Gets side of the node after bi-partitioning.
     * 
     * @param <code>n</code> node of graph G.
     * @return <code>RatioCutPartition::A</code> if <code>n</code>
     * lies on side <code>A</code>, <code>RatioCutPartition::B</code>
     * otherwise.
     */
    public int getSideOfNode(Node n)
    {
	return nativeGetSideOfNode(rcPartitionPointer, graph.getGraphJavaPointer(), 
	    n.getRef());
    }

    /**
     * Gets the sum of all node weights from nodes on side <code>A
     * </code>.
     *
     * @param <code>G</code> graph
     * @return <code>node_weight_on_sideA</code>
     */
    public int getWeightOnSideA()
    {
	return nativeGetWeightOnSideA(rcPartitionPointer, graph.getGraphGTLPointer());
    }

    /**
     * Gets the sum of all node weights from nodes on side B.
     *
     * @param <code>G</code> graph
     * @return <code>node_weight_on_sideB</code>
     */
    public int getWeightOnSideB()
    {
	return nativeGetWeightOnSideB(rcPartitionPointer, graph.getGraphGTLPointer());
    }

    /**
     * Iterate through all edges which belong to the cut, that means
     * all edges with end-nodes on different sides.
     * It is only valid if enabled with {@link #setStoreCutEdges} 
     * before.
     *
     * @return start for iteration through all cut edges.
     */
    public EdgeIterator getCutEdgesIterator()
    {
	return new CutEdgesIterator(graph, rcPartitionPointer);
    }

    /**
     * Iterate through all nodes which belong to side <code>A</code>,
     * It is only valid if enabled with {@link #setStoreNodesAB} 
     * before.
     *
     * @return start for iteration through all nodes on <code>A</code>.
     */
    public NodeIterator getNodesOfSideAIterator()
    {
	return new SideANodesIterator(graph, rcPartitionPointer);
    }

    /**
     * Iterate through all nodes which belong to side <code>B</code>,
     * It is only valid if enabled with {@link #setStoreNodesAB} 
     * before.
     *
     * @return start for iteration through all nodes on <code>B</code>.
     */
    public NodeIterator getNodesOfSideBIterator()
    {
	return new SideBNodesIterator(graph, rcPartitionPointer);
    }

    // **************************************************
    //
    // interface functions
    //
    // **************************************************

    public void attach (Graph g)
    {
	graph = g;
    }

    /**
     * Computes a partitioning of <code>G</code>, that means a division
     * of its vertices in two sides <code>RatioCutPartition::A</code>
     * and <code>RatioCutPartition::B</code>.
     * 
     * @param <code>G</code> graph
     * @return <code>{@link GTL_Algorithm#GTL_OK}</code> on success,
     * <code>{@link GTL_Algorithm#GTL_ERROR}</code> otherwise.
     * @see GTL_Algorithm#run
     */
    public int run ()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeRun(graph.getGraphGTLPointer(), rcPartitionPointer);
    }

    /**
     * Checks whether following preconditions are satisfied:
     * <ul>
     * <li> One of the {@link #setVars} procedures has
     * been executed before.
     * <li> graph <code>G</code> is undirected.
     * <li> if applied, <code>source_node</code> and <code>target_node
     * </code> are 2 distinct nodes with node weights > 0.
     * <li> only node_weights >= 0 are applied.
     * <li> only edge_weights >= 0 are applied.
     * <li> if <code>G</code> has more than 2 nodes, then at least
     * two of them have a weight > 0.
     * <li> if applied fixed source node, <code>fixed[source_node]
     * </code> is <code>FIXA</code>.
     * <li> if applied fixed target node, <code>fixed[target_node]
     * </code> is <code>FIXB</code>.
     * </ul>
     * 
     * @param <code>G</code> graph
     * @return <code>{@link GTL_Algorithm#GTL_OK}</code> on success,
     * <code>{@link GTL_Algorithm#GTL_ERROR}</code> otherwise.
     * @see RatioCutPartition#setVars
     * @see RatioCutPartition#setVarsSide
     * @see RatioCutPartition#setVarsFixed
     * @see GTL_Algorithm#check
     */
    public int check()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeCheck(graph.getGraphGTLPointer(), rcPartitionPointer);
    }

    /**
     * Resets GTL_Algorithm object, such that it can  be applied to another graph.
     *
     * @see GTL_Algorithm#reset
     */
    public void reset ()
    {
	if (graph != null)
	    nativeReset(rcPartitionPointer);
    }

    // **************************************************
    //
    // native functions
    //
    // **************************************************

    private native long nativeNew();
    private native void nativeReset(long rcPartitionPointer);
    private native int nativeRun(long graph, long rcPartitionPointer);
    private native int nativeCheck(long graph, long rcPartitionPointer);
    
    private native void nativeSetVars(long rcPartitionPointer, long jgtl,
	long jgraph, Map nodeWeight, Map edgeWeight);
    private native void nativeSetVars(long rcPartitionPointer, long jgtl,
	long jgraph, Map nodeWeight, Map edgeWeight, long jsource, long jtarget);
    private native void nativeSetVarsSide(long rcPartitionPointer, long jgtl,
	long jgraph, Map nodeWeight, Map edgeWeight, long jsource, long jtarget, Map initSide);
    private native void nativeSetVarsFixed(long rcPartitionPointer, long jgtl,
	long jgraph, Map nodeWeight, Map edgeWeight, long jsource, long jtarget, Map fixed);
    private native void nativeSetVars(long rcPartitionPointer, long jgtl,
	long jgraph, Map nodeWeight, Map edgeWeight, long jsource, long jtarget, Map initSide, Map fixed);
    private native void nativeSetStoreCut(long rcPartitionPointer, boolean set);
    private native void nativeSetStoreNodesAB(long rcPartitionPointer, boolean set);
    private native int nativeGetCutSize(long rcPartitionPointer);
    private native int nativeGetCutRatio(long rcPartitionPointer);
    private native int nativeGetNeededPasses(long rcPartitionPointer);
    private native int nativeGetSideOfNode(long rcPartitionPointer, long jgraph, long jnode);
    private native int nativeGetWeightOnSideA(long rcPartitionPointer, long jgtl);
    private native int nativeGetWeightOnSideB(long rcPartitionPointer, long jgtl);

    // **************************************************
    //
    // variables
    //
    // **************************************************

    protected long rcPartitionPointer;
    protected Graph graph;

    // **************************************************
    //
    // internal classes - iterators
    //
    // **************************************************

    /**
     * Iterator type for edges which belong to the cut.
     */
    class CutEdgesIterator extends GTL_EdgeIterator
    {
	CutEdgesIterator(Graph g, long rcPartitionPointer)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), rcPartitionPointer); 
	}

	protected void init()
	{ 
	    nativeInit(ref);
	}

	private native void nativeInit(long rcPartitionPointer);
    }

    /**
     * Iterator through nodes of Side A.
     */
    class SideANodesIterator extends GTL_NodeIterator
    {
	SideANodesIterator(Graph g, long rcPartitionPointer)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), rcPartitionPointer); 
	}

	protected void init()
	{ 
	    nativeInit(ref);
	}

	private native void nativeInit(long rcPartitionPointer);
    }

    /**
     * Iterator through nodes of Side A.
     */
    class SideBNodesIterator extends GTL_NodeIterator
    {
	SideBNodesIterator(Graph g, long rcPartitionPointer)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), rcPartitionPointer); 
	}

	protected void init()
	{ 
	    nativeInit(ref);
	}

	private native void nativeInit(long rcPartitionPointer);
    }
}
