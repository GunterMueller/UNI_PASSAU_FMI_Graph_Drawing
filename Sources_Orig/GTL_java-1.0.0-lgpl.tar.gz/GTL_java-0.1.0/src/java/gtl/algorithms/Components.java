/* This software is distributed under the GNU Lesser General Public License */
// ************************************************************
//
// class Components
//
// implements the dfs-Algorithm in gtl
//
// ************************************************************

package gtl.algorithms;

import gtl.*;
import java.util.List;

/**
 * Connected components.
 */
public class Components extends Dfs
{
    // **************************************************
    //
    // constructors
    // 
    // **************************************************

    /**
     * Default constructor.
     */
    public Components()
    {
	// the correct native new will be called - 
	// overloading !!
    }

    // **************************************************
    //
    // interface functions
    //
    // **************************************************

    /**
     * Necessary preconditions:
     * <ul>
     * <li> <code>G</code> is undirected.
     * <li> scanning of whole graph is enabled.
     * <li> DFS may be applied 
     * </ul>
     * 
     * @param <code>G</code> graph.
     * @return <code>{@link GTL_Algorithm#GTL_OK}</code> if connected components can
     * be computed for <code>G</code>.
     * @see Dfs#setScanWholeGraph
     * @see Dfs#getScanWholeGraph
     */
    public int check()
    {
	return super.check();
    }

    /**
     * Iteration over all Components of the graph.
     * 
     * @see ComponentIterator
     */
    public ComponentIterator getComponentsIterator()
    {
	return new ComponentIterator(graph, dfsPointer);
    }

    // **************************************************
    //
    // access functions
    //
    // **************************************************

    /**
     * Number of components detected during the last run.
     * 
     * @return number of components.
     */
    public int getNumberOfComponents()
    {
	return nativeNumberOfComponents(dfsPointer);
    }

    // **************************************************
    //
    // Handler
    //
    // **************************************************

    public void initHandler() {}
    public void endHandler() {}
    public void entryHandler(Node n, Node f) {}
    public void leaveHandler(Node n, Node f) {}
    public void beforeRecursiveCallHandler(Edge e, Node n) {}
    public void afterRecursiveCallHandler(Edge e, Node n) {}
    public void oldAdjNodeHandler(Edge e, Node n) {}
    public void newStartHandler(Node n) {}

    // **************************************************
    //
    // Iterator
    //
    // **************************************************

    /**
     * Component.
     */
    public class Component
    {
	Component(List n, List e)
	{
	    nodes = n;
	    edges = e;
	}

	/**
	 * Returns nodes of component.
	 *
	 * @return list of nodes of component
	 */
	public List getNodes()
	{
	    return nodes;
	}

	/**
	 * Returns edges of component.
	 *
	 * @return list of edges of component
	 */
	public List getEdges()
	{
	    return edges;
	}

	private List nodes;
	private List edges;
    }

    /**
     * Iterator over all components of the graph.
     */
    public class ComponentIterator
    {
	ComponentIterator(Graph g, long bi)
	{ 
	    graph   = g;
	    ref	    = bi;
	    init();
	}

	/**
	 * Checks whether a next component exists.
	 *
	 * @return true iff a next component exists
	 */
	public boolean hasNext()
	{
	    return nativeComponentIteratorHasNext(refIter, refEnd);
	}

	/**
	 * Returns next component.
	 *
	 * @return next component
	 */
	public Component next()
	{
	    List nodes = nativeComponentIteratorNextNodes(refIter, graph.getGraphJavaPointer());
	    List edges = nativeComponentIteratorNextEdges(refIter, graph.getGraphJavaPointer());
	    nativeComponentIteratorIteratorNext(refIter);
	    return new Component(nodes, edges);
	}

	protected void init()
	{ 
	    nativeIteratorInit(ref);
	}

	// variables
	protected long refBegin;	    // pointer to iterator
	protected long refIter;	    // pointer to iterator
	protected long refEnd;	    // pointer to endIterator
	protected long data;	    // pointer to dataStructure
	protected Graph graph;	    // graphId
	protected long gtl;	    // graphId
	protected long ref;	    // for some iterators we need a reference to a node/edge

	// native functions
	private native void nativeIteratorInit(long bi);
	private native boolean nativeComponentIteratorHasNext(long refIter, long refEnd);
	private native List nativeComponentIteratorNextNodes(long refIter, long tool);
	private native List nativeComponentIteratorNextEdges(long refIter, long tool);
	private native void nativeComponentIteratorIteratorNext(long refIter);
    }

    // **************************************************
    //
    // native functions
    //
    // **************************************************

    protected native long nativeNew();
    protected native void nativeAttach(long dfs, long tool);

    protected native int nativeNumberOfComponents(long biPointer);
}
