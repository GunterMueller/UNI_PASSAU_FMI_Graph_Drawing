/* This software is distributed under the GNU Lesser General Public License */
// ************************************************************
//
// class Biconnectivity
//
// implements the dfs-Algorithm in gtl
//
// ************************************************************

package gtl.algorithms;

import gtl.*;
import java.util.List;

/**
 * Biconnectivity-test and low-numbers.
 *
 * Obviously there is a close relationship between DFS and the testing of
 * biconnectivity. Thus this test takes advantage of the possibility to 
 * add pieces of code to the DFS-class in order to calculate the
 * low-numbers. 
 */
public class Biconnectivity extends Dfs
{
    // **************************************************
    //
    // constructors
    // 
    // **************************************************

    /**
     * Default constructor. Enables only the calculation of DFS-numbers.
     */
    public Biconnectivity()
    {
	// the correct native new will be called !!!
	// cause overloading !!
    }

    // **************************************************
    //
    // interface functions
    //
    // **************************************************

    /**
     * Necessary preconditions:
     * <ul>
     * <li> <code>G</code> is undirected.
     * <li> storing of predecessors is enabled.
     * <li> DFS may be applied 
     * </ul>
     * 
     * @param <code>G</code> graph.
     * @return <code>{@link GTL_Algorithm#GTL_OK}</code> if binconnectivity-test can
     * be applied to <code>G</code>.
     * @see Dfs#setScanWholeGraph
     * @see Dfs#getScanWholeGraph
     * @see Dfs#setStorePreds
     * @see Dfs#getStorePreds
     */
    public int check()
    {
	return super.check();
    }

    /**
     * Iteration over all added edges to make graph biconnected.
     * 
     * @return iterator through additional edges
     * @see #setMakeBiconnected
     * @see #getMakeBiconnected
     * @see AdditionalEdgesIterator
     */
    public EdgeIterator getAdditionalEdgesIterator()
    {
	return new AdditionalEdgesIterator(graph, dfsPointer);
    }

    /**
     * Iteration over all cutpoints found. A cutpoints is a node 
     * whose removal will disconnect the graph, thus a graph with no
     * cutpoints is biconnected and vice versa.
     * 
     * @return iterator through cutpoints.
     * @see CutPointsIterator
     */
    public NodeIterator getCutPointsIterator()
    {
	return new CutPointsIterator(graph, dfsPointer);
    }

    /**
     * Iteration over all Components of the graph.
     * 
     * @see #setStoreComponents
     * @see #getStoreComponents
     * @see ComponentIterator
     */
    public ComponentIterator getComponentsIterator()
    {
	return new ComponentIterator(graph, dfsPointer);
    }

    // **************************************************
    //
    // parameters
    //
    // **************************************************

    /**
     * Enables or disables the storing of biconnected components.
     * If this feature is enabled, the whole graph will be scanned
     * in order to get all the biconnected components even if the graph
     * isn't connected. By default this feature is disabled.
     * 
     * @param <code>set</code> if true each biconnected component will be
     *   stored.
     * @see ComponentIterator
     */
    public void setStoreComponents(boolean set) 
    { 
	nativeSetStoreComponents(dfsPointer, set);
    }

    /**
     * Returns whether the storing of components is enabled.
     * 
     * @return true iff storing of components is enabled.
     * @see ComponentIterator
     */
    public boolean getStoreComponents()
    {
	return nativeGetStoreComponents(dfsPointer);
    }

     /**
     * If enabled edges will be added to the graph in order to make it 
     * biconnected, if cutpoints are discovered. The list of added edges 
     * can be accessed via <code>additional_begin</code> and
     * <code>additional_end</code>.
     *
     * @param <code>set</code> if true additional edges will we inserted
     *    to make the graph biconnected.
     * @see AdditionalEdgesIterator
     */
   public void setMakeBiconnected(boolean set) 
    { 
	nativeSetMakeBiconnected(dfsPointer, set);
    }

    /**
     * Returns whether addition of edges neccessary to make graph
     * biconnected is enabled. 
     * 
     * @return true iff addition edges is enabled.
     * @see AdditionalEdgesIterator
     */
    public boolean getMakeBiconnected()
    {
	return nativeGetMakeBiconnected(dfsPointer);
    }

    // **************************************************
    //
    // access functions
    //
    // **************************************************

    /**
     * Low-number. 
     *
     * @param <code>n</code> node.
     * @return Low-number of <code>n</code>.
     */
    public int getLowNumber(Node n)
    {
	return nativeGetLowNumber(dfsPointer, n.getRef(), graph.getGraphJavaPointer());
    }

    /**
     * Biconnectivity-test. 
     * 
     * @return true iff graph is biconnected.
     */
    public boolean isBiconnected() 
    {
	return nativeIsBiconnected(dfsPointer);
    }

    /**
     * Number von biconnected components detected during the last run.
     * 
     * @return number of biconnected components.
     */
    public int getNumberOfComponents()
    {
	return nativeNumberOfComponents(dfsPointer);
    }

    // **************************************************
    //
    // Iterator
    //
    // **************************************************

    /**
     * Iterator through all nodes who will cut the graph into two parts.
     */
    class CutPointsIterator extends GTL_NodeIterator
    {
	CutPointsIterator(Graph g, long dfs)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), dfs); 
	}

	protected void init()
	{ 
	    nativeIteratorInit(ref);
	}

	private native void nativeIteratorInit(long dfs);
    }

    /**
     * Iterator through all added edges to make graph biconnected.
     */
    class AdditionalEdgesIterator extends GTL_EdgeIterator
    {
	AdditionalEdgesIterator(Graph g, long dfs)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), dfs); 
	}

	protected void init()
	{ 
	    nativeIteratorInit(ref);
	}

	private native void nativeIteratorInit(long dfs);
    }

    /**
     * Component.
     */
    public class Component
    {
	Component(List n, List e)
	{
	    nodes = n;
	    edges = e;
	}

	/**
	 * Returns nodes of component.
	 *
	 * @return list of nodes of component
	 */
	public List getNodes()
	{
	    return nodes;
	}

	/**
	 * Returns edges of component.
	 *
	 * @return list of edges of component
	 */
	public List getEdges()
	{
	    return edges;
	}

	private List nodes;
	private List edges;
    }

    /**
     * Iterator over all components of the graph.
     */
    public class ComponentIterator
    {
	ComponentIterator(Graph g, long bi)
	{ 
	    graph   = g;
	    ref	    = bi;
	    init();
	}

	/**
	 * Checks whether a next component exists.
	 *
	 * @return true iff a next component exists
	 */
	public boolean hasNext()
	{
	    return nativeComponentIteratorHasNext(refIter, refEnd);
	}

	/**
	 * Returns next component.
	 *
	 * @return next component
	 */
	public Component next()
	{
	    List nodes = nativeComponentIteratorNextNodes(refIter, graph.getGraphJavaPointer());
	    List edges = nativeComponentIteratorNextEdges(refIter, graph.getGraphJavaPointer());
	    nativeComponentIteratorIteratorNext(refIter);
	    return new Component(nodes, edges);
	}

	protected void init()
	{ 
	    nativeIteratorInit(ref);
	}

	// variables
	protected long refBegin;	    // pointer to iterator
	protected long refIter;	    // pointer to iterator
	protected long refEnd;	    // pointer to endIterator
	protected long data;	    // pointer to dataStructure
	protected Graph graph;	    // graphId
	protected long gtl;	    // graphId
	protected long ref;	    // for some iterators we need a reference to a node/edge

	// native functions
	private native void nativeIteratorInit(long bi);
	private native boolean nativeComponentIteratorHasNext(long refIter, long refEnd);
	private native List nativeComponentIteratorNextNodes(long refIter, long tool);
	private native List nativeComponentIteratorNextEdges(long refIter, long tool);
	private native void nativeComponentIteratorIteratorNext(long refIter);
    }

    // **************************************************
    //
    // native functions
    //
    // **************************************************

    protected native long nativeNew();

    protected native void nativeSetStoreComponents(long biPointer, boolean set);
    protected native boolean nativeGetStoreComponents(long biPointer);	
    protected native void nativeSetMakeBiconnected(long biPointer, boolean set);
    protected native boolean nativeGetMakeBiconnected(long biPointer);
    protected native int nativeGetLowNumber(long biPointer, long node, long tool);
    protected native boolean nativeIsBiconnected(long biPointer);
    protected native int nativeNumberOfComponents(long biPointer);

    protected native void nativeAttach(long dfs, long tool);
}
