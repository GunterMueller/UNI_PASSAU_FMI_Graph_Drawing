/* This software is distributed under the GNU Lesser General Public License */
// ************************************************************
//
// class Topsort
//
// implements the dfs-Algorithm in gtl
//
// ************************************************************

package gtl.algorithms;

import gtl.*;
import java.util.List;

/**
 * Topological sorting.
 *
 * Assigns to each node <code>n</code> a number <code>top_num</code> such
 * that for every edge <code>(u,v)</code> <code>top_num[u]</code> &lt;
 * <code>top_num[v]</code>, if possible, i.e. iff the directed graph is
 * acyclic.  
 * 
 * <p>
 * Similar to the testing of biconnectivity, which extends DFS to calculate 
 * low-numbers, the topsort-algorithm extends DFS to calculate the new
 * numbering (and thus to test whether such a numbering is possible).
 *
 * <p>
 * In order to traverse all the nodes in the order of its top-numbers, a 
 * new iterator, <code>topsort_iterator</code> is provided.
 */
public class Topsort extends Dfs
{
    // **************************************************
    //
    // constructors
    // 
    // **************************************************

    /**
     * Default constructor. Enables only the calculation of DFS-numbers.
     */
    public Topsort()
    {
	// the correct native new will be called !!!
    }

    // **************************************************
    //
    // interface functions
    //
    // **************************************************

    /**
     * Iterate through nodes in topsort-order. 
     * 
     * @return iterator through nodes in topsort-order
     * @see TopOrderIterator
     */
    public NodeIterator getTopOrderIterator()
    {
	return new TopOrderIterator(graph, dfsPointer);
    }

    // **************************************************
    //
    // access functions
    //
    // **************************************************

    /**
     * Number in topological order.
     * 
     * @param <code>n</code> node.
     * @return number in topological order.
     */
    public int getTopNumber(Node n)
    {
	return nativeGetTopNumber(dfsPointer, n.getRef(), graph.getGraphJavaPointer());
    }

    /**
     * Tests if graph was acyclic.
     * 
     * @return true iff graph was acyclic.
     */
    public boolean isAcyclic()
    {
	return nativeIsAcyclic(dfsPointer);
    }

    // **************************************************
    //
    // Iterator
    //
    // **************************************************

    /**
     * Iterator through nodes in topsort-order. 
     */
    class TopOrderIterator extends GTL_NodeIterator
    {
	TopOrderIterator(Graph g, long dfs)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), dfs); 
	}

	protected void init()
	{ 
	    nativeIteratorInit(ref);
	}

	private native void nativeIteratorInit(long dfs);
    }

    // **************************************************
    //
    // native functions
    //
    // **************************************************

    protected native long nativeNew();

    protected native int nativeGetTopNumber(long topsortPointer, long node, long tool);
    protected native boolean nativeIsAcyclic(long topsortPointer);

    protected native void nativeAttach(long dfs, long tool);
}
