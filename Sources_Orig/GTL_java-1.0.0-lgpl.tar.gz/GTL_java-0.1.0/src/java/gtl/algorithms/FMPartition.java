/* This software is distributed under the GNU Lesser General Public License */
// ************************************************************
//
// class FMPartition
//
// implements the bfs-Algorithm in gtl
//
// ************************************************************

package gtl.algorithms;

import gtl.*;
import java.util.List;
import java.util.Map;

/**
 * Heuristic graph bi-partitioning algorithm (Fiduccia-Mattheyses).
 *
 * This class implements a heuristic graph bi-partitioning algorithm, based
 * on iterative movement, proposed by C. M. Fiduccia and R. M. Mattheyses
 * in 1982.
 *
 * <p> In the case E is the set of edges of the graph, the algorithm needs
 * <code>O(|E|)</code> time to proceed.
 *
 * @see RatioCutPartition
 */
public class FMPartition implements GTL_Algorithm
{
    // **************************************************
    //
    // constructors
    // 
    // **************************************************

    /**
     * Default constructor.
     */
    public FMPartition()
    {
	fmPartitionPointer = nativeNew();
	graph = null;
    }

    // **************************************************
    //
    // constants
    // 
    // **************************************************

    /**
     * <code>A</code> means the node is on side A.
     */
    public static final int SIDE_A	= 0;

    /**
     * <code>B</code> means the node is on side B.
     */
    public static final int SIDE_B	= 1;
    
    /**
     * <code>FIXA</code> means fix node on side <code>A</code>.
     */
    public static final int FIX_A	= 0;

    /**
     * <code>FIXB</code> means fix node on side <code>B</code>.
     */
    public static final int FIX_B	= 1;

    /**
     * <code>UNFIXED</code> means node is free.
     */
    public static final int UNFIXED	= 2;

    // **************************************************
    //
    // parameters
    //
    // **************************************************

    /**
     * Sets variables.
     * Must be executed before {@link FMPartition#check}!
     *
     * @param <code>node_weight</code> weight of each node.
     * @param <code>edge_weight</code> weight of each edge.
     * @see FMPartition#check
     */
    public void setVars(Map nodeWeight, Map edgeWeight)
    {
	nativeSetVars(fmPartitionPointer, graph.getGraphGTLPointer(),
	    graph.getGraphJavaPointer(), nodeWeight, edgeWeight);
    }

    /**
     * Sets variables.
     * Must be executed before {@link FMPartition#check}!
     * In order to get good results, <code>init_side</code> should
     * almost be in balance.
     *
     * @param <code>G</code> undirected graph.
     * @param <code>node_weight</code> weight of each node.
     * @param <code>edge_weight</code> weight of each edge.
     * @param <code>init_side</code> initial bi-partitioning.
     * @see FMPartition#check
     */
    public void setVarsSide(Map nodeWeight, Map edgeWeight, Map initSide)
    {
	nativeSetVarsSide(fmPartitionPointer, graph.getGraphGTLPointer(),
	    graph.getGraphJavaPointer(), nodeWeight, edgeWeight, initSide);
    }

    /**
     * Sets variables.
     * Must be executed before {@link FMPartition#check}!
     *
     * @param <code>G</code> undirected graph.
     * @param <code>node_weight</code> weight of each node.
     * @param <code>edge_weight</code> weight of each edge.
     * @param <code>fixed</code> fixed nodes.
     * @see FMPartition#check
     */
    public void setVarsFixed(Map nodeWeight, Map edgeWeight, Map fixed)
    {
	nativeSetVarsFixed(fmPartitionPointer, graph.getGraphGTLPointer(),
	    graph.getGraphJavaPointer(), nodeWeight, edgeWeight, fixed);
    }

    /**
     * Sets variables.
     * Must be executed before {@link FMPartition#check}!
     * In order to get good results, <code>init_side</code> should
     * almost be in balance. Fixed nodes are on their fix side, their
     * initial side is overwritten then.
     *
     * @param <code>G</code> undirected graph.
     * @param <code>node_weight</code> weight of each node.
     * @param <code>edge_weight</code> weight of each edge.
     * @param <code>init_side</code> initial bi-partitioning.
     * @param <code>fixed</code> fixed nodes.
     * @see FMPartition#check
     */
    public void setVarsSideFixed(Map nodeWeight, Map edgeWeight, Map initSide, Map fixed)
    {
	nativeSetVars(fmPartitionPointer, graph.getGraphGTLPointer(),
	    graph.getGraphJavaPointer(), nodeWeight, edgeWeight, initSide, fixed);
    }

    /**
     * Enables the storing of cut-edges. If enabled the list of
     * cut-edges can be traversed using {@link CutEdgesIterator}.
     *
     * @param <code>set</code> if <code>true</code> cut_edges will be
     * stored.
     * @see CutEdgesIterator
     */
    public void setStoreCutEdges(boolean set)
    {
	nativeSetStoreCut(fmPartitionPointer, set);
    }

    /**
     * Enables the storing of nodes on their side. If enabled the nodes
     * of each side can be traversed using {@link SideANodesIterator} or
     * {@link SideBNodesIterator}.
     * 
     * @param <code>set</code> if <code>true</code> nodes will be stored
     * on their sides.
     * @see SideANodesIterator
     * @see SideBNodesIterator
     */
    public void setStoreNodesAB(boolean set)
    {
	nativeSetStoreNodesAB(fmPartitionPointer, set);
    }

    /**
     * Gets the size of the cut after bi-partitioning.
     *
     * @return cutsize
     */
    public int getCutsize()
    {
	return nativeGetCutSize(fmPartitionPointer);
    }


    /**
     * Gets the number of passes needed to create a bi-partition with
     * this heuristic.
     *
     * @return number of passes
     */
    public int getNeededPasses()
    {
	return nativeGetNeededPasses(fmPartitionPointer);
    }

		
    /**
     * Gets side of the node after bi-partitioning.
     * 
     * @param <code>n</code> node of graph G.
     * @return <code>FMPartition::A</code> if <code>n</code> lies on
     * side <code>A</code>, <code>FMPartition::B</code> otherwise.
     */
    public int getSideOfNode(Node n)
    {
	return nativeGetSideOfNode(fmPartitionPointer, graph.getGraphJavaPointer(), 
	    n.getRef());
    }

    /**
     * Gets the sum of all node weights from nodes on side A.
     *
     * @param <code>G</code> graph
     * @return <code>node_weight_on_sideA</code>
     */
    public int getWeightOnSideA()
    {
	return nativeGetWeightOnSideA(fmPartitionPointer, graph.getGraphGTLPointer());
    }

    /**
     * Gets the sum of all node weights from nodes on side B.
     *
     * @param <code>G</code> graph
     * @return <code>node_weight_on_sideB</code>
     */
    public int getWeightOnSideB()
    {
	return nativeGetWeightOnSideB(fmPartitionPointer, graph.getGraphGTLPointer());
    }

    /**
     * Iterate through all edges which belong to the cut, that means
     * all edges with end-nodes on different sides.
     * It is only valid if enabled with {@link #setStoreCutEdges} 
     * before.
     *
     * @return start for iteration through all cut edges.
     */
    public EdgeIterator getCutEdgesIterator()
    {
	return new CutEdgesIterator(graph, fmPartitionPointer);
    }

    /**
     * Iterate through all nodes which belong to side <code>A</code>.
     * It is only valid if enabled with {@link #setStoreNodesAB} 
     * before.
     *
     * @return start for iteration through all nodes on <code>A</code>.
     */
    public NodeIterator getNodesOfSideAIterator()
    {
	return new SideANodesIterator(graph, fmPartitionPointer);
    }

    /**
     * Iterate through all nodes which belong to side <code>B</code>,
     * It is only valid if enabled with {@link #setStoreNodesAB} before.
     *
     * @return start for iteration through all nodes on <code>B</code>.
     */
    public NodeIterator getNodesOfSideBIterator()
    {
	return new SideBNodesIterator(graph, fmPartitionPointer);
    }

    // **************************************************
    //
    // interface functions
    //
    // **************************************************

    public void attach (Graph g)
    {
	graph = g;
    }

    /**
     * Computes a partitioning with <code>G</code>, that means a
     * division of its vertices in two sides <code>FMPartition::A
     * </code> and <code>FMPartition::B</code>.
     * 
     * @param <code>G</code> graph
     * @return <code>{@link GTL_Algorithm#GTL_OK}</code> on success,
     * <code>{@link GTL_Algorithm#GTL_ERROR}</code> otherwise.
     * @see GTL_Algorithm#run
     */
    public int run ()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeRun(graph.getGraphGTLPointer(), fmPartitionPointer);
    }

    /**
     * Checks whether following preconditions are satisfied:
     * <ul>
     * <li> {@link FMPartition#setVars} has been executed before.
     * <li> graph <code>G</code> is undirected.
     * <li> only node_weights >= 0 are applied.
     * <li> only edge_weights >= 0 are applied.
     * </ul>
     * 
     * @param <code>G</code> graph
     * @return <code>{@link GTL_Algorithm#GTL_OK}</code> on success,
     * <code>{@link GTL_Algorithm#GTL_ERROR}</code> otherwise.
     * @see FMPartition#setVars
     * @see GTL_Algorithm#check
     */
    public int check()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeCheck(graph.getGraphGTLPointer(), fmPartitionPointer);
    }

    /**
     * Resets algorithm object, such that it can  be applied to another graph.
     *
     * @see GTL_Algorithm#reset
     */
    public void reset ()
    {
	if (graph != null)
	    nativeReset(fmPartitionPointer);
    }

    // **************************************************
    //
    // native functions
    //
    // **************************************************

    private native long nativeNew();
    private native void nativeReset(long fmPartitionPointer);
    private native int nativeRun(long graph, long fmPartitionPointer);
    private native int nativeCheck(long graph, long fmPartitionPointer);
    
    private native void nativeSetVars(long fmPartitionPointer, long jgtl,
	long jgraph, Map nodeWeight, Map edgeWeight);
    private native void nativeSetVarsSide(long fmPartitionPointer, long jgtl,
	long jgraph, Map nodeWeight, Map edgeWeight, Map initSide);
    private native void nativeSetVarsFixed(long fmPartitionPointer, long jgtl,
	long jgraph, Map nodeWeight, Map edgeWeight, Map fixed);
    private native void nativeSetVars(long fmPartitionPointer, long jgtl,
	long jgraph, Map nodeWeight, Map edgeWeight, Map initSide, Map fixed);
    private native void nativeSetStoreCut(long fmPartitionPointer, boolean set);
    private native void nativeSetStoreNodesAB(long fmPartitionPointer, boolean set);
    private native int nativeGetCutSize(long fmPartitionPointer);
    private native int nativeGetNeededPasses(long fmPartitionPointer);
    private native int nativeGetSideOfNode(long fmPartitionPointer, long jgraph, long jnode);
    private native int nativeGetWeightOnSideA(long fmPartitionPointer, long jgtl);
    private native int nativeGetWeightOnSideB(long fmPartitionPointer, long jgtl);

    // **************************************************
    //
    // variables
    //
    // **************************************************

    protected long fmPartitionPointer;
    protected Graph graph;

    // **************************************************
    //
    // internal classes - iterators
    //
    // **************************************************

    class CutEdgesIterator extends GTL_EdgeIterator
    {
	CutEdgesIterator(Graph g, long fmPartitionPointer)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), fmPartitionPointer); 
	}

	protected void init()
	{ 
	    nativeInit(ref);
	}

	private native void nativeInit(long fmPartitionPointer);
    }

    class SideANodesIterator extends GTL_NodeIterator
    {
	SideANodesIterator(Graph g, long fmPartitionPointer)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), fmPartitionPointer); 
	}

	protected void init()
	{ 
	    nativeInit(ref);
	}

	private native void nativeInit(long fmPartitionPointer);
    }

    class SideBNodesIterator extends GTL_NodeIterator
    {
	SideBNodesIterator(Graph g, long fmPartitionPointer)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), fmPartitionPointer); 
	}

	protected void init()
	{ 
	    nativeInit(ref);
	}

	private native void nativeInit(long fmPartitionPointer);
    }
}
