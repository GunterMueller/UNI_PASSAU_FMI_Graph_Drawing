/* This software is distributed under the GNU Lesser General Public License */
// ************************************************************
//
// class GTL_Algorithms
//
// base class for all algorithms in GTL_java
//
// ************************************************************

package gtl.algorithms;

import gtl.*;

/**
 * GTL Algorithms
 * 
 * The interface provides the basic features and behaviour of
 * all algorithms in GTL. To use one of the algorithms you must
 * procede like this:
 * <p>
 * This example shows how to use the Dfs-Algorithm:
 * <pre>
 * Dfs dfs = new Dfs();
 * dfs.attach(g);
 * if (dfs.check() == GTL_Algorithm.GTL_OK)
 * {
 *     dfs.run();
 *     NodeIterator it = dfs.getDfsIterator();
 *     while (it.hasNext())
 *     {
 *         Node n = it.next();
 *         ...
 *     }
 * }
 * </pre>
 *
 */ 

public interface GTL_Algorithm
{
    /**
     * error value returned by algorithms in run and check.
     */
    public static final int GTL_OK = 1;

    /**
     * error value returned by algorithms in run and check.
     */
    public static final int GTL_ERROR = 0;

    /**
     * Attaches algorithm to graph <code>g</code>.
     * 
     * @param <code>g</code> Graph
     */
    public void attach (Graph g);

    /**
     * Applies algorithm to attached graph.
     * 
     * @return <code>GTL_OK</code> on success 
     * <code>GTL_ERROR</code>
     * otherwise 
     */
    public int run ();

    /**
     * Checks whether all preconditions are satisfied.
     * 
     * @return <code>GTL_OK</code> on success 
     * <code>GTL_ERROR</code>
     * otherwise 
     */
    public int check();

    /**
     * Resets algorithm, i.e. prepares the algorithm to be applied to
     * another graph. 
     */
    public void reset ();
}
