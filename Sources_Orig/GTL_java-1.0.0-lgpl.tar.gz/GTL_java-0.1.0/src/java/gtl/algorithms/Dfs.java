/* This software is distributed under the GNU Lesser General Public License */
// ************************************************************
//
// class Dfs
//
// implements the dfs-Algorithm in gtl
//
// ************************************************************

package gtl.algorithms;

import gtl.*;

/**
 * DFS-algorithm 
 * 
 * Encapsulates the DFS-Algoritm together with all the data produced by a  
 * run of DFS. 
 * <p>
 * Since there exits so much differnt things which one might want to 
 * calculate during a DFS this class provides basically two different
 * customization features. First it is possible to take influence on 
 * the behaviour of this algortihm by changing some of the
 * following options:
 * 
 * <ul>
 * <li> <code>startNode</code> 
 *      (default: the first node in the list of all nodes)
 * <li> <code>scanWholeGraph</code> states whether BFS will be 
 *      continued in the unused part of the graph, if not all
 *      nodes were touched at the end of BFS started at the start-node.
 *      (default: disabled)
 * <li> <code>calcCompNum</code> toggle storing of completion-numbers 
 *      for each node, i.e. a numbering which reflects the order in which 
 *      nodes were finished. (default: disabled)
 * <li> <code>storePreds</code> toggle storing the predecessor of each
 *      node. (default: disabled)
 * <li> <code>store nonTreeEdges</code> toggle storing of all nonTreeEdges
 *      (treeEdges are always stored) in a list and thus enable or disable
 *      iteration through all nonTreeEdges.
 *      (default: disabled)
 * </ul>
 * 
 * <p>
 * But the trouble with most DFS-algorithm is that one always wants to
 * add a little bit of code somewhere in the algorithm. And then there are
 * only two ways to  get this done. The more efficient one (in terms of
 * runtime) is to implement the DFS once again and add the new code where
 * necessary. The other way (which is more efficient in terms of
 * code-writing) is to take the algorithm as provided and run through the list
 * of nodes it returns (leading to an extra factor of 2)
 *
 * <p>
 * This DFS-algoritm-class provides a new method to add small pieces of
 * code to  the algorithm: Handler. These are virtual functions called at
 * certain important states of the algorithm (e.g. before a new recursive
 * call). So the only thing to do is to derive your extended DFS from this
 * class and to override the handler where needed. In detail there are the
 * following handler supported (which in this base-class are all empty):
 * 
 * <ul>
 * <li> <code>initHandler</code>
 * <li> <code>endHandler</code> 
 * <li> <code>entryHandler</code> 
 * <li> <code>leaveHandler</code>
 * <li> <code>beforeRecursiveCallHandler</code> 
 * <li> <code>afterRecursiveCallHandler</code> 
 * <li> <code>oldAdjNodeHandler</code>
 * <li> <code>newStartHandler</code>
 * </ul>
 *
 * <p>
 * Please note: We do <em>not</em> claim that the set of handler provided 
 * is sufficient in any way. So if you believe that some new handler is 
 * needed please let us know.
 *
 * <p>
 * There is a lot of information stored during DFS (e.g. nodes in
 * dfs-order, list of non-tree edges). Some of it can be obtained directly
 * by using the corresponding member-function (e.g. <code>dfsNum</code>),
 * but all information that can be thought of as a list (e.g. nodes in
 * dfs-order) can be accessed through iterators. In detail these are (of
 * course depending on what options are chosen!): 
 * 
 * <ul>
 * <li> <code>DfsIterator</code>
 * <li> <code>TreeEdgesIterator</code>
 * <li> <code>NonTreeEdgesIterator</code>
 * <li> <code>RootsIterator</code>
 * </ul>
 */

public class Dfs implements GTL_Algorithm
{
    // **************************************************
    //
    // constructors
    // 
    // **************************************************

    /**
     * Default constructor. Enables only the calculation of DFS-numbers.
     */
    public Dfs()
    {
	dfsPointer = nativeNew();
	graph = null;
    }

    // **************************************************
    //
    // interface functions
    //
    // **************************************************

    public void attach (Graph g)
    {
	graph = g;
	nativeAttach(dfsPointer, graph.getGraphJavaPointer());
    }

    public int run ()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeRun(graph.getGraphGTLPointer(), dfsPointer);
    }

    public int check()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeCheck(graph.getGraphGTLPointer(), dfsPointer);
    }

    /**
     * Reset. Please note that options like scanning of whole graph 
     * are <em>not</em> reset, but the chosen start node will be set back. 
     * So if applying this algorithm more than once with the same start 
     * node, it has to be set explicitly before every run.
     *
     * @see GTL_Algorithm#reset
     */
    public void reset ()
    {
	if (graph != null)
	    nativeReset(dfsPointer);
    }

    /**
     * Number of nodes reached in last DFS.
     *
     * @return number of reached nodes.
     * @see #setScanWholeGraph
     * @see #getScanWholeGraph
     */
    public int getNumberOfReachedNodes ()
    {
	return nativeNumberOfReachedNodes(dfsPointer);
    }

    /**
     * Returns iterator through all (reached) nodes in DFS-Order.
     *
     * @return iterator through all nodes in DFS-order.
     */
    public NodeIterator getDfsIterator()
    {
	if (graph != null)
	    return new DfsIterator(graph, dfsPointer);
	else
	    return null;
    }

    /**
     * Returns iterator through all treeEdges (if enabled).
     *
     * @return iterator through all treeEdges (if enabled).
     */
    public TreeEdgesIterator getTreeEdgesIterator()
    {
	if (graph != null)
	    return new TreeEdgesIterator(graph, dfsPointer);
	else
	    return null;
    }

    /**
     * Returns iterator through all nonTreeEdges (if enabled).
     *
     * @return iterator through all nonTreeEdges (if enabled).
     */
    public NonTreeEdgesIterator getNonTreeEdgesIterator()
    {
	if (graph != null)
	    return new NonTreeEdgesIterator(graph, dfsPointer);
	else
	    return null;
    }

    /**
     * Returns iterator through all root nodes of the DFS forest.
     *
     * @return iterator through all root nodes of the DFS forest.
     */
    public RootsIterator getRootsIterator()
    {
	if (graph != null)
	    return new RootsIterator(graph, dfsPointer);
	else
	    return null;
    }

    // **************************************************
    //
    // parameters
    //
    // **************************************************

    /**
     * Sets start-node for DFS. By default an arbitrary node is
     * chosen and stored.
     *
     * @param <code>n</code> start-node.
     */
    public void setStartNode (Node n) 
    { 
	if (graph != null)
	    nativeStartNode(dfsPointer, n.getRef(), graph.getGraphJavaPointer());
    }

    /**
     * Returns start-node for DfS.
     *
     * @return start-node.
     */
    public Node getStartNode ()
    {
	if (graph != null)
	    return nativeStartNode(dfsPointer, graph.getGraphJavaPointer());
	else
	    return null;
    }

    /**
     * Enables or disables scanning of the whole graph. If enabled and the
     * DFS started at the given start-node stops without having touched all 
     * nodes,  it will be continued with the next unused node, and so on
     * until all nodes were used. This makes sure that for every node
     * dfsNumber is defined. On the other hand, if this feature is disabled,
     * one will be able to check what nodes can be reached, when starting a
     * DFS at the start-node, because for those not reached dfs-number will
     * be 0. 
     * 
     * @param <code>set</code> if true enable scanning the whole graph.
     * 
     */
    public void setScanWholeGraph (boolean set)
    {
	nativeScanWholeGraph(dfsPointer, set);
    }

    /**
     * Returns true iff the  whole graph will be scanned.
     * 
     * @return true iff the  whole graph will be scanned.
     */
    public boolean getScanWholeGraph ()
    {
	return nativeScanWholeGraph(dfsPointer);
    }

    /**
     * Enables or Disables the calculation of the completion number.
     *
     * @param <code>set</code> if true completion-numbers will be calculated.
     */
    public void setCalcCompNum (boolean set)
    {
	nativeCalcCompNum(dfsPointer, set);
    }

    /**
     * Returns true iff completion-numbers will be calculated.
     * 
     * @return true iff completion-numbers will be calculated.
     */
    public boolean getCalcCompNum ()
    {
	return nativeCalcCompNum(dfsPointer);
    }

    /**
     * Enables or disables the storing of predecessors. If enabled for
     * every node the predecessor in DFS will be stored.
     *
     * @param <code>set</code> if true predecessors will be stored.
     */
    public void setStorePreds (boolean set)
    {
	nativeStorePreds(dfsPointer, set);
    }

    /**
     * Returns true iff the storing of predecessors is enabled.
     * 
     * @return true iff the storing of predecessors is enabled.
     */
    public boolean getStorePreds ()
    {
	return nativeStorePreds(dfsPointer);
    }
    
    /**
     * Enables the storing of back-edges. If enabled the list of
     * non-tree-edges can 
     * be traversed in the order they occured using
     * <code>nonTreeEdgesIterator</code> 
     *
     * @param <code>set</code> if true nonTreeEdges will be stored.
     */
    public void setStoreNonTreeEdges (boolean set)
    {
	nativeStoreNonTreeEdges(dfsPointer, set);
    }

    /**
     * Returns true iff the storing of non-tree-edges is enabled.
     * 
     * @return true iff the storing of non-tree-edges is enabled.
     */
    public boolean getStoreNonTreeEdges ()
    {
	return nativeStoreNonTreeEdges(dfsPointer);
    }

    // **************************************************
    //
    // access functions
    //
    // **************************************************

    /**
     * Checks whether node <code>n</code> was reached in last DFS.
     *
     * @param <code>n</code> node to be checked.
     * @return true iff <code>n</code> was reached.
     */
    public boolean isReached (Node n) 
    {
	return getDfsNumber(n) != 0;
    }

    /**
     * DFS-Number of <code>n</code>. Please note that DFS-Number 0 means
     * that this node wasn't reached.
     *
     * @param <code>n</code> node.
     * @return DFS-Number of <code>n</code>.
     */
    public int getDfsNumber (Node n)
    {
	return nativeDfsNumber(dfsPointer, n.getRef(), graph.getGraphJavaPointer());
    }

    /**
     * Returns completion-number of node <code>n</code>, if enabled in last
     * run.
     *
     * @param <code>n</code> node.
     * @return Completion-number of <code>n</code>.
     * @see #setCalcCompNum
     * @see #getCalcCompNum
     */
    public int getCompNumber (Node n)
    {
	return nativeCompNumber(dfsPointer, n.getRef(), graph.getGraphJavaPointer());
    }
	
    /**
     * Returns father of node <code>n</code> in DFS-forest. If
     * <code>n</code> is a root  
     * in the forest or wasn't reached the return 
     * value is <code>node()</code>.
     *
     * @param <code>n</code> node.
     * @return Father of <code>n</code>.
     * @see #setStorePreds
     * @see #getStorePreds
     */    
    public Node getFather (Node n)
    {
	return nativeFather(dfsPointer, n.getRef(), graph.getGraphJavaPointer());
    }

    // **************************************************
    //
    // Handler
    //
    // **************************************************

    /**
     * Handler called before the start of DFS.
     */
    public void initHandler() {}
    
    /**
     * Handler called at the end of DFS.
     */
    public void endHandler() {}

    /**
     * Handler called when touching node <code>n</code>.
     *
     * @param <code>n</code> actual node.
     * @param <code>f</code> predecessor.
     */
    public void entryHandler(Node n, Node f) {}
    
    /**
     * Handler called after all the adjacent edges of <code>n</code> have been 
     * examined.
     *
     * @param <code>n</code> actual node.
     * @param <code>f</code> predecessor.
     */
    public void leaveHandler(Node n, Node f) {}

    /**
     * Handler called when a unused node <code>n</code> connected to the
     * actual node by <code>e</code> is found. 
     *
     * @param <code>e</code> edge connecting the actual node to the unused one.
     * @param <code>n</code> unused node.
     */
    public void beforeRecursiveCallHandler(Edge e, Node n) {}

    /**
     * Handler called after the algorithm return from the subtree starting 
     * at <code>n</code> connected to the actual node by <code>e</code>. 
     *
     * @param <code>e</code> edge connecting the actual node to the unused one.
     * @param <code>n</code> unused node.
     */
    public void afterRecursiveCallHandler(Edge e, Node n) {}

    /**
     * Handler called when a already marked node <code>n</code> connected 
     * to the actual node by <code>e</code> is found during the search of all 
     * adjacent edges of the actual node
     *
     * @param <code>e</code> edge connecting the actual node to the old one.
     * @param <code>n</code> used node.
     */
    public void oldAdjNodeHandler(Edge e, Node n) {}

    /**
     * Called when DFS is started with start-node
     * <code>n</code>. This is particularly useful when 
     * DFS was invoked with the <code>scan_whole_graph</code>
     * option.
     *
     * @param <code>n</code> start-node.
     */
    public void newStartHandler(Node n) {}

    // **************************************************
    //
    // Iterator
    //
    // **************************************************

    /**
    * Iterator through all nodes in DFS-Order.
    */
    class DfsIterator extends GTL_NodeIterator
    {
	DfsIterator(Graph g, long dfs)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), dfs); 
	}

	// for compatibility
	DfsIterator(Graph g, long dfs, long data)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), dfs, data); 
	}

	protected void init()
	{ 
	    nativeDfsIteratorInit(ref);
	}

	private native void nativeDfsIteratorInit(long dfs);
    }

    /**
    * Iterator through all tree edges.
    */
    class TreeEdgesIterator extends GTL_EdgeIterator
    {
	TreeEdgesIterator(Graph g, long dfs)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), dfs); 
	}

	protected void init()
	{ 
	    nativeTreeEdgesIteratorInit(ref);
	}

	private native void nativeTreeEdgesIteratorInit(long dfs);
    }

    /**
    * Iterator through all non tree edges.
    */
    class NonTreeEdgesIterator extends GTL_EdgeIterator
    {
	NonTreeEdgesIterator (Graph g, long dfs)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), dfs); 
	}

	protected void init()
	{ 
	    nativeNonTreeEdgesIteratorInit(ref);
	}

	private native void nativeNonTreeEdgesIteratorInit(long dfs);
    }

    /**
     * Iterator through the root in a DFS-forest.
     *
     * @see #setScanWholeGraph
     * @see #getScanWholeGraph
     */
    public class RootsIterator
    {
	RootsIterator(Graph g, long dfs)
	{ 
	    graph   = g;
	    ref	    = dfs;
	    init();
	}

	/**
	 * Checks whether a next DFSIterator exists.
	 *
	 * @return true iff a next DFSIterator exists
	 * @see Dfs#getDfsIterator
	 */
	public boolean hasNext()
	{
	    return nativeRootsIteratorHasNext(refIter, refEnd);
	}

	/**
	 * Returns next DfsIterator.
	 *
	 * @return next DfsIterator
	 * @see Dfs#getDfsIterator
	 */
	public NodeIterator next()
	{
	    long id = nativeRootsIteratorNext(refIter);
	    return new RootsDfsIterator(graph, id, nativeRootsIteratorCopyData(data));
	}

	protected void init()
	{ 
	    data = nativeRootsIteratorInit(ref);
	}

	private native long nativeRootsIteratorInit(long dfs);
	private native boolean nativeRootsIteratorHasNext(long iter, long end);
	private native long nativeRootsIteratorNext(long iter);
	private native long nativeRootsIteratorCopyData(long data);

	// variables
	protected long refBegin;	    // pointer to iterator
	protected long refIter;	    // pointer to iterator
	protected long refEnd;	    // pointer to endIterator
	protected long data;	    // pointer to dataStructure
	protected Graph graph;	    // graphId
	protected long gtl;	    // graphId
	protected long ref;	    // for some iterators we need a reference to a node/edge
    }

    /**
     * Iterator through all nodes in DFS-Order - extended versions for roots-next-function.
     */
    class RootsDfsIterator extends DfsIterator
    {
	RootsDfsIterator(Graph g, long root, long data)
	{ 
	    super(g, root, data);
	}
	
	protected void init()
	{ 
	    nativeRootsDfsIteratorInit(ref, data);
	}
	
	private native void nativeRootsDfsIteratorInit(long root, long data);
    }

    // **************************************************
    //
    // options
    //
    // **************************************************

    // ... will follow

    // **************************************************
    //
    // native functions
    //
    // **************************************************

    protected native long nativeNew();
    protected native void nativeReset(long dfs);
    protected native void nativeAttach(long dfs, long tool);
    protected native int nativeRun(long graph, long dfs);
    protected native int nativeCheck(long graph, long dfs);
    	
    protected native void nativeStartNode(long dfsPointer, long nodeRef, long toolref);
    protected native Node nativeStartNode(long dfsPointer, long toolref);
    protected native void nativeScanWholeGraph(long dfsPointer, boolean set);
    protected native boolean nativeScanWholeGraph(long dfsPointer);
    protected native void nativeCalcCompNum(long dfsPointer, boolean set);
    protected native boolean nativeCalcCompNum(long dfsPointer);
    protected native void nativeStorePreds(long dfsPointer, boolean set);
    protected native boolean nativeStorePreds(long dfsPointer);
    protected native void nativeStoreNonTreeEdges(long dfsPointer, boolean set);
    protected native boolean nativeStoreNonTreeEdges(long dfsPointer);

    protected native int nativeDfsNumber(long dfsPointer, long nodeRef, long toolref);
    protected native int nativeCompNumber(long dfsPointer, long nodeRef, long toolref);
    protected native Node nativeFather(long dfsPointer, long nodeRef, long toolref);

    protected native int nativeNumberOfReachedNodes(long dfsPointer);

    // **************************************************
    //
    // variables
    //
    // **************************************************

    protected long dfsPointer;
    protected Graph graph;
}
