/* This software is distributed under the GNU Lesser General Public License */
// ************************************************************
//
// class STNumber
//
// implements the bfs-Algorithm in gtl
//
// ************************************************************

package gtl.algorithms;

import gtl.*;
import java.util.List;

/**
* ST-number algorithm.
*
* Encapsulates the st-number algorithm together with all the data produced by it. 
* <p>
* Assigns an integer <code>st[n]</code> to each node <code>n</code> of a undirected,
* biconnected graph, such that each node is connected with at least one node having
* a smaller and with at least one having a larger number than itself. The only 
* exception to this rule are the endpoints of edge <code>st</code> connecting nodes 
* <code>s</code> (st-number 1) and <code>t</code> (highest st-number)
* <p>
* The following options are supported:
* 
* <ul>
* <li> {@link STNumber#getSTEdge} sets/retrieves the edge that connects the node 
*      with the lowest number to that with the highest.
* <li> {@link STNumber#getSNode} sets/retrieves that endpoints of the 
*      {@link STNumber#getSTEdge}, which gets number 1.
* </ul>
*
*/
public class STNumber implements GTL_Algorithm
{
    // **************************************************
    //
    // constructors
    // 
    // **************************************************

    /**
     * Default constructor.
     */
    public STNumber()
    {
	stNumberPointer = nativeNew();
	graph = null;
    }

    // **************************************************
    //
    // parameters
    //
    // **************************************************

    /**
     * Sets edge <code>st</code> for the next run. 
     *
     * @param <code>e</code> edge <code>st</code>
     */
    public void setSTEdge (Edge e)
    {
	nativeSetSTEdge(stNumberPointer, graph.getGraphJavaPointer(), e.getRef());
    }

    /**
     * Get edge <code>st</code>.
     *
     * @return edge <code>st</code>.
     */
    public Edge getSTEdge ()
    {
	return nativeGetSTEdge(stNumberPointer, graph.getGraphJavaPointer());
    }

    /**
     * Sets node <code>s</code> for next run. This must be one of the endpoints 
     * of edge <code>st</code>. This node will get st-number 1 and thus the other 
     * endpoint will get the highest st-number.
     *
     * @param <code>n</code> node <code>s</code>
     */
    public void setSNode (Node n) 
    {
	nativeSetSNode(stNumberPointer, graph.getGraphJavaPointer(), n.getRef());
    }

    /**
     * Get node <code>s</code>
     *
     * @return node <code>s</code>
     */
    public Node getSNode ()
    {
	return nativeGetSNode(stNumberPointer, graph.getGraphJavaPointer());
    }
	

    /**
     * Returns st-number of node <code>n</code> as determined in the last run.
     *
     * @param <code>n</code> node
     * @return st-number of <code>n</code>
     */
    public int getSTNumber(Node n)
    {
	return nativeGetSTNumber(stNumberPointer, graph.getGraphJavaPointer(), n.getRef());
    }

    /**
     * Iteration through the nodes of graph st-numbered in last
     * run in st-number order, i.e. from 1 to highest st-number.
     *
     * @return start of iteration through nodes in st-number order 
     */
    public NodeIterator getIterator()
    {
	return new STNumberIterator(graph, stNumberPointer);
    }

    /**
     * Iteration through the nodes of graph st-numbered in last
     * run in reverse st-number order, i.e. from highest st-number down to 1.
     *
     * @return start of iteration through nodes in reverse st-number order 
     */
    public NodeIterator getReverseIterator()
    {
	return new STNumberReverseIterator(graph, stNumberPointer);
    }

    // **************************************************
    //
    // interface functions
    //
    // **************************************************

    public void attach (Graph g)
    {
	graph = g;
    }

    /**
     * Runs st-number algorithm on graph <code>G</code>. It is assumed that 
     * <code>check</code> was called previously and returned <code>{@link GTL_Algorithm#GTL_OK}</code>.
     *
     * @param <code>G</code> graph 
     * @return <code>{@link GTL_Algorithm#GTL_OK}</code> iff <code>G</code> could be correctly st-numbered
     * @see GTL_Algorithm#run
     */
    public int run ()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeRun(graph.getGraphGTLPointer(), stNumberPointer);
    }

    /**
     * Checks whether st-number algorithm can be applied to <code>G</code>. 
     * Besides from the trivial preconditions that edge <code>st</code> and 
     * node <code>s</code> lie in <code>G</code> and <code>s</code> is really
     * an endpoint of <code>st</code> (which isn't checked), <code>G</code>
     * must be undirected and biconnected. Note: As for all algorithms in GTL, 
     * <code>check</code> must be called, because it might do some 
     * initialization.
     *
     * @param <code>G</code> graph
     * @return <code>{@link GTL_Algorithm#GTL_OK}</code> iff st-number algorithm may be applied
     * @see GTL_Algorithm#check
     */
    public int check()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeCheck(graph.getGraphGTLPointer(), stNumberPointer);
    }

    /**
     * Resets algorithm object, such that it can  be applied to another graph.
     *
     * @see GTL_Algorithm#reset
     */
    public void reset ()
    {
	if (graph != null)
	    nativeReset(stNumberPointer);
    }

    // **************************************************
    //
    // native functions
    //
    // **************************************************

    private native long nativeNew();
    private native void nativeReset(long stNumberPointer);
    private native int nativeRun(long graph, long stNumberPointer);
    private native int nativeCheck(long graph, long stNumberPointer);

    private native void nativeSetSTEdge(long stNumber, long jtool, long jedge);
    private native Edge nativeGetSTEdge(long stNumber, long jtool);
    private native void nativeSetSNode(long stNumber, long jtool, long jnode);
    private native Node nativeGetSNode(long stNumber, long jtool);
    private native int nativeGetSTNumber(long stNumber, long jtool, long jnode);

	
    // **************************************************
    //
    // variables
    //
    // **************************************************

    protected long stNumberPointer;
    protected Graph graph;

    // **************************************************
    //
    // internal classes - iterators
    //
    // **************************************************

    /**
    * Iterator through nodes in st-number-order.
    */
    class STNumberIterator extends GTL_NodeIterator
    {
	STNumberIterator(Graph g, long stNumberPointer)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), stNumberPointer); 
	}

	protected void init()
	{ 
	    nativeSTNumberIteratorInit(ref);
	}

	private native void nativeSTNumberIteratorInit(long stNumberPointer);
    }

    /**
    * Iterator through nodes in reverse st-number-order.
    */
    class STNumberReverseIterator extends GTL_NodeIterator
    {
	STNumberReverseIterator(Graph g, long stNumberPointer)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), stNumberPointer); 
	}

	protected void init()
	{ 
	    nativeSTNumberReverseIteratorInit(ref);
	}

	private native void nativeSTNumberReverseIteratorInit(long stNumberPointer);
    }
}
