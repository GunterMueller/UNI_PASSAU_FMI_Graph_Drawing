/* This software is distributed under the GNU Lesser General Public License */
// ************************************************************
//
// class planarity_FF
//
// implements the bfs-Algorithm in gtl
//
// ************************************************************

package gtl.algorithms;

import gtl.*;
import java.util.List;

/**
* Tests if a graph can be drawn on a plane without any edge crossings.
* 
* This class implements the Lempel-Even-Cederbaum planarity test using 
* PQ-trees. In case the graph is planar a planar embedding is obtained, i.e. 
* for each node in the graph an ordered adjacency list is calculated, such 
* that there exists a planar drawing in which all adjacent edges around a node 
* apply to this order.
*
* <p> If the graph is not planar Kuratowski's famous theorem states that it 
* must contain a subgraph hoemeomorphic to either K5 (the complete graph with 
* five nodes) or K3,3 (the complete bipartite graph with three nodes each side).
* In this case the nodes and edges of the tested graph that form either of these 
* two are calculated.
*
* <p> In case the graph is planar and has N nodes the algorithm needs 
* <code>O(N)</code> time for the test (including the planar embedding). In case 
* the graph isn't planar it needs at most <code>O(E)</code> time if E is the 
* number of edges for both the test and the detection of K5 or K3,3. 
*/
public class Planarity implements GTL_Algorithm
{
    // **************************************************
    //
    // constructors
    // 
    // **************************************************

    /**
     * Default constructor.
     */
    public Planarity()
    {
	planarityPointer = nativeNew();
	graph = null;
    }

    // **************************************************
    //
    // parameters
    //
    // **************************************************

    /** 
     * If <code>p</code> is true a planar embedding will be calculated in 
     * the next run. 
     *  
     * @param <code>p</code> true iff embedding should be calculated.
     * @see Planarity#getEmbedding
     * @see PlanarEmbedding
     */
    public void setCalcEmbedding (boolean p)
    {
	nativeSetCalcEmbedding(planarityPointer, p);
    }

    /** 
     * Returns true if a planar embedding will be calculated in 
     * the next run. 
     *  
     * @return true iff embedding will be calculated.
     * @see Planarity#getEmbedding
     * @see PlanarEmbedding
     */
    public boolean getCalcEmbedding ()
    {
	return nativeGetCalcEmbedding(planarityPointer);
    }

   /** 
     * If <code>p</code> is true the obstructions to planarity will be calculated 
     * in the next run. This implies the calculation of an embedding.
     *  
     * @param <code>p</code> true iff obstructions to planarity should be calculated.
     * @see Planarity#getObstructionEdges
     * @see Planarity#getObstructionNodes
     */
    public void setCalcObstruction (boolean p) 
    {
	nativeSetCalcObstruction(planarityPointer,p);
    }

    /** 
     * Returns true if the obstructions to planarity will be calculated 
     * in the next run. 
     *  
     * @return true iff obstructions to planarity will be calculated.
     * @see Planarity#getObstructionEdges
     * @see Planarity#getObstructionNodes
     */
    public boolean getCalcObstruction ()
    {
	return nativeGetCalcObstruction(planarityPointer);
    }

    /**
     * Determines the strategy used to test a graph which is not biconnected
     * If this is enabled the graph will be made biconnected by adding some 
     * new edges. This is usually faster than testing the biconnected components
     * one by one, which is done if this option is disabled. By default this is
     * enabled.
     * <p>
     * Please note that this is not fully tested, i.e. at the moment this feature 
     * should be used only for the test without embedding or kuratowski graphs.
     *
     * @param <code>p</code> true iff graph should be made biconnected.
     * @see Biconnectivity#setMakeBiconnected
     * @see Biconnectivity#getMakeBiconnected
     */ 
    public void setMakeBiconnected (boolean p) 
    {
	nativeSetMakeBiconnected(planarityPointer, p);
    }

    /**
     * Returns strategy for testing graphs, which are not biconnected.
     * 
     * @return true iff graph will be made biconnected before test
     * @see Biconnectivity#setMakeBiconnected
     * @see Biconnectivity#getMakeBiconnected
     */
    public boolean getMakeBiconnected ()
    {
	return nativeGetMakeBiconnected(planarityPointer);
    }

    /**
     * Result of last test.
     *
     * @return true iff graph in last <code>run</code> was planar.
     */
    public boolean isPlanar ()
    {
	return nativeIsPlanar(planarityPointer);
    }
    
    /**
     * If graph in last <code>run</code> was planar a planar embedding is 
     * calculated during the reductions. This function gives access to it. 
     *
     * @return planar embedding of graph in last <code>run</code>.
     * @see Planarity#setCalcEmbedding
     * @see Planarity#getCalcEmbedding
     */

    public PlanarEmbedding getEmbedding () 
    {
	return new PlanarEmbedding(graph, planarityPointer);
    }

    /**
     * Returns the edges of a subgraph homeomorphic to either K3,3 or K5 if 
     * graph in last <code>run</code> was not planar.
     * 
     * @return edges of subgraph homeomorphic to either K3,3 or K5
     * @see Planarity#getObstructionNodes
     * @see Planarity#setCalcObstruction
     * @see Planarity#getCalcObstruction
     */
    public List getObstructionEdges ()
    { 
	return nativeGetObstructionEdges(graph.getGraphJavaPointer(), planarityPointer);
    }


    /**
     * Returns the nodes of a subgraph homeomorphic to either K3,3 or K5 if 
     * graph in last <code>run</code> was not planar.
     *
     * @return nodes of subgraph homeomorphic to either K3,3 or K5
     * @see Planarity#getObstructionEdges
     * @see Planarity#setCalcObstruction
     * @see Planarity#getCalcObstruction
     */
    public List getObstructionNodes ()
    { 
	return nativeGetObstructionNodes(graph.getGraphJavaPointer(), planarityPointer);
    }

    // **************************************************
    //
    // interface functions
    //
    // **************************************************

    public void attach (Graph g)
    {
	graph = g;
    }

    /**
     * Runs planarity test on <code>G</code>. This should return always 
     * <code>GTL_OK</code>. The return value only tracks errors that might 
     * occur, it is definitly <em>not</em> the result of the test itself.
     * The result of the test is stored in a member variable and can be 
     * accessed via {@link Planarity#isPlanar}.
     *
     * @param <code>G</code> arbitrary graph
     * @return <code>GTL_OK</code> if planarity test was sucessfully applied 
     * or <code>GTL_ERROR</code> if not.
     * @see GTL_Algorithm#run
     */
    public int run ()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeRun(graph.getGraphGTLPointer(), planarityPointer);
    }

    /**
     * Checks whether planarity test can be applied to <code>G</code>. This should 
     * return always <code>GTL_OK</code>. There aren't any restrictions on 
     * <code>G</code>, even multiple edges and selfloops are tolerated. <em>Note:</em> 
     * Selfloops and  multiple edges will not be added to the planar embedding.
     * {@link PlanarEmbedding#getSelfloops} and {@link PlanarEmbedding#getMultipleEdges} can 
     * be used to get these. 
     *
     * @param <code>G</code> arbitrary graph
     * @return <code>GTL_OK</code> if planarity test can be applied 
     * or <code>GTL_ERROR</code> if not.
     * @see GTL_Algorithm#check
     */
    public int check()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeCheck(graph.getGraphGTLPointer(), planarityPointer);
    }

    /**
     * Resets algorithm object, such that it can  be applied to another graph.
     *
     * @see GTL_Algorithm#reset
     */
    public void reset ()
    {
	if (graph != null)
	    nativeReset(planarityPointer);
    }

    // **************************************************
    //
    // native functions
    //
    // **************************************************

    private native long nativeNew();
    private native void nativeReset(long planarity);
    private native int nativeRun(long graph, long planarity);
    private native int nativeCheck(long graph, long planarity);

    private native List nativeGetObstructionNodes(long jtool, long planarityPointer);
    private native List nativeGetObstructionEdges(long jtool, long planarityPointer);
    private native boolean nativeIsPlanar(long planarityPointer);
    private native boolean nativeGetMakeBiconnected(long planarityPointer);
    private native void nativeSetMakeBiconnected(long planarityPointer, boolean p);
    private native boolean nativeGetCalcObstruction(long planarityPointer);
    private native void nativeSetCalcObstruction(long planarityPointer, boolean p);
    private native boolean nativeGetCalcEmbedding(long planarityPointer);
    private native void nativeSetCalcEmbedding(long planarityPointer, boolean p);

	
    // **************************************************
    //
    // variables
    //
    // **************************************************

    protected long planarityPointer;
    protected Graph graph;

    // **************************************************
    //
    // internal public class - for the embedding
    //
    // **************************************************

    /**
    * ordered adjacency lists as a result of planarity testing.
    * 
    * It is known that if a graph is planar the adjacency list of every node can be 
    * ordered in such a way that it reflects the order the adjacent edges will have 
    * in a planar drawing around the node. Although the tested graph might have been 
    * directed the planar embedding one gets will always correspond to the underlying 
    * undirected graph, i.e. an edge from <code>n1</code> to <code>n2</code> will 
    * occurr in both adjacency lists. 
    * 
    */
    public class PlanarEmbedding
    {
	public PlanarEmbedding(Graph g, long planarityPointer)
	{
	    embeddingPointer = nativeNew(planarityPointer);
	    graph = g;
	}

	/**
	* Returns ordered adjacency list of node <code>n</code>
	*
	* @param <code>n</code> node
	* @return ordered adjacency list.
	*/
	public List getAdjacency (Node n) 
	{
	    return nativeGetAdjacency(embeddingPointer, graph.getGraphJavaPointer(), n.getRef());
	}
	
	/**
	* Returns the cyclic successor of edge <code>e</code> in the adjacency list
	* of node <code>n</code>.
	*
	* @param <code>n</code> node
	* @param <code>e</code> edge adjacent to <code>n</code>
	* @return edge following <code>e</code> in adjacency of <code>n</code>
	*/
	public Edge getCyclicNext (Node n, Edge e)
	{
	    return nativeGetCyclicNext(embeddingPointer, graph.getGraphJavaPointer(),
		n.getRef(), e.getRef());
	}
	
	/**
	* Returns the cyclic predecessor of edge <code>e</code> in the adjacency list
	* of node <code>n</code>.
	*
	* @param <code>n</code> node
	* @param <code>e</code> edge adjacent to <code>n</code>
	* @return edge preceding <code>e</code> in adjacency of <code>n</code>
	*/
	public Edge getCyclicPrev (Node n, Edge e)
	{
	    return nativeGetCyclicPrev(embeddingPointer, graph.getGraphJavaPointer(),
		n.getRef(), e.getRef());
	}
	
	/**
	* Returns list of selfloops contained in the graph. These will not occur in
	* the adjacency lists.
	*
	* @return list of selfloops.
	*/
	public List getSelfloops ()
	{
	    return nativeGetSelfloops(embeddingPointer, graph.getGraphJavaPointer());
	}
	/**
	* Returns list of multiple edges contained in the graph. These are edges for 
	* which there is already another edge connecting the same endpoints is contained 
	* in the adjacency lists. Please note that the notion "connecting" is meant in an
	* undirected sense. These edges will not occur it the adjacency lists.
	*
	* @return list of multiple edges.
	*/
	public List getMultipleEdges () 
	{
	    return nativeGetMultipleEdges(embeddingPointer, graph.getGraphJavaPointer());
	}

	protected long embeddingPointer;
	protected Graph graph;

	private native long nativeNew(long planarityPointer);
	private native List nativeGetAdjacency(long embeddingPointer, long jtool, long node);
	private native Edge nativeGetCyclicNext(long embeddingPointer, long jtool, long node, long edge);
	private native Edge nativeGetCyclicPrev(long embeddingPointer, long jtool, long node, long edge);
	private native List nativeGetSelfloops(long embeddingPointer, long jtool);
	private native List nativeGetMultipleEdges(long embeddingPointer, long jtool);
    }
}
