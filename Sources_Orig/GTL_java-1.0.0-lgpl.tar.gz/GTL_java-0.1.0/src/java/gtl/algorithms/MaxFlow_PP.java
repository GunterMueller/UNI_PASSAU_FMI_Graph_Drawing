/* This software is distributed under the GNU Lesser General Public License */
// ************************************************************
//
// class MaxFlow_PP
//
// implements the bfs-Algorithm in gtl
//
// ************************************************************

package gtl.algorithms;

import gtl.*;
import java.util.Map;

/**
 * Maximum flow algorithm (Malhotra, Kumar, Maheshwari).
 */
public class MaxFlow_PP implements GTL_Algorithm
{
    // **************************************************
    //
    // constructors
    // 
    // **************************************************

    /**
     * Default constructor.
     */
    public MaxFlow_PP()
    {
	maxflowPointer = nativeNew();
	graph = null;
    }

    // **************************************************
    //
    // parameters
    //
    // **************************************************

    /**
     * Sets capacity of every edge for maximum flow calculation
     * where artificial start-node and end_node will be computed
     * automatically. 
     * NOTE: You must attach a graph first.
     *
     * @param <code>edgeCapacity</code> capacity of every edge - must be a map <Edge, Double>
     */
    public void setVars(Map edgeCapacity)
    {
	nativeSetVars(maxflowPointer, edgeCapacity);
    }

    /**
     * Sets capacity of every edge for maximum flow calculation.
     * NOTE: You must attach a graph first.
     *
     * @param <code>edgeCapacity</code> capacity of every edge  - must be a map <Edge, Double>
     * @param <code>netSource</code> start-node.
     * @param <code>netTarget</code> end-node.
     */
    public void setVars(Map edgeCapacity, Node netSource, Node netTarget)
    {
	nativeSetVars(maxflowPointer, edgeCapacity, 
	    netSource.getRef(), netTarget.getRef());
    }

    // **************************************************
    //
    // access functions
    //
    // **************************************************

    /**
     * Returns the maximum flow of an edge.
     *
     * @param <code>e</code> edge of a graph G
     * @return maximum flow value.
     */
    public double getMaxFlow(Edge e)
    {
	return nativeMaxFlow(maxflowPointer, e.getRef());
    }

    /**
     * Returns the maximum flow of the whole graph G.
     *
     * @return maximum flow value.
     */
    public double getMaxFlow()
    {
	return nativeMaxFlow(maxflowPointer);
    }
	
	
    /**
     * Returns the remaining free capacity of an edge.
     *
     * @param <code>e</code> edge of a graph G
     * @return remaining capacity.
     */
    public double getRemCap(Edge e)
    {
	return nativeRemCap(maxflowPointer, e.getRef());
    }

    // **************************************************
    //
    // interface functions
    //
    // **************************************************

    public void attach (Graph g)
    {
	graph = g;
	nativeAttach(maxflowPointer, graph.getGraphGTLPointer(), 
	    graph.getGraphJavaPointer());
    }

    /**
     * Computes maximum flow of graph <code>G</code>.
     * 
     * @param <code>G</code> graph
     * @return <code>{@link GTL_Algorithm#GTL_OK}</code> on success 
     * <code>{@link GTL_Algorithm#GTL_ERROR}</code>
     * otherwise.
     * @see GTL_Algorithm#run
     */
    public int run ()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeRun(graph.getGraphGTLPointer(), maxflowPointer);
    }

    /**
     * Checks whether following preconditions are satisfied:
     * <ul>
     * <li> {@link MaxFlow_PP#setVars} has been executed before.
     * <li> only edge_capacities >= 0 are applied.
     * <li> <code>G</code> is directed.
     * <li> <code>G</code> is connected.
     * <li> <code>G</code> has at least one edge and two nodes.
     * <li> if not applied, start-nodes and end-nodes exists.
     * <li> if applied, start-node is not the same node as end-node.
     * </ul>
     * 
     * @param <code>G</code> graph
     * @return <code>{@link GTL_Algorithm#GTL_OK}</code> on success 
     * <code>{@link GTL_Algorithm#GTL_ERROR}</code>
     * otherwise.
     * @see GTL_Algorithm#check
     */
    public int check()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeCheck(graph.getGraphGTLPointer(), maxflowPointer);
    }

    /**
     * Resets maximum flow algorithm, i.e. prepares the
     * algorithm to be applied to another graph. 
     *
     * @see GTL_Algorithm#reset
     */
    public void reset ()
    {
	if (graph != null)
	    nativeReset(maxflowPointer);
    }

    // **************************************************
    //
    // native functions
    //
    // **************************************************

    private native long nativeNew();
    private native void nativeReset(long maxflow);
    private native void nativeAttach(long maxflow, long graph, long tool);
    private native int nativeRun(long graph, long maxflow);
    private native int nativeCheck(long graph, long maxflow);

    private native void nativeSetVars(long maxflow, Map edgeCapacity);
    private native void nativeSetVars(long maxflow, Map edgeCapacity, 
	long source, long target);

    private native double nativeMaxFlow(long maxflowPointer);
    private native double nativeMaxFlow(long maxflowPointer, long edge);
    private native double nativeRemCap(long maxflowPointer, long edge);

    // **************************************************
    //
    // variables
    //
    // **************************************************

    protected long maxflowPointer;
    protected Graph graph;
}
