/* This software is distributed under the GNU Lesser General Public License */
package gtl.algorithms;

import java.util.Map;
import java.util.HashMap;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

import gtl.ds.Heap;
import gtl.ds.HeapTree;
import gtl.ds.HashMapDouble;

import gtl.Graph;
import gtl.Node;
import gtl.NodeIterator;
import gtl.Edge;
import gtl.EdgeIterator;
import gtl.algorithms.GTL_Algorithm;


/**
 * Dijkstra encapsulates the Dijkstra-Algoritm together with all the 
 * data produced by a run of Dijkstra. 
 */
public class Dijkstra implements GTL_Algorithm {

    /**
     * Graph, on which the algorithm shall run.
     */
    private Graph g=null;

    /**
     * Source Node, where the shortest path shall start.
     */
    private Node source=null;

    /**
     * Target Node, where the shortest path shall end.
     */
    private Node target=null;

    /**
     * If this value is true, run will compute the shortest path between 
     * source and target.
     * If it is false, run will compute the shortest path to all Nodes.
     */
    private boolean targetOnly=true;

    /**
     * This map stores for every Edge the costs of that Edge.
     */
    private HashMapDouble costMap=null;

    /**
     * This map stores for every Node the distance to the source Node.
     */
    private HashMapDouble distanceMap=null;

    /**
     * This map stores for every Node the predecessor Node,
     * that is the Node which is one Edge nearer to source in the shortest 
     * path.
     * @see #predecessorEdgeMap
     */
    private Map predecessorNodeMap=null;

    /**
     * This map stores for every Node the Edge from the predecessor Node.
     * @see #predecessorNodeMap
     */
    private Map predecessorEdgeMap=null;

    /**
     * A Node is WHITE, if its shortest distance from source is known. 
     */
    private static final int WHITE=1;

    /**
     * A Node is GREY, if its distance from source is known as less
     * than infinity, but the shortest distance is not known yet.
     */
    private static final int GREY=2;   


    /**
     * Attaches algorithm to graph g.
     *
     * @param g Graph
     */
    public void attach(Graph g) {
	this.g=g;
    }
    

    /**
     * Applies algorithm to attached graph.
     *
     * @return GTL_OK on success GTL_ERROR otherwise
     */
    public int run() {

	//initialize distanceMap
	distanceMap=new HashMapDouble();
	NodeIterator nit=g.getNodeIterator();
	while(nit.hasNext()){
	    distanceMap.put(nit.next(), Double.POSITIVE_INFINITY);
	}
	distanceMap.put(source, 0.0);

	//initialize colourMap
	Map colourMap=new HashMap();

	//initialize predecessorMaps
	predecessorNodeMap=new HashMap();
	predecessorEdgeMap=new HashMap();

	//initialize greySet
	Heap greySet=new HeapTree(new Comparator(){
		public int compare(Object o1, Object o2){
		    double d1=distanceMap.get(o1);
		    double d2=distanceMap.get(o2);
		    return d1<d2?-1:(d1==d2?0:1);
		}
		public boolean equals(Object o){
		    return this==o;
		}
	    });

	// begin with algorithm
	greySet.add(source);
	colourMap.put(source, new Integer(GREY));
	Node v=null;
	
	while(!greySet.isEmpty() && (!targetOnly || !target.equals(v))){

	    v=(Node)greySet.deleteMin();
	    colourMap.put(v,new Integer(WHITE));
	    // v is Node with shortest distance to source in the greySet

	    // update greySet:
	    EdgeIterator it=v.getAdjEdgesIterator();
	    
	    // 'for each neighbour w of v ...'
	    while(it.hasNext()){

		Edge edgeVW=it.next();
		Node w=v.getOpposite(edgeVW);
		if(colourMap.get(w)==null){// w is BLACK

		    // make w GREY
		    greySet.add(w);

		    colourMap.put(w, new Integer(GREY));

		    // set distance of w
		    double distV=distanceMap.get(v);
		    double costE=costMap.get(edgeVW);
		    distanceMap.put(w, distV+costE);

		    //set predecessor of w
		    predecessorNodeMap.put(w,v);
		    predecessorEdgeMap.put(w, edgeVW);
		    
		}
		else{
		    if(colourMap.get(w).equals(new Integer(GREY))){//w is GREY
			
			// if d(w)>d(v)+d(v,w)
			double distW=distanceMap.get(w);
			double distV=distanceMap.get(v);
			double costVW=costMap.get(edgeVW);
			if(distW>distV+costVW){
			    
			    //reset distance of w
			    //correct position of w in greySet
			    greySet.remove(w);
			    distanceMap.put(w, distV+costVW);
			    greySet.add(w);
			    
			    // set predecessor of w
			    predecessorNodeMap.put(w,v);
			    predecessorEdgeMap.put(w, edgeVW);

			}
			
		    }
		    //else: w is WHITE: do nothing
		}
	    }
	    
	}
    
	return GTL_OK;
    }
    

    /**
     * Checks whether all preconditions are satisfied.
     *
     * @return GTL_OK on success GTL_ERROR otherwise
     */
    public int check() {
	if(source!=null && costMap!=null && g!=null
	       && (target!=null || !targetOnly))
	    return GTL_OK;
	else
	    return GTL_ERROR;
    }
    

    /**
     * Resets algorithm, i.e. prepares the algorithm to be applied to 
     * another graph.
     */
    public void reset() {
	g=null;
	source=null;
	target=null;
	targetOnly=true;
	costMap=null;
	distanceMap=null;
	predecessorNodeMap=null;
	predecessorEdgeMap=null;
    }


    /**
     * You must use this method before you call run.
     * (check will return GTL_ERROR if you do not.)
     * Using this method you can decide if run shall compute
     * the shortest path to the target Node (true) or to 
     * all Nodes (false).
     *
     * @param set true will let run compute the shortest path to the
     *            target Node. false will make run compute the shortest 
     *            paths to all Nodes.  
     */
    public void setComputeWayToTargetOnly(boolean set){
	targetOnly=set;
    }

    
    /**
     * Sets s to be the source Node of the algorithm.
     *
     * @param s The Node which shall become the source Node of the algorithm.
     */
    public void setSource(Node s){
	source=s;
    }


    /**
     * Sets t to be the target Node of the algorithm.
     * This means, run will compute the shortest path to t.
     *
     * @param t The Node which shall become the target Node of the algorithm.
     */
    public void setTarget(Node t){
	target=t;
    }


    /**
     * Sets m to be the Map which stores for each Edge a cost value.
     *
     * @param m The Map which stores the costs of the edges. 
     */
    public void setCostMap(HashMapDouble m){
	costMap=m;
    }
    

    /**
     * Returns the length of the shortest path between the source Node
     * and the target Node.
     * 
     * @return A double value representing the shortest distance between 
     *         the source Node and the target Node. Double.POSITIVE_INFINITY
     *         if there is no way from source to target.
     * @throws UnsupportedOperationException if no target is set or
     *         run() has not been called.
     * @see #run()
     * @see #setTarget(Node)
     */
    public double getDistance(){
	if(target!=null)
	    return distanceMap.get(target);
	else
	    throw new UnsupportedOperationException("You "+
		      "must set a target and call run() before you"+
		      " may call getDistance()");
	
    }


    /**
     * Returns a Map containing for each Node the distance from the
     * source Node.
     *
     * @return A Map containing for each Node the distance from the
     *         source Node. If a node is not reachable, the distance is
     *         Double.POSITIVE_INFINITY.
     * @throws UnsupportedOperationException if you computed 'wayToTargetOnly'
     *         or run() has not been called yet.
     * @see #run()
     * @see #setComputeWayToTargetOnly(boolean)
     */
    public HashMapDouble getDistanceMap(){
	if(distanceMap!=null)
	    return distanceMap;
	else
	    throw new UnsupportedOperationException("You may not call"+
		      " getDistanceMap() if you set 'computeWayToTargetOnly'"
		      +" or if run() has not been called yet.");
    }


    /**
     * Returns a Map containing for each Node the predecessor Node.
     * This is the Node which is one Edge nearer to the source Node in 
     * the shortest path.
     *
     * @return A Map containing for each node the predecessor node. If a node 
     *         has no predecessor (i.e. it is unreachable from source), this 
     *         map will return null as predecessor for this node.
     * @throws UnsupportedOperationException if run() has not been called yet.
     * @see #getPredecessorEdgeMap()
     * @see #run()
     */
    public Map getPredecessorNodeMap(){
	if(predecessorNodeMap!=null)
	    return predecessorNodeMap;
	else
	    throw new UnsupportedOperationException("You must call run()"
                      +" before the first a call of getPredecessorNodeMap()");
    }


    /**
     * Returns a Map containing for each node the edge from the predecessor 
     * node. This is the node which is one edge nearer to the source node in 
     * the shortest path.
     *
     * @return A Map containing for each node the edge from the predecessor 
     *         Node. If a node has no predecessor edge (i.e. it is 
     *         unreachable from source), this map will return null as 
     *         predecessor for this node.
     * @throws UnsupportedOperationException if run() has not been called yet.
     * @see #getPredecessorNodeMap()
     * @see #run()
     */
    public Map getPredecessorEdgeMap(){
	if(predecessorEdgeMap!=null)
	    return predecessorEdgeMap;
	else
	    throw new UnsupportedOperationException("You must call run()"
                      +" before the first a call of getPredecessorEdgeMap()");
    }


    /**
     * Returns a NodeIterator, whichs iterates through the nodes
     * of the path of the shortest way from source to target. If target is 
     * unreachable, the first call of hasNext() will return false.
     *
     * @return A NodeIterator, whichs iterates through the nodes
     *         of the path of the shortest way from source to target.
     *         If target is unreachable, the first call of hasNext() will 
     *         return false.
     * @throws UnsupportedOperationException if run() has not been called
     *         yet or no target has been set.
     * @see #getPathEdgeIterator()
     * @see #setTarget(Node)
     * @see #run()
     */
    public NodeIterator getPathNodeIterator(){
	if(target!=null && predecessorNodeMap!=null)
	    return (NodeIterator)new PathNodeIterator();
	else
	    throw new UnsupportedOperationException("Target not set or run"
                      +" not called before call of getPathNodeIterator.");
    }


    /**
     * Returns an EdgeIterator, whichs iterates through the edges
     * of the path of the shortest way from source to target. If target is 
     * unreachable, the first call of hasNext() will return false.
     *
     * @return An EdgeIterator, whichs iterates through the edges
     *         of the path of the shortest way from source to target.
     *         If target is unreachable, the first call of hasNext() will 
     *         return false.
     * @throws UnsupportedOperationException if run() has not been called
     *         yet or no target has been set.
     * @see #getPathNodeIterator()
     * @see #setTarget(Node)
     * @see #run()
     */
    public EdgeIterator getPathEdgeIterator(){
	if(target!=null && predecessorEdgeMap!=null)
	    return (EdgeIterator)new PathEdgeIterator();
	else
	    throw new UnsupportedOperationException("Target not set or run"
                      +" not called before call of getPathEdgeIterator.");
    }


    /**
     * A NodeIterator, which iterates through the Nodes of the shortest 
     * path between source and target.
     *
     * @see Dijkstra.PathEdgeIterator
     */
    private class PathNodeIterator implements NodeIterator{

	/**
	 * Stores the position of the Iterator.
	 */
	ListIterator it;

	/**
	 * Initializes the Iterator.
	 */
	public PathNodeIterator(){
	    LinkedList list=new LinkedList();

	    //build list of predecessor-Nodes 
	    Node predecessor=(Node)predecessorNodeMap.get(target);

	    if(predecessor!=null || source==target)
		list.add(target);

	    while(predecessor!=null){
		list.addFirst(predecessor);
		predecessor=(Node)predecessorNodeMap.get(predecessor);
	    }

	    it=list.listIterator(0);
	    
	}

	/**
	 * Tests, if the iteration has more elements.
	 * @return true if a next node exists.
	 */
	public boolean hasNext(){
	    return it.hasNext();
	}

	/**
	 * Checks whether a previous node exists.
	 * @return true if a previous node exists.
	 */
	public boolean hasPrev(){
	    return it.hasPrevious();
	}

	/**
	 * Returns next node.
	 * @return next node.
	 */
	public Node next(){
	    return (Node)it.next();
	    
	}

	/**
	 * Returns previous node.
	 * @return previous node.
	 */
	public Node prev(){
	    return (Node)it.previous();
	}

    }


    /**
     * An EdgeIterator, which iterates through the Edges of the shortest 
     * path between source and target.
     *
     * @see Dijkstra.PathNodeIterator
     */
    private class PathEdgeIterator implements EdgeIterator{

	/**
	 * Stores the position of the Iterator.
	 */
	ListIterator it;

	/**
	 * Initializes the Iterator.
	 */
	public PathEdgeIterator(){
	    LinkedList list=new LinkedList();
	    
	    //build list of predecessor-Nodes 
	    Node currentNode=target;
	    Node predecessorNode=(Node)predecessorNodeMap.get(currentNode);
	    while(predecessorNode!=null){
		list.addFirst((Edge)predecessorEdgeMap.get(currentNode));
		currentNode=predecessorNode;
		predecessorNode=(Node)predecessorNodeMap.get(currentNode);
	    }

	    it=list.listIterator();
	    
	}

	/**
	 * Tests, if the iteration has more elements.
	 * @return true if a next edge exists.
	 */
	public boolean hasNext(){
	    return it.hasNext();
	}

	/**
	 * Checks whether a previous edge exists.
	 * @return true if a previous edge exists.
	 */
	public boolean hasPrev(){
	    return it.hasPrevious();
	}

	/**
	 * Returns next edge.
	 * @return next edge.
	 */
	public Edge next(){
	    return (Edge)it.next();
	    
	}

	/**
	 * Returns previous edge.
	 * @return previous edge.
	 */
	public Edge prev(){
	    return (Edge)it.previous();
	}

    }


}

 
