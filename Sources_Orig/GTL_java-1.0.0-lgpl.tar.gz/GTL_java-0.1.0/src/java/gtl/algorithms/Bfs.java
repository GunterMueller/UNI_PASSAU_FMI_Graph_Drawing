/* This software is distributed under the GNU Lesser General Public License */
// ************************************************************
//
// class Bfs
//
// implements the bfs-Algorithm in gtl
//
// ************************************************************

package gtl.algorithms;

import gtl.*;

/**
 * BFS-algorithm 
 *
 * Encapsulates the BFS-algorithm together with all data produced
 * by it. There are a few parameters, which on the one hand
 * influence the behaviour of BFS (e.g. start-node) and on the other
 * hand toggle the storing of extra information, such as the
 * level-number of each node. In detail these are:
 * 
 * <ul>
 * <li> <code>startNode </code>
 *      (default: an arbitrary node will be chosen)
 * <li> <code>scanWholeGraph </code>states whether BFS will be 
 *      continued in the unused part of the graph, if not all
 *      nodes were touched at the end of BFS started at the start-node.
 *      (default: disabled)
 * <li> <code>calcLevel </code>toggle storing of level-numbers for each
 *      node, i.e. its distance from the start-node.
 *      (default: disabled)
 * <li> <code>storePreds </code>toggle storing the predecessor of each
 *      node, i.e. the father in the BFS-tree. (default: disabled)
 * <li> <code>storeNonTreeEdges </code>toggle storing of all nonTreeEdges
 *      (treeEdges are always stored) in a list and thus enable or disable
 *      iteration through all nonTreeEdges.
 *      (default: disabled)
 * </ul>
 *
 * <p>
 * Please note that the algorithm always starts with the given
 * start-node (if none was given, the first node is chosen and 
 * stored, thus after BFS the root of the tree is always
 * accesible via <code>startNode</code>) and continues until no more
 * unused nodes are reachable from already used ones. 
 * Thus if the graph isn't connected not all nodes will be reached. If
 * <code>scanWholeGraph </code>isn't set the BFS stops here. 
 * If it is set, the BFS will be continued with the next unused
 * node and so on until all nodes were used.
 *
 * <p>
 * For further customization a few virtual functions, so called handler,
 * are called at crucial stages of the algorithm. In this basic
 * implementation all of these handler are empty. So if one wants 
 * to add only a few lines of code (e.g. some new numbering) he is likely
 * to take this class as base-class and override the handler 
 * where neccessary. In detail these are (please look at the
 * source code to see where they are called):
 *
 * <ul>
 * <li> <code>initHandler</code>
 * <li> <code>endHandler</code>
 * <li> <code>poppedNodeHandler</code> 
 * <li> <code>finishedNodeHandler</code> 
 * <li> <code>unusedNodeHandler</code>
 * <li> <code>usedNodeHandler</code>
 * <li> <code>newStartHandler</code> 
 * </ul>
 *
 * <p>
 * <em>Please note:</em> We do <em>not</em> claim that the set of 
 * handler provided is sufficient in any way. So if you believe
 * that some new handler is needed urgently please let us know.
 *
 * <p>
 * There is a lot of information stored during BFS (e.g. nodes in
 * bfs-order, list of non-tree edges). Some of it can be obtained directly
 * by using the corresponding member-function (e.g. <code>bfsNum</code>),
 * but all information that can be thought of as a list (e.g. nodes in
 * bfs-order) can be accessed through iterators. In detail these are (of
 * course depending on what options are chosen!): 
 * 
 * <ul>
 * <li> <code>DfsIterator</code>
 * <li> <code>TreeEdgesIterator</code>
 * <li> <code>NonTreeEdgesIterator</code>
 * <li> <code>RootsIterator</code>
 * </ul>
 */

public class Bfs implements GTL_Algorithm
{
    // **************************************************
    //
    // constructors
    // 
    // **************************************************

    /**
     * Default constructor. Enables only the calculation of BFS-numbers.
     */
    public Bfs()
    {
	bfsPointer = nativeNew();
	graph = null;
    }

    // **************************************************
    //
    // interface functions
    //
    // **************************************************

    /**
     * Attaches algorithm to graph <code>g</code>.
     * 
     * @param <code>g</code> Graph
     */
    public void attach (Graph g)
    {
	graph = g;
	nativeAttach(bfsPointer, graph.getGraphJavaPointer());
    }

    /**
     * Applies algorithm to attached graph.
     * 
     * @return <code>GTL_OK</code> on success 
     * <code>GTL_ERROR</code>
     * otherwise 
     */
    public int run ()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeRun(graph.getGraphGTLPointer(), bfsPointer);
    }

    /**
     * Checks whether all preconditions are satisfied.
     * 
     * @return <code>GTL_OK</code> on success 
     * <code>GTL_ERROR</code>
     * otherwise 
     */
    public int check()
    {
	if (graph == null)
	    return GTL_ERROR;
	else
	    return nativeCheck(graph.getGraphGTLPointer(), bfsPointer);
    }

    /**
     * Resets algorithm, i.e. prepares the algorithm to be applied to
     * another graph. 
     */
    public void reset ()
    {
	if (graph != null)
	    nativeReset(bfsPointer);
    }

    /**
     * Number of nodes reached in last BFS.
     *
     * @return number of reached nodes.
     * @see #setScanWholeGraph
     */
    public int getNumberOfReachedNodes ()
    {
	return nativeNumberOfReachedNodes(bfsPointer);
    }

    /**
     * Returns iterator through all (reached) nodes in BFS-Order.
     *
     * @return iterator through all nodes in BFS-order.
     */
    public BfsIterator getBfsIterator()
    {
	if (graph != null)
	    return new BfsIterator(graph, bfsPointer);
	else
	    return null;
    }

    /**
     * Returns iterator through all treeEdges (if enabled).
     *
     * @return iterator through all treeEdges (if enabled).
     */
    public TreeEdgesIterator getTreeEdgesIterator()
    {
	if (graph != null)
	    return new TreeEdgesIterator(graph, bfsPointer);
	else
	    return null;
    }

    /**
     * Returns iterator through all nonTreeEdges (if enabled).
     *
     * @return iterator through all nonTreeEdges (if enabled).
     */
    public NonTreeEdgesIterator getNonTreeEdgesIterator()
    {
	if (graph != null)
	    return new NonTreeEdgesIterator(graph, bfsPointer);
	else
	    return null;
    }

    /**
     * Returns iterator through all root nodes of the BFS forest.
     *
     * @return iterator through all root nodes of the BFS forest.
     */
    public RootsIterator getRootsIterator()
    {
	if (graph != null)
	    return new RootsIterator(graph, bfsPointer);
	else
	    return null;
    }

    // **************************************************
    //
    // parameters
    //
    // **************************************************

    /**
     * Sets start-node for BFS. The default start-node is the invalid node
     * <code>node()</code>, in this case an arbitrary node is chosen and 
     * stored when BFS is run.
     *
     * @param <code>n</code> start-node.
     */
    public void setStartNode (Node n) 
    { 
	if (graph != null)
	    nativeStartNode(bfsPointer, n.getRef(), graph.getGraphJavaPointer());
    }

    /**
     * Returns actual start-node for BFS.
     *
     * @return start-node.
     */
    public Node getStartNode ()
    {
	if (graph != null)
	    return nativeStartNode(bfsPointer, graph.getGraphJavaPointer());
	else
	    return null;
    }

    /**
     * Enables or disables scanning of the whole graph. 
     * If enabled and the BFS
     * started at the given start-node stops without having touched all nodes,
     * it will be continued with the next unused node, and so on until all 
     * nodes  were used. This makes sure that for every node bfsNumber is
     * defined. 
     *
     * <p>
     * On the other hand, if this feature is disabled, one will be able to
     * check what nodes can be reached, when starting a BFS at the
     * start-node, because  for those not reached bfs-number will be 0.
     *
     * @param <code>set</code> if true enable scanning the whole graph.
     * @see RootsIterator
     */
    public void setScanWholeGraph (boolean set)
    {
	nativeScanWholeGraph(bfsPointer, set);
    }

    /**
     * Returns true iff the  whole graph will be scanned.
     * 
     * @return true iff the  whole graph will be scanned.
     * @see RootsIterator
     */
    public boolean getScanWholeGraph ()
    {
	return nativeScanWholeGraph(bfsPointer);
    }

    /**
     * Enables or disables the calculation of level-numbers for each 
     * node. If enabled each node gets a level-number meaning its distance 
     * from the start-node.
     *
     * @param <code>set</code> if true level-number will be calculated.
     */
    public void setCalcLevel (boolean set)
    {
	nativeSetCalcLevel(bfsPointer, set);
    }
    
    /**
     * Returns true iff level-numbers will be calculated.
     * 
     * @return true iff level-numbers will be calculated.
     */
    public boolean getCalcLevel () 
    {
	return nativeGetCalcLevel(bfsPointer);
    }

    /**
     * Enables the storing of non-tree-edges. If enabled the list of
     * non-tree-edges can be traversed in the order they occured using
     * <code>backEdgesIterator</code> 
     *
     * @param <code>set</code> if true backEdges will be stored.
     * @see NonTreeEdgesIterator
     */
    public void setStoreNonTreeEdges (boolean set)
    {
	nativeStoreNonTreeEdges(bfsPointer, set);
    }

    /**
     * Returns true iff the storing of non-tree-edges is enabled.
     * 
     * @return true iff the storing of non-tree-edges is enabled.
     * @see NonTreeEdgesIterator
     */
    public boolean getStoreNonTreeEdges ()
    {
	return nativeStoreNonTreeEdges(bfsPointer);
    }

    /**
     * Enables or disables the storing of predecessors. If enabled for
     * every node the predecessor in BFS will be stored.
     *
     * @param <code>set</code> if true predecessors will be stored.
     * @see #getFather
     */
    public void setStorePreds (boolean set)
    {
	nativeStorePreds(bfsPointer, set);
    }

    /**
     * Returns true iff the storing of predecessors is enabled.
     * 
     * @return true iff the storing of predecessors is enabled.
     * @see #getFather
     */
    public boolean getStorePreds ()
    {
	return nativeStorePreds(bfsPointer);
    }

    // **************************************************
    //
    // access functions
    //
    // **************************************************

    /**
     * Checks whether node <code>n</code> was reached in last BFS.
     *
     * @param <code>n</code> node to be checked.
     * @return true iff <code>n</code> was reached.
     */
    public boolean isReached (Node n) 
    {
	return getBfsNumber(n) != 0;
    }

    /**
     * BFS-Number of <code>n</code>. Please note that BFS-Number 0 means
     * that this node wasn't reached.
     *
     * @param <code>n</code> node.
     * @return BFS-Number of <code>n</code>.
     */
    public int getBfsNumber (Node n)
    {
	return nativeBfsNumber(bfsPointer, n.getRef(), graph.getGraphJavaPointer());
    }

    /**
     * Returns completion-number of node <code>n</code>, if enabled in last
     * run.
     *
     * @param <code>n</code> node.
     * @return Completion-number of <code>n</code>.
     * @see #setCalcLevel
     * @see #getCalcLevel
     */
    public int getLevel (Node n)
    {
	return nativeLevel(bfsPointer, n.getRef(), graph.getGraphJavaPointer());
    }
	
    /**
     * Returns father of node <code>n</code> in BFS-forest. If
     * <code>n</code> is a root  
     * in the forest or wasn't reached the return 
     * value is <code>node()</code>.
     *
     * @param <code>n</code> node.
     * @return Father of <code>n</code>.
     * @see #setStorePreds
     * @see #getStorePreds
     */    
    public Node getFather (Node n)
    {
	return nativeFather(bfsPointer, n.getRef(), graph.getGraphJavaPointer());
    }

    // **************************************************
    //
    // Handler
    //
    // **************************************************

    /**
     * Called at the start of BFS. 
     *
     * @param <code>G</code> graph for which BFS was invoked.
     */
    public void initHandler () { };

    /**
     * Called right before the end of BFS.
     *
     * @param <code>G</code> graph for which BFS was invoked.
     */
    public void endHandler () { };

    /**
     * Called after a node was taken out of the queue.
     * 
     * @param <code>n</code> node taken out of the queue.
     */
    public void poppedNodeHandler (Node n) { };

    /**
     * Called when finished with the actual node, i.e. after 
     * looking at all its neighbours.
     *
     * @param <code>n</code> node taken out of the queue.
     */
    public void finishedNodeHandler (Node n) { };

    /**
     * Called when an unused node was found. 
     * 
     * @param <code>n</code> unused node.
     * @param <code>f</code> actual node.
     */
    public void unusedNodeHandler (Node n, Node f) { };

    /**
     * Called when an used node was found. 
     * 
     * @param <code>n</code> used node.
     * @param <code>f</code> actual node.
     */
    public void usedNodeHandler (Node n, Node f) { };

    /**
     * Called when BFS is started with start-node
     * <code>n</code>. This is particularly useful when 
     * BFS was invoked with the <code>scanWholeGraph</code>
     * option.
     *
     * @param <code>n</code> start-node.
     */
    public void newStartHandler (Node n) { };

    // **************************************************
    //
    // Iterator
    //
    // **************************************************

    /**
     * Iterator through all (reached) nodes in BFS-Order.
     *
     * @see Bfs#getBfsIterator
     */
    public class BfsIterator extends GTL_NodeIterator
    {
	BfsIterator(Graph g, long bfs)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), bfs); 
	}

	// for compatibility
	BfsIterator(Graph g, long bfs, long data)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), bfs, data); 
	}

	protected void init()
	{ 
	    nativeBfsIteratorInit(ref);
	}

	private native void nativeBfsIteratorInit(long bfs);
    }

    /**
     * Iterator through all tree edges (if enabled).
     *
     * @see Bfs#getTreeEdgesIterator
     */
    public class TreeEdgesIterator extends GTL_EdgeIterator
    {
	TreeEdgesIterator(Graph g, long bfs)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), bfs); 
	}

	protected void init()
	{ 
	    nativeTreeEdgesIteratorInit(ref);
	}

	private native void nativeTreeEdgesIteratorInit(long bfs);
    }

    /**
     * Iterator through all non tree edges (if enabled).
     *
     * @see Bfs#getNonTreeEdgesIterator
     */
    public class NonTreeEdgesIterator extends GTL_EdgeIterator
    {
	NonTreeEdgesIterator (Graph g, long bfs)
	{ 
	    super(g.getGraphJavaPointer(), g.getGraphGTLPointer(), bfs); 
	}

	protected void init()
	{ 
	    nativeNonTreeEdgesIteratorInit(ref);
	}

	private native void nativeNonTreeEdgesIteratorInit(long bfs);
    }

    /**
     * Iterator through Iterators which represent a component.
     * Each iterator will run through the component in dfs-order.
     *
     * @see Bfs#setScanWholeGraph
     */
    public class RootsIterator
    {
	RootsIterator(Graph g, long bfs)
	{ 
	    graph   = g;
	    ref	    = bfs;
	    init();
	}

	public boolean hasNext()
	{
	    return nativeRootsIteratorHasNext(refIter, refEnd);
	}

	public BfsIterator next()
	{
	    long id = nativeRootsIteratorNext(refIter);
	    return new RootsBfsIterator(graph, id, nativeRootsIteratorCopyData(data));
	}

	protected void init()
	{ 
	    data = nativeRootsIteratorInit(ref);
	}

	private native long nativeRootsIteratorInit(long bfs);
	private native boolean nativeRootsIteratorHasNext(long iter, long end);
	private native long nativeRootsIteratorNext(long iter);
	private native long nativeRootsIteratorCopyData(long data);

	// variables
	protected long refBegin;	    // pointer to beginIterator
	protected long refIter;	    // pointer to iterator
	protected long refEnd;	    // pointer to endIterator
	protected long data;	    // pointer to bfsData
	protected Graph graph;	    // graphId
	protected long gtl;	    // graphId
	protected long ref;	    // for some iterators we need a reference to a node/edge
    }

    /**
     * Internal Iterator for result of Roots-Iterator function next.
     */
    class RootsBfsIterator extends BfsIterator
    {
	RootsBfsIterator(Graph g, long bfs, long data)
	{ 
	    super(g, bfs, data);
	}
	
	protected void init()
	{ 
	    nativeRootsBfsIteratorInit(ref, data);
	}
	
	private native void nativeRootsBfsIteratorInit(long bfs, long data);
    }

    // **************************************************
    //
    // native functions
    //
    // **************************************************

    private native long nativeNew();
    private native void nativeReset(long bfs);
    private native void nativeAttach(long dfs, long tool);
    private native int nativeRun(long graph, long bfs);
    private native int nativeCheck(long graph, long bfs);
    	
    private native void nativeStartNode(long bfsPointer, long nodeRef, long toolref);
    private native Node nativeStartNode(long bfsPointer, long toolref);
    private native void nativeScanWholeGraph(long bfsPointer, boolean set);
    private native boolean nativeScanWholeGraph(long bfsPointer);
    private native void nativeSetCalcLevel(long bfsPointer, boolean set);
    private native boolean nativeGetCalcLevel(long bfsPointer);
    private native void nativeStorePreds(long bfsPointer, boolean set);
    private native boolean nativeStorePreds(long bfsPointer);
    private native void nativeStoreNonTreeEdges(long bfsPointer, boolean set);
    private native boolean nativeStoreNonTreeEdges(long bfsPointer);

    private native int nativeBfsNumber(long bfsPointer, long nodeRef, long toolref);
    private native int nativeLevel(long bfsPointer, long nodeRef, long toolref);
    private native Node nativeFather(long bfsPointer, long nodeRef, long toolref);

    private native int nativeNumberOfReachedNodes(long bfsPointer);

    // **************************************************
    //
    // variables
    //
    // **************************************************

    /** Pointer to native bfs object */
    protected long bfsPointer;
    /** Reference to the attached graph */
    protected Graph graph;
}
