/* This software is distributed under the GNU Lesser General Public License */
package gtl.ds;



import java.util.Iterator;
import java.util.Collection;
import java.util.Vector;
import java.util.TreeMap;
import java.util.NoSuchElementException;
import java.util.Comparator;

import gtl.ds.Heap;

/**
 * The 'standard' heap (aka priority queue).
 * findMin, deleteMin are very efficient, but findMax and deleteMax
 * may take some time. The data is stored in a java.util.Vector.
 * @see java.util.Vector
 */
public class HeapVector implements Heap {

   
    /**
     * This Vector stores the elements of the heap.<br>
     * The left son of the element at pos i is at 2i+1<br>
     * the right son at 2i+2<br>
     * and the father at (i-1)/2.
     */  
    private Vector data;


    /**
     * Class used to compare two elements of the heap.
     */
    private Comparator comparator;


    /**
     * Creates an empty HeapVector.
     * The elements are compared using the 'compareTo' method of interface
     * Comparable. Therefore, the elements MUST be Comparable.
     */
    public HeapVector() {
	data=new Vector();
	comparator=getComparableComparator();
    }


    /**
     * Creates an empty HeapVector with the specified Comparator.
     * @param comp The Comparator used to compare two elements of the heap.
     *             It may NOT be null! To use the 'standard' Comparator,
     *             use the Constructor without any arguments. 
     */
    public HeapVector(Comparator comp) {
	data=new Vector();
	comparator=comp;
    }


    /**
     * Creates a new Heap, filled with the elements of 'collection',
     * using the specified Comparator.
     * @param collection The elements to be the initial elements in the new 
     *                   heap.
     * @param comp The Comparator used to compare two elements of the heap.
     *             if it is null, the elements must be 'Comparable'.
     *             The 'compareTo' method of interface Comparable is used in
     *             this case.
     */ 
    public HeapVector(Collection collection, Comparator comp) {
	if(comp==null)
	    comparator=getComparableComparator();
	else
	    comparator=comp;

	data=new Vector(collection.size());

	Iterator it=collection.iterator();
	while(it.hasNext()){
	    add(it.next());
	}

    }


    /**
     * Copy Constructor
     * @param comp The Comparator used to compare two elements of the heap.
     *             if it is null, the elements must be 'Comparable'.
     *             The 'compareTo' method of interface Comparable is used in
     *             this case.
     */
    public HeapVector(HeapVector hv, Comparator comp) {
	data=new Vector(hv); // funktioniert nur wenn der Iterator von hv 
	                     // das Array linear durchgeht.
	if(comp==null)
	    comparator=getComparableComparator();
	else
	    comparator=comp;
    }


    /**
     * Constructs an empty heap with the specified initial capacity and 
     * with its capacity increment equal to zero.
     * @param initialCapacity the initial capacity of the heap.
     * @param comp The Comparator used to compare two elements of the heap.
     *             if it is null, the elements must be 'Comparable'.
     *             The 'compareTo' method of interface Comparable is used in
     *             this case.
     * @see java.util.Vector#Vector(int)
     */
    public HeapVector(int initialCapacity, Comparator comp){
	data=new Vector(initialCapacity);

	if(comp==null)
	    comparator=getComparableComparator();
	else
	    comparator=comp;
    }


    /**
     * Constructs an empty heap with the specified initial capacity and 
     * capacity increment.
     * @param initialCapacity the initial capacity of the heap.
     * @param capacityIncrement the amount by which the capacity is 
     *        increased when the heap overflows.
     * @param comp The Comparator used to compare two elements of the heap.
     *             if it is null, the elements must be 'Comparable'.
     *             The 'compareTo' method of interface Comparable is used in
     *             this case.
     * @see java.util.Vector#Vector(int,int)
     */
    public HeapVector(int initialCapacity, 
		      int capacityIncrement, 
		      Comparator comp){
	data=new Vector(initialCapacity, capacityIncrement);

	if(comp==null)
	    comparator=getComparableComparator();
	else
	    comparator=comp;
    }


    /**
     * Inserts the specified element to the right position in the heap.
     * Complexity: O(log n)
     * @param o element to be added.
     * @return true always. (Method add in a heap cannot fail. In contrast 
     *         to some other Collection classes' add method. 
     */
    public boolean add(Object o) {
	//push back and swap up
	data.add(o);
	moveUp(size()-1);
	return true;//always return true, heap has changed
    }
    

    /**
     * Adds all elements in the specified Collection to the heap. 
     * @param collection The Collection which shall be added to our heap.
     * @return true if the heap has been changed 
     * (i.e. any Object has been added).
     */
    public boolean addAll(Collection collection) {
	//reserve enough space
	if(data.capacity()-data.size()<collection.size())
	    data.ensureCapacity(data.size()+collection.size());

	Iterator it=collection.iterator();
	if(!it.hasNext())
	    return false;//collection empty, nothing changed
	while(it.hasNext()){
	    add(it.next());
	}
	return true;//some elements have been added, heap has changed
    }
    

    /**
     * Removes all elements. As a result, size() will return 0.
     * @see #size()
     */
    public void clear() {
	data.clear();
    }
    

    /**
     * Tests if the specified object is a component in this heap.
     * @param element The element from which we want to know if it's 
     *                in the heap.
     * @return <code>true</code> if and only if the specified object is the 
     *         same as a component in this heap, as determined by the 
     *         <code>equals</code> method; <code>false</code> otherwise.
     * @see #equals(Object)
     */
    public boolean contains(Object element) {
	return data.contains(element);
    }
    

    /**
     * Returns true if this heap contains all of the elements in the specified
     * Collection.
     * @param collection collection to be checked for containment in this heap.
     * @return <code>true</code> if this heap contains all of the elements 
     *         in the specified collection.
     */
    public boolean containsAll(Collection collection) {
	boolean result=true;
	Iterator it=collection.iterator();
	while(it.hasNext()){
	    result=result && contains(it.next());
	}
	return result;
    }
    

    /**
     * Compares the specified Object with this heap for equality. Returns 
     * true if and only if the specified Object is also a <i>Heap</i> and
     * both store the same Objects. 
     * @param otherHeap the Object to be compared for equality with this heap.
     * @return <code>true</code> if the specified Object is equal to this heap
     */
    public boolean equals(Object otherHeap) {
	//checking if otherHeap is also a heap
	Heap castedOtherHeap=null;
	try{castedOtherHeap=(Heap)otherHeap;}
	catch(ClassCastException e){
	    return false;//otherHeap is no heap
	}
   
	//checking if castedOtherHeap has the same size
	if(size()!=castedOtherHeap.size())
	    return false;//not the same size

	//checking if both heaps contains the same('equal') elements.
	TreeMap map=new TreeMap();
	//map stores the Objects and counts how often they appear.
	Iterator it1=iterator();
	Iterator it2=castedOtherHeap.iterator();
	while(it1.hasNext()){
	    Object current=it1.next();
	    if(map.containsKey(current)){
		//increase counter for current Obj.
		map.put(current, new Integer(((Integer)map.get(current)).intValue()+1));
	    }
	    else{
		//insert current Obj. with counter 1.
		map.put(current, new Integer(1));
	    }
	}
	while(it2.hasNext()){
	    Object current=it2.next();
	    Integer i=(Integer)map.get(current);
	    if(i==null){
		return false;//otherHeap contains value not in this heap
	    }
	    else{
		if(i.intValue()==1)
		    map.remove(current);
		else{
		    map.put(current, new Integer(((Integer)map.get(current)).intValue()-1));
		}
	    }
	}
	return true;//heaps are equal
    }
    

    /**
     * Tests if this heap has no components.
     * @return true if and only if this heap has no components, that is, 
     *         its size is zero; false otherwise.
     */
    public boolean isEmpty() {
	return size()==0;
    }
    

    /**
     * Returns an iterator over the elements in this heap. The iterator
     * walks linearly through the vector, i.e. makes a breadth-first search 
     * in the heap.
     * @return an iterator over the elements in this list in breadth-first 
     *         sequence.
     */
    public Iterator iterator() {
	//must return a breadth-first search iterator. Other methods rely on
	//the fact that the iterator goes breadth-first. (for example the
	//copy constructor HeapVector(HeapVector).
	//therefore be careful with changes here
	return new BreadthFirstIterator();
    }
    

    /**
     * Removes the first occurrence of the specified element in this heap.
     *  If the heap does not contain the element, it is unchanged. 
     * @param object element to be removed from this heap, if present.
     * @return true if the heap contained the specified element.
     */
    public boolean remove(Object object) {
	Iterator it=iterator();
	while(it.hasNext()){
	    if(object.equals(it.next())){
		it.remove();
		return true;
	    }
	}
	return false;//object not found, not removed.
    }
    

    /**
     * Removes from this heap all of its elements that are contained in 
     * the specified Collection.
     * @param c elements to be removed from this collection.
     * @return true if this heap changed as a result of the call.
     */
    public boolean removeAll(Collection c) {
	boolean result=false;
	Iterator it=c.iterator();
	while(it.hasNext()){
	    Object current=it.next();
	    while(remove(current))//remove until all equal Objects are removed
		result=true;
	}
	return result;
    }
    

    /**
     * Retains only the elements in this heap that are contained in the 
     * specified Collection. In other words, removes from this heap all 
     * of its elements that are not contained in the specified Collection.
     * @return true if this heap changed as a result of the call.
     */
    public boolean retainAll(Collection c) {
	Vector v=new Vector(this);
	clear();
	boolean result=v.retainAll(c);
	addAll(v);
	return result;
    }
    

    /**
     * Returns the number of components in this heap.
     * @return the number of components in this vector.
     */
    public int size() {
	return data.size();
    }
    

    /**
     * Returns an array containing all of the elements in this heap in the 
     * breadth-first order.
     */
    public Object[] toArray() {
	return data.toArray();
    }
    

    /**
     * Returns an array containing all of the elements in this heap in the 
     * breadth-first order. The runtime type of the returned array is that 
     * of the specified array. If the heap fits in the specified array, it is
     * returned therein. Otherwise, a new array is allocated with the runtime 
     * type of the specified array and the size of this heap.
     * <p>
     * If the heap fits in the specified array with room to spare (i.e., the 
     * array has more elements than the heap), the element in the array 
     * immediately following the end of the heap is set to null.
     * This is useful in determining the length of the heap only if the caller
     * knows that the heap does not contain any null elements.
     * @param a the array into which the elements of the heap are to be 
     * stored, if it is big enough; otherwise, a new array of the same 
     * runtime type is allocated for this purpose.
     * @return an array containing the elements of the heap.
     */
    public Object[] toArray(Object[] a) {
	return data.toArray(a);
    }
    
    
    /**
     * Returns a string representation of this heap, containing the String 
     * representation of each element.
     * @return a string representation of this collection.
     */
    public String toString(){
	return data.toString();
    }

    
    /**
     * Finds the smallest element in the heap.
     * This method should be very fast. [O(1)].
     * @return The smallest element in the heap.
     */ 
    public Object findMin() {
	if(isEmpty())
	    throw new NoSuchElementException("findMin called on an empty heap.");
	return data.elementAt(0);
    }


    /**
     * Finds the biggest element in the heap.
     * This method is not very efficient. For a better performance, use 
     * MinMaxHeap.
     * @return the biggest element in the heap.
     */ 
    public Object findMax() {
	if(isEmpty())
	    throw new NoSuchElementException("findMax called on an empty heap.");

	//starting search in the lowest level in the tree is enough 
	int startingPoint=size()/2;
	Object maxElem=data.elementAt(startingPoint);
	Object currentElem;

	for(int i=startingPoint+1; i<size(); i++){
	    currentElem=data.elementAt(i);
	    if(comparator.compare(maxElem,currentElem)<0)
		maxElem=currentElem;
	}

	return maxElem;
    }


    /**
     * Removes the smallest element from the heap. This method is very fast.
     * Finding the smallest element is in O(1), but reorganisation 
     * requires O(log n).
     * @return the smallest element from the heap. This is the removed element.
     */ 
    public Object deleteMin() {
	if(isEmpty())
	    throw new NoSuchElementException("deleteMin called on an empty heap.");
	Iterator it=iterator();
	Object smallestObj=null;
	if(it.hasNext()){
	    smallestObj=it.next();
	    it.remove();
	}
	return smallestObj;
    }


    /**
     * Removes the biggest element from the heap. This method is NOT efficient.
     * All elements are searched to find the biggest element. For a better
     * performance use MinMaxHeap.
     * @return the biggest element from the heap.
     */ 
    public Object deleteMax() {
	if(isEmpty())
	    throw new NoSuchElementException("deleteMax called on an empty heap.");

	//search first
	//starting search in the lowest level in the tree is enough 
	int startingPoint=size()/2;
	Object maxElem=data.elementAt(startingPoint);
	int maxPos=startingPoint;
	Object currentElem;

	for(int i=startingPoint+1; i<size(); i++){
	    currentElem=data.elementAt(i);
	    if(comparator.compare(maxElem,currentElem)<0){
		maxElem=currentElem;
		maxPos=i;
	    }
	}
	//now remove it
	if(size()>1){
	    //fetch the last element
	    data.set(maxPos, data.elementAt(size()-1));
	    data.remove(data.size()-1);//delete last
	    moveDown(maxPos);// swap element at pos down to correct the heap
	}
	else
	    clear();
    
	return maxElem;
    }


    /**
     * Sorts the elements in the specified array using the heapSort algorithm.
     * @param a the array to sort
     * @param comp The Comparator used to compare two elements of the heap.
     *             if it is null, the elements must be 'Comparable'.
     *             The 'compareTo' method of interface Comparable is used in
     *             this case.
     * @return sorted array.
     */ 
    public static Object[] heapSort(Object[] a, Comparator comp){
	HeapVector hv=new HeapVector();
	if(comp==null)
	    hv.comparator=getComparableComparator();
	else
	    hv.comparator=comp;
	
	for(int i=0; i<a.length; i++){
	    hv.add(a[i]);
	}
	for(int i=0; i<a.length; i++){
	    a[i]=hv.deleteMin();
	}
	return a;
    }


    /**
     * Sorts the elements in the specified Collection using the heapSort 
     * algorithm.
     * @param a the Collection to sort
     * @param comp The Comparator used to compare two elements of the heap.
     *             if it is null, the elements must be 'Comparable'.
     *             The 'compareTo' method of interface Comparable is used in
     *             this case.
     * @return sorted Object[].
     */ 
    public static Object[] heapSort(Collection c, Comparator comp){
	HeapVector hv=new HeapVector(c, comp);
	Object[] a=new Object[c.size()];
	for(int i=0; i<a.length; i++){
	    a[i]=hv.deleteMin();
	}
	return a;
    }


    /**
     * Returns the current capacity of this heap.
     * @return the current capacity of this heap
     * @see java.util.Vector#capacity()
     */
    public int capacity(){
	return data.capacity();
    }


    /**
     * Increases the capacity of this heap, if necessary, to ensure that 
     * it can hold at least the number of components specified by the 
     * minimum capacity argument. 
     * @param minCapacity the desired minimum capacity.
     * @see java.util.Vector#ensureCapacity(int)
     */
    public void ensureCapacity(int minCapacity){
	data.ensureCapacity(minCapacity);
    }


    /**
     * Trims the capacity of this heap to be the heap's current size. If 
     * the capacity of this heap is larger than its current size, then 
     * the capacity is changed to equal the size by replacing its internal 
     * data array/vector, with a smaller one. An application can use this 
     * operation to minimize the storage of a heap.
     * @see java.util.Vector#trimToSize()
     */
    public void trimToSize(){
	data.trimToSize();
    }


    /**
     * Swaps two elements of the vector/heap.
     */
    private void swap(int x, int y){
	Object tmp=data.elementAt(x);
	data.set(x, data.elementAt(y));
	data.set(y, tmp);
    }


    /**
     * swaps the element at position pos up in the heap
     * to maintain heap structure.
     */
    private void moveUp(int pos){
	if(pos!=0){
	    Object current=data.elementAt(pos);
	    Object father=data.elementAt((pos-1)/2);
	    if(comparator.compare(current,father)<0){
		swap(pos, (pos-1)/2);
		moveUp((pos-1)/2);
	    }
	}
    }


    /**
     * swaps the element at position pos down in the heap
     * to maintain heap structure.
     */
    private void moveDown(int pos){
	int leftSonPos=2*pos+1;
	int rightSonPos=2*pos+2;
	//elem. at pos has left son? 
	if(size()-1>=leftSonPos){
	    Object leftSon=data.elementAt(leftSonPos);
	    if(size()-1>=rightSonPos){//has right son? 
		Object rightSon=data.elementAt(rightSonPos);
		//which son is smaller?
		//left son smaller or equal?
		if(comparator.compare(leftSon, rightSon)<=0){
		    if(comparator.compare(data.elementAt(pos), leftSon)>0){
			swap(pos, leftSonPos);//swap them
			moveDown(leftSonPos);//move down further
		    }
		}
		else{//right son smaller than left son
		    if(comparator.compare(data.elementAt(pos), rightSon)>0){
			swap(pos, rightSonPos);//swap them
			moveDown(rightSonPos);//move down further
		    }
		}
		
	    }
	    else{
		//only one son exists, swap with him if he's smaller
		if(comparator.compare(data.elementAt(pos), leftSon)>0)
		    swap(pos, leftSonPos);//swap them
	    }
	}
    }

    /**
     * 'Standard'-Comparator, used if you call a Constructor with
     * null as Comparator.
     * The Comparator returned compares two elements of a heap using 
     * 'compareTo' of interface Comparable.
     * @return A Comparator which compares using the compareTo method of
     * interface Comparable. 
     */
    private static Comparator getComparableComparator(){

	Comparator comp=new Comparator(){
		
		public int compare(Object o1, Object o2){	    
		    Comparable c1=null;
		    try{c1=(Comparable)o1;}
		    catch(ClassCastException e){
			throw new ClassCastException("Elements of the heap"+
			      " must be 'Comparable' or you have to use"+
			      " a 'java.util.Comparator' to compare them.");
		    }
		    return c1.compareTo(o2);
		}

		public boolean equals(Object o){
		    return this==o;
		}

	    };

	return comp;

    }


    /**
     * This class is used for the method iterator().
     * This iterator walks linearly through the vector, 
     * i.e. makes a breadth-first search in the heap.
     * @see #iterator()
     */
    class BreadthFirstIterator implements Iterator {
	
	/**
	 * stores the current position of the iterator in the vector.
	 */
	private int pos=-1;
	

	/**
	 * Tells you if the iteration has more elements.
	 * @return true if the iteration has more elements.
	 */
	public boolean hasNext(){
	    return size()-1>pos;
	}

	
	/**
	 * Moves the iterator forward and returns the next element.
	 * @return the next element in the iteration.
	 */
	public Object next(){
	    return data.elementAt(++pos);
	}
	
	/**
	 * Removes from the heap the last element returned by the iterator.
	 * Be careful: After remove is another element 'under' the iterator,
	 * because of swapping etc.
	 */
	public void remove(){
	    if(size()>1){
		data.set(pos, data.elementAt(size()-1));//fetch the last element
		data.remove(data.size()-1);//delete last
		moveDown(pos);// swap element at pos down to correct the heap
	    }
	    else
		clear();
	}
	
    }


}
