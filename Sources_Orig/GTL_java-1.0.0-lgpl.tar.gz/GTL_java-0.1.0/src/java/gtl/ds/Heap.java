/* This software is distributed under the GNU Lesser General Public License */
package gtl.ds;

import java.util.Collection;


public interface Heap extends Collection {


    /**
     * Finds the smallest element in the heap, respectively 'compareTo'.
     * @return The smallest element in the heap, respectively 'compareTo'.
     * @see java.lang.Comparable#compareTo(Object)
     */
    public Object findMin();


    /**
     * Finds the biggest element in the heap, respectively 'compareTo'.
     * @return The biggest element in the heap, respectively 'compareTo'.
     * @see java.lang.Comparable#compareTo(Object)
     */
    public Object findMax();


    /**
     * Deletes the smallest element in the heap, respectively 'compareTo'.
     * @return The smallest element in the heap, respectively 'compareTo'.
     * @see java.lang.Comparable#compareTo(Object)
     */
    public Object deleteMin();


    /**
     * Deletes the biggest element in the heap, respectively 'compareTo'.
     * @return The biggest element in the heap, respectively 'compareTo'.
     * @see java.lang.Comparable#compareTo(Object)
     */
    public Object deleteMax();

}
