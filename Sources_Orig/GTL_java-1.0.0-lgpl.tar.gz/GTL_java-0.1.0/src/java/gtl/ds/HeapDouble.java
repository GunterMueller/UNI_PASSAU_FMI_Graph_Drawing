/* This software is distributed under the GNU Lesser General Public License */
package gtl.ds;

import java.util.NoSuchElementException;

import gtl.ds.HeapDoubleIterator;


/**
 * This 'heap' does not implement the Heap interface. It can store only
 * doubles (primitive type, no Double Objects), but should be faster than
 * the other implementations.
 * findMin, deleteMin are very efficient, but findMax and deleteMax
 * may take some time. The data is stored in a double[].
 */
public class HeapDouble {


    /**
     * The initial capacity of a new, empty HeapDouble.
     */
    private final int INITIAL_CAPACITY=10;


    /**
     * The amount of elements the array will grow if its capacity is not
     * big enough. ('grow': a new array will be constructed.)
     * If capacityIncrement is smaller than 1, the array-size will be doubled.
     */
    private int capacityIncrement=0;//see Constructor (int iniCap)


    /**
     * Stores the amount of doubles currently in the heap.
     */
    private int size;


    /**
     * This array stores the elements of the heap.<br>
     * The left son of the element at pos i is at 2i+1<br>
     * the right son at 2i+2<br>
     * and the parent at (i-1)/2.
     */  
    private double[] data;


    /**
     * Creates an empty HeapDouble.
     */
    public HeapDouble() {
	data=new double[INITIAL_CAPACITY];
	size=0;
    }


    /**
     * Constructs an empty heap with the specified initial capacity and 
     * with its capacity increment equal to zero.
     * @param initialCapacity the initial capacity of the heap.
     */
    public HeapDouble(int initialCapacity){
	data=new double[initialCapacity];
	size=0;
    }


    /**
     * Constructs an empty heap with the specified initial capacity and 
     * capacity increment.
     * @param initialCapacity the initial capacity of the heap.
     * @param capacityIncrement the amount by which the capacity is 
     *        increased when the heap overflows.
     */
    public HeapDouble(int initialCapacity, int capacityIncrement){
	data=new double[initialCapacity];
	this.capacityIncrement=capacityIncrement;
	size=0;
    }


    /**
     * Inserts the specified double to the correct position in the heap.
     * Complexity: O(log n)
     * @param d double value to be added.
     * @return true always. (Method add in a heap cannot fail. In contrast 
     *         to some other Collection classes' add method. 
     */
    public boolean add(double d) {
	//enough space?
	if(size()==data.length){
	    double[] data2=null;;
	    if(capacityIncrement>0){
		data2=new double[data.length+capacityIncrement];
	    }
	    else{
		data2=new double[data.length*2];
	    }
	    for(int j=0; j<size(); j++){
		data2[j]=data[j];
	    }
	    data=data2;
	}
	//push back and swap up
	data[size()]=d;
	size++;
	moveUp(size()-1);
	return true;//always return true, heap has changed
    }
    

    /**
     * 'Removes all elements.' As a result, size() will return 0.
     * (Only size is set to 0. The ints are stored further.)
     * @see #size()
     */
    public void clear() {
	size=0;
    }
    

    /**
     * Tests if the specified double is a component in this heap.
     * @param element The double from which we want to know if it's 
     *                in the heap.
     * @return <code>true</code> if and only if the specified double is the 
     *         same as a component in this heap. <code>false</code> otherwise.
     */
    public boolean contains(double element) {
	for(int i=0; i<size(); i++){
	    if(data[i]==element)
		return true;
	}
	return false;
    }
    

    /**
     * Tests if this heap has no components.
     * @return true if and only if this heap has no components, that is, 
     *         its size is zero; false otherwise.
     */
    public boolean isEmpty() {
	return size()==0;
    }
    

    /**
     * Returns an iterator over the elements in this heap. The iterator
     * walks linearly through the array, i.e. makes a breadth-first search 
     * in the heap.
     * @return an iterator over the elements in this list in breadth-first 
     *         sequence.
     */
    public HeapDoubleIterator iterator() {
	//must return a breadth-first search iterator. Other methods rely on
	//the fact that the iterator goes breadth-first. 
	//therefore be careful with changes here
	return new ConcreteHeapDoubleIterator();
    }
    

    /**
     * Removes the first occurrence of the specified element in this heap.
     *  If the heap does not contain the element, it is unchanged. 
     * @param element the double to be removed from this heap, if present.
     * @return true if the heap contained the specified element.
     */
    public boolean remove(double element) {
	HeapDoubleIterator it=iterator();
	while(it.hasNext()){
	    if(element==it.next()){
		it.remove();
		return true;
	    }
	}
	return false;//double not found, not removed.
    }
    

    /**
     * Returns the number of components in this heap.
     * @return the number of components in this vector.
     */
    public int size() {
	return size;
    }
    

    /**
     * Returns an array containing all of the elements in this heap in the 
     * breadth-first order. 
     */
    public double[] toArray() {
	double[] a=new double[size()];
	for(int i=0; i<size(); i++){
	    a[i]=data[i];
	}
	return a;
    }
    
    
    /**
     * Returns a string representation of this heap, containing the String 
     * representation of each element.
     * @return a string representation of this collection.
     */
    public String toString(){
	String result="[";
	if(size()>0)
	    result+=data[0];
	for(int i=1; i<size(); i++){
	    result+=", "+data[i];
	}
	result+="]";
	return result;
    }

    
    /**
     * Finds the smallest element in the heap.
     * This method should be very fast. [O(1)].
     * @return The smallest element in the heap.
     */ 
    public double findMin() {
	if(isEmpty())
	    throw new NoSuchElementException("findMin called on an empty heap.");
	return data[0];
    }


    /**
     * Finds the biggest element in the heap.
     * This method is not very efficient. It searches all elements.
     * @return the biggest element in the heap.
     */ 
    public double findMax() {
	if(isEmpty())
	    throw new NoSuchElementException("findMax called on an empty heap.");
	double maxElem=Integer.MIN_VALUE;
	//maxElem must be beyond size()/2
	for(int i=size()/2; i<size(); i++){
	    if(maxElem<data[i])
		maxElem=data[i];
	}
	return maxElem;
    }


    /**
     * Removes the smallest element from the heap. This method is very fast.
     * Finding the smallest element is in O(1), but reorganisation 
     * requires O(log n).
     * @return the smallest element from the heap. This is the removed element.
     */ 
    public double deleteMin() {
	if(isEmpty())
	    throw new NoSuchElementException("deleteMin called on an empty heap.");
	HeapDoubleIterator it=iterator();
	double smallestDouble=0;//will be overwritten but must initialize
	if(it.hasNext()){
	    smallestDouble=it.next();
	    it.remove();
	}
	return smallestDouble;
    }


    /**
     * Removes the biggest element from the heap. This method is NOT efficient.
     * All elements are searched to find the biggest element. For a better
     * performance use MinMaxHeap.
     * @return the biggest element from the heap.
     */ 
    public double deleteMax() {
	if(isEmpty())
	    throw new NoSuchElementException("deleteMax called on an empty heap.");

	//search first
	//starting search in the lowest level in the tree is enough 
	int startingPoint=size()/2;
	double maxElem=data[startingPoint];
	int maxPos=startingPoint;
	double currentElem;

	for(int i=startingPoint+1; i<size(); i++){
	    currentElem=data[i];
	    if(maxElem<currentElem){
		maxElem=currentElem;
		maxPos=i;
	    }
	}
	//now remove it
	if(size()>1){
	    //fetch the last element
	    data[maxPos]=data[size()-1];
	    size--;
	    moveDown(maxPos);// swap element at pos down to correct the heap
	}
	else
	    clear();
    
	return maxElem;
    }


    /**
     * Sorts the elements in the specified array using the heapSort algorithm.
     * @param a the array to sort
     * @return sorted array.
     */ 
    public static double[] heapSort(double[] a){
	HeapDouble hd=new HeapDouble();
	for(int i=0; i<a.length; i++){
	    hd.add(a[i]);
	}
	for(int i=0; i<a.length; i++){
	    a[i]=hd.deleteMin();
	}
	return a;
    }


    /**
     * Returns the current capacity of this heap.
     * @return the current capacity of this heap
     */
    public int capacity(){
	return data.length;
    }


    /**
     * Increases the capacity of this heap, if necessary, to ensure that 
     * it can hold at least the number of components specified by the 
     * minimum capacity argument. 
     * @param minCapacity the desired minimum capacity.
     */
    public void ensureCapacity(int minCapacity){
	if(data.length<minCapacity){
	    double[] data2=new double[minCapacity];
	    for(int i=0; i<size(); i++){
		data2[i]=data[i];
	    }
	    data=data2;
	}
    }


    /**
     * Trims the capacity of this heap to be the heap's current size. If 
     * the capacity of this heap is larger than its current size, then 
     * the capacity is changed to equal the size by replacing its internal 
     * data array, with a smaller one. An application can use this 
     * operation to minimize the storage of a heap.
     */
    public void trimToSize(){
	if(size()!=data.length){
	    double[] data2=new double[size()];
	    for(int i=0; i<size(); i++){
		data2[i]=data[i];
	    }
	    data=data2;
	}
    }


    /**
     * Swaps two elements of the array/heap. The element at position x is 
     * swapped with the element at position y.
     */
    private void swap(int x, int y){
	double tmp=data[x];
	data[x]=data[y];
	data[y]=tmp;
    }


    /**
     * swaps the element at position pos up in the heap
     * to maintain heap structure.
     */
    private void moveUp(int pos){
	if(pos!=0){
	    double current=data[pos];
	    double father=data[(pos-1)/2];
	    if(current<father){
		swap(pos, (pos-1)/2);
		moveUp((pos-1)/2);
	    }
	}
    }


    /**
     * swaps the element at position pos down in the heap
     * to maintain heap structure.
     */
    private void moveDown(int pos){
	//elem. at pos has left son? ( left son is at position 2i+1)
	if(size()-1>=2*pos+1){
	    double leftSon=data[2*pos+1];
	    if(size()-1>=2*pos+2){//has right son? (at 2i+2)
		double rightSon=data[2*pos+2];
		//which son is smaller?
		if(leftSon<=rightSon){//left son smaller or equal
		    if(data[pos]>leftSon){
			swap(pos, 2*pos+1);//swap them
			moveDown(2*pos+1);//move down further
		    }
		}
		else{//right son smaller than left son
		    if(data[pos]>rightSon){
			swap(pos, 2*pos+2);//swap them
			moveDown(2*pos+2);//move down further
		    }
		}
		
	    }
	    else{
		//only one son exists, swap with him if he's smaller
		if(data[pos]>leftSon)
		    swap(pos, 2*pos+1);//swap them
	    }
	}
    }


    /**
     * This class is used for method iterator().
     * This iterator walks linearly through the vector, 
     * i.e. makes a breadth-first search in the heap.
     * The interface java.util.Iterator can not fit here,
     * because next would return an Object instead of a double.
     * @see HeapDouble#iterator()
     */
    class ConcreteHeapDoubleIterator implements HeapDoubleIterator {
	
	/**
	 * stores the current position of the iterator in the array.
	 */
	private int pos=-1;
	
	
	/**
	 * Tells you if the iteration has more elements.
	 * @return true if the iteration has more elements.
	 */
	public boolean hasNext(){
	    return size()-1>pos;
	}
	
	
	/**
	 * Moves the iterator forward and returns the next element.
	 * @return the next element in the iteration.
	 */
	public double next(){
	    return data[++pos];
	}
	
	/**
	 * Removes from the heap the last element returned by the iterator.
	 * Be careful: After remove is another element 'under' the iterator,
	 * because of swapping etc.
	 */
	public void remove(){
	    if(size()>1){
		data[pos]=data[size()-1];//fetch the last element
		size--;//delete last
		moveDown(pos);// swap element at pos down to correct the heap
	    }
	    else
		clear();
	}
	
    }
    
}
