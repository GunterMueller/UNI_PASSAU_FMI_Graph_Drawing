/* This software is distributed under the GNU Lesser General Public License */
package gtl.ds;



/**
 * This interface is used for method HeapInt::iterator().
 * This iterator walks linearly through the vector, 
 * i.e. makes a breadth-first search in the heap.
 * The interface java.util.Iterator can not fit here,
 * because next would return an Object instead of an int.
 * @see HeapInt#iterator()
 */
public interface HeapIntIterator{
    
    /**
     * Tells you if the iteration has more elements.
     * @return true if the iteration has more elements.
     */
    public boolean hasNext();
    
    
    /**
     * Moves the iterator forward and returns the next element.
     * @return the next element in the iteration.
     */
    public int next();

    
    /**
     * Removes from the heap the last element returned by the iterator.
     * Be careful: After remove is another element 'under' the iterator,
     * because of swapping etc.
     */
    public void remove();

    
}
