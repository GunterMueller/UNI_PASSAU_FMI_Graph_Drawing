/* This software is distributed under the GNU Lesser General Public License */
package gtl.ds;



import java.util.Iterator;
import java.util.Collection;
import java.util.Vector;
import java.util.TreeMap;
import java.util.NoSuchElementException;

import gtl.ds.Heap;


/**
 * A special heap (aka priority queue).
 * In contrast to the other heaps (HeapVector, HeapTree) this class 
 * provides a fast implementation of findMax [O(1)] and deleteMax
 * [O(log n)]. The data is stored in a java.util.Vector.
 *
 * @see java.util.Vector
 */
public class MinMaxHeap implements Heap {

   
    /**
     * This Vector stores the elements of the heap.<br>
     * The left son of the element at pos i is at 2i+1<br>
     * the right son at 2i+2<br>
     * and the father at (i-1)/2.
     */  
    private Vector data;


    /**
     * Creates an empty MinMaxHeap.
     */
    public MinMaxHeap() {
	data=new Vector();
    }


    /**
     * Creates a new Heap, filled with the elements of 'collection'.
     */ 
    public MinMaxHeap(Collection collection) {
	data=new Vector(collection.size());

	Iterator it=collection.iterator();
	while(it.hasNext()){
	    add(it.next());
	}
    }


    /**
     * Copy Constructor
     */
    public MinMaxHeap(MinMaxHeap h) {
	data=new Vector(h); // funktioniert nur wenn der Iterator von hv 
	                     // das Array linear durchgeht.
    }


    /**
     * Constructs an empty heap with the specified initial capacity and 
     * with its capacity increment equal to zero.
     * @param initialCapacity the initial capacity of the heap.
     * @see java.util.Vector#Vector(int)
     */
    public MinMaxHeap(int initialCapacity){
	data=new Vector(initialCapacity);
    }


    /**
     * Constructs an empty heap with the specified initial capacity and 
     * capacity increment.
     * @param initialCapacity the initial capacity of the heap.
     * @param capacityIncrement the amount by which the capacity is 
     *        increased when the heap overflows.
     * @see java.util.Vector#Vector(int,int)
     */
    public MinMaxHeap(int initialCapacity, int capacityIncrement){
	data=new Vector(initialCapacity, capacityIncrement);
    }


    /**
     * Inserts the specified element to the right position in the heap.
     * Complexity: O(log n)
     * @param o element to be added.
     * @return true always. (Method add in a heap cannot fail. In contrast 
     *         to some other Collection classes' add method. 
     */
    public boolean add(Object o) {
	//checking if o is a Comparable.
	try{
	    Comparable c=(Comparable)o;
	}
	catch(ClassCastException e){
	    throw new ClassCastException("Object to add must be 'Comparable'.");
	}
	
	//push back and swap up
	data.add(o);
	moveUp(size()-1);
	return true;//always return true, heap has changed
    }
    

    /**
     * Adds all elements in the specified Collection to the heap. 
     * @param collection The Collection which shall be added to our heap.
     * @return true if the heap has been changed 
     * (i.e. any Object has been added).
     */
    public boolean addAll(Collection collection) {
	//reserve enough space
	if(data.capacity()-data.size()<collection.size())
	    data.ensureCapacity(data.size()+collection.size());

	Iterator it=collection.iterator();
	if(!it.hasNext())
	    return false;//collection empty, nothing changed
	while(it.hasNext()){
	    add(it.next());
	}
	return true;//some elements have been added, heap has changed
    }
    

    /**
     * Removes all elements. As a result, size() will return 0.
     * @see #size()
     */
    public void clear() {
	data.clear();
    }
    

    /**
     * Tests if the specified object is a component in this heap.
     * @param element The element from which we want to know if it's 
     *                in the heap.
     * @return <code>true</code> if and only if the specified object is the 
     *         same as a component in this heap, as determined by the 
     *         <code>equals</code> method; <code>false</code> otherwise.
     * @see #equals(Object)
     */
    public boolean contains(Object element) {
	return data.contains(element);
    }
    

    /**
     * Returns true if this heap contains all of the elements in the specified
     * Collection.
     * @param collection collection to be checked for containment in this heap.
     * @return <code>true</code> if this heap contains all of the elements 
     *         in the specified collection.
     */
    public boolean containsAll(Collection collection) {
	boolean result=true;
	Iterator it=collection.iterator();
	while(it.hasNext()){
	    result=result && contains(it.next());
	}
	return result;
    }
    

    /**
     * Compares the specified Object with this heap for equality. Returns 
     * true if and only if the specified Object is also a <i>Heap</i> and
     * both store the same Objects. 
     * @param otherHeap the Object to be compared for equality with this heap.
     * @return <code>true</code> if the specified Object is equal to this heap
     */
    public boolean equals(Object otherHeap) {
	//checking if otherHeap is also a heap
	Heap castedOtherHeap=null;
	try{castedOtherHeap=(Heap)otherHeap;}
	catch(ClassCastException e){
	    return false;//otherHeap is no heap
	}
   
	//checking if castedOtherHeap has the same size
	if(size()!=castedOtherHeap.size())
	    return false;//not the same size

	//checking if both heaps contains the same('equal') elements.
	TreeMap map=new TreeMap();
	//map stores the Objects and counts how often they appear.
	Iterator it1=iterator();
	Iterator it2=castedOtherHeap.iterator();
	while(it1.hasNext()){
	    Object current=it1.next();
	    if(map.containsKey(current)){
		//increase counter for current Obj.
		map.put(current, new Integer(((Integer)map.get(current)).intValue()+1));
	    }
	    else{
		//insert current Obj. with counter 1.
		map.put(current, new Integer(1));
	    }
	}
	while(it2.hasNext()){
	    Object current=it2.next();
	    Integer i=(Integer)map.get(current);
	    if(i==null){
		return false;//otherHeap contains value not in this heap
	    }
	    else{
		if(i.intValue()==1)
		    map.remove(current);
		else{
		    map.put(current, new Integer(((Integer)map.get(current)).intValue()-1));
		}
	    }
	}
	return true;//heaps are equal
    }
    

    /**
     * Tests if this heap has no components.
     * @return true if and only if this heap has no components, that is, 
     *         its size is zero; false otherwise.
     */
    public boolean isEmpty() {
	return size()==0;
    }
    

    /**
     * Returns an iterator over the elements in this heap. The iterator
     * walks linearly through the vector, i.e. makes a breadth-first search 
     * in the heap.
     * @return an iterator over the elements in this list in breadth-first 
     *         sequence.
     */
    public Iterator iterator() {
	//must return a breadth-first search iterator. Other methods rely on
	//the fact that the iterator goes breadth-first. (for example the
	//copy constructor MinMaxHeap(MinMaxHeap).
	//therefore be careful with changes here
	return new BreadthFirstIterator();
    }
    

    /**
     * Removes the first occurrence of the specified element in this heap.
     *  If the heap does not contain the element, it is unchanged. 
     * @param object element to be removed from this heap, if present.
     * @return true if the heap contained the specified element.
     */
    public boolean remove(Object object) {
	Iterator it=iterator();
	while(it.hasNext()){
	    if(object.equals(it.next())){
		it.remove();
		return true;
	    }
	}
	return false;//object not found, not removed.
    }
    

    /**
     * Removes from this heap all of its elements that are contained in 
     * the specified Collection.
     * @param c elements to be removed from this collection.
     * @return true if this heap changed as a result of the call.
     */
    public boolean removeAll(Collection c) {
	boolean result=false;
	Iterator it=c.iterator();
	while(it.hasNext()){
	    Object current=it.next();
	    while(remove(current))//remove until all equal Objects are removed
		result=true;
	}
	return result;
    }
    

    /**
     * Retains only the elements in this heap that are contained in the 
     * specified Collection. In other words, removes from this heap all 
     * of its elements that are not contained in the specified Collection.
     * @return true if this heap changed as a result of the call.
     */
    public boolean retainAll(Collection c) {
	Vector v=new Vector(this);
	clear();
	boolean result=v.retainAll(c);
	addAll(v);
	return result;
    }
    

    /**
     * Returns the number of components in this heap.
     * @return the number of components in this vector.
     */
    public int size() {
	return data.size();
    }
    

    /**
     * Returns an array containing all of the elements in this heap in the 
     * breadth-first order.
     */
    public Object[] toArray() {
	return data.toArray();
    }
    

    /**
     * Returns an array containing all of the elements in this heap in the 
     * breadth-first order. The runtime type of the returned array is that 
     * of the specified array. If the heap fits in the specified array, it is
     * returned therein. Otherwise, a new array is allocated with the runtime 
     * type of the specified array and the size of this heap.
     * <p>
     * If the heap fits in the specified array with room to spare (i.e., the 
     * array has more elements than the heap), the element in the array 
     * immediately following the end of the heap is set to null.
     * This is useful in determining the length of the heap only if the caller
     * knows that the heap does not contain any null elements.
     * @param a the array into which the elements of the heap are to be 
     * stored, if it is big enough; otherwise, a new array of the same 
     * runtime type is allocated for this purpose.
     * @return an array containing the elements of the heap.
     */
    public Object[] toArray(Object[] a) {
	return data.toArray(a);
    }
    
    
    /**
     * Returns a string representation of this heap, containing the String 
     * representation of each element.
     * @return a string representation of this collection.
     */
    public String toString(){
	return data.toString();
    }

    
    /**
     * Finds the smallest element in the heap, respectively 'compareTo'.
     * This method should be very fast. [O(1)].
     * @return The smallest element in the heap, respectively 'compareTo'.
     * @see java.lang.Comparable#compareTo(Object)
     */ 
    public Object findMin() {
	if(isEmpty())
	    throw new NoSuchElementException("findMin called on an empty heap.");
	return data.elementAt(0);
    }


    /**
     * Finds the biggest element in the heap, respectively 'compareTo'.
     * Unlike findMax in HeapVector or HeapTree, this method is very 
     * efficient, too [O(1)].
     * @return the biggest element in the heap, respectively 'compareTo'.
     * @see HeapVector#findMax()
     * @see HeapTree#findMax()
     */ 
    public Object findMax() {
	if(isEmpty()){
	    throw new NoSuchElementException("findMax called on an empty heap.");
	}
	else{
	    if(size()==1){
		return data.elementAt(0);
	    }
	    else{
		if(size()==2){
		    return data.elementAt(1);
		}
		else{//size>=3
		    Object left=data.elementAt(1);
		    Object right=data.elementAt(2);
		    //return the biggest of the sons
		    if(((Comparable)left).compareTo(right)<0)
			return right;//right is bigger
		    return left;//left is bigger
		}
	    }
	}
    }


    /**
     * Removes the smallest element from the heap. This method is very fast.
     * Finding the smallest element is in O(1), but reorganisation 
     * requires O(log n).
     * @return the smallest element from the heap. This is the removed element.
     */ 
    public Object deleteMin() {
	if(isEmpty())
	    throw new NoSuchElementException("deleteMin called on an empty heap.");
	Iterator it=iterator();
	Object smallestObj=null;
	if(it.hasNext()){
	    smallestObj=it.next();
	    it.remove();
	}
	return smallestObj;
    }


    /**
     * Removes the biggest element from the heap. Unlike deleteMax in 
     * HeapVector or HeapTree, this method is efficient [O(log n)].
     * @return the biggest element from the heap.
     * @see HeapVector#findMax()
     * @see HeapTree#findMax()
     */ 
    public Object deleteMax() {
	Object maxObj=findMax();
	remove(maxObj);
	return maxObj;
    }


    /**
     * Sorts the elements in the specified array using the heapSort algorithm.
     * You should not use this class for sorting. This implementation sorts 
     * slower than HeapVector.heapSort, to get better performance at findMax 
     * and deleteMax.
     * @param a the array to sort
     * @return sorted array.
     */ 
    public static Object[] heapSort(Object[] a){
	MinMaxHeap hv=new MinMaxHeap();
	for(int i=0; i<a.length; i++){
	    hv.add(a[i]);
	}
	for(int i=0; i<a.length; i++){
	    a[i]=hv.deleteMin();
	}
	return a;
    }


    /**
     * Sorts the elements in the specified Collection using the heapSort 
     * algorithm.
     * You should not use this class for sorting. This implementation sorts 
     * slower than HeapVector.heapSort, to get better performance at findMax 
     * and deleteMax.
     * @param a the Collection to sort
     * @return sorted Object[].
     */ 
    public static Object[] heapSort(Collection c){
	MinMaxHeap hv=new MinMaxHeap(c);
	Object[] a=new Object[c.size()];
	for(int i=0; i<a.length; i++){
	    a[i]=hv.deleteMin();
	}
	return a;
    }


    /**
     * Returns the current capacity of this heap.
     * @return the current capacity of this heap
     * @see java.util.Vector#capacity()
     */
    public int capacity(){
	return data.capacity();
    }


    /**
     * Increases the capacity of this heap, if necessary, to ensure that 
     * it can hold at least the number of components specified by the 
     * minimum capacity argument. 
     * @param minCapacity the desired minimum capacity.
     * @see java.util.Vector#ensureCapacity(int)
     */
    public void ensureCapacity(int minCapacity){
	data.ensureCapacity(minCapacity);
    }


    /**
     * Trims the capacity of this heap to be the heap's current size. If 
     * the capacity of this heap is larger than its current size, then 
     * the capacity is changed to equal the size by replacing its internal 
     * data array/vector, with a smaller one. An application can use this 
     * operation to minimize the storage of a heap.
     * @see java.util.Vector#trimToSize()
     */
    public void trimToSize(){
	data.trimToSize();
    }


    /**
     * Swaps two elements of the vector/heap.
     */
    private void swap(int x, int y){
	Object tmp=data.elementAt(x);
	data.set(x, data.elementAt(y));
	data.set(y, tmp);
    }


    /**
     * Computes the level of the element pos in the heap
     * and then calls moveUp(pos, level).
     * @see #moveUp(int,int)
     */
    private void moveUp(int pos){
	//the level of pos is at log2(pos+1).
	//equal to:  ln(pos+1) / ln(2).
	int level=(int)(Math.log((double)(pos+1))/Math.log(2.0));
	moveUp(pos,level);
	
    }
    
    
    /**
     * Swaps the element at position pos up in the heap
     * to maintain heap structure.
     */
    private void moveUp(int pos, int level){
	if(level!=0){
	    if(level==1){//pos==1 or pos==2
		Comparable father=(Comparable)data.elementAt(0);
		Object son=data.elementAt(pos);
		if(father.compareTo(son)>0){
		    swap(0,pos);
		}
	    }
	    else{//level>=2
		if(level%2==0){//must be smaller than father 
		    //and bigger than grandfather
		    int posFather=(pos-1)/2;
		    Object father=data.elementAt(posFather);
		    Object son=data.elementAt(pos);
		    if(((Comparable)father).compareTo(son)<0){
			swap(pos, posFather);
			moveUp(posFather, level-1);
		    }
		    else{
			int posGrandfather=(posFather-1)/2;
			Object grandfather=data.elementAt(posGrandfather);
			if(((Comparable)grandfather).compareTo(son)>0){
			    swap(pos, posGrandfather);
			    moveUp(posGrandfather, level-2);
			}
		    }
		}
		else{//must be bigger than father
		    //and smaller than grandfather
		    int posFather=(pos-1)/2;
		    Object father=data.elementAt(posFather);
		    Object son=data.elementAt(pos);
		    if(((Comparable)father).compareTo(son)>0){
			swap(pos, posFather);
			moveUp(posFather, level-1);
		    }
		    else{
			int posGrandfather=(posFather-1)/2;
			Object grandfather=data.elementAt(posGrandfather);
			if(((Comparable)grandfather).compareTo(son)<0){
			    swap(pos, posGrandfather);
			    moveUp(posGrandfather, level-2);
			}
		    }
		}
	    }
	}
    }


    /**
     * Computes the level of the element pos in the heap
     * and then calls moveDown(pos, level).
     * @see #moveDown(int,int)
     */
    private void moveDown(int pos){
	//the level of pos is at log2(pos+1).
	//equal to:  ln(pos+1) / ln(2).
	int level=(int)(Math.log((double)(pos+1))/Math.log(2.0));
	moveDown(pos,level);
    }


    /**
     * swaps the element at position pos down in the heap
     * to maintain heap structure.
     */
    private void moveDown(int pos, int level){
	if(level%2==0){
	    if(2*pos+2<=size()){//pos has children?
		//search the smallest from kids and kids' kids
		int current=2*pos+1;
		int minPos=current;
		boolean istEnkel=false;
		Comparable minValue=(Comparable)data.elementAt(minPos);
		current++;
		if(current+1<=size()){
		    if(minValue.compareTo(data.elementAt(current))>0){
			minPos=current;
			minValue=(Comparable)data.elementAt(current);
		    }
		    current=(2*pos+1)*2+1;//left son of left son
		    //search smallest of the kids' kids
		    if(current+1<=size()){
			if(minValue.compareTo(data.elementAt(current))>=0){
			    minPos=current;
			    minValue=(Comparable)data.elementAt(current);
			    istEnkel=true;
			}
			current++;
			if(current+1<=size()){
			    if(minValue.compareTo(data.elementAt(current))>0){
				minPos=current;
				minValue=(Comparable)data.elementAt(current);
				istEnkel=true;
			    }
			    current++;
			    if(current+1<=size()){
				if(minValue.compareTo(data.elementAt(current))>0){
				    minPos=current;
				    minValue=(Comparable)data.elementAt(current);
				    istEnkel=true;
				}
				current++;
				if(current+1<=size()){
				    if(minValue.compareTo(data.elementAt(current))>0){
					minPos=current;
					minValue=(Comparable)data.elementAt(current);
					istEnkel=true;
				    }
				}
			    }
			}
		    }
		}
		//minPos, minValue is now the smallest of the kids/kids' kids
		if(istEnkel){
		    if(minValue.compareTo(data.elementAt(pos))<0){
			swap(minPos, pos);

			//if new value at minPos>father, swap them, too
			int posFather=(minPos-1)/2;
			if(((Comparable)data.elementAt(minPos)).compareTo(data.elementAt(posFather))>0)
			    swap(minPos,posFather);

			moveDown(minPos, level+2);
		    }
		}
		else{
		    if(minValue.compareTo(data.elementAt(pos))<0){
			swap(minPos, pos);
			moveDown(minPos, level+1);
		    }
		}
	    }
	}
	else{//level%2==1
	    if(2*pos+2<=size()){//pos has children?
		//search the biggestest
		int current=2*pos+1;
		int maxPos=current;
		boolean istEnkel=false;
		Comparable maxValue=(Comparable)data.elementAt(maxPos);
		current++;
		if(current+1<=size()){
		    if(maxValue.compareTo(data.elementAt(current))<0){
			maxPos=current;
			maxValue=(Comparable)data.elementAt(current);
		    }
		    current=(2*pos+1)*2+1;//left son of left son
		    //search biggest of the kids' kids
		    if(current+1<=size()){
			if(maxValue.compareTo(data.elementAt(current))<=0){
			    maxPos=current;
			    maxValue=(Comparable)data.elementAt(current);
			    istEnkel=true;
			}
			current++;
			if(current+1<=size()){
			    if(maxValue.compareTo(data.elementAt(current))<0){
				maxPos=current;
				maxValue=(Comparable)data.elementAt(current);
				istEnkel=true;
			    }
			    current++;
			    if(current+1<=size()){
				if(maxValue.compareTo(data.elementAt(current))<0){
				    maxPos=current;
				    maxValue=(Comparable)data.elementAt(current);
				    istEnkel=true;
				}
				current++;
				if(current+1<=size()){
				    if(maxValue.compareTo(data.elementAt(current))<0){
					maxPos=current;
					maxValue=(Comparable)data.elementAt(current);
					istEnkel=true;
				    }
				}
			    }
			}
		    }
		}
		//maxPos, maxValue is now the biggest of the kids/kids' kids
		if(istEnkel){
		    if(maxValue.compareTo(data.elementAt(pos))>0){
			swap(maxPos, pos);
	
			//if new value at maxPos<father, swap them, too
			int posFather=(maxPos-1)/2;
			if(((Comparable)data.elementAt(maxPos)).compareTo(data.elementAt(posFather))<0)
			    swap(maxPos,posFather);

			moveDown(maxPos, level+2);
		    }
		}
		else{
		    if(maxValue.compareTo(data.elementAt(pos))>0){
			swap(maxPos, pos);
			moveDown(maxPos, level+1);
		    }
		}
	    }
	}
    }


    /**
     * This class is used for the method iterator().
     * This iterator walks linearly through the vector, 
     * i.e. makes a breadth-first search in the heap.
     * @see #iterator()
     */
    class BreadthFirstIterator implements Iterator {
	
	/**
	 * stores the current position of the iterator in the vector.
	 */
	private int pos=-1;
	

	/**
	 * Tells you if the iteration has more elements.
	 * @return true if the iteration has more elements.
	 */
	public boolean hasNext(){
	    return size()-1>pos;
	}

	
	/**
	 * Moves the iterator forward and returns the next element.
	 * @return the next element in the iteration.
	 */
	public Object next(){
	    return data.elementAt(++pos);
	}
	
	/**
	 * Removes from the heap the last element returned by the iterator.
	 * Be careful: After remove is another element 'under' the iterator,
	 * because of swapping etc.
	 */
	public void remove(){
	    if(size()>1){
		data.set(pos, data.elementAt(size()-1));//fetch the last element
		data.remove(data.size()-1);//delete last
		moveDown(pos);// swap element at pos down to correct the heap
	    }
	    else
		clear();
	}
	
    }


 //    //following methods used to check if constructed heap is legal.
 //    private boolean checkHeap(){
// 	return checkNode(0,true);
//     }
//     private boolean checkNode(int pos, boolean levelEven){
// 	if(levelEven){
// 	    boolean result=true;
// 	    if(2*pos+2<=size()){//hat linken sohn
// 		if(((Comparable)data.elementAt(2*pos+1)).compareTo(data.elementAt(pos))<0)
// 		   result=false;
// 		if(!checkNode(2*pos+1, !levelEven))
// 		    result=false;

// 		if(2*pos+3<=size()){//hat rechten sohn
// 		    if(((Comparable)data.elementAt(2*pos+2)).compareTo(data.elementAt(pos))<0)
// 			result=false;
// 		    if(!checkNode(2*pos+2, !levelEven))
// 			result=false;
		    
// 		    if((2*pos+1)*2+2<=size()){//hat ll enkel
// 			if(((Comparable)data.elementAt((2*pos+1)*2+1)).compareTo(data.elementAt(pos))<0)
// 			    result=false;
// 			if(!checkNode((2*pos+1)*2+1, levelEven))
// 			    result=false;
			
// 			if((2*pos+1)*2+3<=size()){//hat lr enkel
// 			    if(((Comparable)data.elementAt((2*pos+1)*2+2)).compareTo(data.elementAt(pos))<0)
// 				result=false;
// 			    if(!checkNode((2*pos+1)*2+2, levelEven))
// 				result=false;
			    
// 			    if((2*pos+1)*2+4<=size()){//hat rl enkel
// 				if(((Comparable)data.elementAt((2*pos+1)*2+3)).compareTo(data.elementAt(pos))<0)
// 				    result=false;
// 				if(!checkNode((2*pos+1)*2+3, levelEven))
// 				    result=false;

// 				if((2*pos+1)*2+5<=size()){//hat rr enkel
// 				if(((Comparable)data.elementAt((2*pos+1)*2+4)).compareTo(data.elementAt(pos))<0)
// 				    result=false;
// 				if(!checkNode((2*pos+1)*2+4, levelEven))
// 				    result=false;
// 				}
// 			    }
// 			}
// 		    }
// 		}
		
// 	    }
// 	    return result;
// 	}
// 	else{
// 	    boolean result=true;
// 	    if(2*pos+2<=size()){//hat linken sohn
// 		if(((Comparable)data.elementAt(2*pos+1)).compareTo(data.elementAt(pos))>0)
// 		    result=false;
// 		if(!checkNode(2*pos+1, !levelEven))
// 		    result=false;
		
// 		if(2*pos+3<=size()){//hat rechten sohn
// 		    if(((Comparable)data.elementAt(2*pos+2)).compareTo(data.elementAt(pos))>0)
// 			result=false;
// 		    if(!checkNode(2*pos+2, !levelEven))
// 			result=false;
		    
// 		    if((2*pos+1)*2+2<=size()){//hat ll enkel
// 			if(((Comparable)data.elementAt((2*pos+1)*2+1)).compareTo(data.elementAt(pos))>0)
// 			    result=false;
// 			if(!checkNode((2*pos+1)*2+1, levelEven))
// 			    result=false;
			
// 			if((2*pos+1)*2+3<=size()){//hat lr enkel
// 			    if(((Comparable)data.elementAt((2*pos+1)*2+2)).compareTo(data.elementAt(pos))>0)
// 				result=false;
// 			    if(!checkNode((2*pos+1)*2+2, levelEven))
// 				result=false;
			    
// 			    if((2*pos+1)*2+4<=size()){//hat rl enkel
// 				if(((Comparable)data.elementAt((2*pos+1)*2+3)).compareTo(data.elementAt(pos))>0)
// 				    result=false;
// 				if(!checkNode((2*pos+1)*2+3, levelEven))
// 				    result=false;
				
// 				if((2*pos+1)*2+5<=size()){//hat rr enkel
// 				    if(((Comparable)data.elementAt((2*pos+1)*2+4)).compareTo(data.elementAt(pos))>0)
// 					result=false;
// 				    if(!checkNode((2*pos+1)*2+4, levelEven))
// 					result=false;
// 				}
// 			    }
// 			}
// 		    }
// 		}
// 	    }
// 	    return result;
// 	}
//     }
//     private void print(){
// 	System.out.println(toString());
//     }


}
