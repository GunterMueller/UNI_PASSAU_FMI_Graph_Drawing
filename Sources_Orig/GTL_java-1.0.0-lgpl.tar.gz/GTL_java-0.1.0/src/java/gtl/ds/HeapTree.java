/* This software is distributed under the GNU Lesser General Public License */
package gtl.ds;

import java.util.Iterator;
import java.util.Collection;
import java.util.TreeMap;
import java.util.NoSuchElementException;
import java.util.LinkedList;
import java.util.Vector;
import java.util.Comparator;

import gtl.ds.Heap;


/**
 * A heap (aka priority queue), realized as a tree internally.
 * findMin, deleteMin are very efficient, but findMax and deleteMax
 * may take some time. The data is stored in a tree..
 */
public class HeapTree implements Heap {

   
    /**
     * A reference to the root of the tree, which stores the 
     * elements of this heap. If it is null, the heap is empty.
     * This TreeNode's parent must be null. (The root has no parent). 
     */
    private TreeNode root;


    /**
     * A reference to the 'last' element in the tree. 
     * This is the rightmost element in the lowest level of the tree.
     * This reference is used for adding (pushBack) and removing elements. 
     */
    private TreeNode last;


    /**
     * This integer stores the amount of elements stored in the heap.
     */
    private int size;

    
    /**
     * Class used to compare two elements of the heap.
     */
    private Comparator comparator;


    /**
     * Creates an empty HeapTree.
     */
    public HeapTree() {
	root=null;
	last=null;
	size=0;
	comparator=getComparableComparator();
    }


    /**
     * Creates an empty HeapTree with the specified Comparator.
     * @param comp The Comparator used to compare two elements of the heap.
     *             It may NOT be null! To use the 'standard' Comparator,
     *             use the Constructor without any arguments. 
     */
    public HeapTree(Comparator comp) {
	root=null;
	last=null;
	size=0;
	comparator=comp;
    }


    /**
     * Creates a new Heap, filled with the elements of 'collection'.
     * @param comp The Comparator used to compare two elements of the heap.
     *             if it is null, the elements must be 'Comparable'.
     *             The 'compareTo' method of interface Comparable is used in
     *             this case.
     */ 
    public HeapTree(Collection collection, Comparator comp) {
	if(comp==null)
	    comparator=getComparableComparator();
	else
	    comparator=comp;

	Iterator it=collection.iterator();
	while(it.hasNext()){
	    add(it.next());
	}
    }


    /**
     * Copy Constructor
     * @param comp The Comparator used to compare two elements of the heap.
     *             if it is null, the elements must be 'Comparable'.
     *             The 'compareTo' method of interface Comparable is used in
     *             this case.
     */
    public HeapTree(HeapTree ht, Comparator comp) {
	if(comp==null)
	    comparator=getComparableComparator();
	else
	    comparator=comp;

	Iterator it=ht.iterator();
	while(it.hasNext()){
	    add(it.next());
	}
    }


    /**
     * Inserts the specified element to the correct position in the heap.
     * Complexity: O(log n)
     * @param o element to be added.
     * @return true always. (Method add in a heap cannot fail. In contrast 
     *         to some other Collection classes' add method. 
     */
    public boolean add(Object o) {
	//if heap empty, simply add
	if(isEmpty()){
	    root=new TreeNode(o);
	    last=root;
	}
	
	else{
	    if(last.parent==null){
		//last is the only element in the heap,
		//make o the left son.
		TreeNode node=new TreeNode(o);
		last.leftSon=node;
		node.parent=last;
		last=node;
	    }
	    else{
		//push back
		TreeNode node=new TreeNode(o);
		if(last==last.parent.leftSon){//is last a 'left son'?
		    //put o to the right
		    last.parent.rightSon=node;
		    node.parent=last.parent;
		    last=node;
		}
		else{//last is a 'right son'
		    boolean added=false;
		    while(!added){
			//has the parent a parent?
			if(last.parent.parent==null){
			    //parent has no parent:
			    //search the lowest left node from root, 
			    //insert o there as left son
			    TreeNode currentNode=root;
			    while(currentNode.leftSon!=null){
				currentNode=currentNode.leftSon;//walk down
			    }
			    currentNode.leftSon=node;//insert here
			    node.parent=currentNode;
			    last=node;
			    added=true;
			}
			else{//parent has a parent
			    //is parent a left son?
			    if(last.parent==last.parent.parent.leftSon){
				//parent is a left son:
				//walk down to lower left from parent.parent.rightSon
				//insert o there as left son
				TreeNode currentNode=last.parent.parent.rightSon;
				while(currentNode.leftSon!=null){
				    currentNode=currentNode.leftSon;//walk down
				}
				currentNode.leftSon=node;//insert here
				node.parent=currentNode;
				last=node;
				added=true;
			    }
			    else{//parent is a right son
				last=last.parent;
				//search recursively one level higher in the tree
			    }
			}
		    }    
		}
	    }
	    //move up if necessary
	    moveUp(last);
	}
	size++;
	return true;//always return true, because the heap has changed
    }
    

    /**
     * Adds all elements in the specified Collection to the heap. 
     * @param collection The Collection which shall be added to our heap.
     * @return true if the heap has been changed 
     * (i.e. the Collection was not empty.
     */
    public boolean addAll(Collection collection) {
	Iterator it=collection.iterator();
	if(!it.hasNext())
	    return false;//collection empty, nothing changed
	do{
	    add(it.next());
	}while(it.hasNext());
	return true;//some elements have been added, heap has changed
    }
    

    /**
     * Removes all elements. As a result, size() will return 0.
     * @see #size()
     */
    public void clear() {
	    root=null;
	    last=null;
	    size=0;
    }
    

    /**
     * Tests if the specified object is a component in this heap.
     * @param element The element from which we want to know if it's 
     *                in the heap.
     * @return <code>true</code> if and only if the specified object is the 
     *         same as a component in this heap, as determined by the 
     *         <code>equals</code> method; <code>false</code> otherwise.
     * @see #equals(Object)
     */
    public boolean contains(Object element) {
	Iterator it=iterator();
	boolean found=false;
	while(it.hasNext()){
	    if(element.equals(it.next())){
		found=true;
		break;
	    }
	}
	return found;
    }
    

    /**
     * Returns true if this heap contains all of the elements in the specified
     * Collection.
     * @param collection collection to be checked for containment in this heap.
     * @return <code>true</code> if this heap contains all of the elements 
     *         in the specified collection.
     */
    public boolean containsAll(Collection collection) {
	boolean result=true;
	Iterator it=collection.iterator();
	while(it.hasNext()){
	    result=result && contains(it.next());
	}
	return result;
    }
    

    /**
     * Compares the specified Object with this heap for equality. Returns 
     * true if and only if the specified Object is also a <i>Heap</i> and
     * both store the same Objects. 
     * @param otherHeap the Object to be compared for equality with this heap.
     * @return <code>true</code> if the specified Object is equal to this heap
     */
    public boolean equals(Object otherHeap) {
	//checking if otherHeap is also a heap
	Heap castedOtherHeap=null;
	try{castedOtherHeap=(Heap)otherHeap;}
	catch(ClassCastException e){
	    return false;//otherHeap is no heap
	}
   
	//checking if castedOtherHeap has the same size
	if(size()!=castedOtherHeap.size())
	    return false;//not the same size

	//checking if both heaps contains the same('equal') elements.
	TreeMap map=new TreeMap();
	//map stores the Objects and counts how often they appear.
	Iterator it1=iterator();
	Iterator it2=castedOtherHeap.iterator();
	while(it1.hasNext()){
	    Object current=it1.next();
	    if(map.containsKey(current)){
		//increase counter for current Obj.
		map.put(current, new Integer(((Integer)map.get(current)).intValue()+1));
	    }
	    else{
		//insert current Obj. with counter 1.
		map.put(current, new Integer(1));
	    }
	}
	while(it2.hasNext()){
	    Object current=it2.next();
	    Integer i=(Integer)map.get(current);
	    if(i==null){
		return false;//otherHeap contains value not in this heap
	    }
	    else{
		if(i.intValue()==1)
		    map.remove(current);
		else{
		    map.put(current, new Integer(((Integer)map.get(current)).intValue()-1));
		}
	    }
	}
	return true;//heaps are equal
    }
    

    /**
     * Tests if this heap has no components.
     * @return true if and only if this heap has no components, that is, 
     *         its size is zero; false otherwise.
     */
    public boolean isEmpty() {
	return size==0;//or root==null, last==null
    }
    

    /**
     * Returns an iterator over the elements in this heap. The iterator
     * makes a breadth-first search in the heap.
     * @return an iterator over the elements in this list in breadth-first 
     *         sequence.
     */
    public Iterator iterator() {
	return new BreadthFirstIterator();
    }
    

    /**
     * Removes the first occurrence of the specified element in this heap.
     *  If the heap does not contain the element, it is unchanged. 
     * @param object element to be removed from this heap, if present.
     * @return true if the heap contained the specified element.
     */
    public boolean remove(Object object) {
	Iterator it=iterator();
	while(it.hasNext()){
	    if(object.equals(it.next())){
		it.remove();
		return true;
	    }
	}
	return false;//object not found, not removed.
    }
    

    /**
     * Removes from this heap all of its elements that are contained in 
     * the specified Collection.
     * @param c elements to be removed from this collection.
     * @return true if this heap changed as a result of the call.
     */
    public boolean removeAll(Collection c) {
	boolean result=false;
	Iterator it=c.iterator();
	while(it.hasNext()){
	    Object current=it.next();
	    while(remove(current))//remove until all equal Objects are removed
		result=true;
	}
	return result;
    }
    

    /**
     * Retains only the elements in this heap that are contained in the 
     * specified Collection. In other words, removes from this heap all 
     * of its elements that are not contained in the specified Collection.
     * @return true if this heap changed as a result of the call.
     */
    public boolean retainAll(Collection c) {
	Vector v=new Vector(size());
       	Iterator it=iterator();
	for(int i=0; i<size(); i++){
	    v.add(it.next());
	}
	clear();
	boolean result=v.retainAll(c);
	addAll(v);
	return result;
    }
    

    /**
     * Returns the number of components in this heap.
     * @return the number of components in this vector.
     */
    public int size() {
	return size;
    }
    

    /**
     * Returns an array containing all of the elements in this heap in the 
     * breadth-first order.
     */
    public Object[] toArray() {
	Iterator it=iterator();
	Object[] a=new Object[size()];
	for(int i=0; i<size(); i++){
	    a[i]=it.next();
	}
	return a;
    }
    

    /**
     * Returns an array containing all of the elements in this heap in the 
     * breadth-first order. The runtime type of the returned array is that 
     * of the specified array. If the heap fits in the specified array, it is
     * returned therein. Otherwise, a new array is allocated with the runtime 
     * type of the specified array and the size of this heap.
     * <p>
     * If the heap fits in the specified array with room to spare (i.e., the 
     * array has more elements than the heap), the element in the array 
     * immediately following the end of the heap is set to null.
     * This is useful in determining the length of the heap only if the caller
     * knows that the heap does not contain any null elements.
     * @param a the array into which the elements of the heap are to be 
     * stored, if it is big enough; otherwise, a new array of the same 
     * runtime type is allocated for this purpose.
     * @return an array containing the elements of the heap.
     */
    public Object[] toArray(Object[] a) {
	if (a.length < size())
	a = (Object[])java.lang.reflect.Array.newInstance(
		      a.getClass().getComponentType(), size());
	
	Iterator it=iterator();
	int i=0;
	while(it.hasNext()){
	    a[i]=it.next();
	    i++;
	}
	
        if (a.length > size())
	a[size()] = null;

        return a;
    }
    
    
    /**
     * Returns a string representation of this heap, containing the String 
     * representation of each element.
     * @return a string representation of this collection.
     */
    public String toString(){
	Iterator it=iterator();
	String result="[";
	if(it.hasNext())
	    result+=(it.next());
	while(it.hasNext()){
	    result+=", "+(it.next());
	}
	result+="]";
	return result;
    }

    
    /**
     * Finds the smallest element in the heap.
     * This method should be very fast. [O(1)].
     * @return The smallest element in the heap.
     */ 
    public Object findMin() {
	if(isEmpty())
	    throw new NoSuchElementException("findMin called on an empty heap.");
	return root.data;
    }


    /**
     * Finds the biggest element in the heap.
     * This method is not very efficient. It searches all elements.
     * @return the biggest element in the heap.
     */ 
    public Object findMax() {
	if(isEmpty())
	    throw new NoSuchElementException("findMax called on an empty heap.");
	Object maxElem=null;
	Iterator it=iterator();
	maxElem=it.next();
	Object currentElem;
	while(it.hasNext()){
	    currentElem=it.next();
	    if(comparator.compare(maxElem,currentElem)<0)
		maxElem=currentElem;
	}
	return maxElem;
    }


    /**
     * Removes the smallest element from the heap. This method is very fast.
     * Finding the smallest element is in O(1), but reorganisation 
     * requires O(log n).
     * @return the smallest element from the heap. This is the removed element.
     */ 
    public Object deleteMin() {
	if(isEmpty())
	    throw new NoSuchElementException("deleteMin called on an empty heap.");
	Iterator it=iterator();
	Object smallestObj=null;
	if(it.hasNext()){
	    smallestObj=it.next();
	    it.remove();
	}
	return smallestObj;
    }


    /**
     * Removes the biggest element from the heap. This method is NOT efficient.
     * All elements are searched to find the biggest element. For a better
     * performance use MinMaxHeap.
     * @return the biggest element from the heap.
     */ 
    public Object deleteMax() {
	Object maxObj=findMax();
	remove(maxObj);
	return maxObj;
    }


    /**
     * Sorts the elements in the specified array using the heapSort algorithm.
     * @param a the array to sort
     * @param comp The Comparator used to compare two elements of the heap.
     *             if it is null, the elements must be 'Comparable'.
     *             The 'compareTo' method of interface Comparable is used in
     *             this case.
     * @return sorted array.
     */ 
    public static Object[] heapSort(Object[] a, Comparator comp){
	HeapTree ht=new HeapTree();
	if(comp==null)
	    ht.comparator=getComparableComparator();
	else
	    ht.comparator=comp;

	for(int i=0; i<a.length; i++){
	    ht.add(a[i]);
	}
	for(int i=0; i<a.length; i++){
	    a[i]=ht.deleteMin();
	}
	return a;
    }


    /**
     * Sorts the elements in the specified Collection using the heapSort 
     * algorithm.
     * @param a the Collection to sort
     * @param comp The Comparator used to compare two elements of the heap.
     *             if it is null, the elements must be 'Comparable'.
     *             The 'compareTo' method of interface Comparable is used in
     *             this case.
     * @return sorted Object[].
     */ 
    public static Object[] heapSort(Collection c, Comparator comp){
	HeapTree ht=new HeapTree(c, comp);
	Object[] a=new Object[c.size()];
	for(int i=0; i<a.length; i++){
	    a[i]=ht.deleteMin();
	}
	return a;
    }


    /**
     * Swaps two elements of the heap.
     */
    private void swap(TreeNode x, TreeNode y){
	Object tmp=x.data;
	x.data=y.data;
	y.data=tmp;
    }


    /**
     * swaps the element at position pos up in the heap
     * to maintain heap structure.
     */
    private void moveUp(TreeNode pos){
	if(pos!=root){
	    Object current=pos.data;
	    Object father=pos.parent.data;
	    if(comparator.compare(current,father)<0){
		swap(pos, pos.parent);
		moveUp(pos.parent);
	    }
	}
    }


    /**
     * swaps the element at position pos down in the heap
     * to maintain heap structure.
     */
    private void moveDown(TreeNode pos){
	//node at pos has left son?
	if(pos.leftSon!=null){
	    Object leftSonData=pos.leftSon.data;
	    if(pos.rightSon!=null){//has right son? 
		Object rightSonData=pos.rightSon.data;
		//which son is smaller?
		//left son smaller or equal
		if(comparator.compare(leftSonData,rightSonData)<=0){
		    if(comparator.compare(pos.data,leftSonData)>0){
			swap(pos, pos.leftSon);//swap them
			moveDown(pos.leftSon);//move down further
		    }
		}
		else{//right son smaller than left son
		    if(comparator.compare(pos.data,rightSonData)>0){
			swap(pos, pos.rightSon);//swap them
			moveDown(pos.rightSon);//move down further
		    }
		}
		
	    }
	    else{
		//only one son exists, swap with him if he's smaller
		if(comparator.compare(pos.data,leftSonData)>0)
		    swap(pos, pos.leftSon);//swap them
	    }
	}
    }
	

    /**
     * 'Standard'-Comparator, used if you call a Constructor with
     * null as Comparator.
     * The Comparator returned compares two elements of a heap using 
     * 'compareTo' of interface Comparable.
     * @return A Comparator which compares using the compareTo method of
     *         interface Comparable. 
     */
    private static Comparator getComparableComparator(){

	Comparator comp=new Comparator(){

		public int compare(Object o1, Object o2){	    
		    Comparable c1=null;
		    try{c1=(Comparable)o1;}
		    catch(ClassCastException e){
			throw new ClassCastException("Elements of the heap"+
			      " must be 'Comparable' or you have to use"+
			      " a Comparator to compare them.");
		    }
		    return c1.compareTo(o2);
		}

		public boolean equals(Object o){
		    return this==o;
		}

	    };

	return comp;
    }


    /**
     * This class is used for the method iterator().
     * This iterator makes a breadth-first search in the heap.
     * @see #iterator()
     */
    private class BreadthFirstIterator implements Iterator {
	

	/**
	 * Stores the last TreeNode returned by next().
	 * This is used by remove().
	 */
	private TreeNode current=null;


	/**
	 * stores the parent-nodes to be searched next.
	 */
	private LinkedList list;
	

	/**
	 * Constructor. Initializes the Iterator-position.
	 */
	public BreadthFirstIterator() {
	    list=new LinkedList();
	    if(root!=null)
		list.add(root);
	}


	/**
	 * Tells you if the iteration has more elements.
	 * @return true if the iteration has more elements.
	 */
	public boolean hasNext(){
	    return !(list.isEmpty());
	}

	
	/**
	 * Moves the iterator forward and returns the next element.
	 * @return the next element in the iteration.
	 */
	public Object next(){
	    current=(TreeNode)list.removeFirst();
	    if(current.leftSon!=null){
		list.add(current.leftSon);
		if(current.rightSon!=null)
		    list.add(current.rightSon);
	    }
	    return current.data;
	}
	

	/**
	 * Removes from the heap the last element returned by the iterator.
	 * Be careful: After remove is another element 'under' the iterator,
	 * because of swapping etc.
	 */
	public void remove(){
	    if(size()>1){
		//fetch the last element
		current.data=last.data;
		//delete last, set new 'last' reference
		//is last a right son?
		if(last.parent.leftSon!=last){
		    //last son is a right son
		    last=last.parent.leftSon;
		    last.parent.rightSon=null;
		}
		else{//last is a left son
		    TreeNode searcher=last;
		    boolean lastDeleted=false;
		    while(!lastDeleted){
			//has parent a parent?
			if(searcher.parent.parent==null){
			    last.parent.leftSon=null;
			    last=root;//new last is in the lower right corner
			    while(last.rightSon!=null){
				last=last.rightSon;
			    }
			    lastDeleted=true;
			}
			else{//parent has a parent
			    //is parent a right son?
			    if(searcher.parent==searcher.parent.parent.rightSon){
				//yes:delete old last,
				//go from parent.parent.leftSon to the right down
				//set new last reference there
				last.parent.leftSon=null;
				last=searcher.parent.parent.leftSon;
				while(last.rightSon!=null){
				    last=last.rightSon;
				}
				lastDeleted=true;
			    }
			    else{//parent is a left son
				searcher=searcher.parent;
			    }
			}
		    }
		}

		// swap element at current down to correct the heap
		moveDown(current);
		--size;
	    }
	    else//remove last element
		clear();
	}
	
    }


    /**
     * A TreeNode is used to store one element of the heap. The TreeNodes
     * are linked to a parent and two sons each, to get the structure of 
     * a tree. This tree stores the elements of the heap. 
     */
    private class TreeNode{

	/**
	 * This Object stores one element of the heap.
	 */
	private Object data=null;


	/**
	 * A 'pointer' to the parent of this TreeNode. If the pointer is null,
	 * this TreeNode is the root.
	 */
	private TreeNode parent=null;


	/**
	 * A 'pointer' to the leftSon of this TreeNode. If the pointer is null,
	 * this TreeNode has no leftSon.
	 */
	private TreeNode leftSon=null;


	/**
	 * A 'pointer' to the rightSon of this TreeNode. If the pointer is 
	 * null, this TreeNode has no rightSon.
	 */
	private TreeNode rightSon=null;
	

	/**
	 * Constructor, creates a new TreeNode and stores the specified Object.
	 * 
	 */
	public TreeNode(Object o){
	    data=o;
	}

    }
}
