/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GTL_edgeIterator.java
//
// contains definition
//
// ***************************************************************************

package gtl;

/**
 * Abstract basic class for a gtl-based EdgeIterator.
 *
 * @see EdgeIterator
 */
public abstract class GTL_EdgeIterator implements EdgeIterator
{
    protected GTL_EdgeIterator(long toolPointer, long g, long r)
    {
	graphJavaPointer = toolPointer;
	graph   = g;
	ref	= r;
	data    = -1;
	init();
    }

    // data must be of type iterator_data*, will be
    // deleted by iterator !!!
    protected GTL_EdgeIterator(long toolPointer, long g, long r, long d)
    {
	graphJavaPointer = toolPointer;
	graph   = g;
	ref	= r;
	data    = d;
	init();
    }

    // this function is iterator-spezific and must set the id !!!
    protected abstract void init();
    
    synchronized public boolean hasNext()
        { return native_edgeIterHasNext(graphJavaPointer, refIter, refBegin, refEnd, type); }

    synchronized public Edge next()
        { return native_edgeIter_next(graphJavaPointer, refIter, refBegin, type); }

    synchronized public boolean hasPrev()
        { return native_edgeIterHasPrev(graphJavaPointer, refIter, refBegin, refEnd, type); }

    synchronized public Edge prev()
        { return native_edgeIter_prev(graphJavaPointer, refIter, refBegin, type); }

    protected void finalize()
	throws Throwable
    { 
	native_edgeIter_release(graphJavaPointer, refIter, refBegin, refEnd, type);
	if (data != -1)
	    native_release_data(data);
	super.finalize();
    }

    // variables
    protected long refBegin;	    // pointer to iterator
    protected long refIter;	    // pointer to iterator
    protected long refEnd;	    // pointer to endIterator
    
    protected long data;	    // pointer to extra data structure -- not neccessary
    
    protected long graphJavaPointer;// graph_id
    protected long graph;	    // graph_id
    protected long gtl;		    // graph_id

    protected long type;	    // type of iterator
    protected long ref;		    // for some iterators we need a reference to a node/edge
    
    // native functions - iterators
    protected native boolean native_edgeIterHasNext(long gid, long it, long begin, long end, long type);
    protected native Edge native_edgeIter_next(long gid, long it, long begin, long type);
    protected native boolean native_edgeIterHasPrev(long gid, long it, long begin, long end, long type);
    protected native Edge native_edgeIter_prev(long gid, long it, long begin, long type);

    protected native void native_edgeIter_release(long gid, long it, long begin, long end, long type);
    protected native void native_release_data(long data);
}
