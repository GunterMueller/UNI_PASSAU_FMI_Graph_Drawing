/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GML_Error.java
//
// ***************************************************************************

package gtl;

/**
 * Contains informations about reason and
 * position of an error in an GML file.
 */
public class GML_Error {

    // **************************************************
    //
    // constants
    //
    // **************************************************
    
    /** unexpected keyword */
    public static final int GML_UNEXPECTED	    = 0;
    /** syntax error */
    public static final int GML_SYNTAX		    = 1;
    /** premature eof */
    public static final int GML_PREMATURE_EOF	    = 2;
    /** too many digits */
    public static final int GML_TOO_MANY_DIGITS	    = 3;
    /** open bracket left */
    public static final int GML_OPEN_BRACKET	    = 4;
    /** too many brackets */
    public static final int GML_TOO_MANY_BRACKETS   = 5;
    /** all ok */
    public static final int GML_OK		    = 6;
    /** file not found */
    public static final int GML_FILE_NOT_FOUND	    = 7;

    // **************************************************
    //
    // constructor
    //
    // **************************************************

    /**
     * Constructs GML_Error
     *
     * @param error	error message number
     * @param line	line where error occurred
     * @param column	column where error occured
     */
    protected GML_Error (int error, int line, int column)
    {
	mErrorValue = error;
	mLine = line;
	mColumn = column;
    }

    // **************************************************
    //
    // access function
    //
    // **************************************************

    /**
     * Returns the error description.
     *
     * @return error description
     */
    public int error()
    {
	return mErrorValue;
    }
    
    /**
     * Returns the line where the error was detected. This will
     * usually be near the line where the error really is
     * located.
     *
     * @return line where error was detected
     */
    public int line()
    {
	return mLine;
    }

    /**
     * Returns the column where the error was detected.
     *
     * @return column where the error was detected
     */
    public int column()
    {
	return mColumn;
    }

    // **************************************************
    //
    // variables
    //
    // **************************************************

    private int mErrorValue;
    private int mLine;
    private int mColumn;
}
