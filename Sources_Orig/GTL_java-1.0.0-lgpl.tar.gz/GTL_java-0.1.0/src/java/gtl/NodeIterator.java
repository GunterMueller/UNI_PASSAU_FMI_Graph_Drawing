/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// node_iterator.java
//
// interface
//
// ***************************************************************************

package gtl;

/**
 * Interface representing an iterator through a list of nodes.
 *
 * Usage: 
 * <pre>
 * Graph g = new GTL_Graph();
 * NodeIterator it = g.getNodeIterator();
 * while(it.hasNext())
 * {
 *     Node n = it.next();
 *     ...
 * }
 * </pre>
 */
public interface NodeIterator
{
    /**
     * Checks whether a next node exists.
     *
     * @return true iff a next node exists
     */
    public boolean hasNext();
    
    /**
     * Returns next node.
     *
     * @return next node
     */
    public Node next();

    /**
     * Checks whether a previous node exists.
     *
     * @return true iff a previous node exists
     */
    public boolean hasPrev();
    
    /**
     * Returns previous node.
     *
     * @return previous node
     */
    public Node prev();
}
