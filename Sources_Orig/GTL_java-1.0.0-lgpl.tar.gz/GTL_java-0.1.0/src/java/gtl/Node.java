/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// Node.java
//
// contains definition of class Node
//
// ***************************************************************************

package gtl;

/**
 * Interface representing a node in a graph.
 */
public interface Node
{
    // **************************************************
    //
    // access functions
    //
    // **************************************************
    
    /**
     * Returns the global reference of the node. (c++)
     *
     * @return global reference
     */
    public long getRef();

    // **************************************************
    //
    // gtl-interface functions
    //
    // **************************************************

    /**
     * Returns the degree of the node, i. e. <code>outdeg() + indeg()</code>.
     *
     * @return no. of edges
     */
    public int getDegree();

    /**
     * Returns the out degree of the node, i. e. the number of out edges.
     *
     * @return no. of out-edges
     */
    public int getOutdeg();

    /**
     * Returns the in degree of the node, i. e. the number of in edges.
     *
     * @return no. of in-edges
     */
    public int getIndeg();

    /**
     * Returns the node on the opposite side of <code>e</code>.
     * 
     * @param e an edge incident to the node
     * @return node on the opposite side of <code>e</code>
     */
    public Node getOpposite(Edge e);

    /**
     * Returns whether <code>obj</code> represents the same node.
     *
     * @return true iff <code>obj</code> represents the same node
     */
    public boolean equals (Object obj);

    /**
     * Returns true iff node is hidden.
     *
     * @return true iff node is hidden
     */
    public boolean isHidden ();

    /**
     * Returns the eccentricity of the node, i.e. the maximum graph
     * distance to another node
     *
     * @return eccentricity of the node
     */
    public int getEccentricity();
    /* for compatibility */
    public int getExcentricity();

    /**
     * Returns an iterator through the adjacent nodes.
     *
     * @return iterator through the adjacent nodes
     */
    public NodeIterator getAdjNodesIterator();

    /**
     * Returns an iterator through all in-edges.
     *
     * @return iterator through all in-edges
     */
    public EdgeIterator getInEdgesIterator();

    /**
     * Returns an iterator through all out-edges.
     *
     * @return iterator through all out-edges
     */
    public EdgeIterator getOutEdgesIterator();

    /**
     * Returns an iterator through all adjeacent edges.
     *
     * @return iterator through all adjacent edges
     */
    public EdgeIterator getAdjEdgesIterator();

    /**
     * Returns an iterator through all edges.
     *
     * @return iterator through all edges
     */
    public EdgeIterator getInoutEdgesIterator();
}
