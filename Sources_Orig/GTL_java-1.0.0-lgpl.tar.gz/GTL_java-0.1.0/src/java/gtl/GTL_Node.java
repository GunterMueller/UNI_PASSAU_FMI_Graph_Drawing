/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GTL_Node.java
//
// contains definition of class Node and NodeIterator
//
// ***************************************************************************

package gtl;

final class GTL_Node implements Node
{
    // **************************************************
    //
    // constructors
    //
    // **************************************************
    public GTL_Node(long graph, long toolPointer)
    { 
	graph = graph;
	graphJavaPointer = toolPointer;
    }

    // **************************************************
    //
    // internal functions
    //
    // **************************************************

    /** 
     * function must be native - otherwise a ref
     * to a graph is stored ... that's a problem
     */
    private long getGraphJavaPointer()
    {
	return graphJavaPointer;
    }

    private Graph getGraph()
    {
	Graph g = nativeGetGraph(graphJavaPointer);
	return g;
    }

    // **************************************************
    //
    // public functions
    //
    // **************************************************

    public int getDegree()
    { 
	return nativeNodeDegree(graphJavaPointer, ref);
    }
    
    public int getOutdeg()
    { 
	return nativeNodeOutdeg(graphJavaPointer, ref); 
    }
    
    public int getIndeg()
    { 
	return nativeNodeIndeg(graphJavaPointer, ref); 
    }
    
    public int getId()
    { 
	return nativeNodeId(graphJavaPointer, ref); 
    }
    
    public Node getOpposite(Edge e)
    { 
	return nativeNodeOpposite(graphJavaPointer, ref, e.getRef()); 
    }

    public long getRef()
    { 
	return ref; 
    }

    // usefull public functions - e.graph. for hashMap, comparison and so on
    public boolean equals (Object obj)
    {
	if (obj instanceof GTL_Node)
	{
	    GTL_Node n = (GTL_Node)obj;

	    if ((graph == n.graph) && (getId() == n.getId()))
		return true;
	    else
		return false;
	}
	return false;
    }

    public int hashCode()
    {
	return getId();
    }

    public boolean isHidden ()
    {
	return nativeIsHidden(graphJavaPointer, ref);
    }

    public int getEccentricity()
    {
	return nativeExcentricity(graphJavaPointer, ref);
    }

    public int getExcentricity()
    {
	return getEccentricity();
    }

    // **************************************************
    //
    // iterators access functions
    //
    // **************************************************

    public EdgeIterator getInEdgesIterator()
    {
	return new InEdgesIterator(graphJavaPointer, graph, ref);
    }

    public EdgeIterator getOutEdgesIterator()
    {
	return new OutEdgesIterator(graphJavaPointer, graph, ref);
    }

    public NodeIterator getAdjNodesIterator()
    {
	return new AdjNodesIterator(graphJavaPointer, graph, ref);
    }

    public EdgeIterator getAdjEdgesIterator()
    {
	return new AdjEdgesIterator(graphJavaPointer, graph, ref);
    }

    public EdgeIterator getInoutEdgesIterator()
    {
	return new InoutEdgesIterator(graphJavaPointer, graph, ref);
    }
    
    // **************************************************
    //
    // iterators
    //
    // **************************************************

    final class InEdgesIterator extends GTL_EdgeIterator
    {
	InEdgesIterator(long toolPointer, long graph, long ref)
	    { super(toolPointer, graph, ref); }

	protected void init()
	    { nativeInEdgesIterInit(this.graphJavaPointer, this.ref); }

	// native functions
	private native void nativeInEdgesIterInit(long gid, long ref);
    }
    
    final class OutEdgesIterator extends GTL_EdgeIterator
    {
	OutEdgesIterator(long toolPointer, long graph, long ref)
	    { super(toolPointer, graph, ref); }

	protected void init()
	{ 
	    nativeOutEdgesIterInit(this.graphJavaPointer, this.ref); 
	}

	// native functions
	private native void nativeOutEdgesIterInit(long gid, long ref);
    }

    final class AdjEdgesIterator extends GTL_EdgeIterator
    {
	AdjEdgesIterator(long toolPointer, long graph, long ref)
	    { super(toolPointer, graph, ref); }

	protected void init()
	    { native_adjEdgesIterInit(this.graphJavaPointer, this.ref); }

	// native functions
	private native void native_adjEdgesIterInit(long gid, long ref);
    }

    final class InoutEdgesIterator extends GTL_EdgeIterator
    {
	InoutEdgesIterator(long toolPointer, long graph, long ref)
	    { super(toolPointer, graph, ref); }

	protected void init()
	    { nativeInoutEdgesIterInit(this.graphJavaPointer, this.ref); }

	// native functions
	private native void nativeInoutEdgesIterInit(long gid, long ref);
    }

    final class AdjNodesIterator extends GTL_NodeIterator
    {
	AdjNodesIterator(long toolPointer, long graph, long ref)
	    { super(toolPointer, graph, ref); }

	protected void init()
	    { native_adjNodesIterInit(this.graphJavaPointer, this.ref); }

	// native functions
	private native void native_adjNodesIterInit(long gid, long ref);
    }

    // **************************************************
    //
    // variabels
    //
    // **************************************************
    
    private long ref;		  // global reference
    private long graphJavaPointer; // pointer to graph reference
    private long graph;		  // pointer to graph reference

    // **************************************************
    //
    // native functions
    //
    // **************************************************
    
    private native int nativeExcentricity(long gid, long ref);
    private native boolean nativeIsHidden(long gid, long ref);
    private native int nativeNodeDegree(long gid, long ref);
    private native int nativeNodeOutdeg(long gid, long ref);
    private native int nativeNodeIndeg(long gid, long ref);
    private native Node nativeNodeOpposite(long gid, long ref, long edge);
    private native int nativeNodeId(long gid, long ref);
    private native Graph nativeGetGraph(long gid);
}
