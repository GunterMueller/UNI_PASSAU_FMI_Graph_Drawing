/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GTL_edge_iterator.cpp
//
// contains native functions od GTL_edge_iterator
//
// ***************************************************************************


#include <GTL_java/JNI/gtl_GTL_0005fEdgeIterator.h>
#include <GTL_java/graph_java.h>


// ***************************************************************************
// edge_iterator


JNIEXPORT jboolean JNICALL Java_gtl_GTL_1EdgeIterator_native_1edgeIterHasNext
  (JNIEnv*, jobject, jlong gid, jlong iter, jlong begin, jlong end, jlong type)
{
    switch (type) {
	case(ITT_edge_list_iterator): 
		return (*(list<edge>::iterator*)iter) != (*(list<edge>::iterator*)end);
	case(ITT_adj_edges_iterator):
		return (*(node::adj_edges_iterator*)iter) != (*(node::adj_edges_iterator*)end);
	case(ITT_inout_edges_iterator):
		return (*(node::inout_edges_iterator*)iter) != (*(node::inout_edges_iterator*)end);
	default: assert(false);
    }
    return NULL;
}

JNIEXPORT jboolean JNICALL Java_gtl_GTL_1EdgeIterator_native_1edgeIterHasPrev
  (JNIEnv*, jobject, jlong gid, jlong iter, jlong begin, jlong end, jlong type)
{
    switch (type) {
	case(ITT_edge_list_iterator):
	    return (*(list<edge>::iterator*)iter) != (*(list<edge>::iterator*)begin);
	case(ITT_adj_edges_iterator):
	    return (*(node::adj_edges_iterator*)iter) != (*(node::adj_edges_iterator*)begin);
	case(ITT_inout_edges_iterator):
	    return (*(node::inout_edges_iterator*)iter) != (*(node::inout_edges_iterator*)begin);
	default: assert(false);
    }
    return false;
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1EdgeIterator_native_1edgeIter_1next
  (JNIEnv*, jobject, jlong gid, jlong iter, jlong begin, jlong type)
{
    jobject result;

    // move iterator to next element and return current element
    switch (type) {
	case(ITT_edge_list_iterator):
	    result = ((graph_java*)gid)->get_obj( *(*(list<edge>::iterator*)iter));
	    ++(*(list<edge>::iterator*)iter);
	    return result;
	case(ITT_adj_edges_iterator):
	    result = ((graph_java*)gid)->get_obj( *(*(node::adj_edges_iterator*)iter));
	    ++(*(node::adj_edges_iterator*)iter);
	    return result;
	case(ITT_inout_edges_iterator):
	    result = ((graph_java*)gid)->get_obj( *(*(node::inout_edges_iterator*)iter));
	    ++(*(node::inout_edges_iterator*)iter);
	    return result;
	default: assert(false);
    }
    return NULL;
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1EdgeIterator_native_1edgeIter_1prev
  (JNIEnv*, jobject, jlong gid, jlong iter, jlong begin, jlong type)
{
    // get current element, move iterator, return backuped element
    switch (type) {
	case(ITT_edge_list_iterator):
	    --(*(list<edge>::iterator*)iter);
	    return ((graph_java*)gid)->get_obj( *(*(list<edge>::iterator*)iter));
	case(ITT_adj_edges_iterator):
	    --(*(node::adj_edges_iterator*)iter);
	    return ((graph_java*)gid)->get_obj( *(*(node::adj_edges_iterator*)iter));
	case(ITT_inout_edges_iterator):
	    --(*(node::inout_edges_iterator*)iter);
	    return ((graph_java*)gid)->get_obj( *(*(node::inout_edges_iterator*)iter));
	default: assert(false);
    }
    return NULL;
}

JNIEXPORT void JNICALL Java_gtl_GTL_1EdgeIterator_native_1edgeIter_1release
  (JNIEnv*, jobject, jlong gid, jlong iter, jlong begin, jlong end, jlong type)
{
    switch (type) {
	case(ITT_edge_list_iterator):
	    delete (list<edge>::iterator*)begin;
	    delete (list<edge>::iterator*)iter;
	    delete (list<edge>::iterator*)end;
	    break;
	case(ITT_adj_edges_iterator):
	    delete (node::adj_edges_iterator*)begin;
	    delete (node::adj_edges_iterator*)iter;
	    delete (node::adj_edges_iterator*)end;
	    break;
	case(ITT_inout_edges_iterator):
	    delete (node::inout_edges_iterator*)begin;
	    delete (node::inout_edges_iterator*)iter;
	    delete (node::inout_edges_iterator*)end;
	    break;
	default: assert(false);
    }
}

JNIEXPORT void JNICALL Java_gtl_GTL_1EdgeIterator_native_1release_1data
  (JNIEnv *, jobject, jlong data)
{
    delete (iterator_data*)data;
}
