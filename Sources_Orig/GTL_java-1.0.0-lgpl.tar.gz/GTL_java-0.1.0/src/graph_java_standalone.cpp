/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// graph_java_standalone.cpp
//
// ***************************************************************************

#pragma warning (disable: 4786)

#include <GTL_java/graph_java_standalone.h>

GTL_graph_java::GTL_graph_java(JNIEnv* e, jobject o)
    :graph()
{
    env = e;
    obj = o;
    cls = JNI_Util::getObjectClass(env, obj);

    status_clear_allowed = true;

    cls_list = JNI_Util::getClass(env, "java/util/LinkedList");

    edge_obj[edge()] = 0;
    node_obj[node()] = 0;

    init_node = JNI_Util::getMethodID(env, "gtl/GTL_Node", "<init>", "(JJ)V");
    init_edge = JNI_Util::getMethodID(env, "gtl/GTL_Edge", "<init>", "(JJ)V");
    init_list = JNI_Util::getMethodID(env, "java/util/LinkedList", "<init>", "()V");

    add_list = JNI_Util::getMethodID(env, cls_list, "add", "(Ljava/lang/Object;)Z");

    // node - handler
    mid_pre_new_node_handler = JNI_Util::getMethodID(env,cls,"preNewNodeHandler","()V");
    mid_post_new_node_handler = JNI_Util::getMethodID(env, cls,"postNewNodeHandler","(Lgtl/Node;)V");
    mid_pre_del_node_handler = JNI_Util::getMethodID(env, cls,"preDelNodeHandler","(Lgtl/Node;)V");
    mid_post_del_node_handler = JNI_Util::getMethodID(env, cls,"postDelNodeHandler","()V");
    mid_pre_hide_node_handler = JNI_Util::getMethodID(env, cls,"preHideNodeHandler","(Lgtl/Node;)V");
    mid_post_hide_node_handler = JNI_Util::getMethodID(env, cls,"postHideNodeHandler","(Lgtl/Node;)V");
    mid_pre_restore_node_handler = JNI_Util::getMethodID(env, cls,"preRestoreNodeHandler","(Lgtl/Node;)V");
    mid_post_restore_node_handler = JNI_Util::getMethodID(env, cls,"postRestoreNodeHandler","(Lgtl/Node;)V");
    
    // edge - handler
    mid_pre_new_edge_handler = JNI_Util::getMethodID(env, cls,"preNewEdgeHandler","(Lgtl/Node;Lgtl/Node;)V");
    mid_post_new_edge_handler = JNI_Util::getMethodID(env, cls,"postNewEdgeHandler","(Lgtl/Edge;)V");
    mid_pre_del_edge_handler = JNI_Util::getMethodID(env, cls,"preDelEdgeHandler","(Lgtl/Edge;)V");
    mid_post_del_edge_handler = JNI_Util::getMethodID(env, cls,"postDelEdgeHandler","(Lgtl/Node;Lgtl/Node;)V");
    mid_pre_hide_edge_handler = JNI_Util::getMethodID(env, cls,"preHideEdgeHandler","(Lgtl/Edge;)V");
    mid_post_hide_edge_handler = JNI_Util::getMethodID(env, cls,"postHideEdgeHandler","(Lgtl/Edge;)V");
    mid_pre_restore_edge_handler = JNI_Util::getMethodID(env, cls,"preRestoreEdgeHandler","(Lgtl/Edge;)V");
    mid_post_restore_edge_handler = JNI_Util::getMethodID(env, cls,"postRestoreEdgeHandler","(Lgtl/Edge;)V");

    // global handlers
    mid_pre_clear_handler = JNI_Util::getMethodID(env, cls,"preClearHandler","()V");
    mid_post_clear_handler = JNI_Util::getMethodID(env, cls,"postClearHandler","()V");
    mid_pre_make_directed_handler = JNI_Util::getMethodID(env, cls,"preMakeDirectedHandler","()V");
    mid_post_make_directed_handler = JNI_Util::getMethodID(env, cls,"postMakeDirectedHandler","()V");
    mid_pre_make_undirected_handler = JNI_Util::getMethodID(env, cls,"preMakeUndirectedHandler","()V");
    mid_post_make_undirected_handler = JNI_Util::getMethodID(env, cls,"postMakeUndirectedHandler","()V");
    // check whether all is correct

    assert(init_node != 0);
    assert(init_edge != 0);
    assert(init_list != 0);

    assert(add_list != 0);

    // node - handler
    assert(mid_pre_new_node_handler != 0);
    assert(mid_post_new_node_handler != 0);
    assert(mid_pre_del_node_handler != 0);
    assert(mid_post_del_node_handler != 0);
    assert(mid_pre_hide_node_handler != 0);
    assert(mid_post_hide_node_handler != 0);
    assert(mid_pre_restore_node_handler != 0);
    assert(mid_post_restore_node_handler != 0);
    
    // edge - handler
    assert(mid_pre_new_edge_handler != 0);
    assert(mid_post_new_edge_handler != 0);
    assert(mid_pre_del_edge_handler != 0);
    assert(mid_post_del_edge_handler != 0);
    assert(mid_pre_hide_edge_handler != 0);
    assert(mid_post_hide_edge_handler != 0);
    assert(mid_pre_restore_edge_handler != 0);
    assert(mid_post_restore_edge_handler != 0);

    // global handlers
    assert(mid_pre_clear_handler != 0);
    assert(mid_post_clear_handler != 0);
    assert(mid_pre_make_directed_handler != 0);
    assert(mid_post_make_directed_handler != 0);
    assert(mid_pre_make_undirected_handler != 0);
    assert(mid_post_make_undirected_handler != 0);
}

GTL_graph_java::~GTL_graph_java()
{
    // define code of graph::~graph();
    // and make sure no method is called for the object

    status_clear_allowed = false;
    clear();

    // make sure all global references are cleared
    for (map<node, jobject>::iterator nit = node_obj.begin(); nit != node_obj.end(); ++nit)
	env->DeleteGlobalRef(nit->second);
    
    for (map<edge, jobject>::iterator eit = edge_obj.begin(); eit != edge_obj.end(); ++eit)
	env->DeleteGlobalRef(eit->second);

    for (map<string, jclass>::iterator it = classMap.begin(); it != classMap.end(); ++it)
	env->DeleteGlobalRef(it->second);
}

// ***************************************************************************
// java access functions

jclass GTL_graph_java::getClass(string className)
{
    jclass cls = classMap[className];
    if (cls == jclass())
    {
	cls = env->FindClass(className.c_str());
	assert (cls != 0);
	cls = (jclass)env->NewGlobalRef(cls);
	classMap[className] = cls;
	return cls;
    }
    else
	return cls;
}

jmethodID GTL_graph_java::getMethodID(string className, string methodName, string signature)
{
    string mappingName = className+methodName+signature;
    jmethodID id = methodMap[mappingName];
    if (id == jmethodID())
    {
	jclass cls = getClass(className);
	assert (cls != 0);

	id = JNI_Util::getMethodID(env, cls, methodName.c_str(), signature.c_str());
	assert (id != 0);

	methodMap[mappingName] = id;
	return id;
    }
    else
	return id;
}

// ***************************************************************************
// object functions

jobject GTL_graph_java::get_obj()
{
    return obj;
}

// ***************************************************************************
// node functions

node& GTL_graph_java::get_node(jobject obj)
{
    return obj_node[obj];
}

jobject GTL_graph_java::get_obj(const node& n)
{
    return node_obj[n];
}

// ***************************************************************************
// edge-functions

edge& GTL_graph_java::get_edge(jobject obj)
{
    return obj_edge[obj];
}

jobject GTL_graph_java::get_obj(const edge& e)
{
    return edge_obj[e];
}

// ***************************************************************************
// convert list

jobject GTL_graph_java::convert_list(const list<node> &l)
{
    // first of all generate a new List, we use java.util.LinkedLists
    jobject obj = env->NewWeakGlobalRef(
	env->NewObject(cls_list, init_list));

    // o.k. here we are, we have a list, now we just need to copy
    // all elements of our real list l to the new java-list
    list<node>::const_iterator it = l.begin();
    list<node>::const_iterator end = l.end();

    for (; it != end; ++it)
    {
	env->CallBooleanMethod(obj, add_list, get_obj(*it));
    }

    return obj;
}

jobject GTL_graph_java::convert_list(const list<edge> &l)
{
    // first of all generate a new List, we use java.util.LinkedLists
    jobject obj = env->NewWeakGlobalRef(
	env->NewObject(cls_list, init_list));

    // o.k. here we are, we have a list, now we just need to copy
    // all elements of our real list l to the new java-list
    list<edge>::const_iterator it = l.begin();
    list<edge>::const_iterator end = l.end();
    
    for (; it != end; ++it)
    {
	env->CallBooleanMethod(obj, add_list, get_obj(*it));
    }

    return obj;
}

jobject GTL_graph_java::convert_list(const list<string> &l)
{
    // first of all generate a new List, we use java.util.LinkedLists
    jobject obj = env->NewWeakGlobalRef(
	env->NewObject(cls_list, init_list));

    // o.k. here we are, we have a list, now we just need to copy
    // all elements of our real list l to the new java-list
    list<string>::const_iterator it = l.begin();
    list<string>::const_iterator end = l.end();

    for (; it != end; ++it)
    {
	env->CallBooleanMethod(obj, add_list, 
	    env->NewStringUTF((*it).c_str()));
    }

    return obj;
}

// ***************************************************************************
// graph handlers
    
// before deleting graph
void GTL_graph_java::pre_clear_handler()
{
    if (status_clear_allowed)
	env->CallVoidMethod(obj, mid_pre_clear_handler);

    baseclass::pre_clear_handler();
}

// after deleting graph
void GTL_graph_java::post_clear_handler()
{
    baseclass::post_clear_handler();

    if (status_clear_allowed)
	env->CallVoidMethod(obj, mid_post_clear_handler);
}

// ***************************************************************************
// direction handler

void GTL_graph_java::pre_make_directed_handler()
{
    env->CallVoidMethod(obj, mid_pre_make_directed_handler);
    baseclass::pre_make_directed_handler();
}

void GTL_graph_java::post_make_directed_handler()
{
    baseclass::post_make_directed_handler();
    env->CallVoidMethod(obj, mid_post_make_directed_handler);
}

void GTL_graph_java::pre_make_undirected_handler()
{
    env->CallVoidMethod(obj, mid_pre_make_undirected_handler);
    baseclass::pre_make_undirected_handler();
}

void GTL_graph_java::post_make_undirected_handler()
{
    baseclass::pre_make_undirected_handler();
    env->CallVoidMethod(obj, mid_post_make_undirected_handler);
}

// ***************************************************************************
// node handlers
    
// before inserting a node
void GTL_graph_java::pre_new_node_handler()
{
    env->CallVoidMethod(obj, mid_pre_new_node_handler);
    baseclass::pre_new_node_handler();
}

// after inserting node v
void GTL_graph_java::post_new_node_handler(node n)
{
    baseclass::post_new_node_handler(n);

    jclass cls;

    // generate a new java-node
    cls = JNI_Util::getClass(env, "gtl/GTL_Node");
    jobject jnode = JNI_Util::getNewGtlNode(env, (jlong)((graph*)this),
	(jlong)((graph_java*)this));

    // and set global reference in the node
    jfieldID fid = env->GetFieldID(cls, "ref", "J");
    env->SetLongField(jnode, fid, (jlong)jnode);

    // store objects
    node_obj[n] = jnode;
    obj_node[jnode] = n;

    // and call the java-handler with the new node
    env->CallVoidMethod(obj, mid_post_new_node_handler, get_obj(n));
}

void GTL_graph_java::pre_del_node_handler(node n)
{
    // call java-handler
    env->CallVoidMethod(obj, mid_pre_del_node_handler, get_obj(n));
    
    baseclass::pre_del_node_handler(n);

    // when you want to delete a node, we first delete the 
    // reference for java and the entries in our maps
    jobject jnode = node_obj[n];

    // and delete node
    obj_node.erase(jnode);
    node_obj[n] = NULL;
    env->DeleteGlobalRef(jnode);
}

// after deleting a node
void GTL_graph_java::post_del_node_handler()
{
    baseclass::post_del_node_handler();

    env->CallVoidMethod(obj, mid_post_del_node_handler);
}

// ***************************************************************************
// edge handlers
    
// before creating (v,w)
void GTL_graph_java::pre_new_edge_handler(node n1, node n2)
{
    env->CallVoidMethod(obj, mid_pre_new_edge_handler, get_obj(n1), get_obj(n2));
    baseclass::pre_new_edge_handler(n1, n2);
}

// after insertion of e
void GTL_graph_java::post_new_edge_handler(edge e)
{

    baseclass::post_new_edge_handler (e);

    jclass cls;

    // generate a new java-edge
    cls = JNI_Util::getClass(env, "gtl/GTL_Edge");
    jobject jedge = JNI_Util::getNewGtlEdge(env, (jlong)((graph*)this), 
	    (jlong)((graph_java*)this));

    // and set global reference
    jfieldID fid = env->GetFieldID(cls, "ref", "J");
    env->SetLongField(jedge, fid, (jlong)jedge);

    // store references to node
    edge_obj[e] = jedge;
    obj_edge[jedge] = e;

    // and call java-handler
    env->CallVoidMethod(obj, mid_post_new_edge_handler, get_obj(e));
}

// before deleteing edge e
void GTL_graph_java::pre_del_edge_handler(edge e)
{
    // call java-handler
    env->CallVoidMethod(obj, mid_pre_del_edge_handler, get_obj(e));

    baseclass::pre_del_edge_handler(e);

    // get object
    jobject jedge = edge_obj[e];

    // and erase obejct
    obj_edge.erase(jedge);
    edge_obj[e] = NULL;
    env->DeleteGlobalRef(jedge);
}

// after deletion of (v,w)
void GTL_graph_java::post_del_edge_handler(node n1, node n2)
{
    baseclass::post_del_edge_handler(n1, n2);
    env->CallVoidMethod(obj, mid_post_del_edge_handler, get_obj(n1), get_obj(n2));
}

//
// Hiding edges
//
    
// before hiding edge e
void GTL_graph_java::pre_hide_edge_handler(edge e)
{
    env->CallVoidMethod(obj, mid_pre_hide_edge_handler, get_obj(e));
    baseclass::pre_hide_edge_handler(e);
}

// after hiding edge e
void GTL_graph_java::post_hide_edge_handler(edge e)
{
    baseclass::post_hide_edge_handler(e);
    env->CallVoidMethod(obj, mid_post_hide_edge_handler, get_obj(e));
}

// before restoring edge e
void GTL_graph_java::pre_restore_edge_handler(edge e)
{
    env->CallVoidMethod(obj, mid_pre_restore_edge_handler, get_obj(e));
    baseclass::pre_restore_edge_handler(e);
}

// after restoring edge e
void GTL_graph_java::post_restore_edge_handler(edge e)
{
    baseclass::post_restore_edge_handler(e);
    env->CallVoidMethod(obj, mid_post_restore_edge_handler, get_obj(e));
}

//
// Hiding nodes
//
    
// before hiding node e
void GTL_graph_java::pre_hide_node_handler(node e)
{
    env->CallVoidMethod(obj, mid_pre_hide_node_handler, get_obj(e));
    baseclass::pre_hide_node_handler(e);
}

// after hiding node e
void GTL_graph_java::post_hide_node_handler(node e)
{
    baseclass::post_hide_node_handler(e);
    env->CallVoidMethod(obj, mid_post_hide_node_handler, get_obj(e));
}

// before restoring node e
void GTL_graph_java::pre_restore_node_handler(node e)
{
    env->CallVoidMethod(obj, mid_pre_restore_node_handler, get_obj(e));
    baseclass::pre_restore_node_handler(e);
}

// after restoring node e
void GTL_graph_java::post_restore_node_handler(node e)
{
    baseclass::post_restore_node_handler(e);
    env->CallVoidMethod(obj, mid_post_restore_node_handler, get_obj(e));
}



