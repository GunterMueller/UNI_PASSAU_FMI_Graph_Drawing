/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GTL_Graph_edge_iterator.cpp
//
// ***************************************************************************

#include <GTL_java/JNI/gtl_GTL_0005fGraph_GraphEdgeIterator.h>
#include <GTL_java/JNI/gtl_GTL_0005fNode_AdjEdgesIterator.h>
#include <GTL_java/JNI/gtl_GTL_0005fNode_InoutEdgesIterator.h>
#include <GTL_java/JNI/gtl_GTL_0005fNode_InEdgesIterator.h>
#include <GTL_java/JNI/gtl_GTL_0005fNode_OutEdgesIterator.h>
#include <GTL_java/graph_java.h>

// ***************************************************************************
// edge_iterator

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_00024GraphEdgeIterator_nativeEdgeListIterInit
  (JNIEnv* env, jobject obj, jlong gid)
{
    // create a new list<edge> iterator
    graph& g = *((graph*)gid);

    list<edge>::const_iterator* begin = new list<edge>::const_iterator();
    list<edge>::const_iterator* iter = new list<edge>::const_iterator();
    list<edge>::const_iterator* end = new list<edge>::const_iterator();
    *end = g.edges_end();
    *iter = *begin = g.edges_begin();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);
    
    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_edge_list_iterator);
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Node_00024AdjEdgesIterator_native_1adjEdgesIterInit
  (JNIEnv* env, jobject obj, jlong gid, jlong ref)
{
    // create a new node::adj_edges_iterator iterator
    node& n = ((graph_java*)gid)->get_node((jobject)ref);

    node::adj_edges_iterator* begin = new node::adj_edges_iterator;
    node::adj_edges_iterator* iter = new node::adj_edges_iterator;
    node::adj_edges_iterator* end = new node::adj_edges_iterator;
    *end = n.adj_edges_end();
    *iter = *begin = n.adj_edges_begin();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_adj_edges_iterator);
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Node_00024InoutEdgesIterator_nativeInoutEdgesIterInit
  (JNIEnv* env, jobject obj, jlong gid, jlong ref)
{
    // create a new node::adj_edges_iterator iterator
    node& n = ((graph_java*)gid)->get_node((jobject)ref);

    node::inout_edges_iterator* begin = new node::inout_edges_iterator;
    node::inout_edges_iterator* iter = new node::inout_edges_iterator;
    node::inout_edges_iterator* end = new node::inout_edges_iterator;
    *iter = *begin = n.inout_edges_begin();
    *end = n.inout_edges_end();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_inout_edges_iterator);
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Node_00024InEdgesIterator_nativeInEdgesIterInit
  (JNIEnv* env, jobject obj, jlong gid, jlong ref)
{
    // create a new node::adj_edges_iterator iterator
    node& n = ((graph_java*)gid)->get_node((jobject)ref);

    list<edge>::const_iterator* begin = new list<edge>::const_iterator;
    list<edge>::const_iterator* iter = new list<edge>::const_iterator;
    list<edge>::const_iterator* end = new list<edge>::const_iterator;
    *end = n.in_edges_end();
    *iter = *begin = n.in_edges_begin();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_edge_list_iterator);
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Node_00024OutEdgesIterator_nativeOutEdgesIterInit
  (JNIEnv* env, jobject obj, jlong gid, jlong ref)
{
    // create a new node::adj_edges_iterator iterator
    node& n = ((graph_java*)gid)->get_node((jobject)ref);

    list<edge>::const_iterator* begin = new list<edge>::const_iterator;
    list<edge>::const_iterator* iter = new list<edge>::const_iterator;
    list<edge>::const_iterator* end = new list<edge>::const_iterator;
    *end = n.out_edges_end();
    *iter = *begin = n.out_edges_end();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_edge_list_iterator);
}

