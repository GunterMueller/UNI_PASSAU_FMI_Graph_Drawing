/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GTL_Graph_node_iterator.cpp
//
// ***************************************************************************

#include <GTL_java/JNI/gtl_GTL_0005fGraph_GraphNodeIterator.h>
#include <GTL_java/JNI/gtl_GTL_0005fNode_AdjNodesIterator.h>
#include <GTL_java/graph_java.h>

// ***************************************************************************
// node_iterator

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_00024GraphNodeIterator_nativeNodeListIterInit
  (JNIEnv* env, jobject obj, jlong gid)
{
    // create a new list<node> iterator
    graph& g = *((graph*)gid);

    list<node>::const_iterator* begin = new list<node>::const_iterator();
    list<node>::const_iterator* iter = new list<node>::const_iterator();
    list<node>::const_iterator* end = new list<node>::const_iterator();
    *end = g.nodes_end();
    *iter = *begin = g.nodes_begin();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_node_list_iterator);
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Node_00024AdjNodesIterator_native_1adjNodesIterInit
  (JNIEnv *env, jobject obj, jlong gid, jlong ref)
{
    // create a new node::adj_nodes_iterator iterator
    node& n = ((graph_java*)gid)->get_node((jobject)ref);

    node::adj_nodes_iterator* begin = new node::adj_nodes_iterator;
    node::adj_nodes_iterator* iter = new node::adj_nodes_iterator;
    node::adj_nodes_iterator* end = new node::adj_nodes_iterator;
    *end = n.adj_nodes_end();
    *iter = *begin = n.adj_nodes_begin();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_adj_nodes_iterator);
}

