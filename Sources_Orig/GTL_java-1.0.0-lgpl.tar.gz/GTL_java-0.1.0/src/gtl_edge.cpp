/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// Edge.cpp
//
// ***************************************************************************

#include <GTL_java/JNI/gtl_GTL_0005fEdge.h>
#include <GTL_java/graph_java.h>

// ***************************************************************************
// class Edge

JNIEXPORT jboolean JNICALL Java_gtl_GTL_1Edge_nativeIsHidden
  (JNIEnv*, jobject, jlong gid, jlong ref)
{
    return ((graph_java*)gid)->get_edge((jobject)ref).is_hidden();
}


JNIEXPORT jint JNICALL Java_gtl_GTL_1Edge_native_1edgeID
  (JNIEnv*, jobject, jlong gid, jlong ref)
{
    return ((graph_java*)gid)->get_edge((jobject)ref).id();
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Edge_native_1edgeReverse
  (JNIEnv*, jobject, jlong gid, jlong ref)
{
    ((graph_java*)gid)->get_edge((jobject)ref).reverse();
}


JNIEXPORT jobject JNICALL Java_gtl_GTL_1Edge_native_1edgeSource__JJ
  (JNIEnv*, jobject, jlong gid, jlong ref)
{
    // get jgraph
    graph_java& g = *((graph_java*)gid);
    return g.get_obj(g.get_edge((jobject)ref).source());
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Edge_native_1edgeSource__JJJ
  (JNIEnv *, jobject, jlong gid, jlong ref, jlong node)
{
    // get jgraph
    graph_java& g = *((graph_java*)gid);
    g.get_edge((jobject)ref).change_source(g.get_node((jobject)node));
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1Edge_native_1edgeTarget__JJ
  (JNIEnv*, jobject, jlong gid, jlong ref)
{
    // get jgraph
    graph_java& g = *((graph_java*)gid);
    return g.get_obj(g.get_edge((jobject)ref).target());
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Edge_native_1edgeTarget__JJJ
  (JNIEnv *, jobject, jlong gid, jlong ref, jlong node)
{
    // get jgraph
    graph_java& g = *((graph_java*)gid);
    g.get_edge((jobject)ref).change_target(g.get_node((jobject)node));
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1Edge_nativeGetGraph
  (JNIEnv *, jobject, jlong gid)
{
    return ((graph_java*)gid)->get_obj();
}
