/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GTL_node_iterator.cpp
//
// contains native functions of GTL_node_iterator
//
// ***************************************************************************

#include <GTL_java/JNI/gtl_GTL_0005fNodeIterator.h>
#include <GTL_java/graph_java.h>

// ***************************************************************************
// node_iterator

JNIEXPORT jboolean JNICALL Java_gtl_GTL_1NodeIterator_native_1node_1iter_1hasNext
  (JNIEnv*, jobject, jlong gid, jlong iter, jlong begin, jlong end, jlong type)
{
    switch (type) {
	case(ITT_node_list_iterator): 
		return (*(list<node>::iterator*)iter) != (*(list<node>::iterator*)end);
	case(ITT_adj_nodes_iterator):
		return (*(node::adj_nodes_iterator*)iter) != (*(node::adj_nodes_iterator*)end);
	case(ITT_node_list_reverse_iterator): 
		return (*(list<node>::reverse_iterator*)iter) != (*(list<node>::reverse_iterator*)end);
	default: assert(false);
    }
    return false;
}

JNIEXPORT jboolean JNICALL Java_gtl_GTL_1NodeIterator_native_1node_1iter_1hasPrev
  (JNIEnv*, jobject, jlong gid, jlong iter, jlong begin, jlong end, jlong type)
{
    switch (type) {
	case(ITT_node_list_iterator):
	    return (*(list<node>::iterator*)iter) != (*(list<node>::iterator*)begin);
	case(ITT_adj_nodes_iterator):
	    return (*(node::adj_nodes_iterator*)iter) != (*(node::adj_nodes_iterator*)begin);
	case(ITT_node_list_reverse_iterator):
	    return (*(list<node>::reverse_iterator*)iter) != (*(list<node>::reverse_iterator*)begin);
	default: assert(false);
    }
    
    return false;
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1NodeIterator_native_1node_1iter_1next
  (JNIEnv*, jobject, jlong gid, jlong iter, jlong begin, jlong type)
{
    // move iterator to next element and return current element
    jobject result;
    switch (type) {
	case(ITT_node_list_iterator):
	    result = ((graph_java*)gid)->get_obj( *(*(list<node>::iterator*)iter));
	    ++(*(list<node>::iterator*)iter);
	    return result;
	case(ITT_adj_nodes_iterator):
	    result = ((graph_java*)gid)->get_obj( *(*(node::adj_nodes_iterator*)iter));
	    ++(*(node::adj_nodes_iterator*)iter);
	    return result;
	case(ITT_node_list_reverse_iterator):
	    result = ((graph_java*)gid)->get_obj( *(*(list<node>::reverse_iterator*)iter));
	    ++(*(list<node>::reverse_iterator*)iter);
	    return result;
	default: assert(false);
    }
    return NULL;
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1NodeIterator_native_1node_1iter_1prev
  (JNIEnv*, jobject, jlong gid, jlong iter, jlong begin, jlong type)
{
    // get current element, move iterator, return backuped element
    switch (type) {
	case(ITT_node_list_iterator):
	    --(*(list<node>::iterator*)iter);
	    return ((graph_java*)gid)->get_obj( *(*(list<node>::iterator*)iter));
	case(ITT_adj_nodes_iterator):
	    --(*(node::adj_nodes_iterator*)iter);
	    return ((graph_java*)gid)->get_obj( *(*(node::adj_nodes_iterator*)iter));
	case(ITT_node_list_reverse_iterator):
	    --(*(list<node>::reverse_iterator*)iter);
	    return ((graph_java*)gid)->get_obj( *(*(list<node>::reverse_iterator*)iter));
	default: assert(false);
    }
    return NULL;
}


JNIEXPORT void JNICALL Java_gtl_GTL_1NodeIterator_native_1node_1iter_1release
  (JNIEnv*, jobject, jlong gid, jlong iter, jlong begin, jlong end, jlong type)
{
    switch (type) {
	case(ITT_node_list_iterator):
	    delete (list<node>::iterator*)begin;
	    delete (list<node>::iterator*)iter;
	    delete (list<node>::iterator*)end;
	    break;
	case(ITT_adj_nodes_iterator):
	    delete (node::adj_nodes_iterator*)begin;
	    delete (node::adj_nodes_iterator*)iter;
	    delete (node::adj_nodes_iterator*)end;
	    break;
	case(ITT_node_list_reverse_iterator):
	    delete (list<node>::reverse_iterator*)begin;
	    delete (list<node>::reverse_iterator*)iter;
	    delete (list<node>::reverse_iterator*)end;
	    break;
	default: assert(false);
    }
}

JNIEXPORT void JNICALL Java_gtl_GTL_1NodeIterator_native_1release_1data
  (JNIEnv *, jobject, jlong data)
{
    delete (iterator_data*)data;
}

