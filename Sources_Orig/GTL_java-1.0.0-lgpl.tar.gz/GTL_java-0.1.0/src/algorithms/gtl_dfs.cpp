/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// gtl_dfs.cpp
//
// contains native functions of Dfs
//
// ***************************************************************************

#pragma warning (disable: 4800)

#include <GTL_java/JNI/gtl_algorithms_Dfs.h>
#include <GTL_java/graph_java.h>
#include <GTL/dfs.h>

class my_own_dfs : public dfs
{
public:
    my_own_dfs(JNIEnv* e, jobject d)
	: dfs()
    {
	env = e;
	jdfs = d;
	jgraph = 0;
	
	jclass cls = env->GetObjectClass(jdfs);
	assert(cls != 0);
	
	// get method signatures
	init = env->GetMethodID(cls, "initHandler","()V");
	end = env->GetMethodID(cls, "endHandler","()V");
	entry = env->GetMethodID(cls, "entryHandler","(Lgtl/Node;Lgtl/Node;)V");
	leave = env->GetMethodID(cls, "leaveHandler","(Lgtl/Node;Lgtl/Node;)V");
	before = env->GetMethodID(cls, "beforeRecursiveCallHandler","(Lgtl/Edge;Lgtl/Node;)V");
	after = env->GetMethodID(cls, "afterRecursiveCallHandler","(Lgtl/Edge;Lgtl/Node;)V");
	old = env->GetMethodID(cls, "oldAdjNodeHandler","(Lgtl/Edge;Lgtl/Node;)V");
	new_start = env->GetMethodID(cls, "newStartHandler","(Lgtl/Node;)V");
	
	assert(init != 0);
	assert(end != 0);
	assert(entry != 0);
	assert(leave != 0);
	assert(before != 0);
	assert(after != 0);
	assert(old != 0);
	assert(new_start != 0);
    }
    
    void set_jgraph(graph_java* jg)
    {
	jgraph = jg;
    }
    
    void init_handler (graph& G) 
    { env->CallVoidMethod(jdfs, init); }
    
    void end_handler (graph& G)
    { env->CallVoidMethod(jdfs, end); }
    
    void entry_handler (graph& G, node& n, node& f)
    { env->CallVoidMethod(jdfs, entry, jgraph->get_obj(n), jgraph->get_obj(f)); }
    
    void leave_handler (graph& G, node& n, node& f)
    { env->CallVoidMethod(jdfs, leave, jgraph->get_obj(n), jgraph->get_obj(f)); }
    
    void before_recursive_call_handler (graph& G, edge& e, node& n) 
    { env->CallVoidMethod(jdfs, before, jgraph->get_obj(e), jgraph->get_obj(n)); }
    
    void after_recursive_call_handler (graph& G, edge& e, node& n) 
    { env->CallVoidMethod(jdfs, after, jgraph->get_obj(e), jgraph->get_obj(n)); }
    
    void old_adj_node_handler (graph& G, edge& e, node& n) 
    { env->CallVoidMethod(jdfs, old, jgraph->get_obj(e), jgraph->get_obj(n)); }
    
    void new_start_handler (graph& G, node& n)    
    { env->CallVoidMethod(jdfs, new_start, jgraph->get_obj(n)); }

private:
    JNIEnv* env;
    jobject jdfs;

    jmethodID init;
    jmethodID end;
    jmethodID entry;
    jmethodID leave;
    jmethodID before;
    jmethodID after;
    jmethodID old;
    jmethodID new_start;

    graph_java* jgraph;
};


JNIEXPORT void JNICALL Java_gtl_algorithms_Dfs_nativeAttach
  (JNIEnv *, jobject, jlong jdfs, jlong jtool)
{
    my_own_dfs& Dfs = *((my_own_dfs*)jdfs);
    Dfs.set_jgraph((graph_java*)jtool);
}

JNIEXPORT jboolean JNICALL Java_gtl_algorithms_Dfs_nativeCalcCompNum__J
  (JNIEnv *, jobject, jlong jdfs)
{
    return ((dfs*)jdfs)->calc_comp_num();
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Dfs_nativeCalcCompNum__JZ
  (JNIEnv *, jobject, jlong jdfs, jboolean set)
{
    ((dfs*)jdfs)->calc_comp_num(set);
}

JNIEXPORT jint JNICALL Java_gtl_algorithms_Dfs_nativeCheck
  (JNIEnv *, jobject, jlong jgtl, jlong jdfs)
{
    dfs& Dfs = *((dfs*)jdfs);
    graph& g = *((graph*)jgtl);
    return Dfs.check(g);
}

JNIEXPORT jint JNICALL Java_gtl_algorithms_Dfs_nativeCompNumber
  (JNIEnv *, jobject, jlong jdfs, jlong noderef, jlong jtool)
{
    dfs& Dfs = *((dfs*)jdfs);
    graph_java& g = *((graph_java*)jtool);
    node& n = g.get_node((jobject)noderef);
    return Dfs.comp_num(n);
}


JNIEXPORT jint JNICALL Java_gtl_algorithms_Dfs_nativeDfsNumber
  (JNIEnv *, jobject, jlong jdfs, jlong noderef, jlong jtool)
{
    dfs& Dfs = *((dfs*)jdfs);
    graph_java& g = *((graph_java*)jtool);
    node& n = g.get_node((jobject)noderef);
    return Dfs.dfs_num(n);
}

JNIEXPORT jobject JNICALL Java_gtl_algorithms_Dfs_nativeFather
  (JNIEnv *, jobject, jlong jdfs, jlong noderef, jlong jtool)
{
    dfs& Dfs = *((dfs*)jdfs);
    graph_java& g = *((graph_java*)jtool);
    node& n = g.get_node((jobject)noderef);
    node father = Dfs.father(n);
    if (father == node())
	return 0;
    else
	return g.get_obj(father);
}

JNIEXPORT jlong JNICALL Java_gtl_algorithms_Dfs_nativeNew
  (JNIEnv *env, jobject obj)
{
    obj = env->NewWeakGlobalRef(obj);
    dfs* Dfs = new my_own_dfs(env, obj);
    return (jlong)Dfs;
}

JNIEXPORT jint JNICALL Java_gtl_algorithms_Dfs_nativeNumberOfReachedNodes
  (JNIEnv *, jobject, jlong jdfs)
{
    dfs& Dfs = *((dfs*)jdfs);
    return Dfs.number_of_reached_nodes();
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Dfs_nativeReset
  (JNIEnv *, jobject, jlong jdfs)
{
    dfs& Dfs = *((dfs*)jdfs);
    Dfs.reset();
}

JNIEXPORT jint JNICALL Java_gtl_algorithms_Dfs_nativeRun
  (JNIEnv *, jobject, jlong jgtl, jlong jdfs)
{
    dfs& Dfs = *((dfs*)jdfs);
    graph& g = *((graph*)jgtl);
    return Dfs.run(g);
}

JNIEXPORT jboolean JNICALL Java_gtl_algorithms_Dfs_nativeScanWholeGraph__J
  (JNIEnv *, jobject, jlong jdfs)
{
    return ((dfs*)jdfs)->scan_whole_graph();
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Dfs_nativeScanWholeGraph__JZ
  (JNIEnv *, jobject, jlong jdfs, jboolean set)
{
    ((dfs*)jdfs)->scan_whole_graph(set);
}

JNIEXPORT jobject JNICALL Java_gtl_algorithms_Dfs_nativeStartNode__JJ
  (JNIEnv *, jobject, jlong jdfs, jlong jgraph)
{
    return ((graph_java*)jgraph)->get_obj( ((dfs*)jdfs)->start_node() );
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Dfs_nativeStartNode__JJJ
  (JNIEnv *, jobject, jlong jdfs, jlong node, jlong jgraph)
{
    ((dfs*)jdfs)->start_node(((graph_java*)jgraph)->get_node((jobject)node));
}

JNIEXPORT jboolean JNICALL Java_gtl_algorithms_Dfs_nativeStoreNonTreeEdges__J
  (JNIEnv *, jobject, jlong jdfs)
{
    return ((dfs*)jdfs)->store_non_tree_edges();
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Dfs_nativeStoreNonTreeEdges__JZ
  (JNIEnv *, jobject, jlong jdfs, jboolean set)
{
    ((dfs*)jdfs)->store_non_tree_edges(set);
}


JNIEXPORT jboolean JNICALL Java_gtl_algorithms_Dfs_nativeStorePreds__J
  (JNIEnv *, jobject, jlong jdfs)
{
    return ((dfs*)jdfs)->store_preds();
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Dfs_nativeStorePreds__JZ
  (JNIEnv *, jobject, jlong jdfs, jboolean set)
{
    ((dfs*)jdfs)->store_preds(set);
}


