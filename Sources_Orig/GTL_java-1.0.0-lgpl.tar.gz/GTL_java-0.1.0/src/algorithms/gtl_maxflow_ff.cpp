/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// gtl_maxflow_ff.cpp
//
// contains native functions of maxflow
//
// ***************************************************************************

#include <GTL_java/JNI/gtl_algorithms_MaxFlow_0005fFF.h>
#include <GTL_java/graph_java.h>
#include <GTL/maxflow_ff.h>

class my_own_maxflow : public maxflow_ff
{
public:
    my_own_maxflow(JNIEnv* e, jobject d)
	: maxflow_ff()
    {
	env = e;
	jmaxflow = d;
	jgraph = 0;
	gtl_graph = 0;

	jclass clsMap = env->FindClass("java/util/Map");
	jclass clsD   = env->FindClass("java/lang/Double");
	assert(clsMap != 0);
	assert(clsD   != 0);

	// get method signatures

	get = env->GetMethodID(clsMap, "get","(Ljava/lang/Object;)Ljava/lang/Object;");
	d_val = env->GetMethodID(clsD, "doubleValue","()D");

	assert(get != 0);
	assert(d_val != 0);
    }

    edge_map<double>* make_edge_capacity(jobject map)
    {
	map = env->NewWeakGlobalRef(map);
	edge_map<double>* cap = new edge_map<double>;
	list<edge>::const_iterator it = gtl_graph->edges_begin();
	list<edge>::const_iterator end = gtl_graph->edges_end();
	for (; it != end; ++it)
	{
	    jobject Double = env->CallObjectMethod(map, get,
		jgraph->get_obj(*it));
	    (*cap)[*it] = env->CallDoubleMethod(Double, d_val);
	}

	return cap;
    }

    void set_graph(graph* gg, graph_java* jg)
    {
	jgraph = jg;
	gtl_graph  = gg;
    }

    graph* gtl()
    {
	return gtl_graph;
    }

    graph_java* jgtl()
    {
	return jgraph;
    }



private:
    JNIEnv* env;
    jobject jmaxflow;

    jmethodID get;
    jmethodID d_val;

    graph_java* jgraph;
    graph* gtl_graph;
};


JNIEXPORT jlong JNICALL Java_gtl_algorithms_MaxFlow_1FF_nativeNew
  (JNIEnv *env, jobject obj)
{
    obj = env->NewWeakGlobalRef(obj);
    my_own_maxflow* maxff = new my_own_maxflow(env, obj);
    return (jlong)maxff;
}

JNIEXPORT void JNICALL Java_gtl_algorithms_MaxFlow_1FF_nativeReset
  (JNIEnv *, jobject, jlong jmaxff)
{
    maxflow_ff& maxff = *((maxflow_ff*)jmaxff);
    maxff.reset();
}

JNIEXPORT void JNICALL Java_gtl_algorithms_MaxFlow_1FF_nativeAttach
  (JNIEnv *, jobject, jlong jmaxff, jlong jgtl, jlong jtool)
{
    my_own_maxflow& maxff = *((my_own_maxflow*)jmaxff);
    maxff.set_graph((graph*)jgtl, (graph_java*)jtool);
}


JNIEXPORT jint JNICALL Java_gtl_algorithms_MaxFlow_1FF_nativeRun
  (JNIEnv *, jobject, jlong jgtl, jlong jmaxff)
{
    maxflow_ff& maxff = *((maxflow_ff*)jmaxff);
    graph& g = *((graph*)jgtl);
    return maxff.run(g);
}

JNIEXPORT jint JNICALL Java_gtl_algorithms_MaxFlow_1FF_nativeCheck
  (JNIEnv *, jobject, jlong jgtl, jlong jmaxff)
{
    maxflow_ff& maxff = *((maxflow_ff*)jmaxff);
    graph& g = *((graph*)jgtl);
    return maxff.check(g);
}

JNIEXPORT void JNICALL Java_gtl_algorithms_MaxFlow_1FF_nativeSetVars__JLjava_util_Map_2
  (JNIEnv *, jobject, jlong jmaxff, jobject jmap)
{
    my_own_maxflow& maxff = *((my_own_maxflow*)jmaxff);
    edge_map<double>* mapping = maxff.make_edge_capacity(jmap);
    maxff.set_vars(*mapping);
    delete mapping;
}

JNIEXPORT void JNICALL Java_gtl_algorithms_MaxFlow_1FF_nativeSetVars__JLjava_util_Map_2JJ
  (JNIEnv *, jobject, jlong jmaxff, jobject jmap, jlong source, jlong target)
{
    my_own_maxflow& maxff = *((my_own_maxflow*)jmaxff);
    edge_map<double>* mapping = maxff.make_edge_capacity(jmap);
    maxff.set_vars(*mapping, maxff.jgtl()->get_node((jobject)source),
	maxff.jgtl()->get_node((jobject)target));
    delete mapping;
}

JNIEXPORT jdouble JNICALL Java_gtl_algorithms_MaxFlow_1FF_nativeMaxFlow__J
  (JNIEnv *, jobject, jlong jmaxff)
{
    my_own_maxflow& maxff = *((my_own_maxflow*)jmaxff);
    return maxff.get_max_flow();
}

JNIEXPORT jdouble JNICALL Java_gtl_algorithms_MaxFlow_1FF_nativeMaxFlow__JJ
  (JNIEnv *, jobject, jlong jmaxff, jlong edge)
{
    my_own_maxflow& maxff = *((my_own_maxflow*)jmaxff);
    return maxff.get_max_flow(maxff.jgtl()->get_edge((jobject)edge));
}


JNIEXPORT jdouble JNICALL Java_gtl_algorithms_MaxFlow_1FF_nativeRemCap
  (JNIEnv *, jobject, jlong jmaxff, jlong edge)
{
    my_own_maxflow& maxff = *((my_own_maxflow*)jmaxff);
    return maxff.get_rem_cap(maxff.jgtl()->get_edge((jobject)edge));
}

