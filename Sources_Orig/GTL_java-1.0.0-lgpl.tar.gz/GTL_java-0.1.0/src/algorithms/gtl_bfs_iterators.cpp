/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// gtl_bfs_iteratos.cpp
//
// contains native functions of Bfs
//
// ***************************************************************************

#include <GTL_java/JNI/gtl_algorithms_Bfs_BfsIterator.h>
#include <GTL_java/JNI/gtl_algorithms_Bfs_RootsIterator.h>
#include <GTL_java/JNI/gtl_algorithms_Bfs_RootsBfsIterator.h>
#include <GTL_java/JNI/gtl_algorithms_Bfs_TreeEdgesIterator.h>
#include <GTL_java/JNI/gtl_algorithms_Bfs_NonTreeEdgesIterator.h>
#include <GTL_java/graph_java.h>
#include <GTL/bfs.h>

// internal class
class bfs_data : public iterator_data
{
public:
    bfs_data(list<node>::const_iterator* d_end, 
	list<list<node>::const_iterator >::const_iterator* d_root_end)
    {
	bfs_end = d_end;
	bfs_roots_end = d_root_end;
    }

    ~bfs_data()
    {
	delete bfs_end;
	delete bfs_roots_end;
    }

    list<node>::const_iterator* bfs_end;
    list<list<node>::const_iterator >::const_iterator* bfs_roots_end;
};

JNIEXPORT void JNICALL Java_gtl_algorithms_Bfs_00024BfsIterator_nativeBfsIteratorInit
  (JNIEnv *env, jobject obj, jlong jbfs)
{
    bfs& Bfs = *((bfs*)jbfs);

    // begin and end of iterator must be set on end
    // a call of iter.next will so return the first element
    list<node>::const_iterator* begin = new list<node>::const_iterator();
    list<node>::const_iterator* iter = new list<node>::const_iterator();
    list<node>::const_iterator* end = new list<node>::const_iterator();
    *end = Bfs.end();
    *iter = *begin = Bfs.begin();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_node_list_iterator);
}

JNIEXPORT jlong JNICALL Java_gtl_algorithms_Bfs_00024RootsIterator_nativeRootsIteratorInit
  (JNIEnv *env, jobject obj, jlong jbfs)
{
    bfs& Bfs = *((bfs*)jbfs);

    // begin and end of iterator must be set on end
    // a call of iter.next will so return the first element
    list<list<node>::const_iterator >::const_iterator* begin = new list<list<node>::const_iterator >::const_iterator();
    list<list<node>::const_iterator >::const_iterator* iter = new list<list<node>::const_iterator >::const_iterator();
    list<list<node>::const_iterator >::const_iterator* end = new list<list<node>::const_iterator >::const_iterator();
    *iter = *begin = Bfs.roots_begin();
    *end = Bfs.roots_end();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);

    list<node>::const_iterator* bfs_end = new list<node>::const_iterator;
    *bfs_end = Bfs.end();
    bfs_data* bb = new bfs_data(bfs_end, end);
    return (jlong)(bb);
}

JNIEXPORT jboolean JNICALL Java_gtl_algorithms_Bfs_00024RootsIterator_nativeRootsIteratorHasNext
  (JNIEnv*, jobject, jlong iter, jlong end)
{
    // check wether the next element will be the end
    return (*(list<list<node>::const_iterator >::iterator*)iter)
	!= (*(list<list<node>::const_iterator >::iterator*)end);
}

JNIEXPORT jlong JNICALL Java_gtl_algorithms_Bfs_00024RootsIterator_nativeRootsIteratorNext
  (JNIEnv *, jobject, jlong iter)
{
    // returns the next iterator position

    // we need a temporary object, will be deleted in dfsIteratorInit
    list<list<node>::const_iterator>::iterator* tmp_iter = new list<list<node>::const_iterator>::iterator;
    *tmp_iter = *((list<list<node>::const_iterator>::iterator*)iter);

    ++(*(list<list<node>::const_iterator>::iterator*)iter);
    return (jlong)tmp_iter;
}

JNIEXPORT jlong JNICALL Java_gtl_algorithms_Bfs_00024RootsIterator_nativeRootsIteratorCopyData
  (JNIEnv *, jobject, jlong data)
{
    return (jlong)(new bfs_data(((bfs_data*)data)->bfs_end, ((bfs_data*)data)->bfs_roots_end));
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Bfs_00024RootsBfsIterator_nativeRootsBfsIteratorInit
  (JNIEnv *env, jobject obj, jlong jroots, jlong data)
{
    // get a copy of current iterator
    list<list<node>::const_iterator>::const_iterator root_tmp = 
	*((list<list<node>::const_iterator>::const_iterator*)jroots);

    // delete temporary iterator
    delete (list<list<node>::const_iterator>::const_iterator*)jroots;
    
    // begin and end of iterator must be set on end
    // a call of iter.next will so return the first element
    list<node>::const_iterator* begin = new list<node>::const_iterator();
    list<node>::const_iterator* iter = new list<node>::const_iterator();
    list<node>::const_iterator* end = new list<node>::const_iterator();

    *begin = *iter = *root_tmp;
    ++root_tmp;

    if (root_tmp == *(((bfs_data*)data)->bfs_roots_end))
	*end = *((bfs_data*)data)->bfs_end;
    else
        *end = *root_tmp;

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_node_list_iterator);
}


JNIEXPORT void JNICALL Java_gtl_algorithms_Bfs_00024TreeEdgesIterator_nativeTreeEdgesIteratorInit
  (JNIEnv *env, jobject obj, jlong jbfs)
{
    bfs& Bfs = *((bfs*)jbfs);

    // begin and end of iterator must be set on end
    // a call of iter.next will so return the first element
    list<edge>::const_iterator* begin = new list<edge>::const_iterator();
    list<edge>::const_iterator* iter = new list<edge>::const_iterator();
    list<edge>::const_iterator* end = new list<edge>::const_iterator();
    *end = Bfs.tree_edges_end();
    *iter = *begin = Bfs.tree_edges_begin();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_edge_list_iterator);
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Bfs_00024NonTreeEdgesIterator_nativeNonTreeEdgesIteratorInit
  (JNIEnv *env, jobject obj, jlong jbfs)
{
    bfs& Bfs = *((bfs*)jbfs);

    // begin and end of iterator must be set on end
    // a call of iter.next will so return the first element
    list<edge>::const_iterator* begin = new list<edge>::const_iterator();
    list<edge>::const_iterator* iter = new list<edge>::const_iterator();
    list<edge>::const_iterator* end = new list<edge>::const_iterator();
    *end = Bfs.non_tree_edges_end();
    *iter = *begin = Bfs.non_tree_edges_begin();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_edge_list_iterator);
}


