/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// gtl_dfs_iteratos.cpp
//
// contains native functions of Dfs
//
// ***************************************************************************

#include <GTL_java/JNI/gtl_algorithms_Dfs_DfsIterator.h>
#include <GTL_java/JNI/gtl_algorithms_Dfs_RootsIterator.h>
#include <GTL_java/JNI/gtl_algorithms_Dfs_RootsDfsIterator.h>
#include <GTL_java/JNI/gtl_algorithms_Dfs_TreeEdgesIterator.h>
#include <GTL_java/JNI/gtl_algorithms_Dfs_NonTreeEdgesIterator.h>
#include <GTL_java/graph_java.h>
#include <GTL/dfs.h>

// internal class
class dfs_data : public iterator_data
{
public:
    dfs_data(list<node>::const_iterator* d_end, 
	list<list<node>::const_iterator >::const_iterator* d_root_end)
    {
	dfs_end = d_end;
	dfs_roots_end = d_root_end;
    }

    ~dfs_data()
    {
	delete dfs_end;
	delete dfs_roots_end;
    }

    list<node>::const_iterator* dfs_end;
    list<list<node>::const_iterator >::const_iterator* dfs_roots_end;
};

JNIEXPORT void JNICALL Java_gtl_algorithms_Dfs_00024DfsIterator_nativeDfsIteratorInit
  (JNIEnv *env, jobject obj, jlong jdfs)
{
    dfs& Dfs = *((dfs*)jdfs);

    // begin and end of iterator must be set on end
    // a call of iter.next will so return the first element
    list<node>::const_iterator* begin = new list<node>::const_iterator();
    list<node>::const_iterator* iter = new list<node>::const_iterator();
    list<node>::const_iterator* end = new list<node>::const_iterator();
    *end = Dfs.end();
    *iter = *begin = Dfs.begin();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_node_list_iterator);
}

JNIEXPORT jlong JNICALL Java_gtl_algorithms_Dfs_00024RootsIterator_nativeRootsIteratorInit
  (JNIEnv *env, jobject obj, jlong jdfs)
{
    dfs& Dfs = *((dfs*)jdfs);

    // begin and end of iterator must be set on end
    // a call of iter.next will so return the first element
    list<list<node>::const_iterator >::const_iterator* begin = new list<list<node>::const_iterator >::const_iterator();
    list<list<node>::const_iterator >::const_iterator* iter = new list<list<node>::const_iterator >::const_iterator();
    list<list<node>::const_iterator >::const_iterator* end = new list<list<node>::const_iterator >::const_iterator();
    *iter = *begin = Dfs.roots_begin();
    *end = Dfs.roots_end();
    
    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);

    list<node>::const_iterator* dfs_end = new list<node>::const_iterator;
    *dfs_end = Dfs.end();
    dfs_data* dd = new dfs_data(dfs_end, end);
    return (jlong)(dd);
}

JNIEXPORT jboolean JNICALL Java_gtl_algorithms_Dfs_00024RootsIterator_nativeRootsIteratorHasNext
  (JNIEnv*, jobject, jlong iter, jlong end)
{
    // check wether the next element will be the end
    return (*(list<list<node>::const_iterator >::iterator*)iter) != 
	(*(list<list<node>::const_iterator >::iterator*)end);
}

JNIEXPORT jlong JNICALL Java_gtl_algorithms_Dfs_00024RootsIterator_nativeRootsIteratorNext
  (JNIEnv *, jobject, jlong iter)
{
    // returns the next iterator position

    // we need a temporary object, will be deleted in dfsIteratorInit
    list<list<node>::const_iterator>::iterator* tmp_iter = new list<list<node>::const_iterator>::iterator;
    *tmp_iter = *((list<list<node>::const_iterator>::iterator*)iter);

    ++(*(list<list<node>::const_iterator>::iterator*)iter);
    return (jlong)tmp_iter;
}

JNIEXPORT jlong JNICALL Java_gtl_algorithms_Dfs_00024RootsIterator_nativeRootsIteratorCopyData
  (JNIEnv *, jobject, jlong data)
{
    return (jlong)(new dfs_data(((dfs_data*)data)->dfs_end, ((dfs_data*)data)->dfs_roots_end));
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Dfs_00024RootsDfsIterator_nativeRootsDfsIteratorInit
  (JNIEnv *env, jobject obj, jlong jroots, jlong data)
{
    // get a copy of current iterator
    list<list<node>::const_iterator>::const_iterator root_tmp = 
	*((list<list<node>::const_iterator>::const_iterator*)jroots);

    // delete temporary iterator
    delete (list<list<node>::const_iterator>::const_iterator*)jroots;
    
    // begin and end of iterator must be set on end
    // a call of iter.next will so return the first element
    list<node>::const_iterator* begin = new list<node>::const_iterator();
    list<node>::const_iterator* iter = new list<node>::const_iterator();
    list<node>::const_iterator* end = new list<node>::const_iterator();

    *begin = *iter = *root_tmp;
    ++root_tmp;

    if (root_tmp == *(((dfs_data*)data)->dfs_roots_end))
	*end = *((dfs_data*)data)->dfs_end;
    else
        *end = *root_tmp;

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_node_list_iterator);
}


JNIEXPORT void JNICALL Java_gtl_algorithms_Dfs_00024TreeEdgesIterator_nativeTreeEdgesIteratorInit
  (JNIEnv *env, jobject obj, jlong jdfs)
{
    dfs& Dfs = *((dfs*)jdfs);

    // begin and end of iterator must be set on end
    // a call of iter.next will so return the first element
    list<edge>::const_iterator* begin = new list<edge>::const_iterator();
    list<edge>::const_iterator* iter = new list<edge>::const_iterator();
    list<edge>::const_iterator* end = new list<edge>::const_iterator();
    *end = Dfs.tree_edges_end();
    *iter = *begin = Dfs.tree_edges_begin();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_edge_list_iterator);
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Dfs_00024NonTreeEdgesIterator_nativeNonTreeEdgesIteratorInit
  (JNIEnv *env, jobject obj, jlong jdfs)
{
    dfs& Dfs = *((dfs*)jdfs);

    // begin and end of iterator must be set on end
    // a call of iter.next will so return the first element
    list<edge>::const_iterator* begin = new list<edge>::const_iterator();
    list<edge>::const_iterator* iter = new list<edge>::const_iterator();
    list<edge>::const_iterator* end = new list<edge>::const_iterator();
    *end = Dfs.non_tree_edges_end();
    *iter = *begin = Dfs.non_tree_edges_begin();

    // set id of iterator
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);

    jfieldID fid;
    fid = env->GetFieldID(cls, "refBegin", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)begin);
    fid = env->GetFieldID(cls, "refIter", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)iter);
    fid = env->GetFieldID(cls, "refEnd", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, (jlong)end);
    fid = env->GetFieldID(cls, "type", "J");
    assert(fid != 0);
    env->SetLongField(obj, fid, ITT_edge_list_iterator);
}


