/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// gtl_bfs.cpp
//
// contains native functions of Bfs
//
// ***************************************************************************

#pragma warning (disable: 4800)

#include <GTL_java/JNI/gtl_algorithms_Bfs.h>
#include <GTL_java/graph_java.h>
#include <GTL/bfs.h>

class my_own_bfs : public bfs
{
public:
    my_own_bfs(JNIEnv* e, jobject d)
	: bfs()
    {
	env = e;
	jbfs = d;
	jgraph = 0;

	jclass cls = env->GetObjectClass(jbfs);
	assert(cls != 0);

	// get method signatures
	init = env->GetMethodID(cls, "initHandler","()V");
	end = env->GetMethodID(cls, "endHandler","()V");
	popped = env->GetMethodID(cls, "poppedNodeHandler","(Lgtl/Node;)V");
	finished = env->GetMethodID(cls, "finishedNodeHandler","(Lgtl/Node;)V");
	unused = env->GetMethodID(cls, "unusedNodeHandler","(Lgtl/Node;Lgtl/Node;)V");
	used = env->GetMethodID(cls, "usedNodeHandler","(Lgtl/Node;Lgtl/Node;)V");
	new_start = env->GetMethodID(cls, "newStartHandler","(Lgtl/Node;)V");

	assert(init != 0);
	assert(end != 0);
	assert(popped != 0);
	assert(finished != 0);
	assert(unused != 0);
	assert(used != 0);
	assert(new_start != 0);
    }

    void set_jgraph(graph_java* jg)
    {
	jgraph = jg;
    }

    virtual void init_handler (graph& G) 
    { env->CallVoidMethod(jbfs, init); }
    
    virtual void end_handler (graph& G)
    { env->CallVoidMethod(jbfs, end); }
    
    virtual void popped_node_handler (graph& G, node& n)
    { env->CallVoidMethod(jbfs, popped, jgraph->get_obj(n)); }

    virtual void finished_node_handler (graph& G, node& n)
    { env->CallVoidMethod(jbfs, finished, jgraph->get_obj(n)); }

    virtual void unused_node_handler (graph& G, node& n, node& f)
    { env->CallVoidMethod(jbfs, unused, jgraph->get_obj(n), jgraph->get_obj(f)); }

    virtual void used_node_handler (graph& G, node& n, node& f)
    { env->CallVoidMethod(jbfs, used, jgraph->get_obj(n), jgraph->get_obj(f)); }

    virtual void new_start_handler (graph& G, node& n)
    { env->CallVoidMethod(jbfs, new_start, jgraph->get_obj(n)); }

private:
    JNIEnv* env;
    jobject jbfs;

    jmethodID init;
    jmethodID end;
    jmethodID popped;
    jmethodID finished;
    jmethodID unused;
    jmethodID used;
    jmethodID new_start;

    graph_java* jgraph;
};

JNIEXPORT void JNICALL Java_gtl_algorithms_Bfs_nativeAttach
  (JNIEnv *, jobject, jlong jbfs, jlong jtool)
{
    my_own_bfs& Bfs = *((my_own_bfs*)jbfs);
    Bfs.set_jgraph((graph_java*)jtool);
}

JNIEXPORT jint JNICALL Java_gtl_algorithms_Bfs_nativeBfsNumber
  (JNIEnv *, jobject, jlong jbfs, jlong noderef, jlong jtool)
{
    bfs& Bfs = *((bfs*)jbfs);
    graph_java& g = *((graph_java*)jtool);
    node& n = g.get_node((jobject)noderef);
    return Bfs.bfs_num(n);
}

JNIEXPORT jint JNICALL Java_gtl_algorithms_Bfs_nativeCheck
  (JNIEnv *, jobject, jlong jgtl, jlong jbfs)
{
    bfs& Bfs = *((bfs*)jbfs);
    graph& g = *((graph*)jgtl);
    return Bfs.check(g);
}

JNIEXPORT jobject JNICALL Java_gtl_algorithms_Bfs_nativeFather
  (JNIEnv *, jobject, jlong jbfs, jlong noderef, jlong jtool)
{
    bfs& Bfs = *((bfs*)jbfs);
    graph_java& g = *((graph_java*)jtool);
    node& n = g.get_node((jobject)noderef);
    node father = Bfs.father(n);
    if (father == node())
	return 0;
    else
	return g.get_obj(father);
}

JNIEXPORT jboolean JNICALL Java_gtl_algorithms_Bfs_nativeGetCalcLevel
  (JNIEnv *, jobject, jlong jbfs)
{
    bfs& Bfs = *((bfs*)jbfs);
    return Bfs.calc_level();
}

JNIEXPORT jint JNICALL Java_gtl_algorithms_Bfs_nativeLevel
  (JNIEnv *, jobject, jlong jbfs, jlong noderef, jlong jtool)
{
    bfs& Bfs = *((bfs*)jbfs);
    graph_java& g = *((graph_java*)jtool);
    node& n = g.get_node((jobject)noderef);
    return Bfs.level(n);
}

JNIEXPORT jlong JNICALL Java_gtl_algorithms_Bfs_nativeNew
  (JNIEnv *env, jobject obj)
{
    obj = env->NewWeakGlobalRef(obj);
    bfs* Bfs = new my_own_bfs(env, obj);
    return (jlong)Bfs;
}

JNIEXPORT jint JNICALL Java_gtl_algorithms_Bfs_nativeNumberOfReachedNodes
  (JNIEnv *, jobject, jlong jbfs)
{
    bfs& Bfs = *((bfs*)jbfs);
    return Bfs.number_of_reached_nodes();
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Bfs_nativeReset
  (JNIEnv *, jobject, jlong jbfs)
{
    bfs& Bfs = *((bfs*)jbfs);
    Bfs.reset();
}

JNIEXPORT jint JNICALL Java_gtl_algorithms_Bfs_nativeRun
  (JNIEnv *, jobject, jlong jgtl, jlong jbfs)
{
    bfs& Bfs = *((bfs*)jbfs);
    graph& g = *((graph*)jgtl);
    int temp = Bfs.run(g);
    return temp;
}

JNIEXPORT jboolean JNICALL Java_gtl_algorithms_Bfs_nativeScanWholeGraph__J
  (JNIEnv *, jobject, jlong jbfs)
{
    return ((bfs*)jbfs)->scan_whole_graph();
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Bfs_nativeScanWholeGraph__JZ
  (JNIEnv *, jobject, jlong jbfs, jboolean set)
{
    ((bfs*)jbfs)->scan_whole_graph(set);
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Bfs_nativeSetCalcLevel
  (JNIEnv *, jobject, jlong jbfs, jboolean set)
{
    ((bfs*)jbfs)->calc_level(set);
}

JNIEXPORT jobject JNICALL Java_gtl_algorithms_Bfs_nativeStartNode__JJ
  (JNIEnv *, jobject, jlong jbfs, jlong jgraph)
{
    return ((graph_java*)jgraph)->get_obj( ((bfs*)jbfs)->start_node() );
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Bfs_nativeStartNode__JJJ
  (JNIEnv *, jobject, jlong jbfs, jlong node, jlong jgraph)
{
    ((bfs*)jbfs)->start_node(((graph_java*)jgraph)->get_node((jobject)node));
}

JNIEXPORT jboolean JNICALL Java_gtl_algorithms_Bfs_nativeStoreNonTreeEdges__J
  (JNIEnv *, jobject, jlong jbfs)
{
    return ((bfs*)jbfs)->store_non_tree_edges();
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Bfs_nativeStoreNonTreeEdges__JZ
  (JNIEnv *, jobject, jlong jbfs, jboolean set)
{
    ((bfs*)jbfs)->store_non_tree_edges(set);
}


JNIEXPORT jboolean JNICALL Java_gtl_algorithms_Bfs_nativeStorePreds__J
  (JNIEnv *, jobject, jlong jbfs)
{
    return ((bfs*)jbfs)->store_preds();
}

JNIEXPORT void JNICALL Java_gtl_algorithms_Bfs_nativeStorePreds__JZ
  (JNIEnv *, jobject, jlong jbfs, jboolean set)
{
    ((bfs*)jbfs)->store_preds(set);
}


