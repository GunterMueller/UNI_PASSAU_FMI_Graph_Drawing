/* This software is distributed under the GNU Lesser General Public License */
// ***************************************************************************
//
// GTL_Graph.cp
//
// ***************************************************************************

#include <GTL_java/JNI/gtl_GTL_0005fGraph.h>
#include <GTL_java/graph_java.h>
#include <GTL_java/graph_java_standalone.h>

// ***************************************************************************
// class Graph


// ***************************************************************************
// native functions of class Graph

JNIEXPORT jobject JNICALL Java_gtl_GTL_1Graph_nativeCenter
  (JNIEnv *, jobject, jlong ref, jlong tool_ref)
{
    return ((graph_java*)tool_ref)->get_obj(((graph*)ref)->center());
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeClear
  (JNIEnv*, jobject, jlong ref)
{
    ((graph*)ref)->clear();
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeDelAllEdges
  (JNIEnv*, jobject, jlong ref)
{
    ((graph*)ref)->del_all_edges();
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeDelAllNodes
  (JNIEnv*, jobject, jlong ref)
{
    ((graph*)ref)->del_all_nodes();
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeDelEdge
  (JNIEnv*, jobject, jlong ref, jlong tool_ref, jlong edge)
{
    graph_java& g = *((graph_java*)tool_ref);
    ((graph*)ref)->del_edge(g.get_edge((jobject)edge));
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeDelNode
  (JNIEnv*, jobject, jlong ref, jlong tool_ref, jlong node)
{
    graph_java& g = *((graph_java*)tool_ref);
    ((graph*)ref)->del_node(g.get_node((jobject)node));
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeHideEdge
  (JNIEnv*, jobject, jlong ref, jlong tool_ref, jlong edge)
{
    graph_java& g = *((graph_java*)tool_ref);
    ((graph*)ref)->hide_edge(g.get_edge((jobject)edge));
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1Graph_nativeHideNode
  (JNIEnv*, jobject, jlong ref, jlong tool_ref, jlong node)
{
    graph_java& g = *((graph_java*)tool_ref);
    list<edge> l = ((graph*)ref)->hide_node(g.get_node((jobject)node));
    return g.convert_list(l);
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1Graph_nativeInsertReverseEdges
  (JNIEnv*, jobject, jlong ref, jlong tool_ref)
{
    graph_java& g = *((graph_java*)tool_ref);
    list<edge> l = ((graph*)ref)->insert_reverse_edges();
    return g.convert_list(l);
}

JNIEXPORT jboolean JNICALL Java_gtl_GTL_1Graph_nativeIsAcyclic
  (JNIEnv*, jobject, jlong ref)
{
    return ((graph*)ref)->is_acyclic();
}

JNIEXPORT jboolean JNICALL Java_gtl_GTL_1Graph_nativeIsBidirected
  (JNIEnv* env, jobject, jlong ref, jlong tool_ref, jobject jmap)
{
    graph_java& g = *((graph_java*)tool_ref);

    // make sure our object won't be affected during our operation
    jmap = env->NewLocalRef(jmap);

    // create edge_map and run is_bidirected
    edge_map<edge> temp_map;
    bool result = ((graph*)ref)->is_bidirected(temp_map);

    // get methodID
    jclass cls = env->GetObjectClass(jmap);
    assert(cls != 0);
    jmethodID mid = env->GetMethodID(cls, "put",
	"(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
    assert(mid != 0);

    // get all entries of the map and copy it -- I know it's not the
    // best method doing that, maybe it's better to do it in java
    // but at the moment I don't care
    graph::edge_iterator it  = ((graph*)ref)->edges_begin();
    graph::edge_iterator end = ((graph*)ref)->edges_end();

    for (; it != end; ++it)
    {
	edge r = temp_map[*it];
	if (r != edge())
	    env->CallObjectMethod(jmap, mid, g.get_obj(*it), g.get_obj(r));
    }

    // o.k. we should be finished, so let's delete our local reference and quit
    env->DeleteLocalRef(jmap);
    return result;
}

JNIEXPORT jboolean JNICALL Java_gtl_GTL_1Graph_nativeIsConnected
  (JNIEnv*, jobject, jlong ref)
{
    return ((graph*)ref)->is_connected();
}

JNIEXPORT jboolean JNICALL Java_gtl_GTL_1Graph_nativeIsDirected
  (JNIEnv*, jobject, jlong ref)
{
    return ((graph*)ref)->is_directed();
}

JNIEXPORT jboolean JNICALL Java_gtl_GTL_1Graph_nativeIsUndirected
  (JNIEnv*, jobject, jlong ref)
{
    return ((graph*)ref)->is_undirected();
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1Graph_nativeLoad
  (JNIEnv* env, jobject, jlong ref, jstring string)
{
    const char *str = env->GetStringUTFChars(string, 0);
    GML_error err = ((graph*)ref)->load(str);
    env->ReleaseStringUTFChars(string, str);
    jclass cls = env->FindClass("gtl/GML_Error");
    assert(cls != 0);
    jmethodID mid = env->GetMethodID(cls, "<init>", "(III)V");
    assert(mid != 0);
    return env->NewWeakGlobalRef(env->NewObject(cls, mid, err.err_num, err.line, err.column));
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeMakeDirected
  (JNIEnv*, jobject, jlong ref)
{
    ((graph*)ref)->make_directed();
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeMakeUndirected
  (JNIEnv*, jobject, jlong ref)
{
    ((graph*)ref)->make_undirected();
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1Graph_nativeNewEdge
  (JNIEnv*, jobject, jlong ref, jlong tool_ref, jlong node1, jlong node2)
{
    // get graph
    graph_java& g = *((graph_java*)tool_ref);

    // create a new edge
    edge e = ((graph*)ref)->new_edge(g.get_node((jobject)node1),g.get_node((jobject)node2));

    // return new edge
    return g.get_obj(e);
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeNewJgraph__
  (JNIEnv* env, jobject obj)
{
    // get class and so on of class Graph
    obj = env->NewWeakGlobalRef(obj);
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);
    jfieldID refid = env->GetFieldID(cls, "ref", "J");
    assert(refid != 0);
    jfieldID toolid = env->GetFieldID(cls, "toolRef", "J");
    assert(toolid != 0);

    // create a new graph_java and set environment and so on
    GTL_graph_java* gtl = new GTL_graph_java(env, obj);

    // store new graph
    env->SetLongField(obj, refid, (jlong)((graph*)gtl));
    env->SetLongField(obj, toolid, (jlong)((graph_java*)gtl));
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeNewJgraph__J
  (JNIEnv* env, jobject obj, jlong ref)
{
    // get class and so on of class Graph
    obj = env->NewWeakGlobalRef(obj);
    jclass   cls = env->GetObjectClass(obj);
    assert(cls != 0);
    jfieldID fid = env->GetFieldID(cls, "ref", "J");
    assert(fid != 0);

    // we need no new jgraph, ref refers already to this graph
    // so we just need to store this reference in java-graph
    env->SetLongField(obj, fid, ref);
}

JNIEXPORT jobject JNICALL Java_gtl_GTL_1Graph_nativeNewNode
  (JNIEnv* env, jobject, jlong ref, jlong tool_ref)
{
    // get graph
    graph_java& g = *((graph_java*)tool_ref);

    // create a new node
    node n = ((graph*)ref)->new_node();

    // return new node
    return g.get_obj(n);
}

JNIEXPORT jint JNICALL Java_gtl_GTL_1Graph_nativeNumberOfEdges
  (JNIEnv*, jobject, jlong ref)
{
    return ((graph*)ref)->number_of_edges();
}

JNIEXPORT jint JNICALL Java_gtl_GTL_1Graph_nativeNumberOfNodes
  (JNIEnv*, jobject, jlong ref)
{
    return ((graph*)ref)->number_of_nodes();
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeRelease
  (JNIEnv* env, jobject, jlong ref, jlong tool_ref)
{
    // free references
    env->DeleteWeakGlobalRef(((graph_java*)tool_ref)->get_obj());

    // we must kill the graph, so let's do it
    delete ((graph*)ref);
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeRestoreEdge
  (JNIEnv*, jobject, jlong ref, jlong tool_ref, jlong edge)
{
    graph_java& g = *((graph_java*)tool_ref);
    ((graph*)ref)->restore_edge(g.get_edge((jobject)edge));
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeRestoreGraph
  (JNIEnv *, jobject, jlong ref)
{
    ((graph*)ref)->restore_graph();
}

JNIEXPORT void JNICALL Java_gtl_GTL_1Graph_nativeRestoreNode
  (JNIEnv*, jobject, jlong ref, jlong tool_ref, jlong node)
{
    graph_java& g = *((graph_java*)tool_ref);
    ((graph*)ref)->restore_node(g.get_node((jobject)node));
}

JNIEXPORT jboolean JNICALL Java_gtl_GTL_1Graph_nativeSave
  (JNIEnv* env, jobject, jlong ref, jstring string)
{
    const char *str = env->GetStringUTFChars(string, 0);
    bool result = (((graph*)ref)->save(str) == 1);
    env->ReleaseStringUTFChars(string, str);
    return result;
}

