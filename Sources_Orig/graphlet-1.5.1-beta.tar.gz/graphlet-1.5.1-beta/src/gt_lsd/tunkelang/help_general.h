/* Functions needed but having nothing to do with xv or algorithm */

extern int a_to_b_like_x_to_d(int a, int b, int d);

extern int  signum(int argument);

extern int  det(int x1, int y1, int x2, int y2, int x3, int y3);

extern void save_real_graphcoords(char *name);

extern void breakhandler(void);
