main(int argc, char **argv)
{
 graphed_main(argc,argv);
}

void init_user_menu(void)
{
#include "tunkelang_export.h"
#include "tunkelang_init.c"
}
