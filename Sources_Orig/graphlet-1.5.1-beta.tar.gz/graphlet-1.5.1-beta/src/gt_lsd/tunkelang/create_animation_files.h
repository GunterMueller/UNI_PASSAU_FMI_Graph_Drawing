extern Sgraph build_graph(void);

extern void save_image(int image_number);
