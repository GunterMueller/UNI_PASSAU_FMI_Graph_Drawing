extern int bfs(int i, unsigned short flag);
