extern void make_connected(Sgraph sgraph,Slist *list_of_edges);

extern void renumber_the_nodes_starting_at_one(Sgraph sgraph);

extern void update_coords_of(Sgraph sgraph);

extern void make_straight_line_edges(Sgraph sgraph);

