#ifndef GT_LSD_H
#define GT_LSD_H

//
// lsd_main.h
//

// Walter Bachl: 25.6.96
// Basic definitions to call sgraph-algorithms
// Implementation: main.cc



//////////////////////////////////////////////////////////////////////
//
// Gem
//
//////////////////////////////////////////////////////////////////////


class GT_Gem : public GT_Algorithm {

protected:

    double insert_max_temp, insert_start_temp,
	insert_final_temp, insert_max_iter,
	insert_gravity, insert_oscilation,
	insert_rotation, insert_shake;
    int	insert_skip;
    double arrange_max_temp, arrange_start_temp,
	arrange_final_temp, arrange_max_iter,
	arrange_gravity, arrange_oscilation,
	arrange_rotation, arrange_shake;
    int	arrange_skip;
    double optimize_max_temp, optimize_start_temp,
	optimize_final_temp, optimize_max_iter,
	optimize_gravity, optimize_oscilation,
	optimize_rotation, optimize_shake;
    int	optimize_skip,
	the_random, quality, default_edgelength;

public:
    GT_Gem (const string& name);
    virtual ~GT_Gem ();
    
    virtual int run (GT_Graph& g);
    virtual int check (GT_Graph& g, string& message);
};



class GT_Tcl_Gem : public GT_Tcl_Algorithm<GT_Gem>
{
    
public:    
    GT_Tcl_Gem (const string& name);
    virtual ~GT_Tcl_Gem ();
    
    virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
};



//////////////////////////////////////////////////////////////////////
//
// Tree Layout Walker
//
//////////////////////////////////////////////////////////////////////


class GT_Tree_Walker : public GT_Algorithm
{

protected:
    int vertical, sibling, subtree;  // Parameters set in Dialog

public:
    GT_Tree_Walker (const string& name);
    virtual ~GT_Tree_Walker ();
    
    virtual int run (GT_Graph& g);
    virtual int check (GT_Graph& g, string& message);
};



class GT_Tcl_Tree_Walker : public GT_Tcl_Algorithm<GT_Tree_Walker>
{
public:
    GT_Tcl_Tree_Walker (const string& name);
    virtual ~GT_Tcl_Tree_Walker ();
    
    virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
};



//////////////////////////////////////////////////////////////////////
//
// Spring RF
//
//////////////////////////////////////////////////////////////////////


class GT_SpringRf : public GT_Algorithm {

protected:
    int weighted, max_iter, edgelen;
    double max_force, vibration;

public:
    GT_SpringRf (const string& name);
    virtual ~GT_SpringRf ();
    
    virtual int run (GT_Graph& g);
    virtual int check (GT_Graph& g, string& message);
};


class GT_Tcl_SpringRf : public GT_Tcl_Algorithm<GT_SpringRf>
{
public:
    GT_Tcl_SpringRf (const string& name);
    virtual ~GT_Tcl_SpringRf ();
    
    virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
};



//////////////////////////////////////////////////////////////////////
//
// Springembedder Kamada
//
//////////////////////////////////////////////////////////////////////


class GT_SpringKamada : public GT_Algorithm {

  protected:
    int edgelength;

  public:
    GT_SpringKamada (const string& name);
    virtual ~GT_SpringKamada ();
    
    virtual int run (GT_Graph& g);
    virtual int check (GT_Graph& g, string& message);
};


class GT_Tcl_SpringKamada : public GT_Tcl_Algorithm<GT_SpringKamada>
{
  public:
    GT_Tcl_SpringKamada (const string& name);
    virtual ~GT_Tcl_SpringKamada ();

    virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
};

//////////////////////////////////////////////////////////////////////
//
// minimal bends layout
//
//////////////////////////////////////////////////////////////////////

/*
class GT_MinimalBendsLayout : public GT_Algorithm {

protected:
    int edgelength;

public:
    GT_MinimalBendsLayout (const string& name);
    virtual ~GT_MinimalBendsLayout ();
    
    virtual int run (GT_Graph& g);
    virtual int check (GT_Graph& g, string& message);
};


class GT_Tcl_MinimalBendsLayout : public GT_Tcl_Algorithm<GT_MinimalBendsLayout> {
public:
    GT_Tcl_MinimalBendsLayout (const string& name);
    virtual ~GT_Tcl_MinimalBendsLayout ();

    virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
};

*/

//////////////////////////////////////////////////////////////////////
//
// Tunkelang Layout
//
//////////////////////////////////////////////////////////////////////


class GT_Tunkelang : public GT_Algorithm {

protected:
    int edgelength, cut_value, scan_corners;  // Parameters set in Dialog
    int quality, rec_depth, randomize;

public:
    GT_Tunkelang (const string& name);
    virtual ~GT_Tunkelang ();
    
    virtual int run (GT_Graph& g);
    virtual int check (GT_Graph& g, string& message);
};


class GT_Tcl_Tunkelang : public GT_Tcl_Algorithm<GT_Tunkelang>
{

public:
    GT_Tcl_Tunkelang (const string name);
    virtual ~GT_Tcl_Tunkelang ();
    
    virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
};



//////////////////////////////////////////////////////////////////////
//
// DAG Layout
//
//////////////////////////////////////////////////////////////////////


class GT_Sugiyama : public GT_Algorithm
{
public:
    // Constructor
    GT_Sugiyama (const string& name);
    virtual ~GT_Sugiyama ();
    
    virtual int run (GT_Graph& g);
    virtual int check (GT_Graph& g, string& message);
};



class GT_Tcl_Sugiyama : public GT_Tcl_Algorithm<GT_Sugiyama>
{   
public:
    GT_Tcl_Sugiyama (const string& name);
    virtual ~GT_Tcl_Sugiyama();
};


#endif
