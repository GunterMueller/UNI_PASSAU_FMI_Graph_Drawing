/* (C) Universitaet Passau 1986-1994 */
#include <xview/xview.h>
#include <xview/panel.h>

#include <sgraph/std.h>
#include <sgraph/sgraph.h>
#include <sgraph/algorithms.h>
#include <sgraph/slist.h>
#include <sgraph/graphed.h>
#include "minimal_bends_layout_export.h"
#include <graphed/graphed_pin_sf.h>
#include <graphed/gridder.h>
#include <graphed/util.h>


Minimal_bends_settings minimal_bends_settings;


Minimal_bends_settings init_minimal_bends_settings(void)
{
	Minimal_bends_settings settings;

	settings.grid = 64;
	settings.grid_defaults = GRIDDER_DISTANCE_2_LARGEST_SIZE;

	return settings;
}



void	save_minimal_bends_settings (void)
{
	minimal_bends_settings = init_minimal_bends_settings();
}


static	int	snode_degree (Snode node)
{
	Sedge	edge;
	int	degree = 0;
	
	for_sourcelist (node, edge) {
		degree ++;
	} end_for_sourcelist (node, edge);
	if (node->graph->directed) for_targetlist (node, edge) {
		degree ++;
	} end_for_targetlist (node, edge);
	
	return degree;
}


int	test_minimal_bends_layout (Sgraph_proc_info info)
{
	Sgraph	graph;
	Snode	node;
	
	graph = info->sgraph;
	if (graph == empty_graph || graph->nodes == empty_node) {
		error ("empty graph\n");
		return FALSE;
	} else if (graph->nodes == graph->nodes->suc) {
		return TRUE;
	} else if (!test_sgraph_connected(graph)) {
		error ("graph is not connected\n");
		return FALSE;
	} else {
	
		Slist	nodes_with_degree_greater_four;
		int	degree, degree_ok;
		
		
		/* Check for nodes with degree > 4 */
		
		nodes_with_degree_greater_four = empty_slist;
		degree_ok = TRUE;
		for_all_nodes (graph, node) {
			degree = snode_degree (node);
			if (degree > 4) {
				degree_ok = FALSE;
				nodes_with_degree_greater_four = add_to_slist (
					nodes_with_degree_greater_four,
					make_attr(ATTR_DATA, (char *)node));
			}
		} end_for_all_nodes (graph, node);
		
		if (!degree_ok) {
			if (nodes_with_degree_greater_four == nodes_with_degree_greater_four->suc) {
				error ("There is a node with degree > 4\n");
			} else {
				error ("There are nodes with degree > 4\n");
			}
			info->new_selected = SGRAPH_SELECTED_GROUP;
			info->new_selection.group = nodes_with_degree_greater_four;
			return FALSE;
		}

		return TRUE; /*test_graph_is_drawn_planar (graphed_graph(graph));*/
		
	}
}


void	 	 check_and_call_minimal_bends_layout (Sgraph_proc_info info)
{
	Sgraph	graph;
	
	graph = info->sgraph;
	
	if (test_minimal_bends_layout(info)) {
		call_minimal_bends_layout (info);
		info->recenter = TRUE;
	} else {
		error ("Cannot apply algorithm\n");
	}
}
