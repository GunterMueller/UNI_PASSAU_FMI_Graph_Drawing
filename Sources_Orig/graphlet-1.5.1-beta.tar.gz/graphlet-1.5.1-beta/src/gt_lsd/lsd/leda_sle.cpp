// 
// L      S      D
// Leda & Sgraph Do it
//
// an interface to run
// Sgraph-alorithms on LEDA-graph-structures

// Author: Dirk Heider
// email: heider@fmi.uni-passau.de

///////////////////////////////////////////////////////////
// MODULE DESCRIPTION
//
// The LEDA- STRAIGHT_LINE_EMBEDDING-algorithm
// is executed on the GA-Graph. The changes made are NOT
// reflected on the Sgraph-Counterpart. To let the changes
// take effect on the Sgraph-graph for a second algorithm,
// the GA-graph is copied to the Sgraph before running any
// further algorithm.
// To prepare the graph for STRAIGHT_LINE_EMBEDDING()
// LEDA's PLANAR() must be called for clockwise
// ordering of the edges.
///////////////////////////////////////////////////////////

// LSD-standard includes
#include "lsdstd.h"

#include <LEDA/vector.h>

static void delete_multiple_edges(graph& lgraph);

static node_array<int> node_xcoord;
static node_array<int> node_ycoord;

////////////////////////////////////////////////////////////////////////////
// WA: CH Wo wird der Algo (straight line embedding) aufgerufen?
//        Warum fuegt er Kanten ein, die er dann eh wieder loescht?
//

void LEDA_SLE(Sgraph_proc_info info)
{
	ENTRY;
	Sgraph           sgraph                 = info->sgraph;
	LSD*             lsd                    = (LSD*) sgraph->graphed;
	GT_Graph*        gt_graph               = lsd->gt_graph();	
	graph*           leda_graph             = gt_graph->attached();
	
	list<edge>       additional_edges;
	bool             edges_added            = false;
	bool             undirected;
	edge_array<edge> bi_edges(*leda_graph);
	list<GT_Point>   gt_line;
	list_item        it;

	edge             ledge;
	node             lnode, target;

	assert(sgraph);
	assert(lsd);
	assert(gt_graph);
	assert(leda_graph);
	
	// nothing changes in "the_sgraph", since only
	// algorithms on LEDA-graphs are used here:	
	info->no_changes = true;

	// sorry, to make a graph directed, it must be directed!
	if ((undirected = leda_graph->is_undirected()))	{
		leda_graph->make_directed();
	}
	
	// sorry, to compute LEDAs SLE, the graph MUST be bidirected!
	if (!Is_Bidirected(*leda_graph, bi_edges))	{
		// WA CH Darf der wirklich einfach so die Kanten loeschen?
		// If some edges have a reverse yet, delete it. Otherwise, 
		// a reverse for a reverse edge will be inserted below.
		delete_multiple_edges(*leda_graph);
		// no bi-edges are there now. ->insert the reverse for every edge
		additional_edges = leda_graph->insert_reverse_edges();
		edges_added = true;
	}
	else {		cout << "2" << endl;}

	// the graph given to STRAIGHT_LINE_EMBEDDING() has
	// to be a planar map, so we have to prepare it:	
	if (!PLANAR(*leda_graph, true))	{
		cout << "LEDA-PLANAR() failed!" << endl;
		LEAVE;
		return;
	}
	
	TRACE("SLE");
	node_xcoord.init(*leda_graph);
	node_ycoord.init(*leda_graph);
	 {		cout << "1" << endl;}
	STRAIGHT_LINE_EMBEDDING(*leda_graph, node_xcoord, node_ycoord);
 {		cout << "2" << endl;}

	forall_nodes(lnode, *leda_graph)	{
		// copy the x- and y-coordinates from the  nodearrays to
		// generic attributes of the GT-graph
		lsd->gt_graph()->gt(lnode).graphics()->x( (node_xcoord[lnode]) * 64 );
		lsd->gt_graph()->gt(lnode).graphics()->y( (node_ycoord[lnode]) * 64 );
	}
	TRACE("SLE o.k.");

	// set the edgelines to the new positions of their source & target nodes
	forall_nodes(lnode, *leda_graph)  {
		forall_out_edges(ledge, lnode)	{
			//it is not necessary to delete the old edgeline!!!

			// create the new edgeline: source (lnode is the source!)
			gt_line.append(
				GT_Point( lsd->gt_graph()->gt(lnode).graphics()->x(),
					      lsd->gt_graph()->gt(lnode).graphics()->y() ) );
			// and target position
			target = leda_graph->opposite(lnode, ledge);
			gt_line.append(
				GT_Point( lsd->gt_graph()->gt(target).graphics()->x(),
					      lsd->gt_graph()->gt(target).graphics()->y() ) );
			// and set it
			cout << "Vor set line " << endl;
			lsd->gt_graph()->gt(ledge).graphics()->line(gt_line);
			cout << "Nach set line " << endl;
			gt_line.clear();
		}
	}
		
	if (edges_added)  {
		forall_items(it, additional_edges)  {
			leda_graph->del_edge(additional_edges[it]);
		}
		additional_edges.clear();
			
	}

	if (undirected)  {
		leda_graph->make_undirected();
	}
	LEAVE;
}

////////////////////////////////////////////////////////////////////////////
//

void delete_multiple_edges(graph& lgraph)
{
	list<edge> del_list;
	list_item it;
	
	edge_array<bool> deleted(lgraph, false);

	edge e, e1, e2;
	node n;

	forall_nodes(n, lgraph)  {
		forall_out_edges(e1, n)	{
			if (! deleted[e1])	{
				forall_in_edges(e2, n)	{
					if (! deleted[e2])	{
						if (lgraph.target(e1) == lgraph.source(e2))		{
							deleted[e2] = true;
						}
					}
				}
			}
		}
	}
	
	forall_edges(e, lgraph)	{
		if (deleted[e])		{
			del_list.append(e);			
		}
	}

	forall_items(it, del_list) 	{
		e = del_list[it];
		lgraph.del_edge(e);
	}
}
