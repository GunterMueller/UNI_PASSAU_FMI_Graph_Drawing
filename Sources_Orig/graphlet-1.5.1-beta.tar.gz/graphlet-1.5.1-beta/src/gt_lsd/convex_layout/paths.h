/* (C) Universitaet Passau 1986-1994 */
 
#define STDH "std.h"
#define SGRAPHH "sgraph.h"
#define GRAPHEDH "graphed.h"
#define SLISTH "slist.h"

  
    
  
