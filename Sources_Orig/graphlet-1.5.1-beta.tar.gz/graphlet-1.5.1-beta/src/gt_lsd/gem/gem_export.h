#include "gem_panel.h"
#include "gem_main.h"

extern void gem_init_graph(void); /* adtgraph.h */
