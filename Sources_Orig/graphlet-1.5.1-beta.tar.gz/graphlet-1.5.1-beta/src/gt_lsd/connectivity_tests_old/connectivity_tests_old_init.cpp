/*
add_to_tools_menu ("check connectivity", menu_check_connectivity);
add_to_tools_menu ("check biconnectivity", menu_check_biconnectivity);
*/
