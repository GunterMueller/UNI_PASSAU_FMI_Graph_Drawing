// 
// L      S      D
// Leda & Sgraph Do it
//
//
// Author: Dirk Heider
// email: heider@fmi.uni-passau.de
// Changes and adjustment to graphlet: Walter Bachl
// Additional Changes: Michael Himsolt
//

///////////////////////////////////////////////////////////
//
// Main Programm to call the algorithms which are
// implemented in sgraph.
//
///////////////////////////////////////////////////////////

#include <gt_base/Graphlet.h>
#include <gt_base/config.h>

#include <gt_tcl/Tcl.h>
#include <gt_tcl/Tcl_Algorithm.h>
#include <gt_tcl/GraphScript.h>

// LSD standard includes
#include "lsd/lsdstd.h"
#include "gt_lsd.h"

//////////////////////////////////////////
//
// Gem
//
//////////////////////////////////////////

//
// Algorithm
//

GT_Gem::GT_Gem (const string& name) : GT_Algorithm (name)
{
}

GT_Gem::~GT_Gem ()
{
}

int GT_Gem::run (GT_Graph& g)
{
    // check on empty graph
    if (g.leda().number_of_nodes() < 1 ) {
	return GT_OK;
    }

    graph leda = g.leda();
    LSD   lsd;

    lsd.gt_graph (&g);
    gem_init_graph();
    set_gem_default_config (
	insert_max_temp, insert_start_temp,
	insert_final_temp, insert_max_iter,
	insert_gravity, insert_oscilation,
	insert_rotation, insert_shake,
	insert_skip,
	arrange_max_temp, arrange_start_temp,
	arrange_final_temp, arrange_max_iter,
	arrange_gravity, arrange_oscilation,
	arrange_rotation, arrange_shake,
	arrange_skip,
	optimize_max_temp, optimize_start_temp,
	optimize_final_temp, optimize_max_iter,
	optimize_gravity, optimize_oscilation,
	optimize_rotation, optimize_shake,
	optimize_skip,
	the_random, quality, default_edgelength);
    read_config();
    lsd.callSgraph(call_gem);

    remove_all_bends (g);    
    adjust_coordinates (g, 10, 10);
    return GT_OK;
}

int GT_Gem::check (GT_Graph& /* g */, string& message)
{
    message = "";
    return GT_OK;
}

//
// Tcl Wrapper
//

GT_Tcl_Gem::GT_Tcl_Gem (const string& name) : GT_Tcl_Algorithm<GT_Gem> (name)
{
}

GT_Tcl_Gem::~GT_Tcl_Gem ()
{
}

int GT_Tcl_Gem::parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph*/* g*/)
{
    int code = TCL_OK;
    // int value;
	
    code = Tcl_GetDouble (info.interp(), info.argv(index++), &insert_max_temp);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&insert_start_temp);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&insert_final_temp);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&insert_max_iter);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&insert_gravity);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&insert_oscilation);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&insert_rotation);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&insert_shake);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetInt (info.interp(), info.argv(index++),
	&insert_skip);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
	
    code = Tcl_GetDouble (info.interp(), info.argv(index++)
	,&arrange_max_temp);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&arrange_start_temp);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&arrange_final_temp);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&arrange_max_iter);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&arrange_gravity);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&arrange_oscilation);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&arrange_rotation);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&arrange_shake);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetInt (info.interp(), info.argv(index++),
	&arrange_skip);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
	
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&optimize_max_temp);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&optimize_start_temp);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&optimize_final_temp);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&optimize_max_iter);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&optimize_gravity);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&optimize_oscilation);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&optimize_rotation);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetDouble (info.interp(), info.argv(index++),
	&optimize_shake);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetInt (info.interp(), info.argv(index++),
	&optimize_skip);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetInt (info.interp(), info.argv(index++),
	&the_random);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetInt (info.interp(), info.argv(index++),
	&quality);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    
    code = Tcl_GetInt (info.interp(), info.argv(index++),
	&default_edgelength);
    if (code != TCL_OK) {
	// GT_Error error; value = error.msg (error.wrong_int_val, index);
	return code;
    }
    return code;
}

//////////////////////////////////////////
//
// Tree Layout Walker
//
//////////////////////////////////////////

//
// Algorithm 
//

GT_Tree_Walker::GT_Tree_Walker (const string& name) : GT_Algorithm (name)
{
}

GT_Tree_Walker::~GT_Tree_Walker ()
{
}

int GT_Tree_Walker::run (GT_Graph& g)
{
    // check on empty graph
    if (g.leda().number_of_nodes() < 1 ) {
	return GT_OK;
    }
    
    graph leda = g.leda();
    LSD   lsd;

    lsd.gt_graph (&g);

    lsd.init_call();
    call_tree_layout_walker(lsd.proc_info(), vertical, sibling, subtree);
    lsd.clean_up();

    remove_all_bends (g);
    adjust_coordinates (g, 10, 10);
    return GT_OK;
}

int GT_Tree_Walker::check (GT_Graph& /* g */, string& message)
{
    message = "";
    return GT_OK;
}

//
// Tcl Wrapper
//

GT_Tcl_Tree_Walker::GT_Tcl_Tree_Walker (const string& name) :
	GT_Tcl_Algorithm<GT_Tree_Walker> (name)
{
}

GT_Tcl_Tree_Walker::~GT_Tcl_Tree_Walker ()
{
}

int GT_Tcl_Tree_Walker::parse (GT_Tcl_info& info, int& index,
    GT_Tcl_Graph* /* g*/)
{
    int code = TCL_OK;
    // int value;
	
    // Order: vertical-, sibling- and subtree- separation
    code = Tcl_GetInt (info.interp(), info.argv(index++), &vertical);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (error.wrong_int_val, index);
	return code;
    }
	
    code = Tcl_GetInt (info.interp(), info.argv(index++), &sibling);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (GT_Error::wrong_int_val, info.argv(index));
	return code;
    }
	
    code = Tcl_GetInt (info.interp(), info.argv(index++), &subtree);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (GT_Error::wrong_int_val, info.argv(index));
	return code;
    }
    return code;
}

//////////////////////////////////////////
//
// Springembedder RF
//
//////////////////////////////////////////

//
// Algorithm
//

GT_SpringRf::GT_SpringRf (const string& name) : GT_Algorithm (name)
{
}

GT_SpringRf::~GT_SpringRf ()
{
}

int GT_SpringRf::run (GT_Graph& g)
{
    // check on empty graph
    if (g.leda().number_of_nodes() < 1 ) {
	return GT_OK;
    }
	
    graph leda = g.leda();
    LSD   lsd;

    lsd.gt_graph (&g);
    springembedder_rf_settings = init_springembedder_rf_settings(
	weighted, max_force,
	vibration, max_iter, edgelen);
    lsd.callSgraph(call_springembedder_rf);
    
    remove_all_bends (g);
    adjust_coordinates (g, 10, 10);
    return GT_OK;
}

int GT_SpringRf::check (GT_Graph& /* g */, string& message)
{
    message = "";
    return GT_OK;
}

//
// Tcl Wrapper
//

GT_Tcl_SpringRf::GT_Tcl_SpringRf (const string& name) :
	GT_Tcl_Algorithm<GT_SpringRf> (name)
{
}

GT_Tcl_SpringRf::~GT_Tcl_SpringRf ()
{
}

int GT_Tcl_SpringRf::parse (GT_Tcl_info& info, int& index,
    GT_Tcl_Graph* /* g*/)
{
    int code = TCL_OK;
    // int value;
    code = Tcl_GetInt (info.interp(), info.argv(index++), &weighted);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (error.wrong_int_val, index);
	return code;
    }
	
    code = Tcl_GetDouble (info.interp(), info.argv(index++), &max_force);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (GT_Error::wrong_int_val, info.argv(index));
	return code;
    }
	
    code = Tcl_GetDouble (info.interp(), info.argv(index++), &vibration);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (GT_Error::wrong_int_val, info.argv(index));
	return code;
    }
    
    code = Tcl_GetInt (info.interp(), info.argv(index++), &max_iter);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (GT_Error::wrong_int_val, info.argv(index));
	return code;
    }
    
    code = Tcl_GetInt (info.interp(), info.argv(index++), &edgelen);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (GT_Error::wrong_int_val, info.argv(index));
	return code;
    }

    return code;
}

/*
  //////////////////////////////////////////
  //
  // Minimal Bends Layout
  //
  //////////////////////////////////////////

  GT_MinimalBendsLayout::GT_MinimalBendsLayout (const string& name) : GT_Algorithm (name)
  {
  }

  GT_MinimalBendsLayout::~GT_MinimalBendsLayout ()
  {
  }

  int GT_MinimalBendsLayout::run (GT_Graph& g)
  {
  // check on empty graph
  if (g.leda().number_of_nodes() < 1 ) {
  return GT_OK;
  }

  graph leda = g.leda();
  LSD   lsd;
  lsd.gt_graph (&g);

    // Call the algorithm
    lsd.init_call();
    check_and_call_minimal_bends_layout(lsd.proc_info(), edgelength);
    lsd.clean_up();
	
    return GT_OK;
    }

    int GT_MinimalBendsLayout::check (GT_Graph& g, string& message)
    {
    // Test whether the graph is strong connected
    message = "Error: Graph is not streng connected";
    return GT_OK;
    }

    // Tcl Wrapper

    GT_Tcl_MinimalBendsLayout::GT_Tcl_MinimalBendsLayout (const string& name) :
    GT_Tcl_Algorithm<GT_MinimalBendsLayout> (name)
    {
    }

    GT_Tcl_MinimalBendsLayout::~GT_Tcl_MinimalBendsLayout ()
    {
    }

    int GT_Tcl_MinimalBendsLayout::parse (GT_Tcl_info& info, int& index,
    GT_Tcl_Graph* / * g* /)
    {
    int code = TCL_OK;

    code = Tcl_GetInt (info.interp(), info.argv(index++), &edgelength);
    if (code != TCL_OK) {
    // GT_Error error;
    // value = error.msg (GT_Error::wrong_int_val, info.argv(index));
    return code;
    }

    return code;
    }
    */

//////////////////////////////////////////
//
// SPRINGEMBEDDER KAMADA
//
//////////////////////////////////////////

GT_SpringKamada::GT_SpringKamada (const string& name) : GT_Algorithm (name)
{
}   

GT_SpringKamada::~GT_SpringKamada ()
{
}

int GT_SpringKamada::run (GT_Graph& g)
{
    // check on empty graph
    if (g.leda().number_of_nodes() < 1 ) {
	return GT_OK;
    }
    
    graph leda = g.leda();
    LSD   lsd;
    lsd.gt_graph (&g);

    // Call the algorithm
    lsd.init_call();
    call_springembedder_kamada(lsd.proc_info(), edgelength);
    lsd.clean_up();

    remove_all_bends (g);
    adjust_coordinates (g, 10, 10);

    return GT_OK;
}

int GT_SpringKamada::check (GT_Graph& /* g */, string& message)
{
    message = "";
    return GT_OK;
}

//
// Tcl Wrapper
//


GT_Tcl_SpringKamada::GT_Tcl_SpringKamada (const string& name) :
	GT_Tcl_Algorithm<GT_SpringKamada> (name)
{
}

GT_Tcl_SpringKamada::~GT_Tcl_SpringKamada ()
{
}

int GT_Tcl_SpringKamada::parse (GT_Tcl_info& info, int& index,
    GT_Tcl_Graph* /* g*/)
{
    int code = TCL_OK;

    code = Tcl_GetInt (info.interp(), info.argv(index++), &edgelength);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (GT_Error::wrong_int_val, info.argv(index));
	return code;
    }

    return code;
}

//////////////////////////////////////////
//
// Tunkelang Layout
//
//////////////////////////////////////////

//
// Algortihm
//

GT_Tunkelang::GT_Tunkelang (const string& name) : GT_Algorithm (name)
{
}

GT_Tunkelang::~GT_Tunkelang ()
{
}

int GT_Tunkelang::run (GT_Graph& g)
{
    // check on empty graph
    if (g.leda().number_of_nodes() < 1 ) {
	return GT_OK;
    }
    
    graph *leda = g.attached();
    LSD   lsd;
	bool is_undirected = leda->is_undirected ();
	leda->make_directed();
	
    lsd.gt_graph (&g);
    //sugiyama_settings = init_sugiyama_settings();
	
    lsd.init_call();
    call_tunkelang(lsd.proc_info(), edgelength, quality, rec_depth,
	randomize, cut_value, scan_corners);
    lsd.clean_up();

    remove_all_bends (g);
    adjust_coordinates (g, 10, 10);
	
	if (is_undirected ) {
		leda->make_undirected();
	}

    return GT_OK;
}

int GT_Tunkelang::check (GT_Graph& /* g */, string& message)
{
    message = "";
    return GT_OK;
}

//
// Tcl Wrapper
//

GT_Tcl_Tunkelang::GT_Tcl_Tunkelang (const string name) : 
	GT_Tcl_Algorithm<GT_Tunkelang> (name)
{
}

GT_Tcl_Tunkelang::~GT_Tcl_Tunkelang ()
{
}

int GT_Tcl_Tunkelang::parse (GT_Tcl_info& info, int& index,
    GT_Tcl_Graph* /* g */)
{
    int code = TCL_OK;
    // int value;
	
    // Order: edgelength
    code = Tcl_GetInt (info.interp(), info.argv(index++), &edgelength);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (error.wrong_int_val, index);
	return code;
    }
    code = Tcl_GetInt (info.interp(), info.argv(index++), &quality);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (error.wrong_int_val, index);
	return code;
    }
    code = Tcl_GetInt (info.interp(), info.argv(index++), &rec_depth);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (error.wrong_int_val, index);
	return code;
    }
    code = Tcl_GetInt (info.interp(), info.argv(index++), &randomize);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (error.wrong_int_val, index);
	return code;
    }
    code = Tcl_GetInt (info.interp(), info.argv(index++), &cut_value);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (error.wrong_int_val, index);
	return code;
    }
    code = Tcl_GetInt (info.interp(), info.argv(index++), &scan_corners);
    if (code != TCL_OK) {
	// GT_Error error;
	// value = error.msg (error.wrong_int_val, index);
	return code;
    }
    return code;
}

//////////////////////////////////////////
//
// DAG Layout
//
//////////////////////////////////////////

//
// Algorithm
//

GT_Sugiyama::GT_Sugiyama (const string& name) : GT_Algorithm (name)
{
}

GT_Sugiyama::~GT_Sugiyama ()
{
}

int GT_Sugiyama::run (GT_Graph& g)
{
    // check on empty graph
    if (g.leda().number_of_nodes() < 1 ) {
	return GT_OK;
    }

    graph *leda = g.attached();
	LSD   lsd;
	bool is_undirected = leda->is_undirected ();
	leda->make_directed();
	lsd.gt_graph (&g);
    sugiyama_settings = init_sugiyama_settings();
    lsd.callSgraph(call_sugiyama_layout);

	if (is_undirected ) {
		leda->make_undirected();
	}
    adjust_coordinates (g, 10, 10);
    return GT_OK;
}

int GT_Sugiyama::check (GT_Graph& /* g */, string& message)
{
    message = "";
    return GT_OK;
}

//
// Tcl Wrapper
//

GT_Tcl_Sugiyama::GT_Tcl_Sugiyama (const string& name) :
	GT_Tcl_Algorithm<GT_Sugiyama> (name)
{
}

GT_Tcl_Sugiyama::~GT_Tcl_Sugiyama()
{
}

//////////////////////////////////////////////
//
// Main Initialization function for interface
//
//////////////////////////////////////////////

int GT_gt_lsd_init (Tcl_Interp* interp, GT_GraphScript* /* graphscript */)
{
    int code = 0;

#ifdef 	GT_MODULE_GT_SPRINGEMBEDDER_KAMADA
    GT_Tcl_SpringKamada* layout_spring_kamada =
	new GT_Tcl_SpringKamada ("layout_spring_kk");
    code = layout_spring_kamada->install(interp);
    if (code == TCL_ERROR) {
	return code;
    }
#endif

	
#ifdef GT_MODULE_GT_DAG
    GT_Tcl_Algorithm_Command* layout_dag =
	new GT_Tcl_Sugiyama ("layout_dag");
    code = layout_dag->install(interp);
    if (code == TCL_ERROR) {
	return code;
    }
#endif

	
#ifdef GT_MODULE_GT_TUNKELANG	
    GT_Tcl_Algorithm_Command* layout_tunkelang =
	new GT_Tcl_Tunkelang ("layout_tunkelang");
    code = layout_tunkelang->install(interp);
    if (code == TCL_ERROR) {
	return code;
    }
#endif

	
#ifdef GT_MODULE_GT_SPRINGEMBEDDER_FR

    GT_Tcl_Algorithm_Command* layout_spring_rf =
	new GT_Tcl_SpringRf ("layout_spring_fr");
    code = layout_spring_rf->install(interp);
    if (code == TCL_ERROR) {
	return code;
    }
#endif

#ifdef GT_MODULE_GT_TREE_WALKER
    GT_Tcl_Algorithm_Command* layout_tree =
	new GT_Tcl_Tree_Walker ("layout_tree");
    code = layout_tree->install(interp);
    if (code == TCL_ERROR) {
	return code;
    }
#endif

#ifdef GT_MODULE_GT_GEM
    GT_Tcl_Algorithm_Command* layout_gem =
	new GT_Tcl_Gem ("layout_gem");
    code = layout_gem->install(interp);
    if (code == TCL_ERROR) {
	return code;
    }
#endif
    /*
      GT_Tcl_Algorithm_Command* layout_minimalbends =
      new GT_Tcl_MinimalBendsLayout ("layout_minimalbends");
      code = layout_minimalbends->install(interp);
      if (code == TCL_ERROR) {
      return code;
      }
      */
    return code;
}
