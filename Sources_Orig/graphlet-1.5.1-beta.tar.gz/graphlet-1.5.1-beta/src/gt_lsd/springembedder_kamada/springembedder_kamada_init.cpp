{
	add_to_layout_menu ("Spring Embedder (Kamada)", springembedder_kamada_menu_proc);
	ls_algorithm_set (ls_algorithm_create(),
		LS_NAME,           "spring_kamada",
		LS_FULL_NAME,      "Spring Embedder (Kamada)",
		LS_CALL_PROC,      call_springembedder_kamada,
		LS_ACTIVE,         FALSE,
		NULL);
}
