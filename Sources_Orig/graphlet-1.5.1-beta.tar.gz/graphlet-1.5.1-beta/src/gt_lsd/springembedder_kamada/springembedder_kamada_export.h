extern	GraphEd_Menu_Proc springembedder_kamada_menu_proc;
extern	void	call_springembedder_kamada (Sgraph_proc_info info, int edgelength);
