void	call_check_connectivity (Sgraph_proc_info sgraph_info);
void	call_menu_check_connectivity (Menu menu, Menu menu_item);
void	call_check_strong_connectivity (Sgraph_proc_info sgraph_info);
void	call_menu_check_strong_connectivity (Menu menu, Menu_item menu_item);

extern  void    add_to_tools_menue (char *string, void*);

add_to_tools_menu ("check (weak) connectivity", call_menu_check_connectivity);
add_to_tools_menu ("check (weak) biconnectivity", call_menu_check_biconnectivity);
add_to_tools_menu ("check strong connectivity", call_menu_check_strong_connectivity);
add_to_tools_menu ("check strong biconnectivity", call_menu_check_strong_biconnectivity);
