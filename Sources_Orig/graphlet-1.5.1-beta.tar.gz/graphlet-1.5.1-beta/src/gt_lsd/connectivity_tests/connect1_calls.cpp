/* (C) Universitaet Passau 1986-1994 */

/* test.c  Beispielprogramm zum Test von connect1 */




#include <sgraph/std.h>
#include <sgraph/slist.h>
#include <sgraph/sgraph.h> 
#include <sgraph/graphed.h> 
#include <sgraph/algorithms.h>

extern bool test_sgraph_strongly_biconnected(Sgraph g);

void	call_check_connectivity (Sgraph_proc_info sgraph_info)
{ 
	if  (test_sgraph_connected(sgraph_info->sgraph))
		message("The graph is connected.\n");
	else
		message("The graph is not connected.\n");
} 

void	call_menu_check_connectivity (Menu menu, Menu menu_item)
{
	assert(menu = menu);
	assert(menu_item = menu_item);
	call_sgraph_proc ( (void*)call_check_connectivity , (char*)NULL); 
} 



 
 
void	call_check_strong_connectivity (Sgraph_proc_info sgraph_info)
{ 
	if  (test_sgraph_strongly_connected(sgraph_info->sgraph))
		message("The graph is strongly connected.\n");
	else
		message("The graph is not strongly connected.\n");
} 

void	call_menu_check_strong_connectivity (Menu menu, Menu_item menu_item)
{
	assert(menu = menu);
	assert(menu_item = menu_item);	
	call_sgraph_proc ( (void*)call_check_strong_connectivity, (char*)NULL); 
} 
 


void	call_check_biconnectivity (Sgraph_proc_info sgraph_info)
{ 
	if  (test_sgraph_biconnected(sgraph_info->sgraph))
		message("The graph is biconnected.\n");
	else
		message("The graph is not biconnected.\n");
} 

void	call_menu_check_biconnectivity (Menu menu, Menu_item menu_item)
{ 
	assert(menu = menu);
	assert(menu_item = menu_item);
	call_sgraph_proc ( (void*)call_check_biconnectivity, (char*)NULL); 
} 
 
 

void	call_check_strong_biconnectivity (Sgraph_proc_info sgraph_info)
{ 
	if  (test_sgraph_strongly_biconnected(sgraph_info->sgraph))
		message("The graph is strongly biconnected.\n");
	else
		message("The graph is not strongly biconnected.\n");
} 

void	call_menu_check_strong_biconnectivity (Menu menu, Menu_item menu_item)
{ 
	assert(menu = menu);
	assert(menu_item = menu_item);
	call_sgraph_proc ( (void*)call_check_strong_biconnectivity, (char*)NULL); 
} 
