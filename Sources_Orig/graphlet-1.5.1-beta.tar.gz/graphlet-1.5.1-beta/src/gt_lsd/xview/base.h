 
/*
taken from XView to fake Sgraph that XView is there...
*/

#ifndef xview_base_DEFINED
#define xview_base_DEFINED

#endif /* ~xview_base_DEFINED */
