#ifndef TCL_INFO_H
#define TCL_INFO_H

//
// Tcl_Info.h
//
// This file defines the class GT_Tcl_info
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Info.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/06 08:41:40 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include <gt_base/Error.h>
#include "Tcl.h"

class GT_Tcl_Graph;


class GT_Tcl_info
{
    GT_VARIABLE (Tcl_Interp*, interp);
    GT_VARIABLE (int, argc);
    GT_VARIABLE (char**, argv);
    GT_COMPLEX_VARIABLE (string, msg);
	
public:

    //
    // Constructors and Desctructors
    //
	
    GT_Tcl_info();
    GT_Tcl_info (Tcl_Interp* interp, int argc, char** argv);
    virtual ~GT_Tcl_info();

    //
    // argv access
    //
	
    const char* argv (const int i) const;
    char* argv (const int i);

    inline const char* operator[] (const int i) const;
    inline char* operator[] (const int i);
    
    const GT_Key operator() (const int i) const;
    GT_Key operator() (const int i);
    
    //
    // Is argument index
    // - is_last_arg:   the last argument
    // - exists:        does it exist at all ?
    //
    
    bool is_last_arg (const int index);
    bool exists (const int index);

    //
    // How many arguments are left
    //
    
    bool args_left (const int index, const int n, bool exact = true);
    int args_left (const int index);
    bool args_left_at_least (const int index, const int n) {
	return args_left (index, n, false);
    }
    bool args_left_exactly (const int index, const int n) {
	return args_left (index, n);
    }
	
    //
    // some special access methods for msg ...
    //
	
    string& msg(); // non-const access to msg

    void msg (const int error);
    void msg (const int error, const int i);
    void msg (const int error, const string& s);

    //
    // client_data special access
    //
	
    GT_Tcl_Graph* g();

};


const char* GT_Tcl_info::operator[] (const int i) const {
    return argv(i);
}


char* GT_Tcl_info::operator[] (const int i) {
    return argv(i);
}
    

#endif
