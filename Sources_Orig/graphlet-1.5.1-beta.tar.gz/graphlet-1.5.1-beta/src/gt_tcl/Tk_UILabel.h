#ifndef GT_TK_UILABEL_H
#define GT_TK_UILABEL_H

//
// Tk_UILabel.h
//
// This file defines the class GT_Tk_UILabel.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tk_UILabel.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:13 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//


#include "Tk_UIObject.h"


class GT_Tk_UILabel : public GT_Tk_UIObject
{
    GT_CLASS (GT_Tk_UILabel, GT_Tk_UIObject);

    GT_VARIABLE (GT_Graph*, g);
    GT_VARIABLE (node, n);
    GT_VARIABLE (edge, e);
	
public:
    GT_Tk_UILabel (const int uid,
	GT_Tcl_Device* device,
	GT_UIObject* parent,
	GT_Graph* g);
    GT_Tk_UILabel (const int uid,
	GT_Tcl_Device* device,
	GT_UIObject* parent,
	GT_Graph* g, node n);
    GT_Tk_UILabel (const int uid,
	GT_Tcl_Device* device,
	GT_UIObject* parent,
	GT_Graph* g, edge e);
	
    virtual ~GT_Tk_UILabel ();

    virtual const GT_Key& type () const;
    virtual GT_Common_Attributes& attrs ();
    virtual const GT_Common_Attributes& attrs () const;

    virtual void make_update_coords_cmd (string& cmd,
	bool may_move_or_scale);
    virtual void make_create_cmd (string& cmd);
    virtual void make_tags_cmd (string& cmd);
    virtual void make_update_attrs_cmd (string& cmd);
};


#endif
