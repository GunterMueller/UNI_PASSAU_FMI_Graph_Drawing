#ifndef TCL_GRAPH_H
#define TCL_GRAPH_H

//
// GT_Tcl_Graph.h
// 
// This module defines the class GT_Tcl_Graph
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Graph.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/04 08:46:23 $
// $Locker:  $
// $State: Exp $
// ----------------------------------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#include <gt_base/Graphlet.h>
#include <gt_base/Graph.h>

#include "Tcl_Info.h"
#include "Tk_Device.h"


//////////////////////////////////////////
//
// class GT_Tcl_Graph
//
//////////////////////////////////////////

class GT_Device;
class GT_Tcl_Device;

class GT_UIObject;

class GT_Tk_UIGraph;
class GT_Tk_UINode;
class GT_Tk_UIEdge;
class GT_Tk_UILabel;


class GT_Tcl_Graph : public GT_Graph
{
    GT_CLASS (GT_Tcl_Graph, GT_Graph);

    list<GT_Device*> the_devices;
    
    GT_VARIABLE (list<string>, tcl_new_node_actions);
    GT_VARIABLE (list<string>, tcl_del_node_actions);
    GT_VARIABLE (list<string>, tcl_new_edge_actions);
    GT_VARIABLE (list<string>, tcl_del_edge_actions);
    GT_VARIABLE (list<string>, tcl_rev_edge_actions);
    GT_VARIABLE (list<string>, tcl_clear_actions);

public:

    //
    // Constructor && Descructor
    //
	
    GT_Tcl_Graph();
    virtual ~GT_Tcl_Graph();

    //
    // The next two commands are static as they are passed via
    // function pointers in C (without ++) procedures.
    //

    // cmd is the command "graph"
	
    static int cmd (ClientData clientData,
	Tcl_Interp* interp,
	int argc,
	char** argv);

    // static_parser is the parser for the arguments of "graph"
	
    static int static_parser (ClientData clientData,
	Tcl_Interp* interp,
	int argc,
	char** argv);

    // parser is the non-static (i.e. customizable) part of static_parser
	
    virtual int parser (Tcl_Interp* interp, int argc, char** argv);

	
    //////////////////////////////////////////
    //
    // Graph
    //
    //////////////////////////////////////////

	
    virtual void new_graph ();
    virtual void new_graph_action ();

    //
    // Tcl Command interpreters
    //
	
    virtual int canvas_cmd (GT_Tcl_info& tcl_info, int argc);
	
    virtual int configure_cmd (GT_Tcl_info& tcl_info,
	int argc,
	const GT_Tcl::Get_Mode mode);
	
    virtual int draw_cmd (GT_Tcl_info& tcl_info,
	int argc);

    virtual int print_cmd (GT_Tcl_info& tcl_info,
	int argc);
    virtual void print (ostream& out);	
	
    virtual int load_cmd (GT_Tcl_info& tcl_info,
	int argc);

    virtual int delete_cmd (GT_Tcl_info& tcl_info,
	int argc);
    virtual void clear_action();


    virtual int nodes_cmd (GT_Tcl_info& tcl_info,
	int argc);
    virtual int edges_cmd (GT_Tcl_info& tcl_info,
	int argc);

    //
    // Configure procs
    //
	
    virtual int common_configure_set (GT_Common_Attributes& attrs,
	const GT_Key& key,
	GT_Tcl_info& tcl_info, int argc,
	bool& found);
    virtual int common_configure_get (const GT_Common_Attributes& attrs,
	const GT_Key& key,
	string& value,
	const GT_Tcl::Get_Mode mode,
	bool &found);

    virtual int graphconfigure_set (
	const GT_Key& key,
	GT_Tcl_info& tcl_info, int argc,
	bool& found);
    virtual int graphconfigure_get (
	const GT_Key& key,
	string& value,
	const GT_Tcl::Get_Mode mode,
	bool& found);


    //////////////////////////////////////////
    //
    // Node
    //
    //////////////////////////////////////////

	
    virtual int create_node_cmd (GT_Tcl_info& tcl_info,
	int argc);
    virtual void new_node_action (node n);
    virtual void del_node_action (node n);

    //
    // Tcl Command procs
    //
	
    virtual int nodeconfigure_cmd (GT_Tcl_info& tcl_info,
	int argc,
	const GT_Tcl::Get_Mode mode);

    virtual int nodemove_cmd (GT_Tcl_info& tcl_info,
	int argc);
    virtual int nodedraw_cmd (GT_Tcl_info& tcl_info,
	int argc);
    virtual int nodedelete_cmd ( GT_Tcl_info& tcl_info,
	int argc);
	
    //
    // Node Configuration procs
    //
	
    virtual int nodeconfigure_set (const node n,
	const GT_Key& key,
	GT_Tcl_info& tcl_info, int argc,
	bool& found);
    virtual int nodeconfigure_get (const node n,
	const GT_Key& key,
	string& value,
	const GT_Tcl::Get_Mode mode,
	bool& found);


	
    //////////////////////////////////////////
    //
    // Edge 
    //
    //////////////////////////////////////////


    virtual int create_edge_cmd (
	GT_Tcl_info& tcl_info,
	int argc);
    virtual void new_edge_action (edge e);
    virtual void del_edge_action (edge e);	
    virtual void rev_edge_action (edge e);	

    //
    // TcL Command procs
    //
	
    virtual int edgeconfigure_cmd (GT_Tcl_info& tcl_info,
	int argc,
	const GT_Tcl::Get_Mode mode);

    virtual int edgedelete_cmd (
	GT_Tcl_info& tcl_info,
	int argc);
    virtual int edgedraw_cmd (
	GT_Tcl_info& tcl_info,
	int argc);

    //
    // Edge Configuration procs
    //
	
    virtual int edgeconfigure_set (const edge n,
	const GT_Key& key,
	GT_Tcl_info& tcl_info, int argc,
	bool& found);
    virtual int edgeconfigure_get (const edge n,
	const GT_Key& key,
	string& value,
	const GT_Tcl::Get_Mode mode,
	bool& found);



    //////////////////////////////////////////
    //
    // Action (hook) commands
    //
    //////////////////////////////////////////

	
    virtual int action_cmd (
	GT_Tcl_info& tcl_info,
	int argc);

    virtual void insert_hook (list<string>& hooks,
	const string& proc);
    virtual int run_hooks (const list<string>& hooks,
	const int uid,
	const GT_Key& action_name);


	
    //////////////////////////////////////////
    //
    // Drawing
    //
    //////////////////////////////////////////

    //
    // Configure Common Graphics
    //
	
    virtual int graphicsconfigure_set (GT_Common_Graphics* graphics,
	const GT_Key& key,
	GT_Tcl_info& tcl_info,	int argc,
	bool& found);

    virtual int graphicsconfigure_get (const GT_Common_Graphics* graphics,
	const GT_Key& key,
	string& value,
	const GT_Tcl::Get_Mode mode,
	bool& found);

    //
    // draw procs
    //
	
    virtual int draw ();	
    virtual int draw (node n);
    virtual int draw (edge e);	

    virtual int move_node (node n,
	const double x_diff,
	const double y_diff);
    virtual int move_nodes (const list<node>& nodes,
	const double x_diff,
	const double y_diff);
    virtual int move_edge (edge e,
	const double x_diff,
	const double y_diff);

    virtual int begin_draw ();
    virtual int end_draw ();


    //
    // update
    //

    virtual void update ();
    virtual void update (node n);
    virtual void update (edge e);
	
    virtual void update_label_coordinates ();
    virtual void update_label_coordinates (node n);
    virtual void update_label_coordinates (edge e);

    virtual void update_coordinates ();
    virtual void update_coordinates (node n);
    virtual void update_coordinates (edge e);


    //
    // Customization
    //
    
    virtual GT_Tk_UIGraph* new_tk_uigraph (const int uid,
	GT_Tcl_Device* const device,
	GT_UIObject* parent,
	GT_Graph* g);
    virtual GT_Tk_UINode* new_tk_uinode (const int uid,
	GT_Tcl_Device* const device,
	GT_UIObject* parent,
	GT_Graph* g,
	const node n);
    virtual GT_Tk_UIEdge* new_tk_uiedge (const int uid,
	GT_Tcl_Device* const device,
	GT_UIObject* parent,
	GT_Graph* g,
	const edge e);
    virtual GT_Tk_UILabel* new_tk_uilabel (const int uid,
	GT_Tcl_Device* device,
	GT_UIObject* parent,
	GT_Graph* g);
    virtual GT_Tk_UILabel* new_tk_uilabel (const int uid,
	GT_Tcl_Device* device,
	GT_UIObject* parent,
	GT_Graph* g,
	node n);
    virtual GT_Tk_UILabel* new_tk_uilabel (const int uid,
	GT_Tcl_Device* device,
	GT_UIObject* parent,
	GT_Graph* g,
	edge e);

    virtual GT_Tcl_Device* new_tcl_device (
	const string& name,
	Tcl_Interp* interp);
	
    //
    // Searching for nodes and edges
    //
	
protected:
	
    virtual node find_node_with_uid (const int node_id);
    virtual edge find_edge_with_uid (const int edge_id);

    virtual int find_node_with_uid (GT_Tcl_info& tcl_info,
	const int node_id,
	node& n);
    virtual int find_edge_with_uid (GT_Tcl_info& tcl_info,
	const int edge_id,
	edge& e);

    virtual int strip_GT_prefix (GT_Tcl_info& tcl_info,
	const char* s,
	int& stripped);
	
public:
    virtual int find_node (GT_Tcl_info& tcl_info, const char* s, node& n);
    virtual int find_edge (GT_Tcl_info& tcl_info, const char* s, edge& e);
    virtual int find_graph (GT_Tcl_info& tcl_info, const char* s, graph& g);


    //
    // Tcl helper methods
    //

    int list_of_nodes (GT_Tcl_info& tcl_info, int argc,
	list<node>& nodes);
    int list_of_edges (GT_Tcl_info& tcl_info, int argc,
	list<edge>& edges);
};

#endif
