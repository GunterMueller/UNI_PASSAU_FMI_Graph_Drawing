//
// GraphScript.cc
//
// This file implements the class GT_UI.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/GraphScript.cpp,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/10/27 14:09:24 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Tcl_Graph.h"

#include <gt_base/config.h>
#include <tk.h>

#include "GraphScript.h"


//
// Constructors and Destructors
//


GT_GraphScript::GT_GraphScript (Tcl_Interp* interp)
{
    the_interp = interp;
    the_tcl_only = false;
}



GT_GraphScript::~GT_GraphScript ()
{
}



//
// Initialization of GraphScript
//

int GT_GraphScript::init ()
{
    //
    // Initialize GT(graphlet_dir)
    //
	
    char* graphlet_dir_env = getenv ("GRAPHLET_DIR");
    char* graphlet_dir_value = GT_Tcl::SetVar2 (the_interp,
	"GT", "graphlet_dir",
	graphlet_dir_env == 0 ? GT_GRAPHLET_DIR : graphlet_dir_env,
	TCL_GLOBAL_ONLY);
    if (graphlet_dir_value == NULL) {
	Tcl_AddErrorInfo (the_interp, "Error initializing GT(graphlet_dir)");
	return TCL_ERROR;
    }

    //
    // Initialize GT(major_version)
    // Initialize GT(minor_version)
    // Initialize GT(mini_version)
    // Initialize GT(release)
    //

    string major_version ("%d", GT_MAJOR_VERSION);
    char* major_version_value = GT_Tcl::SetVar2 (the_interp,
	"GT", "major_version", major_version,
	TCL_GLOBAL_ONLY);
    string minor_version ("%d", GT_MINOR_VERSION);
    char* minor_version_value = GT_Tcl::SetVar2 (the_interp,
	"GT", "minor_version", minor_version,
	TCL_GLOBAL_ONLY);
    string mini_version ("%d", GT_MINI_VERSION);
    char* mini_version_value = GT_Tcl::SetVar2 (the_interp,
	"GT", "mini_version", mini_version,
	TCL_GLOBAL_ONLY);
    char* release_value = Tcl_SetVar2 (the_interp,
	"GT", "release", GT_RELEASE,
	TCL_GLOBAL_ONLY);
    if (major_version_value == NULL ||
	minor_version_value == NULL ||
	mini_version_value == NULL ||
	release_value == NULL) {
	return TCL_ERROR;
    }

    string graphscript_init_script =
	graphlet_dir_value + string ("/lib/graphscript/init.tcl");
    int code = Tcl_EvalFile (the_interp, graphscript_init_script.cstring());
    if (code == TCL_ERROR) {
	string msg =
	    string ("Error while initializing GraphScript at ") +
	    graphscript_init_script;
	Tcl_AddErrorInfo (the_interp, msg.cstring());
	return code;
    }

    code = Tcl_Eval (the_interp, "GT_init");
    if (code == TCL_ERROR) {
	Tcl_AddErrorInfo (the_interp, "Error evaluating GT_init");
	return code;
    }
		
    return commands_init ();
}



//
// Commands initialization
//

int GT_GraphScript::commands_init ()
{
    //
    // install command "graph"
    //
	
    if (GT_Tcl::CreateCommand (
	the_interp,
	"graph", 
	GT_Tcl_Graph::cmd,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL) == NULL) {
		
	return TCL_ERROR;

    }
	
    return TCL_OK;
}



//
// int GT_GraphScript::application_init (Tcl_Interp *interp)
//


int GT_GraphScript::application_init (Tcl_Interp *interp)
{
    int code;
    code = Tcl_Init (interp);
    if (code == TCL_ERROR) {
	return code;
    }

    if (!the_tcl_only) {
	code = Tk_Init (interp);
	if (code == TCL_ERROR) {
	    return code;
	}
    }

    //
    // Initialize Graphlet
    //
    GT::init();

    //
    // Initialize GraphScript
    //
    code = this->init();
    if (code == TCL_ERROR) {
	return code;
    }

    //
    // Add more initializations and commands here
    //
	
    return code;
}


int GT_GraphScript::main (int argc, char **argv,
    Tcl_AppInitProc *application_init)
{
    Tk_Main (argc, argv, application_init);

    return 0;
}
