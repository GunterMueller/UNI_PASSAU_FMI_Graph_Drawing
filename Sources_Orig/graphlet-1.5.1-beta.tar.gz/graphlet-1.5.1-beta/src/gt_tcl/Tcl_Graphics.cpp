//
// GT_Tcl_Graphics.h
// 
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Graphics.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:12 $
// $Locker:  $
// $State: Exp $
// ----------------------------------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#include "Tcl_Graph.h"



#include "Tcl_Graphics.h"


int GT_Tcl_Graph::graphicsconfigure_set (GT_Common_Graphics* graphics,
    const GT_Key& key,
    GT_Tcl_info& tcl_info,
    int argc,
    bool& found)
{
    int code = TCL_OK;
	
    //
    // Common
    //
	
    if (key == GT_Keys::option_type) {

	found = true;
	graphics->type (tcl_info (argc++));
	code = TCL_OK;
		
    } else if (key == GT_Keys::option_w) {
		
	found = true;

	double w;
	code = Tcl_GetDouble (tcl_info.interp(), tcl_info[argc++], &w);
	if (code == TCL_OK) {
	    if (w > GT_epsilon) {
		graphics->w (w);
	    } else {
		graphics->w (GT_epsilon);
	    }
	}
		
    } else if (key == GT_Keys::option_h) {
		
	found = true;

	double h;
	code = Tcl_GetDouble (tcl_info.interp(), tcl_info[argc++], &h);
	if (code == TCL_OK) {
	    if (h > GT_epsilon) {
		graphics->h (h);
	    } else {
		graphics->h (GT_epsilon);
	    }
	}
			
    } else if (key == GT_Keys::option_x) {
		
	found = true;

	double x;
	code = Tcl_GetDouble (tcl_info.interp(), tcl_info[argc++], &x);
	if (code == TCL_OK) {
	    graphics->x (x);
	}
		
    } else if (key == GT_Keys::option_y) {
		
	found = true;

	double y;
	code = Tcl_GetDouble (tcl_info.interp(), tcl_info[argc++], &y);
	if (code == TCL_OK) {
	    graphics->y (y);
	}
		
    } else if (key == GT_Keys::option_fill) {
		
	found = true;
	graphics->fill (tcl_info(argc++));
	code = TCL_OK;
		
    } else if (key == GT_Keys::option_outline) {
		
	found = true;
	graphics->outline (tcl_info(argc++));
	code = TCL_OK;
		
    } else if (key == GT_Keys::option_stipple) {
		
	found = true;
	graphics->stipple (tcl_info(argc++));
	code = TCL_OK;
		
    } else if (key == GT_Keys::option_anchor) {
		
	found = true;
	graphics->anchor (tcl_info(argc++));
	code = TCL_OK;
		
    } else if (key == GT_Keys::option_width) {
		
	found = true;

	double width;
	code = Tcl_GetDouble (tcl_info.interp(), tcl_info[argc++], &width);
	if (code == TCL_OK) {
	    graphics->width (width);
	}
		
    }

    // Arc

    else if (key == GT_Keys::option_extent) {
		
	double extent;
	code = Tcl_GetDouble (tcl_info.interp(), tcl_info[argc++], &extent);
	if (code == TCL_OK) {
	    graphics->extent (extent);
	}
		
    }

    else if (key == GT_Keys::option_start) {
		
	found = true;

	double start;
	code = Tcl_GetDouble (tcl_info.interp(), tcl_info[argc++], &start);
	if (code == TCL_OK) {
	    graphics->start (start);
	}
		
    } else if (key == GT_Keys::option_style) {
		
	found = true;
	graphics->style (tcl_info(argc++));
	code = TCL_OK;
    }

    //
    // Bitmap
    //
	
    else if (key == GT_Keys::option_foreground) {
		
	found = true;
	graphics->foreground (tcl_info(argc++));
	code = TCL_OK;
		
    } else if (key == GT_Keys::option_background) {
		
	found = true;
	graphics->background (tcl_info(argc++));
	code = TCL_OK;

    } else if (key == GT_Keys::option_bitmap) {
		
	found = true;
	graphics->bitmap (tcl_info(argc++));
	code = TCL_OK;
		
    }

    //
    // Line
    //
	
    else if (key == GT_Keys::option_arrow) {

	found = true;
	graphics->arrow (tcl_info(argc++));
	code = TCL_OK;
		
    } else if (key == GT_Keys::option_arrowshape) {

	found = true;
	graphics->arrowshape (tcl_info(argc++));
	code = TCL_OK;
		
    } else if (key == GT_Keys::option_capstyle) {

	found = true;
	graphics->capstyle (tcl_info(argc++));
	code = TCL_OK;
		
    } else if (key == GT_Keys::option_joinstyle) {

	found = true;
	graphics->joinstyle (tcl_info(argc++));
	code = TCL_OK;
		
    }
	
    //
    // Image
    //
	
    else if (key == GT_Keys::option_image) {		

	found = true;
	graphics->image (tcl_info(argc++));
	code = TCL_OK;
		
    }

    //
    // Polygon
    //
	
    else if (key == GT_Keys::option_smooth) {
		
	found = true;

	int int_smooth;
	code = Tcl_GetBoolean (tcl_info.interp(), tcl_info[argc++],
	    &int_smooth);
	if (code == TCL_OK) {
	    graphics->smooth (int_smooth == 0 ? false : true);
	}
		
    } else if (key == GT_Keys::option_splinesteps) {
		
	found = true;

	int splinesteps;
	code = Tcl_GetInt (tcl_info.interp(), tcl_info[argc++], &splinesteps);
	if (code == TCL_OK) {
	    graphics->splinesteps (splinesteps);
	}
		
    }

    //
    // Text
    //

    else if (key == GT_Keys::option_justify) {

	found = true;
	graphics->justify (tcl_info(argc++));
	code = TCL_OK;
		
    } else if (key == GT_Keys::option_xfont) {

	found = true;
	graphics->font (tcl_info(argc++));
	code = TCL_OK;
    }

    //
    // Line
    //
	
    else if (key == GT_Keys::option_line) {
		
	found = true;

	char** list_argv;
	int list_argc;
		
	//
	// Split the list
	//
		
	code = Tcl_SplitList (tcl_info.interp(),
	    tcl_info[argc++],
	    &list_argc,
	    &list_argv);
		
	//
	// Test & go
	//
		
	if (code != TCL_OK) {
	    tcl_info.msg (GT_Error::internal_error,
		"in Tcl_SplitList");
	} else if (list_argc % 2 != 0) {
	    tcl_info.msg (
		"List for -line has an uneven number of entries");
	    code = TCL_ERROR;
	} else {
		
	    GT_Polyline points;
	    for (int i = 0; i+1 < list_argc; i += 2) {
				
		double x,y;
				
		code = Tcl_GetDouble (tcl_info.interp(),
		    list_argv[i],
		    &x);
		if (code != TCL_OK) {
		    tcl_info.msg (GT_Error::wrong_double_val,
			list_argv[i]);
		    return code;
		}
				
		code = Tcl_GetDouble (tcl_info.interp(),
		    list_argv[i+1],
		    &y);
		if (code != TCL_OK) {
		    tcl_info.msg (GT_Error::wrong_double_val,
			list_argv[i+1]);
		    return code;
		}
				
		points.append (GT_Point (x,y));
	    }
			
	    graphics->line (points);
	    code =  TCL_OK;
	}
		
    } else {
	tcl_info.msg (GT_Error::wrong_keyword, key.name());
	code = TCL_ERROR;
    }
	
    return code;
}



int GT_Tcl_Graph::graphicsconfigure_get (const GT_Common_Graphics* graphics,
    const GT_Key& key,
    string& value,
    const GT_Tcl::Get_Mode mode,
    bool& found)
{
    int code = TCL_OK;
	
    bool get_all = (key == GT_Keys::empty);

    //
    // Common
    //
	
    if (key == GT_Keys::option_type || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_type,
	    graphics->type(),
	    mode);
	found = true;
    }
    if (key == GT_Keys::option_w || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_w,
	    graphics->w(),
	    mode);
	found = true;
    }
    if (key == GT_Keys::option_h || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_h,
	    graphics->h(),
	    mode);
	found = true;
    }
    if (key == GT_Keys::option_x || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_x,
	    graphics->x(),
	    mode);
	found = true;
    }
    if (key == GT_Keys::option_y || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_y,
	    graphics->y(),
	    mode);
	found = true;
    }

    if (key == GT_Keys::option_fill || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_fill,
	    graphics->fill(),
	    mode);
	found = true;
    }
	
    if (key == GT_Keys::option_outline || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_outline,
	    graphics->outline(),
	    mode);
	found = true;
    }
	
    if (key == GT_Keys::option_stipple || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_stipple,
	    graphics->stipple(),
	    mode);
	found = true;
    }
	
    if (key == GT_Keys::option_anchor || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_anchor,
	    graphics->anchor(),
	    mode);
	found = true;
    }

    if (key == GT_Keys::option_width || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_width,
	    graphics->width(),
	    mode);
	found = true;
    }


    //
    // Arc
    //

    if (key == GT_Keys::option_extent || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_extent,
	    graphics->extent(),
	    mode);
	found = true;
    }

    if (key == GT_Keys::option_start || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_start,
	    graphics->start(),
	    mode);
	found = true;
    }
	
    if (key == GT_Keys::option_style || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_style,
	    graphics->style(),
	    mode);
	found = true;
    }
	
    //
    // Bitmap
    //
	
    if (key == GT_Keys::option_bitmap || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_bitmap,
	    graphics->bitmap(),
	    mode);
	found = true;
    }

    if (key == GT_Keys::option_foreground || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_foreground,
	    graphics->foreground(),
	    mode);
	found = true;
    }
	
    if (key == GT_Keys::option_background || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_background,
	    graphics->background(),
	    mode);
	found = true;
    }
	
    //
    // Image
    //
	
    if (key == GT_Keys::option_image || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_image,
	    graphics->image(),
	    mode);
	found = true;
    }

    //
    // Line
    //
	
    if (key == GT_Keys::option_arrow || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_arrow,
	    graphics->arrow(),
	    mode);
	found = true;
    }

    if (key == GT_Keys::option_arrowshape || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_arrowshape,
	    graphics->arrowshape(),
	    mode);
	found = true;
    }

    if (key == GT_Keys::option_capstyle || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_capstyle ,
	    graphics->capstyle(),
	    mode);
	found = true;
    }

    if (key == GT_Keys::option_joinstyle || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_joinstyle,
	    graphics->joinstyle(),
	    mode);
	found = true;
    }


    //
    // Polygon
    //

    if (key == GT_Keys::option_smooth || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value,  GT_Keys::option_smooth,
	    graphics->smooth(),
	    mode);
	found = true;
    }
	
    if (key == GT_Keys::option_splinesteps || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_splinesteps,
	    graphics->splinesteps(),
	    mode);
	found = true;
    }

    //
    // Text
    //
	
    if (key == GT_Keys::option_justify || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_justify,
	    graphics->justify(),
	    mode);
	found = true;
    }
	
    if (key == GT_Keys::option_xfont || (get_all && code == TCL_OK)) {
	code = GT_Tcl::format_value (value, GT_Keys::option_xfont,
	    graphics->font(),
	    mode);
	found = true;
    }
	
    //
    // Line
    //
	
    if (key == GT_Keys::option_line || (get_all && code == TCL_OK)) {
		
	if (mode == GT_Tcl::configure) {
	    value += string ("{ %s { ", GT_Keys::option_line.name());
	}

	GT_Point p;
	forall (p, graphics->line()) {
	    value += string ("%f %f ",
		p.xcoord(),
		p.ycoord());
	}
		
	if (mode == GT_Tcl::configure) {
	    value += " } }";
	}

	found = true;
	code = TCL_OK;
    }
    if (!found) {
	GT_Error error;
	value = error.msg (GT_Error::wrong_keyword, key.name());
    }

    return code;
}
