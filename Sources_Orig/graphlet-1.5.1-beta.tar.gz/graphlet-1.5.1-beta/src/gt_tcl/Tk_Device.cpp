//
// Tcl_Devices.cc
//
// This file implements the classes GT_UIObjects, GT_Device and
// GT_Devices.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tk_Device.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:12 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Tcl_Graph.h"

#include "Tk_Device.h"


GT_Tcl_Device::GT_Tcl_Device (const string& name, Tcl_Interp* interp) :
	GT_Device (name), the_interp(interp)
{
}

GT_Tcl_Device::~GT_Tcl_Device ()
{
}
