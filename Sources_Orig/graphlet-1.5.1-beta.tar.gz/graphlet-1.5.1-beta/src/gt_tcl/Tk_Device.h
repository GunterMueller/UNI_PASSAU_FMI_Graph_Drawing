#ifndef GT_TCL_DEVICE_H
#define GT_TCL_DEVICE_H

//
// Device.h
//
// This file defines the classes GT_Tcl_Device.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tk_Device.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:13 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include <gt_base/Device.h>

class GT_Tcl_Device : public GT_Device {

    GT_CLASS (GT_Tcl_Device, GT_Device);

    GT_VARIABLE (Tcl_Interp*, interp);
	
public:

    GT_Tcl_Device (const string& name, Tcl_Interp* interp);
    virtual ~GT_Tcl_Device ();
};

#endif
