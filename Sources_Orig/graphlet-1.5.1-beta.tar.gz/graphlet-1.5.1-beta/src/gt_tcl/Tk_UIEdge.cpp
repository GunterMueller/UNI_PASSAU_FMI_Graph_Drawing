//
// Tk_UIEdge.cc
//
// This file implements the class GT_Tk_UIEdge.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tk_UIEdge.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:13 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Tcl_Graph.h"

// #include "GraphScript.h"
#include "Tk_UIEdge.h"


//////////////////////////////////////////
//
// Constructors and Destructors
//
//////////////////////////////////////////


GT_Tk_UIEdge::GT_Tk_UIEdge (const int uid,
    GT_Tcl_Device* const device,
    GT_UIObject* parent,
    GT_Graph* g,
    const edge e) :
	GT_Tk_UIObject (uid, device, parent)
{
    the_g = g;
    the_e = e;
    graphics (g->gt(e).graphics());
}


GT_Tk_UIEdge::~GT_Tk_UIEdge ()
{
    ;
}


//////////////////////////////////////////
//
// type
//
//////////////////////////////////////////

const GT_Key& GT_Tk_UIEdge::type() const
{
    return GT_Keys::uiobject_edge;
}



//////////////////////////////////////////
//
// make commands
//
//////////////////////////////////////////


void GT_Tk_UIEdge::make_create_cmd (string& cmd )
{
    GT_Common_Graphics* cg = graphics();

    if (!cg->type().active()) {
	graphics()->type (GT_Keys::type_line);		
    }

    if (!cg->arrow().active() && the_g->leda().is_directed()) {
	cg->arrow (GT_Keys::anchor_last);
    }
    
    baseclass::make_create_cmd (cmd);
}
