//
// Tcl_Algorithm.cc
//
// This file implements the class GT_Algorithm.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Algorithm.cpp,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/06 08:41:34 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Tcl_Graph.h"

#include "Tcl_Algorithm.h"


//////////////////////////////////////////
//
// class GT_Tcl_Algorithm
//
//////////////////////////////////////////


//
// Constructors and Destructor
//

GT_Tcl_Algorithm_Command::GT_Tcl_Algorithm_Command (const string& name) :
	GT_Tcl_Command (name, GT::keymapper.add (name))
{
    reset_before_run (false);   
    might_change_structure (true);
    might_change_coordinates (true);
}



GT_Tcl_Algorithm_Command::~GT_Tcl_Algorithm_Command ()
{
}


	
//
// command line parser
//


int GT_Tcl_Algorithm_Command::algorithm_parser (GT_Tcl_info& info, int& index,
    GT_Algorithm& algorithm)
{
    string msg;
    int code = TCL_OK;

    if (!info.exists (index)) {
		
	info.msg ("No graph given");
	code = TCL_ERROR;
		
    } else {

	//
	// If the first argument is a Graphet identier, it must be the graph
	//
	
	GT_Tcl_Graph* g;
	string first_argument = info.argv (index);
	if (is_gt_object (first_argument)) {
	    code = GT_Tcl_Graph_Command::get (info.interp(),
		first_argument, g);
	    if (code == TCL_ERROR) {
		return code;
	    } else {
		index ++;
	    }
	}

	//
	// Parse the arguments.
	//
	
	while (info.exists (index)) {
	    code = parse (info, index, g);
	    if (code == TCL_ERROR) {
		return code;
	    }
	}

	//
	// If we have a graph, run the algorithm.
	//
	
	if (g != 0) {

	    // Check first.
	    
	    code = algorithm.check (*g, info.msg());
	    
	    if (code == GT_OK) {

		// Reset (probably).
		if (the_reset_before_run) {
		    algorithm.reset();
		}

		// Run and save result if not empty.
		code = algorithm.run (*g);
		if (the_result != "") {
		    info.msg (the_result);
		}

		// Draw
		g->begin_draw();
		g->draw();
		g->end_draw();
			
	    } else {

		// Error: result holds error message.
		if (the_result != "") {
		    info.msg (string ("{ \"%s\" %s }",
			info.msg().cstring(),
			the_result.cstring()));
		}
		
	    }   
	}
    }

    return code;
}


int GT_Tcl_Algorithm_Command::parse (GT_Tcl_info& info,
    int& /* index */,
    GT_Tcl_Graph* /* g */)
{
    info.msg ("Error while parsing parameters\n");
    return TCL_ERROR;
}
