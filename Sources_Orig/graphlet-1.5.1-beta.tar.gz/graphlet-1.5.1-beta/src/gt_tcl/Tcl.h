#ifndef GT_TCL_H
#define GT_TCL_H

//
// Tcl.h
//
// This file defines Tcl/Tk utilities and the class GT_Tcl,
// which contains utilities for a Tcl interface.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/04 08:46:17 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#ifdef _WIN32
// HAIL Microsoft
#define list GT_dummy_list
#endif

#include <tcl.h>

#ifdef _WIN32
#undef list
// HAIL LEDA
#endif

#include <gt_base/Graph.h>

typedef list<int> GT_Tk_Id_List;

class GT_Tcl_info;  // forward declaration

class GT_Tcl
{
    GT_BASE_CLASS (GT_Tcl);

public:

    GT_Tcl();
    virtual ~GT_Tcl();

    enum Get_Mode {
	configure,
	get
    };
	
    static int format_value (string& formatted,
	const GT_Key& key,
	const int i,
	const Get_Mode mode);
    static int format_value (string& formatted,
	const GT_Key& key,
	const bool b,
	const Get_Mode mode);
    static int format_value (string& formatted,
	const GT_Key& key,
	const double d,
	const Get_Mode mode);
    static int format_value (string& formatted,
	const GT_Key& key,
	const string& s,
	const Get_Mode mode);
    static int format_value (string& formatted,
	const GT_Key& key,
	const GT_Key& k,
	const Get_Mode mode);
	
    //
    // Convenient Wrappers for TCL Calls
    //
    // This list is by NO means complete; functions are added as needed
    //

    static char* SetVar2 (Tcl_Interp *interp,
	const string& array, const string& index,
	const string& new_value,
	int flags);

    static Tcl_Command CreateCommand (Tcl_Interp *interp,
	const string& name,
	Tcl_CmdProc* proc,
	void *client_data,
	Tcl_CmdDeleteProc* delete_proc);

    static string gt (const GT_Graph& g);
    static string gt (const GT_Graph& g, const node n);
    static string gt (const GT_Graph& g, const edge e);

    static string list_of_strings (const list<string>& strings);
    static void list_of_strings (const list<string>& strings,
	string& result);

    static int get_int (GT_Tcl_info& info, const char* s, int& result);
    static int get_double (GT_Tcl_info& info, const char* s, double& result);
    static int get_boolean (GT_Tcl_info& info, const char* s, int& result);
    static int get_boolean (GT_Tcl_info& info, const char* s, bool& result);
};
    
#endif
