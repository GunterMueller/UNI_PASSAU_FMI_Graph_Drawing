#ifndef TCL_EDGE_H
#define TCL_EDGE_H

//
// Tcl_Edge.h
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Edge.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:12 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#endif
