//
// Tcl_Info.h
//
// This file implements the class GT_Tcl_info
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Info.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:12 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include <gt_base/Graphlet.h>

#include "Tcl_Info.h"


GT_Tcl_info::GT_Tcl_info ()
{
    ;
}


GT_Tcl_info::GT_Tcl_info (Tcl_Interp* interp,
    int argc, char** argv)
{
    the_interp = interp;
    the_argc   = argc;
    the_argv   = argv;
}


GT_Tcl_info::~GT_Tcl_info()
{
    ;
}


//
// Special access to argv
//

const char* GT_Tcl_info::argv (const int i) const
{
    assert (i < the_argc);
    return the_argv[i];
}


char* GT_Tcl_info::argv (const int i)
{
    assert (i < the_argc);
    return the_argv[i];
}


const GT_Key GT_Tcl_info::operator() (const int i) const
{
    return GT::keymapper.add (argv(i));
}



GT_Key GT_Tcl_info::operator() (const int i)
{
    return GT::keymapper.add (argv(i));
}



//
// argc utils
//

bool GT_Tcl_info::is_last_arg (const int index)
{
    return args_left (index, 0, true);
}


bool GT_Tcl_info::exists (const int index)
{
    return args_left (index, 0, false);
}


int GT_Tcl_info::args_left (const int index)
{
    return (the_argc-1 - index);
}


bool GT_Tcl_info::args_left (const int index, const int n,
    bool exact)
{
    if (exact) {
	return (the_argc-1 == index+n);
    } else {
	return (the_argc-1 >= index+n);
    }
}



//
// Special access to argv
//

string& GT_Tcl_info::msg ()
{
    return the_msg;
}


void GT_Tcl_info::msg (const int error)
{
    msg (GT::error.msg (error));
}


void GT_Tcl_info::msg (const int error, const int i)
{
    msg (GT::error.msg (error, i));
}


void GT_Tcl_info::msg (const int error, const string& s)
{
    msg (GT::error.msg (error, s));
}
