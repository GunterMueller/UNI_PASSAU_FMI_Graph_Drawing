#ifndef GT_TK_UIOBJECT_H
#define GT_TK_UIOBJECT_H

//
// Tk_UIObject.h
//
// This file defines the class GT_Tk_UIObject.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tk_UIObject.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:13 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//


#include <gt_base/UIObject.h>


class GT_Tk_UIObject : public GT_UIObject
{
    GT_CLASS (GT_Tk_UIObject, GT_UIObject);

protected:	
    GT_Tk_Id_List the_tk_items;
	
public:

    GT_Tk_UIObject (const int uid,
	GT_Tcl_Device* const device,
	GT_UIObject* parent);
    virtual ~GT_Tk_UIObject ();

    //
    // Tk_UIObject virtuals
    //

    virtual bool create ();
    virtual bool move (const double move_x, const double move_y);
    virtual bool update ();
    virtual bool update_attrs ();
    virtual bool update_coords ();
    virtual bool del ();

    virtual bool raise (const char* tag = 0);
    virtual bool lower (const char* tag = 0);
    
    virtual void make_tags_cmd (string& cmd);
    virtual void make_create_cmd (string& cmd);
    virtual void make_move_cmd (
	const double x_move,
	const double y_move,
	string& cmd);
    virtual void make_update_attrs_cmd (string& cmd);
    virtual void make_update_coords_cmd (string& cmd,
    bool may_move_or_scale);
    virtual void make_delete_cmd (string& cmd);

    virtual bool tcl_eval (const string& cmd);

    //
    // Helpers
    //
	
    void coords_box (const GT_Rectangle& center,
	vector& v);

    void coords_diamond (const GT_Rectangle& center,
	vector& v);
};


#endif
