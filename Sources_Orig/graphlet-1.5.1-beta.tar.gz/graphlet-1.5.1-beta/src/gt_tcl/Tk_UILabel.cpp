//
// Tk_UINode.cc
//
// This file implements the class GT_Tk_UINode.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tk_UILabel.cpp,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/09 18:28:47 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Tcl_Graph.h"

// #include "GraphScript.h"
#include "Tk_UILabel.h"

#include <gt_base/Graph_Attributes.h>
#include <gt_base/Node_Attributes.h>
#include <gt_base/Edge_Attributes.h>


//////////////////////////////////////////
//
// Constructors and Destructors
//
//////////////////////////////////////////


GT_Tk_UILabel::GT_Tk_UILabel (const int uid,
    GT_Tcl_Device* device,
    GT_UIObject* parent,
    GT_Graph* g) :
	GT_Tk_UIObject (uid, device, parent)
{
    the_g = g;
    the_n = 0;
    the_e = 0;
    graphics (g->gt().label_graphics());
}


GT_Tk_UILabel::GT_Tk_UILabel (const int uid,
    GT_Tcl_Device* device,
    GT_UIObject* parent,
    GT_Graph* g,
    node n) :
	GT_Tk_UIObject (uid, device, parent)
{
    the_g = g;
    the_n = n;
    the_e = 0;
    graphics (g->gt(n).label_graphics());
}


GT_Tk_UILabel::GT_Tk_UILabel (const int uid,
    GT_Tcl_Device* device,
    GT_UIObject* parent,
    GT_Graph* g,
    edge e) :
	GT_Tk_UIObject (uid, device, parent),
	the_g (g), the_n(0), the_e(e)
{
    the_g = g;
    the_n = 0;
    the_e = e;
    graphics (g->gt(e).label_graphics());
}
		


GT_Tk_UILabel::~GT_Tk_UILabel ()
{
}



//////////////////////////////////////////
//
// type
//
//////////////////////////////////////////


const GT_Key& GT_Tk_UILabel::type() const
{
    if (n() != 0) {
	return GT_Keys::uiobject_node_label;
    } else if (e() != 0) {
	return GT_Keys::uiobject_edge_label;
    } else if (g() != 0) {
	return GT_Keys::uiobject_graph_label;
    } else {
	return GT_Keys::uiobject_label;
    }
}



const GT_Common_Attributes& GT_Tk_UILabel::attrs() const
{
    if (n() != 0) {
	return g()->gt(n());
    } else if (e() != 0) {
	return g()->gt(e());
    } else {
	return g()->gt();
    }
}



GT_Common_Attributes& GT_Tk_UILabel::attrs()
{
    if (n() != 0) {
	return g()->gt(n());
    } else if (e() != 0) {
	return g()->gt(e());
    } else {
	return g()->gt();
    }
}



//////////////////////////////////////////
//
// make_create_cmd
//
//////////////////////////////////////////


void GT_Tk_UILabel::make_update_coords_cmd (string& cmd,
    bool /* may_move_or_scale */)
{
    double x,y;
    
    const GT_Key& this_type = type();
    if (this_type == GT_Keys::uiobject_node_label) {

	x = graphics()->x();
	y = graphics()->y();

    } else if (this_type == GT_Keys::uiobject_edge_label) {
		
	x = graphics()->x();
	y = graphics()->y();
		
    } else {
	x = 0.0;
	y = 0.0;
    }

    cmd += string ("%f %f", x,y);
}



void GT_Tk_UILabel::make_create_cmd (string& cmd)
{
    if (graphics()->type() == GT_Key(0)) {
	graphics()->type (GT_Keys::type_text);
    }
	
    baseclass::make_create_cmd (cmd);

    return;
}



void GT_Tk_UILabel::make_tags_cmd (string& cmd)
{
    baseclass::make_tags_cmd (cmd);
    cmd += " GT_text";
}


void GT_Tk_UILabel::make_update_attrs_cmd (string& cmd)
{
    baseclass::make_update_attrs_cmd (cmd);
    
    GT_Common_Attributes& a = attrs();
    const string& label = a.label();
    
    if (a.is_changed (GT_Common_Attributes::tag_label)) {

	char* newstring = new char[label.length()*2 + 1 + strlen(" -text {}")];
	strcpy (newstring, " -text \"");
	char* n = newstring + strlen(" -text \"");
	
	const char* c = label.cstring();
	
	while (*c != '\0') {
	    if (*c == '$' || *c == '\\' || *c == '"' ||
		*c == '{' || *c == '}' ||
		*c == '[' || *c == ']') {
		*n++ = '\\';
	    }
	    *n++ = *c;
	    c++;
	}
	*n++ = '"';
	*n++ = '\0';
	
	cmd += newstring;
	delete newstring;
	a.reset_changed (GT_Common_Attributes::tag_label);
    }

    return;
}
