#ifndef GT_GRAPHSCRIPT_H
#define GT_GRAPHSCRIPT_H

//
// GraphScript.h
//
// This file defines the class GT_GraphScript.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/GraphScript.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/10/27 14:09:25 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//


class GT_GraphScript {

    GT_BASE_CLASS (GT_GraphScript);

    GT_VARIABLE (Tcl_Interp*, interp);
    GT_VARIABLE (bool, tcl_only);
    
public:

    GT_GraphScript (Tcl_Interp* interp);
    virtual ~GT_GraphScript ();

    virtual int init ();
    virtual int commands_init ();

    virtual int application_init (Tcl_Interp *interp);

    static int main  (int argc, char **argv,
	Tcl_AppInitProc* application_init);
};

#endif
