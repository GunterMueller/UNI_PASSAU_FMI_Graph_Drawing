//
// Tcl_Command.cc
//
// This file implements the class GT_Tcl_Command.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Command.cpp,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/04 08:46:18 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Tcl_Graph.h"

#include "Tcl_Command.h"



//////////////////////////////////////////
//
// class GT_Tcl_Command
//
//////////////////////////////////////////


//
// Constructors and Destructors
//


GT_Tcl_Command::GT_Tcl_Command (const string& name,
    const GT_Key& type)
{
    this->the_name = name;
    this->the_type = type;
    this->the_info = 0;
}



GT_Tcl_Command::~GT_Tcl_Command ()
{
}



//
// exists
// is_gt_object
//


bool GT_Tcl_Command::exists (Tcl_Interp* interp, const string& name)
{
    Tcl_CmdInfo infoPtr;
    return (Tcl_GetCommandInfo (interp, name.cstring(), &infoPtr) == 1);
}


bool GT_Tcl_Command::is_gt_object (const char* name)
{
    return (!strncmp (name,"GT:",3));
}


//
// cmd_install
//


int GT_Tcl_Command::cmd_install (Tcl_Interp* interp,
    Tcl_CmdProc *proc,
    Tcl_CmdDeleteProc *delete_proc)
{
    if (exists (interp, the_name)) {
	Tcl_SetResult (interp,
	    GT::error.msg (GT_Error::name_exists, the_name).cstring(),
	    TCL_VOLATILE);
		
	return TCL_ERROR;
    }
	
    GT_Tcl::CreateCommand (interp,
	name().cstring(),
	proc,
	(ClientData*)this,
	delete_proc);

    Tcl_AppendResult (interp, the_name.cstring(), 0);

    return TCL_OK;
}


int GT_Tcl_Command::install (Tcl_Interp* interp)
{
    return cmd_install (interp, cmd, 0);
}


	
int GT_Tcl_Command::cmd (ClientData client_data,
    Tcl_Interp*  interp,
    int argc,
    char** argv)
{
    GT_Tcl_Command* this_cmd = (GT_Tcl_Command*)client_data;

    int index = 1;
    GT_Tcl_info info (interp, argc, argv);

    int code = this_cmd->cmd_parser (info, index);

    Tcl_AppendResult (interp, info.msg().cstring(), 0);
    return code;
}


int GT_Tcl_Command::cmd_parser (GT_Tcl_info& /* info */, int& /* index */)
{
    return TCL_OK;
}



//
// GT_Tcl_Graph_Command::get
//



int GT_Tcl_Command::get (Tcl_Interp* interp,
    const string& name,
    GT_Tcl_Command*& cmd)
{
    if (!is_gt_object (name)) {
	string msg ("%s is not a GT object.", name.cstring());
	Tcl_AppendResult (interp, msg.cstring(), NULL);
	return TCL_ERROR;
    }
	
    if (!exists (interp, name)) {
	string msg ("%s does not exist.", name.cstring());
	Tcl_AppendResult (interp, msg.cstring(), NULL);
	return TCL_ERROR;		
    }
	
    Tcl_CmdInfo infoPtr;
    Tcl_GetCommandInfo (interp, name.cstring(), &infoPtr);
    cmd = (GT_Tcl_Command*)(infoPtr.clientData);

    return TCL_OK;
}



//////////////////////////////////////////
//
// class GT_Tcl_Graph_Command
//
//////////////////////////////////////////


//
// Constructors and Destructors
//


GT_Tcl_Graph_Command::GT_Tcl_Graph_Command (const string& name,
    GT_Tcl_Graph& g):
	GT_Tcl_Command (name, GT_Keys::graph)
{
    this->the_graph = &g;
}



GT_Tcl_Graph_Command::~GT_Tcl_Graph_Command ()
{
}



int GT_Tcl_Graph_Command::install (Tcl_Interp* interp)
{
    return baseclass::cmd_install (interp,
	GT_Tcl_Graph::static_parser,
	(Tcl_CmdDeleteProc *)NULL);
}



int GT_Tcl_Graph_Command::get (Tcl_Interp* interp,
    const string& name,
    GT_Tcl_Graph*& g)
{
    GT_Tcl_Command* cmd;
    int code = GT_Tcl_Command::get (interp, name, cmd);
    if (code != TCL_ERROR && cmd->type() == GT_Keys::graph) {
		
	GT_Tcl_Graph_Command* graph_cmd = (GT_Tcl_Graph_Command*)cmd;
	g = graph_cmd->graph();
	return code;
		
    } else {
		
	g = 0;
	string msg ("%s is not graph", name.cstring());
	return TCL_ERROR;
    }
}
