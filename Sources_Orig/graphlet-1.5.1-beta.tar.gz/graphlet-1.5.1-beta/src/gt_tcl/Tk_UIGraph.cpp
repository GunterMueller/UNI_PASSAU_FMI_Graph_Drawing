//
// Tk_UIGraph.cc
//
// This file implements the class GT_Tk_UIGraph.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tk_UIGraph.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:13 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Tcl_Graph.h"

// #include "GraphScript.h"
#include "Tcl_Graph.h"
#include "Tk_UIGraph.h"

#include <gt_base/Graph_Attributes.h>


//////////////////////////////////////////
//
// Constructors and Destructors
//
//////////////////////////////////////////


GT_Tk_UIGraph::GT_Tk_UIGraph (const int uid,
    GT_Tcl_Device* const device,
    GT_UIObject* parent,
    GT_Graph* g) :
	GT_Tk_UIObject (uid, device, parent)
{
    the_g = g;
    graphics (g->gt().graphics());
}
		

GT_Tk_UIGraph::~GT_Tk_UIGraph ()
{
}


//////////////////////////////////////////
//
// type
//
//////////////////////////////////////////


const GT_Key& GT_Tk_UIGraph::type() const
{
    return GT_Keys::uiobject_graph;
}



//////////////////////////////////////////
//
// make_graph_cmd
//
//////////////////////////////////////////


void GT_Tk_UIGraph::make_create_cmd (string& /* cmd */)
{
}
