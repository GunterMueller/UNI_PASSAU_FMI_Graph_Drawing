#ifndef GT_TK_UIGRAPH_H
#define GT_TK_UIGRAPH_H

//
// Tk_UIGraph.h
//
// This file defines the class GT_Tk_UIGraph.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tk_UIGraph.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:13 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//


#include "Tk_UIObject.h"


class GT_Tk_UIGraph : public GT_Tk_UIObject
{
    GT_CLASS (GT_Tk_UIGraph, GT_Tk_UIObject);

    GT_VARIABLE (GT_Graph*, g);
	
public:
    GT_Tk_UIGraph (const int uid,
	GT_Tcl_Device* const device,
	GT_UIObject* parent,
	GT_Graph* g);
	
    virtual ~GT_Tk_UIGraph ();

    virtual const GT_Key& type () const;

    virtual void make_create_cmd (string& cmd);
};


#endif
