//
// GT_Tcl_Graph.h
// 
// This module implements the class GT_Tcl_Graph
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Graph.cpp,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/06 08:41:38 $
// $Locker:  $
// $State: Exp $
// ----------------------------------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#include "Tcl_Graph.h"

#include <fstream.h> // graph printing I/O operations

#include <gt_base/Id.h>
#include <gt_base/Leda_Shuttle.h>
#include <gt_base/Parser.h>

#include "GraphScript.h"
#include "Tcl_Command.h"
#include "Tk_UIGraph.h"
#include "Tk_UILabel.h"


//////////////////////////////////////////
//
// Constructor
//
//////////////////////////////////////////

GT_Tcl_Graph::GT_Tcl_Graph ()
{
    return;
}


//////////////////////////////////////////
//
// Destructor
//
//////////////////////////////////////////

GT_Tcl_Graph::~GT_Tcl_Graph ()
{
    return;
}


//////////////////////////////////////////
//
// GT_Tcl_Graph::cmd
//
// Tcl handler for the command "graph".
//
//////////////////////////////////////////


int GT_Tcl_Graph::cmd  (ClientData /* client_data */,
    Tcl_Interp* interp,
    int argc,
    char** /* argv */)
{
    if (argc > 1) {

	Tcl_SetResult (interp,
	    GT::error.msg (GT_Error::wrong_number_of_args).cstring(),
	    TCL_VOLATILE);
		
	Tcl_AppendResult (interp,
	    "Usage: <graph> command argument ...", 0);
		
	return TCL_ERROR;
    }

    //
    // Create a new GT_Tcl_Graph
    //
	
    GT_Tcl_Graph* g = new GT_Tcl_Graph;

    GT_Shuttle* leda_shuttle = new GT_Leda_Shuttle<graph>;
    g->attach (*leda_shuttle);

    g->new_graph();

    //
    // Create a new Tcl command.
    //

    GT_Tcl_Graph_Command* command = new GT_Tcl_Graph_Command (
	string ("GT:%d", g->gt().uid()),
	*g);
    return command->install (interp);
}


//////////////////////////////////////////
//
// GT_Tcl_Graph::new_graph
// GT_Tcl_Graph::new_graph_action
//
//////////////////////////////////////////


void GT_Tcl_Graph::new_graph ()
{
    gt().id (GT::id.next_id());

    new_graph_action ();
}


void GT_Tcl_Graph::new_graph_action ()
{
    GT_Graph_Attributes& graph_attrs = gt();
	
    graph_attrs.uid (GT::id.next_id());
    graph_attrs.label_uid (GT::id.next_id());

    if (graph_attrs.graphics() == 0) {
	graph_attrs.graphics (new_graph_graphics());
    }
    if (graph_attrs.label_graphics() == 0) {
	graph_attrs.label_graphics (new_graph_graphics());
    }
}



//////////////////////////////////////////
//
// static_parser
//
//////////////////////////////////////////


int GT_Tcl_Graph::static_parser (ClientData client_data,
    Tcl_Interp*  interp,
    int argc,
    char** argv)
{
    GT_Tcl_Graph* g = ((GT_Tcl_Graph_Command*)client_data)->graph();

    if (g == 0) {	
	string err (GT::error.msg (GT_Error::no_graph, argv[0]));
	Tcl_SetResult (interp, err.cstring(), TCL_VOLATILE);
	return TCL_ERROR;
    } else {
	return g->parser (interp, argc, argv);
    }
}


//////////////////////////////////////////
//
// GT_Tcl_Graph::parser dispatches the command line arguments.
//
//////////////////////////////////////////


int GT_Tcl_Graph::parser (Tcl_Interp* interp, int argc, char** argv)
{
    if (argc < 2) {
	string err (GT::error.msg (GT_Error::wrong_number_of_args));
	Tcl_SetResult (interp, err.cstring(), TCL_VOLATILE);
	return TCL_ERROR;
    }
		
    //
    // Initialize tcl_info
    //
		
    string msg;
	
    GT_Tcl_info tcl_info (interp, argc, argv);

    //
    // Parse the arguments
    //
	
    argc = 1;
    const string command = argv[argc++];

    int result = TCL_ERROR;
    if (command == "create") {

	if (tcl_info.args_left (argc) >= 0) {

	    const string next_command = argv[argc++];
		
	    if (next_command == "node") {
		result = create_node_cmd (tcl_info, argc);
	    } else if (next_command == "edge") {
		result = create_edge_cmd (tcl_info, argc);
	    } else {
		tcl_info.msg (GT_Error::no_command, next_command);
		result = TCL_ERROR;
	    }
			
	} else {
	    tcl_info.msg (GT_Error::wrong_number_of_args);
	    result = TCL_ERROR;
	}
    } else if (command == "new_node") {
	result = create_node_cmd (tcl_info, argc);
    } else if (command == "new_edge") {
	result = create_edge_cmd (tcl_info, argc);
	
    } else if (command == "canvas") {
	result = canvas_cmd (tcl_info, argc);
    } else if (command == "configure" || command == "graphconfigure") {
	result = configure_cmd (tcl_info, argc, GT_Tcl::configure);
    } else if (command == "get") {
	result = configure_cmd (tcl_info, argc, GT_Tcl::get);
    } else if (command == "draw") {
	result = draw_cmd (tcl_info, argc);
    } else if (command == "print" || command == "save") {
	result = print_cmd (tcl_info, argc);
    } else if (command == "load") {
	result = load_cmd (tcl_info, argc);
    } else if (command == "delete") {
	result = delete_cmd (tcl_info, argc);
    } else if (command == "nodeconfigure") {
	result = nodeconfigure_cmd (tcl_info, argc, GT_Tcl::configure);
    } else if (command == "nodeget") {
	result = nodeconfigure_cmd (tcl_info, argc, GT_Tcl::get);
    } else if (command == "nodedraw") {
	result = nodedraw_cmd (tcl_info, argc);
    } else if (command == "nodemove") {
	result = nodemove_cmd (tcl_info, argc);
    } else if (command == "nodedelete") {
	result = nodedelete_cmd (tcl_info, argc);
    } else if (command == "edgeconfigure") {
	result = edgeconfigure_cmd (tcl_info, argc, GT_Tcl::configure);
    } else if (command == "edgeget") {
	result = edgeconfigure_cmd (tcl_info, argc, GT_Tcl::get);
    } else if (command == "edgedraw") {
	result = edgedraw_cmd (tcl_info, argc);
    } else if (command == "edgedelete") {
	result = edgedelete_cmd (tcl_info, argc);
    } else if (command == "nodes") {
	result = nodes_cmd (tcl_info, argc);
    } else if (command == "edges") {
	result = edges_cmd (tcl_info, argc);
    } else if (command == "action") {
	result = action_cmd (tcl_info, argc);
    } else {		
	tcl_info.msg (GT_Error::no_command, argv[1]);
	result = TCL_ERROR;
    }
		
    Tcl_SetResult (tcl_info.interp(), tcl_info.msg().cstring(),
	TCL_VOLATILE);
    return result;
}



//////////////////////////////////////////
//
// GT_Tcl_Graph::canvas_cmd
//
//////////////////////////////////////////


int GT_Tcl_Graph::canvas_cmd (
    GT_Tcl_info& tcl_info,
    int argc)
{
    if (tcl_info.exists (argc)) {

	int list_argc;
	char **list_argv;
	int code = Tcl_SplitList (tcl_info.interp(),
	    tcl_info[argc],
	    &list_argc,
	    &list_argv);

	if (code != TCL_OK) {
	    tcl_info.msg (GT_Error::internal_error,
		"in Tcl_SplitList");
	    return code;
	}
		
	int i;
	for (i = 0; i < list_argc; i++) {

	    string name = list_argv[i];

	    bool is_already_there = false;
	    list_item it;
	    forall_items (it, the_devices) {
		if (the_devices.inf(it)->name() == name) {
		    is_already_there = true;
		    break;
		}
	    }
	    if (!is_already_there) {
		the_devices.append (new_tcl_device (name, tcl_info.interp()));
	    }
	}

	return TCL_OK;
		
    } else {
	
	//
	// Get the canvases
	//

	string msg;
		
	GT_Device* device;
	forall (device, the_devices) {
	    msg += device->name() + " ";
	}
		
	tcl_info.msg (msg);
	return TCL_OK;
    }
}


//
// device customization
//

GT_Tcl_Device* GT_Tcl_Graph::new_tcl_device (const string& name,
    Tcl_Interp* interp)
{
    return new GT_Tcl_Device (name, interp);
}



//////////////////////////////////////////
//
// GT_Tcl_Graph::configure_cmd
//
//////////////////////////////////////////


int GT_Tcl_Graph::configure_cmd (
    GT_Tcl_info &tcl_info,
    int argc,
    const GT_Tcl::Get_Mode mode)
{
    int code = TCL_ERROR;
    bool found = false;

    if (!tcl_info.exists (argc)) {

	//
	// No arguments - get em all
	//
	
	code = graphconfigure_get (GT_Keys::empty,
	    tcl_info.msg(), mode, found);

    } else if (tcl_info.is_last_arg (argc)) {

	code = graphconfigure_get (tcl_info(argc++),
	    tcl_info.msg(), mode, found);

    } else {

	//
	// More than one argument - set operation
	//
	
	code = graphconfigure_set (tcl_info(argc++),
	    tcl_info, argc, found);

    }

    return code;
}



int GT_Tcl_Graph::common_configure_set (GT_Common_Attributes& attrs,
    const GT_Key& key,
    GT_Tcl_info& tcl_info, int argc,
    bool& found)
{
    int code = TCL_OK;

    if (key == GT_Keys::option_label) {
			
	attrs.label (tcl_info[argc++]);
	found = true;
	code = TCL_OK;
			
    } else if (key == GT_Keys::option_id) {
		
	int id;
	
	code = Tcl_GetInt (tcl_info.interp(), tcl_info[argc++], &id);
	found = true;
	if (code == TCL_OK) {
	    attrs.id (id);
	}			
		
    } else if (key == GT_Keys::option_label_anchor) {
			
	attrs.label_anchor (tcl_info(argc++));
	found = true;
	code = TCL_OK;
			
    } else if (key == GT_Keys::option_edge_anchor) {
			
	attrs.edge_anchor (tcl_info(argc++));
	found = true;
	code = TCL_OK;
			
    }
	
    return code;	
}



int GT_Tcl_Graph::common_configure_get (const GT_Common_Attributes& attrs,
    const GT_Key& key,
    string& value,
    const GT_Tcl::Get_Mode mode,
    bool& found)
{
    int code = TCL_OK;
    bool get_all = (key == GT_Keys::empty);
	
    if (key == GT_Keys::option_id || (get_all && code == TCL_OK)) {
		
	code = GT_Tcl::format_value (value,
	    GT_Keys::option_id, attrs.id(),
	    mode);
	found = true;
    }

    if (key == GT_Keys::option_label || (get_all && code == TCL_OK)) {
		
	code = GT_Tcl::format_value (value,
	    GT_Keys::option_label, attrs.label(),
	    mode);	
	found = true;
    }
	
    if (key == GT_Keys::option_label_anchor || (get_all && code == TCL_OK)) {
			
	code = GT_Tcl::format_value (value,
	    GT_Keys::option_label_anchor, attrs.label_anchor(),
	    mode);
	found = true;
    }

    if (key == GT_Keys::option_edge_anchor || (get_all && code == TCL_OK)) {
			
	code = GT_Tcl::format_value (value,
	    GT_Keys::option_edge_anchor, attrs.edge_anchor(),
	    mode);
	found = true;
    }

    return code;
}



int GT_Tcl_Graph::graphconfigure_set (
    const GT_Key& key,
    GT_Tcl_info& tcl_info, int argc,
    bool& found)
{
    int code = TCL_OK;
    GT_Graph_Attributes& graph_attrs = gt();

    if (key == GT_Keys::option_directed) {
		
	int directed;
	code = Tcl_GetBoolean (tcl_info.interp(), tcl_info[argc], &directed);
	found = true;
		
	if (code == TCL_OK) {
	    if (directed) {
		leda().make_directed ();
	    } else {
		leda().make_undirected ();
	    }
	}			
		
    }

    if (!found && code == TCL_OK) {
	code = common_configure_set (graph_attrs,
	    key,
	    tcl_info, argc,
	    found);
    }

    if (!found && code == TCL_OK) {
	code = graphicsconfigure_set (graph_attrs.graphics(),
	    key,
	    tcl_info, argc,
	    found);
    }
	
    return code;	
}



int GT_Tcl_Graph::graphconfigure_get (
    const GT_Key& key,
    string& value,
    const GT_Tcl::Get_Mode mode,
    bool& found)
{
    int code = TCL_OK;

    const GT_Graph_Attributes& graph_attrs = gt();
    bool get_all = (key == GT_Keys::empty);
	
    if (key == GT_Keys::option_directed || (get_all && code == TCL_OK)) {
		
	int directed = leda().is_directed();
	code = GT_Tcl::format_value (value,
	    GT_Keys::option_directed, directed,
	    mode);
	found = true;
    }
	
    if (!found || (get_all && code == TCL_OK)) {
		
	code = common_configure_get (graph_attrs,
	    key, value,
	    mode,
	    found);

    }

    if (!found || (get_all && code == TCL_OK)) {
		
	code = graphicsconfigure_get (graph_attrs.graphics(),
	    key, value,
	    mode,
	    found);
    }
	
    return code;
}



//////////////////////////////////////////
//
// GT_Tcl_Graph::print_cmd
// GT_Tcl_Graph::print
//
//////////////////////////////////////////


int GT_Tcl_Graph::print_cmd (
    GT_Tcl_info& tcl_info,
    int argc)
{
    if (!tcl_info.exists (argc)) {
	tcl_info.msg (GT_Error::wrong_number_of_args);
	return TCL_ERROR;
    }

    if (attached() == 0) {
	tcl_info.msg (GT_Error::no_graph);
	return TCL_ERROR;				
    }
	
    //
    // Print to file
    //

    string command = tcl_info[argc];

    if (command == "-file" || command[0] != '-') {

	string filename;
	if (tcl_info.is_last_arg (argc)) {
	    filename = tcl_info[argc];
	} else if (tcl_info.args_left(argc) == 1 && command == "-file") {
	    argc ++;
	    filename = tcl_info[argc];
	} else {
	    tcl_info.msg (GT_Error::wrong_number_of_args);
	    return TCL_ERROR;
	}
		
	if (filename.length() > 0) {

	    ofstream outfile (filename);
	    if (outfile == 0) {
		tcl_info.msg (GT_Error::fileopen_error, filename);
		return TCL_ERROR;
	    }

	    print (outfile);
	    return TCL_OK;
			
	} else {
	    tcl_info.msg (GT_Error::no_filename);
	    return TCL_ERROR;
	}

    } else {
	tcl_info.msg (GT_Error::wrong_keyword, command);
	return TCL_ERROR;
    }
}


void GT_Tcl_Graph::print (ostream& out)
{
    out << *this << endl;
    return;
}



//////////////////////////////////////////
//
// GT_Tcl_Graph::load_cmd
//
//////////////////////////////////////////


int GT_Tcl_Graph::load_cmd (
    GT_Tcl_info& tcl_info,
    int argc)
{
    if (tcl_info.is_last_arg (argc)) {
	tcl_info.msg (GT_Error::wrong_number_of_args);
	return TCL_ERROR;
    }

    string command = tcl_info[argc++];

    if (command == "-file") {

	if (!tcl_info.is_last_arg (argc)) {
	    tcl_info.msg (GT_Error::wrong_number_of_args);
	    return TCL_ERROR;
	}
		
	string filename = tcl_info[argc];

	if (filename.length() > 0) {

	    ifstream infile (filename);
	    if (infile == 0) {
		tcl_info.msg (GT_Error::fileopen_error, tcl_info[argc]);
		return TCL_ERROR;
	    }
	    infile.close();
			

	    GT_List_of_Attributes* parsed_attrs;
	    parsed_attrs = GT::parser->parser (filename);

	    if (parsed_attrs != 0) {
		if (attached() != 0) {
		    leda().clear();
		}
		string message;
		if (extract (parsed_attrs, message) != GT_OK) {
		    tcl_info.msg (message);
		    return TCL_ERROR;
		}
	    }
			
	    return TCL_OK;
			
	} else {
	    tcl_info.msg (GT_Error::no_filename);
	    return TCL_ERROR;
	}

    } else {
	tcl_info.msg (GT_Error::wrong_keyword, command);
	return TCL_ERROR;
    }
}



//////////////////////////////////////////
//
// GT_Tcl_Graph::draw_cmd
// GT_Tcl_Graph::draw
//
//////////////////////////////////////////


int GT_Tcl_Graph::draw_cmd (
    GT_Tcl_info& tcl_info,
    int argc)
{
    if (tcl_info.exists (argc)) {
	tcl_info.msg (GT_Error::wrong_number_of_args);
	return TCL_ERROR;
    }

    int code;
    
    code = begin_draw();
    if (code == TCL_ERROR) {
	return code;
    }
    code = draw();
    if (code == TCL_ERROR) {
	return code;
    }
    
    return end_draw();
}



//
// draw
//

int GT_Tcl_Graph::draw ()
{
    //
    // Draw the graph
    //
	
    const GT_Graph_Attributes& attrs = gt();

    //
    // If the type has changed, then update the label
    //

    bool must_recreate_label;
    if (attrs.graphics()->is_changed (GT_Common_Graphics::tag_type) &&
	attrs.graphics()->is_initialized (
	    GT_Common_Attributes::tag_label))
    {
	must_recreate_label = true;
    } else {
	must_recreate_label = false;
    }
	
    GT_Device* device;
    forall (device, the_devices) {

	GT_UIObject* uigraph = device->object (attrs.uid());
	if (uigraph == 0) {
				
	    uigraph = new_tk_uigraph (attrs.uid(),
		(GT_Tcl_Device*)device,
		0,
		this);

	    if (uigraph->create() == false) {
		delete uigraph;
		return TCL_ERROR;
	    } else {
		device->insert (attrs.uid(), uigraph);
	    }
			
	} else {
	    uigraph->update();
	}
    }

    if (attrs.label().length() > 0 ||
	attrs.is_changed(GT_Common_Attributes::tag_label) ||
	must_recreate_label) {

	GT_UIObject* uilabel = device->object (attrs.label_uid());
		
	if (uilabel == 0) {
			
	    uilabel = new_tk_uilabel (attrs.label_uid(),
		(GT_Tcl_Device*)device,
		0,
		this);
			
	    if (uilabel->create() == false) {
		return TCL_ERROR;
	    } else {
		device->insert (attrs.label_uid(), uilabel);
	    }
			
	} else {
	    if (must_recreate_label) {
		uilabel->create ();
	    } else {
		uilabel->update ();
	    }
	}
    }
	
    //
    // Draw all nodes in g
    //

    node n;
    forall_nodes (n, leda()) {
	int code = draw (n);
	if (code != TCL_OK) {
	    return code;
	}
    }

    //
    // Draw all edges in g
    //

    edge e;
    forall_edges (e, leda()) {
	int code = draw (e);
	if (code != TCL_OK) {
	    return code;
	}	
    }
	
    return TCL_OK;
}


//
// draw customization
//


GT_Tk_UIGraph* GT_Tcl_Graph::new_tk_uigraph (const int uid,
    GT_Tcl_Device* const device,
    GT_UIObject* parent,
    GT_Graph* g)
{
    return new GT_Tk_UIGraph (uid, device, parent, g);
}



GT_Tk_UILabel* GT_Tcl_Graph::new_tk_uilabel (const int uid,
    GT_Tcl_Device* device,
    GT_UIObject* parent,
    GT_Graph* g)
{
    return new GT_Tk_UILabel (uid, device, parent, g);
}



//
// Draw utilities
//


void GT_Tcl_Graph::update ()
{
    GT_Graph::update();
}


void GT_Tcl_Graph::update_coordinates ()
{
    GT_Graph::update_coordinates();
}


void GT_Tcl_Graph::update_label_coordinates ()
{
    GT_Graph::update_label_coordinates();
}


//////////////////////////////////////////
//
//  int GT_Tcl_Graph::begin_draw ()
//  int GT_Tcl_Graph::end_draw ()
//
//////////////////////////////////////////


int GT_Tcl_Graph::begin_draw ()
{
    return GT_Graph::begin_draw();
}


int GT_Tcl_Graph::end_draw ()
{
    return GT_Graph::end_draw();
}



//
// Delete a graph and all Tcl/Tk objects
//

int GT_Tcl_Graph::delete_cmd (
    GT_Tcl_info& tcl_info,
    int argc)
{
    graph& leda_graph = leda();
	
    if (tcl_info.is_last_arg (argc)) {
			
	//
	// Delete all nodes in the graph
	//

	while (leda_graph.number_of_nodes() > 0) {
	    leda_graph.del_node (leda_graph.first_node());
	}
	leda_graph.clear();
		
	//
	// Delete the associated Tcl command
	//
		
	Tcl_DeleteCommand (tcl_info.interp(), tcl_info[0]);

    } else {		
	tcl_info.msg (GT_Error::wrong_number_of_args);
	return TCL_ERROR;
    }
	
    return TCL_OK;
}


void GT_Tcl_Graph::clear_action ()
{
    graph& g = leda();

    run_hooks (tcl_clear_actions(), gt().uid(), GT_Keys::action_clear);

    edge e;
    forall_edges (e, g) {
	del_edge_action (e);
    }
	
    node n;
    forall_nodes (n, g) {
	del_node_action (n);
    }
}


//////////////////////////////////////////
//
// Return a list of nodes or edges
//
//////////////////////////////////////////


int GT_Tcl_Graph::nodes_cmd (
    GT_Tcl_info& tcl_info,
    int argc)
{
    if (!tcl_info.exists (argc)) {
		
	string list_of_nodes;
	node n;
	const graph& g = leda();
	forall_nodes (n, g) {
	    list_of_nodes += string (" GT:%d", gt(n).uid());
	}

	tcl_info.msg (list_of_nodes);
	return TCL_OK;
		
    } else {

	const string command = tcl_info[argc++];

	if (command == "-edge" && tcl_info.args_left(argc) == 0) {

	    edge e;
	    int code = find_edge (tcl_info, tcl_info[argc++], e);
	    if (code != TCL_OK) {
		return code;
	    }

	    tcl_info.msg (string ("{ GT:%d GT:%d }",
		gt (gt(e).source()).uid(), gt (gt(e).target()).uid()));

	    return TCL_OK;
	    
	} else if (command == "-opposite" && tcl_info.args_left(argc) == 1) {

	    node n;
	    int code = find_node (tcl_info, tcl_info[argc++], n);
	    if (code != TCL_OK) {
		return code;
	    }
	    
	    edge e;
	    code = find_edge (tcl_info, tcl_info[argc++], e);
	    if (code != TCL_OK) {
		return code;
	    }

	    tcl_info.msg (string ("GT:%d", gt(leda().opposite (n,e)).uid()));
	    
	    return TCL_OK;
	    
	} else {
	    tcl_info.msg (GT_Error::wrong_number_of_args);
	    return TCL_ERROR;
	}
    }
}


int GT_Tcl_Graph::edges_cmd (
    GT_Tcl_info& tcl_info,
    int argc)
{
    int code;

    enum {
	no_operation,
	all_edges,
	adj_edges,
	in_edges,
	out_edges,
	between_edges,
	multi_edges
    } operation;

	
    node n; // adj_edges
    node source; // between_edges
    node target; // between_edges


    operation = no_operation;
    if (!tcl_info.exists (argc)) {
		
	operation = all_edges;
		
    } else if (tcl_info.args_left (argc) == 0) {
		
	operation = adj_edges;
		
    } else if (tcl_info.args_left (argc) == 1) {

	if (streq (tcl_info[argc], "-node") ||
	    streq (tcl_info[argc], "-adj")) {
	    
	    operation = adj_edges;
	    argc ++;

	} else if (streq (tcl_info[argc], "-in")) {
		
	    operation = in_edges;
	    argc ++;
			
	} else if (streq (tcl_info[argc], "-out")) {
		
	    operation = out_edges;
	    argc ++;
	}
	
    } else if (tcl_info.args_left (argc) == 2) {

	if (streq (tcl_info[argc], "-between")) {
		
	    operation = between_edges;
	    argc ++;
		
	} else if (streq (tcl_info[argc], "-multi")) {
		
	    operation = multi_edges;
	    argc ++;
	}
		
    } else {
	tcl_info.msg (GT_Error::wrong_number_of_args);
	return TCL_ERROR;
    }

    switch (operation) {
		
	case all_edges: {
	}
	break;
		
	case adj_edges:
	case in_edges:
	case out_edges: {
	    code = find_node (tcl_info, tcl_info[argc], n);
	    if (code != TCL_OK) {
		return code;
	    }
	}
	break;

	case between_edges:
	case multi_edges: {
	    code = find_node (tcl_info, tcl_info[argc], source);
	    if (code != TCL_OK) {
		return code;
	    }
	    code = find_node (tcl_info, tcl_info[argc + 1], target);
	    if (code != TCL_OK) {
		return code;
	    }
	}
	break;

	default:
	    break;
    }

    //
    // Find the edges
    //
	
    string list_of_edges;
    const graph& g = leda();
    edge e;
	
    forall_edges (e, g) switch (operation) {
		
	case all_edges: {
	    list_of_edges += string (" GT:%d", gt(e).uid());
	}
	break;
		
	case adj_edges: {
	    if (g.source(e) == n || g.target(e) == n) {
		list_of_edges += string (" GT:%d", gt(e).uid());
	    }
	}
	break;
		
	case in_edges: {
	    if (g.target(e) == n) {
		list_of_edges += string (" GT:%d", gt(e).uid());
	    }
	}
	break;
		
	case out_edges: {
	    if (g.source(e) == n) {
		list_of_edges += string (" GT:%d", gt(e).uid());
	    }
	}
	break;
		
	case multi_edges: {
	    if (g.source(e) == source && g.target(e) == target) {
		list_of_edges += string (" GT:%d", gt(e).uid());
	    } else if (g.is_undirected() &&
		g.source(e) == target && g.target(e) == source) {
		list_of_edges += string (" GT:%d", gt(e).uid());
	    }
	}
		
	case between_edges: {
	    if (g.source(e) == source && g.target(e) == target) {
		list_of_edges += string (" GT:%d", gt(e).uid());
	    } else if (g.source(e) == target && g.target(e) == source) {
		list_of_edges += string (" GT:%d", gt(e).uid());
	    }
	}
	break;

	default:
	    break;
    }
	
    tcl_info.msg (list_of_edges);
    return TCL_OK;

}


//////////////////////////////////////////
//
// void GT_Tcl_Graph::insert_hook (list<string>& hooks,
//   const string& proc)
//
// int GT_Tcl_Graph::run_hooks (const list<string>& hooks,
//   const int uid,
//   const GT_Key& action_name)
//
// Note: no real error checking, but returns TCL_ERROR if one
// hook fails.
//
//////////////////////////////////////////


void GT_Tcl_Graph::insert_hook (list<string>& hooks,
    const string& proc)
{
    hooks.append (proc);
}



int GT_Tcl_Graph::run_hooks (const list<string>& hooks,
    const int uid,
    const GT_Key& action_name)
{
    int code = TCL_OK;

    if (!the_devices.empty()) {
		
	GT_Tcl_Device* device = (GT_Tcl_Device*)the_devices.head();
		
	list_item it;
	forall_items (it, hooks) {
	    string cmd ("%s GT:%d GT:%d %s",
		hooks.contents(it).cstring(),
		gt().uid(),
		uid,
		action_name.description()->name().cstring());
	    if (Tcl_Eval (device->interp(), cmd.cstring()) != TCL_OK) {
		code = TCL_ERROR;
	    }
	}
    }
	
    return code;
}



//////////////////////////////////////////
//
// $graph action -... proc
//
//////////////////////////////////////////

int GT_Tcl_Graph::action_cmd (
    GT_Tcl_info& tcl_info,
    int argc)
{
    if (tcl_info.args_left (argc) == 0) {
		
	string argument (tcl_info[argc]);
		
	if (argument == "-new_node") {
	    tcl_info.msg() = GT_Tcl::list_of_strings (
		the_tcl_new_node_actions);
	} else if (argument == "-del_node") {
	    if (!tcl_del_node_actions().empty()) {
		tcl_info.msg (tcl_del_node_actions().head());
	    } else {
		tcl_info.msg ("");
	    }
	} else if (argument == "-new_edge") {
	    if (!tcl_new_edge_actions().empty()) {
		tcl_info.msg (tcl_new_edge_actions().head());
	    } else {
		tcl_info.msg ("");
	    }
	} else if (argument == "-del_edge") {
	    if (!tcl_del_edge_actions().empty()) {
		tcl_info.msg (tcl_del_edge_actions().head());
	    } else {
		tcl_info.msg ("");
	    }
	} else if (argument == "-rev_edge") {
	    if (!tcl_clear_actions().empty()) {
		tcl_info.msg (tcl_rev_edge_actions().head());
	    } else {
		tcl_info.msg ("");
	    }
	} else if (argument == "-clear") {
	    if (!tcl_new_node_actions().empty()) {
		tcl_info.msg (tcl_clear_actions().head());
	    } else {
		tcl_info.msg ("");
	    }
	} else {
	    tcl_info.msg (GT_Error::wrong_keyword, argument);
	    return TCL_ERROR;
	}		

	return TCL_OK;
		
    } else if (tcl_info.args_left (argc) == 1) {	
		
	string argument (tcl_info[argc]);
	string proc (tcl_info.argv (argc+1));
		
	if (argument == "-new_node") {
	    insert_hook (the_tcl_new_node_actions, proc);
	} else if (argument == "-del_node") {
	    insert_hook (the_tcl_del_node_actions, proc);
	} else if (argument == "-new_edge") {
	    insert_hook (the_tcl_new_edge_actions, proc);
	} else if (argument == "-del_edge") {
	    insert_hook (the_tcl_del_edge_actions, proc);
	} else if (argument == "-rev_edge") {
	    insert_hook (the_tcl_rev_edge_actions, proc);
	} else if (argument == "-clear") {
	    insert_hook (the_tcl_clear_actions, proc);
	} else {
	    tcl_info.msg (GT_Error::wrong_keyword, argument);
	    return TCL_ERROR;
	}		

	return TCL_OK;

    } else {
	tcl_info.msg (GT_Error::wrong_number_of_args);
	return TCL_ERROR;
    }
}


//////////////////////////////////////////
//
// Find node/edge/graph from tcl
//
//////////////////////////////////////////


//
// Strip possibly leading "GT:" prefix and convert to integer
//

int GT_Tcl_Graph::strip_GT_prefix (GT_Tcl_info& tcl_info,
    const char* s,
    int& stripped)
{
    //
    // strip off leading "GT:"
    //

    if (GT_Tcl_Command::is_gt_object(s)) {

	//
	// convert to integer
	//
	
	int uid;
	int code = Tcl_GetInt (tcl_info.interp(),
	    ((char*)s)+3,
	    &uid);

	if (code != TCL_OK) {
	    tcl_info.msg (GT_Error::no_id, s);
	    return code;
	} else {
	    stripped = uid;
	    return code;
	}
    }

    return TCL_OK;
}


//
// Find the node with the uiobject id uid
//

node GT_Tcl_Graph::find_node_with_uid (const int uid)
{
    const graph& g = leda();
    node n;

    forall_nodes (n, g) {
	if (gt(n).uid() == uid) {
	    return n;
	}
    }
    return 0;
}


//
// The same as above, but now with Tcl support
//

int GT_Tcl_Graph::find_node_with_uid (GT_Tcl_info& tcl_info,
    const int uid,
    node& n)
{
    node found = find_node_with_uid (uid);

    if (found != 0) {
	n = found;
	return TCL_OK;
    } else {
	tcl_info.msg (GT_Error::no_id, uid);
	return TCL_ERROR;
    }
}


int GT_Tcl_Graph::find_node (GT_Tcl_info& tcl_info,
    const char* s,
    node& n)
{
    int uid;
    int code = strip_GT_prefix (tcl_info, s, uid);

    if (code != TCL_OK) {
	return code;
    }

    return find_node_with_uid (tcl_info, uid, n);
}


//
// ... and now the same for edges
//

edge GT_Tcl_Graph::find_edge_with_uid (const int uid)
{
    const graph& g = leda();
    edge e;
	
    forall_edges (e, g) {
	if (gt(e).uid() == uid) {
	    return e;
	}
    }
    return 0;
}


int GT_Tcl_Graph::find_edge_with_uid (GT_Tcl_info& tcl_info,
    const int uid,
    edge& e)
{
    edge found = find_edge_with_uid (uid);

    if (found != 0) {
	e = found;
	return TCL_OK;
    } else {
	tcl_info.msg (GT_Error::no_id, uid);
	return TCL_ERROR;
    }

}


int GT_Tcl_Graph::find_edge (GT_Tcl_info& tcl_info,
    const char* s,
    edge& e)
{
    int uid;
    int code = strip_GT_prefix (tcl_info, s, uid);
    if (code != TCL_OK) {
	return code;
    }

    return find_edge_with_uid (tcl_info, uid, e);
}


//
// .. . and now for graphs
//

int GT_Tcl_Graph::find_graph (GT_Tcl_info& /* tcl_info */,
    const char* /* s */,
    graph& /* g */)
{
    // NOT IMPLEMENTED YET
    return TCL_ERROR;
}



//////////////////////////////////////////
//
// Tcl helper methods
//
//////////////////////////////////////////


int GT_Tcl_Graph::list_of_nodes (GT_Tcl_info& tcl_info, int argc,
    list<node>& nodes)
{
    char** list_argv;
    int    list_argc;
    int code;

    //
    // Split the list
    //
    
    code = Tcl_SplitList (tcl_info.interp(),
	tcl_info[argc],
	&list_argc,
	&list_argv);
    
    if (code != TCL_OK) {
	tcl_info.msg (GT_Error::internal_error, "in Tcl_SplitList");
	return code;
    }
    
    //
    // Parse the list of nodes
    //

    node n;
    for (int i = 0; i < list_argc; i++) {

	code = find_node (tcl_info, list_argv[i], n);
	if (code != TCL_OK) {
	    return code;
	}

	nodes.append (n);
    }

    return TCL_OK;
}



int GT_Tcl_Graph::list_of_edges (GT_Tcl_info& tcl_info, int argc,
    list<edge>& edges)
{
    char** list_argv;
    int    list_argc;
    int code;

    //
    // Split the list
    //
    
    code = Tcl_SplitList (tcl_info.interp(),
	tcl_info[argc],
	&list_argc,
	&list_argv);
    
    if (code != TCL_OK) {
	tcl_info.msg (GT_Error::internal_error, "in Tcl_SplitList");
	return code;
    }
    
    //
    // Parse the list of edges
    //

    edge n;
    for (int i = 0; i < list_argc; i++) {

	code = find_edge (tcl_info, list_argv[i], n);
	if (code != TCL_OK) {
	    return code;
	}

	edges.append (n);
    }

    return TCL_OK;
}
