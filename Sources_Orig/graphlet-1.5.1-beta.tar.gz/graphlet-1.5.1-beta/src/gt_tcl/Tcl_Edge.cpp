// ---------------------------------------------------------------------
// Tcl_Edge.cc
// 
// Memberfunctions for the GT_TclGraph class.
// ---------------------------------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Edge.cpp,v $
// $Author: himsolt $
// $Revision: 1.4 $
// $Date: 1996/11/17 16:12:36 $
// $Locker:  $
// $State: Exp $
// ----------------------------------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#include "Tcl_Graph.h"

#include "Tcl_Edge.h"

#include <gt_base/Id.h>
#include "GraphScript.h"
#include "Tk_UIEdge.h"
#include "Tk_UILabel.h"

#include <LEDA/array.h>

//////////////////////////////////////////
//
// GT_Tcl_Graph::create_edge_cmd
// GT_Tcl_Graph::new_edge_cmd
//
//////////////////////////////////////////


int GT_Tcl_Graph::create_edge_cmd (GT_Tcl_info& tcl_info,
    int argc)
{
    int code;
	
    if (tcl_info.args_left (argc) == 3 || tcl_info.args_left (argc) == 1) {

	bool short_arguments = false;
	if (tcl_info.args_left (argc) == 3) {
	    short_arguments = false;
	} else {
	    short_arguments = true;
	}
	
	//
	// Check syntax
	//
		
	if (!short_arguments) {
	    
	    if (!streq (tcl_info[argc + 0], "source") ||
		!streq (tcl_info[argc + 2], "target")) {

		tcl_info.msg (GT_Error::wrong_keyword, tcl_info[argc]);
		return TCL_ERROR;
	    }
	}

	//
	// Find source and target
	//

	int source_index = short_arguments ? (argc+0) : (argc+1);
	node source;
	code = find_node (tcl_info, tcl_info[source_index], source);
	if (code != TCL_OK) {
	    return code;
	}

	int target_index = short_arguments ? (argc+1) : (argc+3);
	node target;
	code = find_node (tcl_info, tcl_info[target_index], target);
	if (code != TCL_OK) {
	    return code;
	}

	
	edge e = leda().new_edge (source, target);

	//
	// Note: source & target, line assignment in gt is
	// preliminary -- MH
	//

	GT_Edge_Attributes& gt_attrs = gt(e);

// 	gt_attrs.source (source);
// 	gt_attrs.target (target);
		
	GT_Polyline points;
	points.append (gt(source).graphics()->center());
	points.append (gt(target).graphics()->center());
	gt_attrs.graphics()->line (points);
			
	//
	// return the uid of the edge.
	//

	string s ("GT:%d", gt_attrs.uid());
	tcl_info.msg (s);

	return TCL_OK;
		
    } else {
	tcl_info.msg (GT::error.msg(GT_Error::wrong_number_of_args));
	return TCL_ERROR;
    }
}



void GT_Tcl_Graph::new_edge_action (edge e)
{
    baseclass::new_edge_action (e);
	
    GT_Edge_Attributes& edge_attrs = gt(e);

    edge_attrs.uid (GT::id.next_id());
    edge_attrs.label_uid (GT::id.next_id());

    if (edge_attrs.graphics()== 0) {
	edge_attrs.graphics (new_edge_graphics());
    }
    if (gt(e).label_graphics() == 0) {
	gt(e).label_graphics (new_edge_graphics());
    }

    // An edge is a line by default
    // other types subject to later extension
	
    edge_attrs.graphics()->type (GT_Keys::type_line);
	
    run_hooks (tcl_new_edge_actions(), edge_attrs.uid(),
	GT_Keys::action_new_edge);
}



void GT_Tcl_Graph::rev_edge_action (edge e)
{
    GT_Edge_Attributes& edge_attrs = gt(e);

    run_hooks (tcl_rev_edge_actions(), edge_attrs.uid(),
	GT_Keys::action_rev_edge);

    node old_source = edge_attrs.source();
    node old_target = edge_attrs.target();

    edge_attrs.source (old_target);
    edge_attrs.target (old_source);

}



//////////////////////////////////////////
//
// GT_Tcl_Graph::edgeconfigure_cmd
//
//////////////////////////////////////////


int GT_Tcl_Graph::edgeconfigure_cmd (
    GT_Tcl_info& tcl_info,
    int argc,
    const GT_Tcl::Get_Mode mode)
{
    int code = TCL_ERROR;
    bool found = false;
	
    edge e;
    code = find_edge (tcl_info, tcl_info[argc++], e);
    if (code != TCL_OK) {
	return code;
    };

    if (!tcl_info.exists (argc)) {

	//
	// No arguments - get em all
	//
	
	code = edgeconfigure_get (e, GT_Keys::empty,
	    tcl_info.msg(), mode, found);

    } else if (tcl_info.is_last_arg (argc)) {

	//
	// One argument - retrieve a single value
	//
	
	code = edgeconfigure_get (e, tcl_info(argc++),
	    tcl_info.msg(), mode, found);

    } else {

	//
	// More than one argument - set operation
	//
	
	code = edgeconfigure_set (e, tcl_info(argc++),
	    tcl_info, argc, found);

    }

    return code;
}



int GT_Tcl_Graph::edgeconfigure_set (const edge e,
    const GT_Key& key,
    GT_Tcl_info& tcl_info,
    int argc,
    bool& found)
{
    int code = TCL_OK;

    GT_Edge_Attributes& edge_attrs = gt(e);	

    if (!found && code == TCL_OK) {
	code = common_configure_set (edge_attrs,
	    key,
	    tcl_info, argc,
	    found);
    }

    if (!found && code == TCL_OK) {
	code = graphicsconfigure_set (edge_attrs.graphics(),
	    key,
	    tcl_info, argc,
	    found);
    }
	
    return code;
}


		
int GT_Tcl_Graph::edgeconfigure_get (const edge e,
    const GT_Key& key,
    string& value,
    const GT_Tcl::Get_Mode mode,
    bool& found)
{
    bool get_all = (key == GT_Keys::empty);
    int code = TCL_OK;
	
    const GT_Edge_Attributes& edge_attrs = gt(e);
	
    if (key == GT_Keys::option_source || (get_all && code == TCL_OK)) {
		
	string source ("GT:%d", gt(edge_attrs.source()).uid());
	code = GT_Tcl::format_value (value,
	    GT_Keys::option_source, source,
	    mode);
	found = true;
    }

    if (key == GT_Keys::option_target || (get_all && code == TCL_OK)) {
		
	string target ("GT:%d", gt(edge_attrs.target()).uid());
	code = GT_Tcl::format_value (value,
	    GT_Keys::option_target, target,
	    mode);
	found = true;
    }
	
    if (!found || (get_all && code == TCL_OK)) {
		
	code = common_configure_get (edge_attrs,
	    key, value,
	    mode,
	    found);

    }

    if (!found || (get_all && code == TCL_OK)) {
		
	code = graphicsconfigure_get (edge_attrs.graphics(),
	    key, value,
	    mode,
	    found);
    }
	
    return code;
}



//////////////////////////////////////////
//
// GT_Tcl_Graph::edgedraw_cmd
// GT_Tcl_Graph::draw (e)
//
//////////////////////////////////////////


int GT_Tcl_Graph::edgedraw_cmd (
    GT_Tcl_info& tcl_info,
    int argc)
{
    if (!tcl_info.is_last_arg (argc)) {
	tcl_info.msg (GT_Error::wrong_number_of_args);
	return TCL_ERROR;
    }

    int code;
    edge e;
    
    code = find_edge (tcl_info, tcl_info[argc], e);
    if (code != TCL_OK) {
	return code;
    }

    code = begin_draw();
    if (code != TCL_OK) {
	return code;
    }
    
    code = draw (e);
    if (code != TCL_OK) {
	return code;
    }
		
    return end_draw();
}


int GT_Tcl_Graph::draw (edge e)
{
    const GT_Edge_Attributes& attrs = gt(e);

    const GT_Common_Graphics* edge_graphics =
	attrs.graphics();
    const GT_Common_Graphics* source_graphics =
	gt(gt(e).source()).graphics();
    const GT_Common_Graphics* target_graphics =
	gt(gt(e).target()).graphics();

    //
    // Update coordinates if neccessary
    //
	
    bool geometry_initialized =
	edge_graphics->is_initialized (GT_Common_Graphics::tag_geometry);
    bool geometry_changed =
	edge_graphics->is_changed (GT_Common_Graphics::tag_geometry);
    bool source_geometry_changed =
	source_graphics->is_changed (GT_Common_Graphics::tag_geometry);
    bool target_geometry_changed =
	target_graphics->is_changed (GT_Common_Graphics::tag_geometry);
    bool label_changed =
	attrs.is_changed (GT_Common_Attributes::tag_label);

    if (!geometry_initialized || geometry_changed ||
	source_geometry_changed || target_geometry_changed ||
	label_changed) {

	update_coordinates(e);
	update_label_coordinates(e);

	gt().graphics()->is_changed (GT_Common_Graphics::tag_geometry);
    }

    //
    // If the type has changed, then re-create the label
    //

    bool label_is_empty = (attrs.label().length() == 0);
    bool must_recreate_label =
	attrs.graphics()->is_changed (GT_Common_Graphics::tag_type) &&
	!label_is_empty;

    //
    // Draw on all devices
    //
	
    GT_Device* device;
    forall (device, the_devices) {

	GT_UIObject* uiedge = device->object (attrs.uid());
	
	if (uiedge == 0) {
			
	    uiedge = new_tk_uiedge (
		attrs.uid(),
		(GT_Tcl_Device*)device,
		device->object (gt().uid()),
		this,
		e);
			
	    if (uiedge->create() == false) {
		delete uiedge;
		return TCL_ERROR;
	    } else {
		device->insert (attrs.uid(), uiedge);
	    }
			
	} else {
	    uiedge->update ();
	}

	GT_UIObject* uilabel = device->object (attrs.label_uid());
			
	if (geometry_changed ||
	    attrs.is_changed(GT_Common_Attributes::tag_label) ||
	    must_recreate_label) {

	    if (uilabel == 0) {

		if (!label_is_empty) {
			
		    uilabel = new_tk_uilabel (
			attrs.label_uid(),
			(GT_Tcl_Device*)device,
			uiedge,
			this,
			e);

		    if (uilabel->create() == false) {
			delete uilabel;
			return TCL_ERROR;
		    } else {
			device->insert (attrs.label_uid(), uilabel);
		    }
		}
				
	    } else {
		if (must_recreate_label) {
		    // Set label "changed" so it is drawn
		    gt(e).set_changed (GT_Common_Attributes::tag_label);
		    uilabel->create ();
		} else  if (!label_is_empty) {
		    uilabel->update ();
		} else {
		    uilabel->del ();
		    delete uilabel;
		    device->del (attrs.label_uid());
		    gt(e).reset_changed (GT_Common_Attributes::tag_label);
		}
	    }
	}
    }

    return TCL_OK;
}



//
// draw customization
//


GT_Tk_UIEdge* GT_Tcl_Graph::new_tk_uiedge (const int uid,
    GT_Tcl_Device* const device,
    GT_UIObject* parent,
    GT_Graph* g,
    const edge e)
{
    return new GT_Tk_UIEdge (uid, device, parent, g, e);
}


GT_Tk_UILabel* GT_Tcl_Graph::new_tk_uilabel (const int uid,
    GT_Tcl_Device* device,
    GT_UIObject* parent,
    GT_Graph* g,
    edge e)
{
    return new GT_Tk_UILabel (uid, device, parent, g, e);
};


//////////////////////////////////////////
//
// Draw utilities
//
//////////////////////////////////////////


void GT_Tcl_Graph::update (edge e)
{
    GT_Graph::update(e);
}


static void compute_min (const array<point>& points1, point& min1,
    const array<point>& points2, point& min2)
{
    double minimum = DBL_MAX; // Should be enough
    int i, j;
    int min_i = 0, min_j = 0;
	
    for (i = points1.low(); i <= points1.high(); i++) {
	for (j = points2.low(); j <= points2.high(); j++) {
	    double dist = points1[i].distance (points2[j]);
	    if (dist < minimum) {
		min_i = i;
		min_j = j;
		minimum = dist;
	    }
	}
    }

    min1 = points1[min_i];
    min2 = points2[min_j];
}



void GT_Tcl_Graph::update_coordinates (edge e)
{
    //
    // Get some information on the edge
    // and its source and targer nodes
    //
	
    const GT_Edge_Attributes& edge_attrs = gt(e);
    const GT_Node_Attributes& source_attrs = gt(edge_attrs.source());
    const GT_Node_Attributes& target_attrs = gt(edge_attrs.target());
	
    const GT_Common_Graphics* graphics = edge_attrs.graphics();
    const GT_Common_Graphics* source_graphics = source_attrs.graphics();
    const GT_Common_Graphics* target_graphics = target_attrs.graphics();
	
    const GT_Rectangle& source_center = source_graphics->center();
    const GT_Rectangle& target_center = target_graphics->center();
	
    const GT_Key edge_anchor = edge_attrs.edge_anchor();
    GT_Key source_anchor;
    GT_Key target_anchor;

    //
    // Find out what to do. edge anchors have precedence over
    // anchors listed in the source or target nodes.
    //
	
    if (!edge_anchor.active()) {
	source_anchor = source_attrs.edge_anchor();
	target_anchor = target_attrs.edge_anchor();
    } else {
	source_anchor = edge_anchor;
	target_anchor = edge_anchor;
    }
	
    GT_Polyline line = graphics->line();
    if (line.length() == 0) {
	line.append (source_graphics->center());
	line.append (target_graphics->center());
    }
    bool single_line = (line.length() == 2);

	// See wether all anchors are discrete, i.e. find the best fit
	// in a list of points
    bool source_discrete_anchor = (
	source_anchor == GT_Keys::anchor_corners ||
	source_anchor == GT_Keys::anchor_middle ||
	source_anchor == GT_Keys::anchor_8);
    bool target_discrete_anchor = (
	target_anchor == GT_Keys::anchor_corners ||
	target_anchor == GT_Keys::anchor_middle ||
	target_anchor == GT_Keys::anchor_8);
	
    if (source_discrete_anchor || target_discrete_anchor) {

	//
	// Preprocessing: determine how many corners to
	// check
	//

	int source_corners_to_check;
	if (source_anchor == GT_Keys::anchor_corners ||
	    source_anchor == GT_Keys::anchor_middle) {
	    source_corners_to_check = 4;
	} else if (source_anchor == GT_Keys::anchor_8) {
	    source_corners_to_check = 8;
	} else {
	    source_corners_to_check = 1;
	}
		
	int target_corners_to_check = 0;
	if (target_anchor == GT_Keys::anchor_corners ||
	    target_anchor == GT_Keys::anchor_middle) {
	    target_corners_to_check = 4;
	} else if (target_anchor == GT_Keys::anchor_8) {
	    target_corners_to_check = 8;
	} else {
	    target_corners_to_check = 1;
	}
		
	array<point> source_corners (source_corners_to_check);
	array<point> target_corners (target_corners_to_check);
		
	//
	// More preprocessing: get the corners
	//
		
	int s = 0; // index for sources
	int t = 0; // index for targets

	if (source_anchor == GT_Keys::anchor_corners ||
	    source_anchor == GT_Keys::anchor_8) {
			
	    source_corners[s++] = source_center.anchor_ne();
	    source_corners[s++] = source_center.anchor_se();
	    source_corners[s++] = source_center.anchor_sw();
	    source_corners[s++] = source_center.anchor_nw();
	}
		
	if (source_anchor == GT_Keys::anchor_middle ||
	    source_anchor == GT_Keys::anchor_8) {
			
	    source_corners[s++] = source_center.anchor_n();
	    source_corners[s++] = source_center.anchor_e();
	    source_corners[s++] = source_center.anchor_s();
	    source_corners[s++] = source_center.anchor_w();
	}

	if (s == 0) { // no match
	    source_corners[s++] = line.head();
	}

	if (target_anchor == GT_Keys::anchor_corners ||
	    target_anchor == GT_Keys::anchor_8) {
			
	    target_corners[t++] = target_center.anchor_ne();
	    target_corners[t++] = target_center.anchor_se();
	    target_corners[t++] = target_center.anchor_sw();
	    target_corners[t++] = target_center.anchor_nw();
	}
		
	if (target_anchor == GT_Keys::anchor_middle ||
	    target_anchor == GT_Keys::anchor_8) {
			
	    target_corners[t++] = target_center.anchor_n();
	    target_corners[t++] = target_center.anchor_e();
	    target_corners[t++] = target_center.anchor_s();
	    target_corners[t++] = target_center.anchor_w();
	}

	if (t == 0) { // no match
	    target_corners[t++] = line.head();
	}

	//
	// Compute the best fit corner
	//
		
	point min_source_corner;
	point min_target_corner;
	point dummy;
		
	if (!single_line) {

	    array<point> edge_near_source (1);
	    edge_near_source [0] = line.contents (
		line.succ (line.first()));
	    compute_min (source_corners, min_source_corner,
		edge_near_source, dummy);
			
	    array<point> edge_near_target (1);
	    edge_near_target [0] = line.contents (
		line.pred (line.last()));
	    compute_min (edge_near_target, dummy,
		target_corners, min_target_corner);

	} else {

	    compute_min (
		source_corners, min_source_corner,
		target_corners, min_target_corner);
	}

	//
	// Assign it
	//
		
	line[line.first()] = min_source_corner;
	line[line.last()] = min_target_corner;

    }

	
    extern void clip_line_out_of_node (const GT_Rectangle& r,
	const point& fix,
	point& adjust);

    if (!source_discrete_anchor || !target_discrete_anchor) {

	point p0,p1, pn1,pn;
	if (single_line) {
	    p0 = source_graphics->center();
	    pn = target_graphics->center();
	    p1 = pn;
	    pn1 = p0;
	} else {
	    p0 = source_graphics->center();
	    p1 = line [line.item(1)];
	    pn1 = line [line.pred(line.last())];
	    pn = target_graphics->center();
	}

	if (!source_discrete_anchor) {
	    clip_line_out_of_node (source_graphics->center(), p1, p0);
	    line[line.first()] = p0;
	}
		
	if (!target_discrete_anchor) {
	    clip_line_out_of_node (target_graphics->center(), pn1, pn);
	    line[line.last()] = pn;
	}
    }
	
    gt(e).graphics()->line (line);

    GT_Graph::update_coordinates (e);
}




void GT_Tcl_Graph::update_label_coordinates (edge e)
{
    const GT_Edge_Attributes& edge_attrs = gt(e);
    const GT_Common_Graphics* graphics =
	edge_attrs.graphics();

    const GT_Key label_anchor = edge_attrs.label_anchor();
    GT_Point p;

    if (label_anchor == GT_Keys::anchor_first) {

	const GT_Polyline& line = graphics->line();
	const segment s = line.nth_segment (0);
		
	p = GT_Point ((s.xcoord1()  + s.xcoord2()) / 2,
	    ((s.ycoord1()  + s.ycoord2()) / 2));
			
    } else if (label_anchor == GT_Keys::anchor_last) {
		
	const GT_Polyline& line = graphics->line();
	const segment s = line.nth_segment (line.length()-1);
		
	p = GT_Point ((s.xcoord1()  + s.xcoord2()) / 2,
	    ((s.ycoord1()  + s.ycoord2()) / 2));
		
    } else {

	const GT_Polyline& line = graphics->line();
	const int l = line.length();
	const segment s = line.nth_segment ((l>2) ? (l/2 - 1) : 0);
		
	p = GT_Point ((s.xcoord1()  + s.xcoord2()) / 2,
	    ((s.ycoord1()  + s.ycoord2()) / 2));
    }
	
    gt(e).label_graphics()->center(
	GT_Rectangle (p, graphics->w(), graphics->h()));

    GT_Graph::update_label_coordinates (e);
}


//////////////////////////////////////////
//
// GT_Tcl_Graph::edgedelete_cmd
// GT_Tcl_Graph::del_edge_action
//
//////////////////////////////////////////


int GT_Tcl_Graph::edgedelete_cmd (
    GT_Tcl_info& tcl_info,
    int argc)
{
    int code;
    if (!tcl_info.is_last_arg (argc)) {
	tcl_info.msg (GT_Error::wrong_number_of_args);
	return TCL_ERROR;
    }

    edge e;
    code = find_edge (tcl_info, tcl_info[argc], e);
    if (code != TCL_OK) {
	return code;
    }

    leda().del_edge (e);
    return TCL_OK;
}


	
void GT_Tcl_Graph::del_edge_action (edge e)
{
    int edge_uid = gt(e).uid();
    int label_uid = gt(e).label_uid();

    run_hooks (tcl_del_edge_actions(), gt(e).uid(),
	GT_Keys::action_del_edge);

    GT_Device* device;
    forall (device, the_devices) {

	GT_UIObject* uiobject;
	uiobject = device->object (edge_uid);
	if (uiobject != 0) {
	    uiobject->del();
	    delete uiobject;
	    device->del (edge_uid);
	}
		

	uiobject = device->object (label_uid);
	if (uiobject != 0) {
	    uiobject->del();
	    delete uiobject;
	    device->del (label_uid);
	}
    }

    baseclass::del_edge_action (e);
}
