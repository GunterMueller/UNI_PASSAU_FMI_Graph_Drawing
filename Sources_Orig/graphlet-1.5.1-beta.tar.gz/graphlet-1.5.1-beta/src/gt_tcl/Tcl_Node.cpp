// ---------------------------------------------------------------------
// Tcl_Node.cc
// 
// This module handles the node-functions of the GT_Tcl_Graph - class.
// ---------------------------------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Node.cpp,v $
// $Author: himsolt $
// $Revision: 1.5 $
// $Date: 1996/11/17 16:12:36 $
// $Locker:  $
// $State: Exp $
// ----------------------------------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#include "Tcl_Graph.h"

#include "Tcl_Node.h"

#include <gt_base/Id.h>
#include "GraphScript.h"

#include "Tk_UINode.h"
#include "Tk_UILabel.h"



//////////////////////////////////////////
//
// GT_Tcl_Graph::create_node_cmd
// GT_Tcl_Graph::new_node_action
//
//////////////////////////////////////////


int GT_Tcl_Graph::create_node_cmd (
    GT_Tcl_info& tcl_info,
    int /* argc */)
{    
    node n = leda().new_node ();

    string s ("GT:%d", gt(n).uid());
    tcl_info.msg (s);

    return TCL_OK;
}


void GT_Tcl_Graph::new_node_action (node n)
{
    GT_Graph::new_node_action (n);

    GT_Node_Attributes& node_attrs = gt(n);
		
    node_attrs.uid (GT::id.next_id());
    node_attrs.label_uid (GT::id.next_id());

    if (node_attrs.graphics() == 0) {
	node_attrs.graphics (new_node_graphics());
    }
    if (node_attrs.label_graphics() == 0) {
	node_attrs.label_graphics (new_node_graphics());
    }

    run_hooks (tcl_new_node_actions(), node_attrs.uid(),
	GT_Keys::action_new_node);
}



//////////////////////////////////////////
//
// GT_Tcl_Graph::nodeconfigure_cmd
//
//////////////////////////////////////////


int GT_Tcl_Graph::nodeconfigure_cmd (
    GT_Tcl_info& tcl_info,
    int argc,
    const GT_Tcl::Get_Mode mode)
{
    int code = TCL_ERROR;
    bool found = false;
	
    //
    // Get the node
    //
	
    node n;
    code = find_node (tcl_info, tcl_info[argc++], n);
    if (code != TCL_OK) {
	return code;
    };

    if (!tcl_info.exists (argc)) {

	//
	// No arguments - get em all
	//
	
	code = nodeconfigure_get (n, GT_Keys::empty,
	    tcl_info.msg(), mode, found);

    } else if (tcl_info.is_last_arg (argc)) {

	//
	// One argument - retrieve a single value
	//
	
	code = nodeconfigure_get (n, tcl_info(argc++),
	    tcl_info.msg(), mode, found);

    } else {

	//
	// More than one argument - set operation
	//
	
	code = nodeconfigure_set (n, tcl_info(argc++),
	    tcl_info, argc, found);

    }

    return code;
}



int GT_Tcl_Graph::nodeconfigure_set (const node n,
    const GT_Key& key,
    GT_Tcl_info& tcl_info, int argc,
    bool& found)
{
    int code = TCL_OK;
	
    GT_Node_Attributes& node_attrs = gt(n);

    if (!found && code == TCL_OK) {
	code = common_configure_set (node_attrs,
	    key,
	    tcl_info, argc,
	    found);
    }

    if (!found && code == TCL_OK) {
	code = graphicsconfigure_set (node_attrs.graphics(),
	    key,
	    tcl_info, argc,
	    found);
    }

    return code;
}



int GT_Tcl_Graph::nodeconfigure_get (const node n,
    const GT_Key& key,
    string& value,
    const GT_Tcl::Get_Mode mode,
    bool& found)
{
    bool get_all = (key == GT_Keys::empty);	
    int code = TCL_OK;	

    GT_Node_Attributes& node_attrs = gt(n);
	
    if (!found || (get_all && code == TCL_OK)) {
		
	code = common_configure_get (node_attrs,
	    key, value,
	    mode,
	    found);

    }

    if (!found || (get_all && code == TCL_OK)) {
		
	code = graphicsconfigure_get (node_attrs.graphics(),
	    key, value,
	    mode,
	    found);
    }
	
    return code;
}



//////////////////////////////////////////
//
// GT_Tcl_Graph::nodedraw_cmd
// GT_Tcl_Graph::cmd
//
//////////////////////////////////////////


int GT_Tcl_Graph::nodedraw_cmd (GT_Tcl_info& tcl_info, int argc)
{
    if (!tcl_info.is_last_arg (argc)) {
	tcl_info.msg (GT_Error::wrong_number_of_args);
	return TCL_ERROR;
    }

    int code;
    node n;

    code = find_node (tcl_info, tcl_info[argc], n);
    if (code != TCL_OK) {
	return code;
    }

    code = begin_draw();
    if (code != TCL_OK) {
	return code;
    }
    
    code = draw (n);
    if (code != TCL_OK) {
	return code;
    }
	
    edge e;
    forall_inout_edges (e, n) {
	code = draw (e);
	if (code != TCL_OK) {
	    return code;
	}
    }
		
    return end_draw ();
}



int GT_Tcl_Graph::draw (node n)
{
    const GT_Node_Attributes& attrs = gt(n);

    //
    // Check wether coordinates need to be updated
    //
	
    bool geometry_changed =
	attrs.graphics()->is_changed (GT_Common_Graphics::tag_geometry);
    bool label_changed =
	attrs.is_changed (GT_Common_Attributes::tag_label);
	
    if (geometry_changed) {

	update_coordinates(n);

	edge e;
	forall_inout_edges (e, n) {
	    gt(e).graphics()->set_changed (GT_Common_Graphics::tag_geometry);
	}
    }

    if (geometry_changed || label_changed) {
	update_label_coordinates(n);
    }
	
    //
    // If the type has changed, then update the label
    //

    bool label_is_empty = (attrs.label().length() == 0);
    bool must_recreate_label =
	attrs.graphics()->is_changed (GT_Common_Graphics::tag_type) &&
	!label_is_empty;

    //
    // Draw the node
    //
	
    GT_Device* device;
    forall (device, the_devices) {

	GT_UIObject* uinode = device->object (attrs.uid());

	if (uinode == 0) {
				
	    uinode = new_tk_uinode (attrs.uid(),
		(GT_Tcl_Device*)device,
		device->object (gt().uid()),
		this,
		n);

	    if (uinode->create() == false) {
		delete uinode;
		return TCL_ERROR;
	    } else {
		device->insert (attrs.uid(), uinode);
	    }
			
	} else {
	    uinode->update ();
	}
			
		
	if (// geometry_changed ||
	    attrs.is_changed(GT_Common_Attributes::tag_label) ||
	    must_recreate_label) {

	    GT_UIObject* uilabel = device->object (attrs.label_uid());

	    if (uilabel == 0) {

		if (!label_is_empty) {

		    uilabel = new_tk_uilabel (attrs.label_uid(),
			(GT_Tcl_Device*)device,
			uinode,
			this,
			n);

		    if (uilabel->create() == false) {
			return TCL_ERROR;
		    } else {
			device->insert (attrs.label_uid(), uilabel);
		    }
		}
				
	    } else {
		
		if (must_recreate_label) {
		    // Set label "changed" so it is drawn
		    gt(n).set_changed (GT_Common_Attributes::tag_label);
		    uilabel->create ();
		} else if (!label_is_empty) {
		    uilabel->update ();
		} else {
		    uilabel->del ();
		    delete uilabel;
		    device->del (attrs.label_uid());
		    gt(n).reset_changed (GT_Common_Attributes::tag_label);
		}
	    }
	}
    }

    gt(n).graphics()->old_center (gt(n).graphics()->center());
    
    return TCL_OK;
}



//
// draw customization
//


GT_Tk_UINode* GT_Tcl_Graph::new_tk_uinode (const int uid,
    GT_Tcl_Device* const device,
    GT_UIObject* parent,
    GT_Graph* g,
    const node n)
{
    return new GT_Tk_UINode (uid, device, parent, g, n);
}


GT_Tk_UILabel* GT_Tcl_Graph::new_tk_uilabel (const int uid,
    GT_Tcl_Device* device,
    GT_UIObject* parent,
    GT_Graph* g,
    node n)
{
    return new GT_Tk_UILabel (uid, device, parent, g, n);
}



//
// Draw utilities
//


void GT_Tcl_Graph::update (node n)
{
    GT_Graph::update (n);
}


void GT_Tcl_Graph::update_coordinates (node n)
{
    GT_Graph::update_coordinates (n);
}


void GT_Tcl_Graph::update_label_coordinates (node n)
{
    GT_Node_Attributes& node_attrs = gt(n);
    const GT_Common_Graphics* graphics =
	node_attrs.graphics();
    GT_Common_Graphics* label_graphics =
	node_attrs.label_graphics();

    if (node_attrs.label().length() > 0 && label_graphics != 0) {

	double w = graphics->w();
	double h = graphics->h();

	const GT_Key anchor = node_attrs.label_anchor();
	const GT_Rectangle& center = graphics->center();

	GT_Point p;
	if (anchor == GT_Keys::anchor_center) {
	    p = center.anchor_c();
	} else if (anchor == GT_Keys::anchor_n) {
	    p = center.anchor_n();
	} else if (anchor == GT_Keys::anchor_ne) {
	    p = center.anchor_ne();
	} else if (anchor == GT_Keys::anchor_e) {
	    p = center.anchor_e();
	} else if (anchor == GT_Keys::anchor_se) {
	    p = center.anchor_se();
	} else if (anchor == GT_Keys::anchor_s) {
	    p = center.anchor_s();
	} else if (anchor == GT_Keys::anchor_sw) {
	    p = center.anchor_sw();
	} else if (anchor == GT_Keys::anchor_w) {
	    p = center.anchor_w();
	} else if (anchor == GT_Keys::anchor_nw) {
	    p = center.anchor_nw();
	} else {
	    p = center;
	}
		
	node_attrs.label_graphics()->center (GT_Rectangle (p, w, h));
    }

    GT_Graph::update_label_coordinates (n);
}



//////////////////////////////////////////
//
// GT_Tcl_Graph::nodemove_cmd
// GT_Tcl_Graph::move_node
//
//////////////////////////////////////////


int GT_Tcl_Graph::nodemove_cmd (
    GT_Tcl_info& tcl_info,
    int argc)
{
    int code;
	
    if (tcl_info.args_left (argc, 2)) {

	//
	// Get the x and y values.
	//

	double x_diff;
	double y_diff;

	code = Tcl_GetDouble (tcl_info.interp(),
	    tcl_info[argc + 1],
	    &x_diff);

	if (code != TCL_OK) {
	    tcl_info.msg (GT_Error::wrong_double_val,
		tcl_info[argc+1]);
	    return code;
	}
	
	code = Tcl_GetDouble (tcl_info.interp(),
	    tcl_info[argc+2],
	    &y_diff);
	
	if (code != TCL_OK) {
	    tcl_info.msg (GT_Error::wrong_double_val,
		tcl_info[argc+2]);
	    return code;
	}
	
	//
	// Move each node in the listArgv
	//

	list<node> nodes;
	code = list_of_nodes (tcl_info, argc, nodes);
	if (code != TCL_OK) {
	    return code;
	}

	code = move_nodes (nodes, x_diff, y_diff);
	if (code != TCL_OK) {
	    return code;
	}
	
	return TCL_OK;

    } else {

	tcl_info.msg (GT_Error::wrong_number_of_args);
	return TCL_ERROR;

    }
	
    return TCL_OK;
}



int GT_Tcl_Graph::move_node (node n,
    const double move_x,
    const double move_y)
{
    int code = TCL_OK;
	
    const GT_Node_Attributes& node_attrs = gt(n);
    const int node_uid = node_attrs.uid();

    //
    // move the node
    //
	
    GT_Device* device;
    forall (device, the_devices) {
		
	GT_UIObject* uiobject = device->object (node_uid);
	if (uiobject != 0) {
	    if (uiobject->move (move_x, move_y) == false) {
		return TCL_ERROR;
	    }
	}
    }

    //
    // Change coordinates
    //

    baseclass::move_node (n, move_x, move_y);

	
    //
    // Since the position is already updated on the screen,
    // reset the change
    //
	
    gt(n).graphics()->reset_changed (GT_Common_Graphics::tag_geometry);
    gt(n).graphics()->old_center (gt(n).graphics()->center());

    //
    // update coordinates for the edges and draw them.
    //
	
    edge e;
    forall_inout_edges (e, n) {
	gt(e).graphics()->set_changed (GT_Common_Graphics::tag_geometry);
	code = draw (e);
	if (code == TCL_ERROR) {
	    return code;
	}
    }

    return code;
}



int GT_Tcl_Graph::move_nodes (const list<node>& nodes,
    const double move_x,
    const double move_y)
{
    int code = TCL_OK;
	
    
    node n;
    forall (n, nodes) {
	
	//
	// move the UIObjects associated with the nodes
	//
	
	const int node_uid = gt(n).uid();

	GT_Device* device;
	forall (device, the_devices) {
	    GT_UIObject* uiobject = device->object (node_uid);
	    if (uiobject != 0) {
		if (uiobject->move (move_x, move_y) == false) {
		    return TCL_ERROR;
		}
	    }
	}

 	//
	// Change coordinates
	//

	baseclass::move_node (n, move_x, move_y);

        //
	// HERE comes the trick:
	// Since the position is already updated on the screen,
	// reset the change
	//
	
	gt(n).graphics()->reset_changed (GT_Common_Graphics::tag_geometry);
	gt(n).graphics()->old_center (gt(n).graphics()->center());
	
    }

    //
    // Update coordinates for the edges and draw them.
    //

    edge e;
    forall (n, nodes) {
	forall_adj_edges (e, n) {

	    node opposite = leda().opposite (n,e);
	    if (nodes.search (opposite) != 0 && n == leda().source(e)) {

		// Both endnodes are in the list
		
		move_edge (e, move_x, move_y);
	    }
	}
    }
    
    forall (n, nodes) {
	forall_inout_edges (e, n) {
	    
	    node opposite = leda().opposite (n,e);
	    if (nodes.search (opposite) == 0) {

		// Only one endnode is in the list
	    
		gt(e).graphics()->set_changed (
		    GT_Common_Graphics::tag_geometry);
		code = draw (e);
		if (code == TCL_ERROR) {
		    return code;
		}
	    }
	}
    }
    
    return code;
}



int GT_Tcl_Graph::move_edge (edge e,
    const double move_x,
    const double move_y)
{
    //
    // move the UIObjects associated with the edges
    //
	
    const int edge_uid = gt(e).uid();
    
    GT_Device* device;
    forall (device, the_devices) {
	GT_UIObject* uiobject = device->object (edge_uid);
	if (uiobject != 0) {
	    if (uiobject->move (move_x, move_y) == false) {
		return TCL_ERROR;
	    }
	}
    }

    //
    // This uses the same trick as above: now adjust the coordinates
    // and tell nobody what we have done ...
    //
    
    baseclass::move_edge (e, move_x, move_y);
    gt(e).graphics()->reset_changed (
	GT_Common_Graphics::tag_geometry);

    return TCL_OK;
}



//////////////////////////////////////////
//
// GT_Tcl_Graph::nodedelete_cmd
// GT_Tcl_Graph::del_node_action
//
//////////////////////////////////////////


int GT_Tcl_Graph::nodedelete_cmd (GT_Tcl_info& tcl_info, int argc)
{
    int code;
	
    if (tcl_info.is_last_arg (argc)) {

	node n;
	code = find_node (tcl_info, tcl_info[argc], n);
	if (code != TCL_OK) {
	    return code;
	}
		
	leda().del_node (n);
	return TCL_OK;
		
    } else {
		
	tcl_info.msg (GT_Error::wrong_number_of_args);		
	return TCL_ERROR;
    }

    return TCL_OK;
}



void GT_Tcl_Graph::del_node_action (node n)
{
    run_hooks (tcl_del_node_actions(), gt(n).uid(),
	GT_Keys::action_del_node);

    int node_uid = gt(n).uid();
    int label_uid = gt(n).label_uid();
	
    GT_Device* device;
    forall (device, the_devices) {

	GT_UIObject* uiobject;
	uiobject = device->object (node_uid);
	if (uiobject != 0) {
	    uiobject->del();
	    delete uiobject;
	    device->del (node_uid);
	}

	uiobject = device->object (label_uid);
	if (uiobject != 0) {
	    uiobject->del();
	    delete uiobject;
	    device->del (label_uid);
	}
    }

    baseclass::del_node_action (n);
}
