#ifndef GT_TK_UIEDGE_H
#define GT_TK_UIEDGE_H

//
// Tk_UIEdge.h
//
// This file defines the class GT_Tk_UIEdge.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tk_UIEdge.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:13 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//


#include "Tk_UIObject.h"


class GT_Tk_UIEdge : public GT_Tk_UIObject
{
    GT_CLASS (GT_Tk_UIEdge, GT_Tk_UIObject);

    GT_VARIABLE (GT_Graph*, g);
    GT_VARIABLE (edge, e);

public:
	
    GT_Tk_UIEdge (const int uid,
	GT_Tcl_Device* const device,
	GT_UIObject* parent,
	GT_Graph* g,
	const edge e);
	
    virtual ~GT_Tk_UIEdge ();
	
    virtual const GT_Key& type () const;

    virtual void make_create_cmd (string& cmd);
};


#endif
