//
// Tk_UIObject.cc
//
// This file implements the class GT_Tk_UIObject.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tk_UIObject.cpp,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/11 08:27:07 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Tcl_Graph.h"

// #include "GraphScript.h"
#include "Tk_UIObject.h"

//
// Constructors
//

GT_Tk_UIObject::GT_Tk_UIObject (const int uid,
    GT_Tcl_Device* const device,
    GT_UIObject* parent) :
	GT_UIObject (uid, device, parent)
{

}


//
// Destructor
//


GT_Tk_UIObject::~GT_Tk_UIObject ()
{
}



//
// Auxiliary procedures
//


bool accepts (const GT_Key& type,
    const GT_Common_Graphics::Graphics attribute)
{
    unsigned long accepted = 0;
	
    if (type == GT_Keys::type_arc) {
		
	accepted =
	    GT_Common_Graphics::tag_extent |
	    GT_Common_Graphics::tag_fill |
	    GT_Common_Graphics::tag_outline |
	    GT_Common_Graphics::tag_start |
	    GT_Common_Graphics::tag_stipple |
	    GT_Common_Graphics::tag_style |
	    GT_Common_Graphics::tag_width;
		
    } else if (type == GT_Keys::type_bitmap) {
		
	accepted =
	    GT_Common_Graphics::tag_anchor |
	    GT_Common_Graphics::tag_background |
	    GT_Common_Graphics::tag_foreground |
	    GT_Common_Graphics::tag_bitmap;
		
    } else if (type == GT_Keys::type_image) {

	accepted =
	    GT_Common_Graphics::tag_anchor |
	    GT_Common_Graphics::tag_image;
		
    } else if (type == GT_Keys::type_line) {
		
	accepted =
	    GT_Common_Graphics::tag_arrow |
	    GT_Common_Graphics::tag_arrowshape |
	    GT_Common_Graphics::tag_capstyle |
	    GT_Common_Graphics::tag_fill |
	    GT_Common_Graphics::tag_joinstyle |
	    GT_Common_Graphics::tag_smooth |
	    GT_Common_Graphics::tag_splinesteps |
	    GT_Common_Graphics::tag_stipple |
	    GT_Common_Graphics::tag_width;
		
    } else if (type == GT_Keys::type_polygon) {

	accepted =
	    GT_Common_Graphics::tag_fill |
	    GT_Common_Graphics::tag_smooth |
	    GT_Common_Graphics::tag_splinesteps |
	    GT_Common_Graphics::tag_stipple;
		
    } else if (type == GT_Keys::type_oval) {

	accepted =
	    GT_Common_Graphics::tag_fill |
	    GT_Common_Graphics::tag_outline |
	    GT_Common_Graphics::tag_stipple |
	    GT_Common_Graphics::tag_width;
		
    } else if (type == GT_Keys::type_rectangle) {

	accepted =
	    GT_Common_Graphics::tag_fill |
	    GT_Common_Graphics::tag_outline |
	    GT_Common_Graphics::tag_stipple |
	    GT_Common_Graphics::tag_width;
		
    } else if (type == GT_Keys::type_text) {

	accepted =
	    GT_Common_Graphics::tag_anchor |
	    GT_Common_Graphics::tag_fill |
	    GT_Common_Graphics::tag_font |
	    GT_Common_Graphics::tag_justify |
	    GT_Common_Graphics::tag_stipple |
	    GT_Common_Graphics::tag_width;
		
    }

    return ((attribute & accepted) != 0);
}


//
// Procedures that generate Tcl Commands
//

void GT_Tk_UIObject::make_tags_cmd (string& cmd)
{
    cmd = string("%s GT:%d",
	type().name().cstring(),
	uid());
	
    GT_UIObject* p = parent();
    while (p != 0 && p->uid() != -1) {
	cmd += string (" GT:%d", p->uid());
	p = p->parent();
    }
}


void GT_Tk_UIObject::make_create_cmd (string& cmd)
{
    const GT_Common_Graphics* cg = graphics();

    //
    // First, set standard type, fill and outline
    //

    // Type
    if (!cg->type().active()) {
	graphics()->type (GT_Keys::type_rectangle);	
    }
    const GT_Key& type = cg->type();

    if (!cg->fill().active() &&
	accepts (type, GT_Common_Graphics::tag_fill))
    {
	if (type == GT_Keys::type_line || type == GT_Keys::type_text) {
	    graphics()->fill (GT_Keys::black);
	} else {
	    graphics()->fill (GT_Keys::white);
	}
    }
    const GT_Key& fill = cg->fill();
    
    if (!cg->outline().active() &&
	accepts (type, GT_Common_Graphics::tag_outline))
    {
	graphics()->outline (GT_Keys::black);
    }
    const GT_Key& outline = cg->outline();

    if (cg->is_changed (GT_Common_Graphics::tag_type)) {
	for(unsigned tag = GT_Common_Graphics::common_graphics_tag_min;
	    tag <= GT_Common_Graphics::common_graphics_tag_max;
	    tag = tag << 1) {
	    
	    if (cg->is_initialized (tag)) {
		graphics()->set_changed (tag);
	    }
	}
    }
    
    //
    // Create the command
    //
    
    if (type == GT_Keys::type_arc) {

	cmd = string ("%s create arc ",
	    device()->name().cstring());
	make_update_coords_cmd (cmd, false);

    } else if (type == GT_Keys::type_bitmap &&
	cg->bitmap().active()) {
		
	cmd = string ("%s create bitmap ",
	    device()->name().cstring());
	make_update_coords_cmd (cmd, false);
	cmd += string (" -bitmap %s",
	    cg->bitmap().name().cstring());
		
    } else if (type == GT_Keys::type_image &&
	cg->image().active()) {
		
	cmd = string ("%s create image ",
	    device()->name().cstring());
	make_update_coords_cmd (cmd, false);
	cmd += string (" -image %s",
	    cg->image().name().cstring());
		
    } else if (type == GT_Keys::type_line) {

	cmd = string ("%s create line",
	    device()->name().cstring());		
	make_update_coords_cmd (cmd, false);
		
    } else if (type == GT_Keys::type_oval) {

	cmd = string ("%s create oval ",
	    device()->name().cstring());
	make_update_coords_cmd (cmd, false);

    } else if (type == GT_Keys::type_polygon) {

	cmd = string ("%s create polygon ",
	    device()->name().cstring());
	make_update_coords_cmd (cmd, false);

    } else if (type == GT_Keys::type_text) {

	cmd = string ("%s create text ",
	    device()->name().cstring());		
	make_update_coords_cmd (cmd, false);
		
    } else /* assume rectangle */ {

	cmd = string ("%s create rectangle ", device()->name().cstring());
	make_update_coords_cmd (cmd, false);
    }

    make_update_attrs_cmd (cmd);

    graphics()->reset_changed (GT_Common_Graphics::tag_type);
	
    string tags;
    make_tags_cmd (tags);
	
    cmd += string (" -tags {%s}", tags.cstring());

}


void GT_Tk_UIObject::make_move_cmd (
    const double x_move,
    const double y_move,
    string& cmd)
{	
    cmd = string (
	"%s move GT:%d %f %f",
	device()->name().cstring(),
	uid(),
	x_move,
	y_move);
}


void GT_Tk_UIObject::make_update_coords_cmd (string& command,
    bool may_move_or_scale)
{
    const GT_Common_Graphics* cg = graphics();
    const GT_Key type = cg->type();

    if (may_move_or_scale &&
	cg->old_center().w() >= GT_epsilon &&
	cg->old_center().h() >= GT_epsilon &&
	cg->center().w() >= GT_epsilon &&
	cg->center().h() >= GT_epsilon) {
	
	bool new_command_created = false;
	    
	double dx = cg->center().x() - cg->old_center().x();
	double dy = cg->center().y() - cg->old_center().y();
	
	if (fabs(dx) > GT_epsilon || fabs(dy) > GT_epsilon) {
	    command = string ("%s move GT:%d %f %f",
		device()->name().cstring(),
		uid(),
		dx,dy);
	    new_command_created = true;
	}

	double start_x = cg->center().x();
	double start_y = cg->center().y();
	double scale_x = cg->center().w() / cg->old_center().w();
	double scale_y = cg->center().h() / cg->old_center().h();
	
	if ((fabs(scale_x - 1.0) > GT_epsilon) ||
	    (fabs(scale_y - 1.0) > GT_epsilon)) {
	    
	    command = string ("\n%s scale GT:%d %f %f %f %f",
		device()->name().cstring(),
		uid(),
		start_x, start_y, scale_x, scale_y);
	    new_command_created = true;
	}

	if (!new_command_created) {
	    command = "";
	}
	    
    } else if (type == GT_Keys::type_arc) {
		
	vector vec(4);
	coords_box (cg->center(), vec);
		
	command += string (" %f %f %f %f ",
	    vec[0], vec[1], vec[2], vec[3]);
		
    } else if (type == GT_Keys::type_bitmap) {

	command += string (" %f %f ", cg->x(), cg->y());
		
    } else if (type == GT_Keys::type_image) {

	command += string (" %f %f ", cg->x(), cg->y());
		
    } else if (type == GT_Keys::type_line && cg->line().length() > 0) {
		
	GT_Point p;
	forall (p, cg->line()) {
	    command += string (" %f %f", p.xcoord(), p.ycoord());
	}
		
    } else if (type == GT_Keys::type_image) {
		
	command += string (" %f %f", cg->x(), cg->y());
		
    } else if (type == GT_Keys::type_oval) {

	vector vec(4);
	coords_box (cg->center(), vec);
		
	command += string (" %f %f %f %f ",
	    vec[0], vec[1], vec[2], vec[3]);

    } else if (type == GT_Keys::type_polygon) {

	vector vec(10);
	coords_diamond (cg->center(), vec);
		
	command += string (" %f %f %f %f %f %f %f %f %f %f ",
	    vec[0], vec[1], vec[2], vec[3], vec[4],
	    vec[5], vec[6], vec[7], vec[8], vec[9]);

    } else if (type == GT_Keys::type_text) {

	command += string (" %f %f ", cg->x(), cg->y());
		
    } else /* assume it behaves like a rectangle */ {

	vector vec(4);
	coords_box (cg->center(), vec);
	command += string (" %f %f %f %f ",
	    vec[0], vec[1],vec[2], vec[3]);
    }

    graphics()->reset_changed (GT_Common_Graphics::tag_geometry);
}



void GT_Tk_UIObject::make_update_attrs_cmd (string& command)
{
    GT_Common_Graphics* cg = graphics();
    string cmd;

    const GT_Key& type = cg->type();
    bool need_update = false;
	
    if (accepts (type, GT_Common_Graphics::tag_fill) &&
	cg->is_changed (GT_Common_Graphics::tag_fill)) {

	const GT_Key& fill = cg->fill();

	if (fill.active()) {

	    cmd += string (" -fill {%s}",
		fill.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_fill);
    }

    if (accepts (type, GT_Common_Graphics::tag_outline) &&
	cg->is_changed (GT_Common_Graphics::tag_outline)) {

	const GT_Key outline = cg->outline();
		
	if (outline.active()) {
		
	    cmd += string (" -outline {%s}",
		outline.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_outline);
    }

    if (accepts (type, GT_Common_Graphics::tag_stipple) &&
	cg->is_changed (GT_Common_Graphics::tag_stipple)) {

	const GT_Key stipple = cg->stipple();
		
	if (stipple.active()) {

	    cmd += string (" -stipple {%s}",
		stipple.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_stipple);
    }

    if (accepts (type, GT_Common_Graphics::tag_anchor) &&
	cg->is_changed (GT_Common_Graphics::tag_anchor)) {

	const GT_Key anchor = cg->anchor();

	if (cg->anchor().active()) {
		
	    cmd += string (" -anchor {%s}",
		anchor.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_anchor);
    }

    if (accepts (type, GT_Common_Graphics::tag_width) &&
	cg->is_changed (GT_Common_Graphics::tag_width)) {

	cmd += string (" -width %f", cg->width());
	need_update = true;

	cg->reset_changed (GT_Common_Graphics::tag_width);
    }

    if (accepts (type, GT_Common_Graphics::tag_extent) &&
	cg->is_changed (GT_Common_Graphics::tag_extent)) {

	cmd += string (" -extent %f", cg->extent());
	need_update = true;
		
	cg->reset_changed (GT_Common_Graphics::tag_extent);
    }


    if (accepts (type, GT_Common_Graphics::tag_start) &&
	cg->is_changed (GT_Common_Graphics::tag_start)) {
		
	cmd += string (" -start %f", cg->start());
	need_update = true;

	cg->reset_changed (GT_Common_Graphics::tag_start);
    }

    if (accepts (type, GT_Common_Graphics::tag_style) &&
	cg->is_changed (GT_Common_Graphics::tag_style)) {		

	const GT_Key style = cg->style();

	if (cg->style().active()) {
		
	    cmd += string (" -style {%s}",
		style.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_style);
    }
	
    if (accepts (type, GT_Common_Graphics::tag_foreground) &&
	cg->is_changed (GT_Common_Graphics::tag_foreground)) {
		
	const GT_Key foreground = cg->foreground();

	if (foreground.active()) {
		
	    cmd += string (" -foreground {%s}",
		foreground.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_foreground);
    }

    if (accepts (type, GT_Common_Graphics::tag_background) &&
	cg->is_changed (GT_Common_Graphics::tag_background)) {
		
	const GT_Key background = cg->background();

	if (background.active()) {
		
	    cmd += string (" -background {%s}",
		background.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_background);
    }

    if (accepts (type, GT_Common_Graphics::tag_bitmap) &&
	cg->is_changed (GT_Common_Graphics::tag_bitmap)) {
		
	const GT_Key bitmap = cg->bitmap();

	if (bitmap.active()) {
		
	    cmd += string (" -bitmap {%s}",
		bitmap.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_bitmap);
    }

    if (accepts (type, GT_Common_Graphics::tag_arrow) &&
	cg->is_changed (GT_Common_Graphics::tag_arrow)) {
		
	const GT_Key arrow = cg->arrow();

	if (arrow.active()) {
		
	    cmd += string (" -arrow {%s}",
		arrow.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_arrow);
    }
	
    if (accepts (type, GT_Common_Graphics::tag_arrowshape) &&
	cg->is_changed (GT_Common_Graphics::tag_arrowshape)) {
		
	const GT_Key arrowshape = cg->arrowshape();

	if (arrowshape.active()) {
		
	    cmd += string (" -arrowshape {%s}",
		arrowshape.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_arrowshape);
    }

    if (accepts (type, GT_Common_Graphics::tag_capstyle) &&
	cg->is_changed (GT_Common_Graphics::tag_capstyle)) {
		
	const GT_Key capstyle = cg->capstyle();

	if (capstyle.active()) {
		
	    cmd += string (" -capstyle {%s}",
		capstyle.name().cstring());
	    need_update = true;
	}
    }
	
    if (accepts (type, GT_Common_Graphics::tag_joinstyle) &&
	cg->is_changed (GT_Common_Graphics::tag_joinstyle)) {
		
	const GT_Key joinstyle = cg->joinstyle();

	if (joinstyle.active()) {
		
	    cmd += string (" -joinstyle {%s}",
		joinstyle.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_joinstyle);
    }

    if (accepts (type, GT_Common_Graphics::tag_image) &&
	cg->is_changed (GT_Common_Graphics::tag_image)) {
		
	const GT_Key image = cg->image();

	if (image.active()) {
		
	    cmd += string (" -image {%s}",
		image.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_image);
    }

    if (accepts (type, GT_Common_Graphics::tag_smooth) &&
	cg->is_changed (GT_Common_Graphics::tag_smooth)) {
		
	cmd += string (" -smooth %s", cg->smooth() ? "true" : "false");
	need_update = true;

	cg->reset_changed (GT_Common_Graphics::tag_smooth);
    }

    if (accepts (type, GT_Common_Graphics::tag_splinesteps) &&
	cg->is_changed (GT_Common_Graphics::tag_splinesteps)) {
		
	cmd += string (" -splinesteps %d", cg->splinesteps());
	need_update = true;

	cg->reset_changed (GT_Common_Graphics::tag_splinesteps);
    }


    if (accepts (type, GT_Common_Graphics::tag_justify) &&
	cg->is_changed (GT_Common_Graphics::tag_justify)) {
		
	const GT_Key justify = cg->justify();

	if (justify.active()) {
		
	    cmd += string (" -justify {%s}",
		justify.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_justify);
    }

    if (accepts (type, GT_Common_Graphics::tag_font) &&
	cg->is_changed (GT_Common_Graphics::tag_font)) {
		
	const GT_Key font = cg->font();

	if (font.active()) {
		
	    cmd += string (" -font {%s}",
		font.name().cstring());
	    need_update = true;
	}

	cg->reset_changed (GT_Common_Graphics::tag_font);
    }
	
    if (need_update) {
	command += cmd;
    }
}


void GT_Tk_UIObject::make_delete_cmd (string& cmd)
{
    cmd = string ("%s delete GT:%d",
	device()->name().cstring(),
	uid());
}


bool GT_Tk_UIObject::tcl_eval (const string& cmd)
{
    bool successful = true;
    //#define GT_DEBUG_TCL_EVAL
#ifdef GT_DEBUG_TCL_EVAL
    cout << "GT_Tk_UIObject::tcl_eval "
	 << '"' << cmd << '"'
	 << endl;
#endif
	
    if (cmd.length() > 0) {
		
	//
	// Must cast here since device points to a generic device
	//
	Tcl_Interp* interp = ((GT_Tcl_Device*)device())->
	    interp();

	int code = Tcl_Eval (interp, cmd.cstring());
	// 		int code = TCL_OK;
		
	if (code != TCL_OK) {
	    cerr << "==========================================" << endl;
	    cerr << "Tcl error " << code
		 << ", \"" << interp->result << "\" in drawing command "
		 << endl;
	    cerr << "GT_Tk_UIObject::tcl_eval "
		 << '"' << cmd << '"'
		 << endl;
	    cerr << "==========================================" << endl;
	}

	// 		cout << "GT_Tk_UIObject::tcl_eval result "
	// 			 << '"' << interp->result << '"'
	// 			 << endl;
	// 		cout << "GT_Tk_UIObject::tcl_eval code "
	// 			 << code
	// 			 << endl;
		
	successful = (code != TCL_ERROR);
    }

    return successful;
}


//////////////////////////////////////////
//
// Tk_UIObject Virtuals ovverides
//
//////////////////////////////////////////


//
// create
//

bool GT_Tk_UIObject::create ()
{
    string cmd;
    make_create_cmd (cmd);

    if (tcl_eval (cmd)) {

	//
	// Must cast here since device points to a generic device
	//
	Tcl_Interp* interp = ((GT_Tcl_Device*)device())->
	    interp();

	//
	// assume only one item here (needs extension !)
	//
		
	const int item = atoi (interp->result);
	the_tk_items.append (item);
	return true;
    }

    return false;
}


//
// move
//

bool GT_Tk_UIObject::move (const double move_x, const double move_y)
{
    string cmd;
    make_move_cmd (move_x, move_y, cmd);
    return tcl_eval (cmd);
}


//
// update
//

bool GT_Tk_UIObject::update ()
{
    const bool type_changed = graphics()->is_changed(
	GT_Common_Graphics::tag_type);
	
    if (!type_changed) {
	return update_coords() && update_attrs();
    } else {
	graphics()->reset ();
	return del() && create ();
    }
}


bool GT_Tk_UIObject::update_attrs ()
{
    string cmd;
    make_update_attrs_cmd (cmd);
    if (cmd != "") {
	cmd = string ("%s itemconfigure %d ", device()->name().cstring(),
	    the_tk_items.head()) + cmd;
    }
    return tcl_eval (cmd);
}


bool GT_Tk_UIObject::update_coords ()
{
    string cmd ("%s coords %d ", device()->name().cstring(),
	the_tk_items.head());
    make_update_coords_cmd (cmd, true);
    return tcl_eval (cmd);
}


//
// del
//

bool GT_Tk_UIObject::del ()
{
    string cmd;
	
    make_delete_cmd (cmd);
    the_tk_items.clear();
	
    return tcl_eval (cmd);
}


//////////////////////////////////////////
//
// raise
// lower
//
///////////////////////////////////////////

bool GT_Tk_UIObject::raise (const char* tag)
{
    string cmd = string ("%s raise GT:%d %s",
	device()->name().cstring(),
	uid(),
	tag == 0 ? "" : tag);

    return tcl_eval (cmd);
}


bool GT_Tk_UIObject::lower (const char* tag)
{
    string cmd = string ("%s lower GT:%d %s",
	device()->name().cstring(),
	uid(),
	tag == 0 ? "" : tag);

    return tcl_eval (cmd);
}

    

//
// Helpers
//


void GT_Tk_UIObject::coords_box (const GT_Rectangle& center,
    vector& vec)
{
    double x = center.x();
    double y = center.y();
    double w = center.w();
    double h = center.h();

    vec[0] = x - w/2;
    vec[1] = y - h/2;
    vec[2] = x + w/2;
    vec[3] = y + h/2;
}


void GT_Tk_UIObject::coords_diamond (const GT_Rectangle& center,
    vector& vec)
{    
    double x = center.x();
    double y = center.y();
    double w = center.w();
    double h = center.h();

    vec[0] = x;
    vec[1] = y - h/2;
    vec[2] = x + w/2;
    vec[3] = y;
    vec[4] = x;
    vec[5] = y + h/2;
    vec[6] = x - w/2;
    vec[7] = y;
    vec[8] = vec[0];
    vec[9] = vec[1];
}
