//
// Tk_UINode.cc
//
// This file implements the class GT_Tk_UINode.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tk_UINode.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:41:13 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Tcl_Graph.h"

// #include "GraphScript.h"
// #include "Tcl_Node.h"
#include "Tk_UINode.h"

#include <gt_base/Node_Attributes.h>


//////////////////////////////////////////
//
// Constructors and Destructors
//
//////////////////////////////////////////


GT_Tk_UINode::GT_Tk_UINode (const int uid,
    GT_Tcl_Device* const device,
    GT_UIObject* parent,
    GT_Graph* g,
    const node n) :
	GT_Tk_UIObject (uid, device, parent)
{
    the_g = g;
    the_n = n;
    graphics (g->gt(n).graphics());
}
		

GT_Tk_UINode::~GT_Tk_UINode ()
{
}


//////////////////////////////////////////
//
// type
//
//////////////////////////////////////////


const GT_Key& GT_Tk_UINode::type() const
{
    return GT_Keys::uiobject_node;
}



//////////////////////////////////////////
//
// make_node_cmd
//
//////////////////////////////////////////


void GT_Tk_UINode::make_create_cmd (string& cmd )
{
    baseclass::make_create_cmd (cmd);
}
