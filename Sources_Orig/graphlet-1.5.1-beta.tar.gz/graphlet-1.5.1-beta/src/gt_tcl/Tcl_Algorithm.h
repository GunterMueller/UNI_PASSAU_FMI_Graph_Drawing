#ifndef GT_TCL_ALGORITHM_H
#define GT_TCL_ALGORITHM_H

//
// Algorithm.h
//
// This file defines the class GT_Tcl_Algorithm.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl_Algorithm.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/06 08:41:35 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//


#include <gt_base/Algorithm.h>

#include "Tcl_Command.h"

class Tcl_Info;

class GT_Tcl_Algorithm_Command : public GT_Tcl_Command {

    GT_COMPLEX_VARIABLE (string, result);

    GT_VARIABLE (bool, reset_before_run);
    GT_VARIABLE (bool, might_change_structure);
    GT_VARIABLE (bool, might_change_coordinates);

public:
    
    GT_Tcl_Algorithm_Command (const string&  name);
    ~GT_Tcl_Algorithm_Command ();

    //
    // Argument parsing
    //
	
    virtual int algorithm_parser (GT_Tcl_info& info, int& index,
	GT_Algorithm& algorithm);
    virtual int parse (GT_Tcl_info& info, int& index,
	GT_Tcl_Graph* g);    
};



template<class Algorithm>
class GT_Tcl_Algorithm : public GT_Tcl_Algorithm_Command,
			 public Algorithm
{

public:

    //
    // Constructor and Destructor
    //
    GT_Tcl_Algorithm (const string&  name);
    ~GT_Tcl_Algorithm ();
    
    virtual int cmd_parser (GT_Tcl_info& info, int& index);
};


template<class Algorithm>
GT_Tcl_Algorithm<Algorithm>::GT_Tcl_Algorithm (const string& name) :
	GT_Tcl_Algorithm_Command (name),
	Algorithm (name)
{
}


template<class Algorithm>
GT_Tcl_Algorithm<Algorithm>::~GT_Tcl_Algorithm ()
{
}


//
// cmd_parser redefines GT_Tcl_Command::cmd_parser
//

template<class Algorithm>
int GT_Tcl_Algorithm<Algorithm>::cmd_parser (GT_Tcl_info& info, int& index)
{
    return GT_Tcl_Algorithm_Command::algorithm_parser (info, index, *this);
}


#endif
