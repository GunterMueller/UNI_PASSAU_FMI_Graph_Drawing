//
// Tcl.cc
//
// This file implements the class GT_Tcl.cc, an interface to Tcl.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_tcl/Tcl.cpp,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/04 08:46:16 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include <gt_base/Graphlet.h>
#include <gt_base/Graph.h>

#include "Tcl_Info.h"


GT_Tcl::GT_Tcl ()
{
    return;
}



GT_Tcl::~GT_Tcl ()
{

    return;
}


int GT_Tcl::format_value (string& formatted,
    const GT_Key& key,
    const int i,
    const Get_Mode mode)
{
    switch (mode) {
	case get :
	    formatted += string ("%d", i);
	    break;
	case configure:
	    formatted += string ("{ %s %d } ",
		key.name().cstring(), i);
	    break;
	default:
	    break;
    }

    return TCL_OK;
}


int GT_Tcl::format_value (string& formatted,
    const GT_Key& key,
    const bool b,
    const Get_Mode mode)
{
    switch (mode) {
	case get :
	    formatted += string ("%s", b == true ? "true" : "false");
	    break;
	case configure:
	    formatted += string ("{ %s %s } ",
		key.name().cstring(),  b == true ? "true" : "false");
	    break;
	default:
	    break;
    }

    return TCL_OK;
}


int GT_Tcl::format_value (string& formatted,
    const GT_Key& key,
    const double d,
    const Get_Mode mode)
{
    switch (mode) {
	case get :
	    formatted += string ("%g", d);
	    break;
	case configure:
	    formatted += string ("{ %s %f } ",
		key.name().cstring(),d);
	    break;
	default:
	    break;
    }

    return TCL_OK;
}


int GT_Tcl::format_value (string& formatted,
    const GT_Key& key,
    const string& s,
    const Get_Mode mode)
{
    switch (mode) {
	case get :
	    formatted += string ("%s",
		s.cstring());
	    break;
	case configure:
	    formatted += string ("{ %s %s } ",
		key.name().cstring(), s.cstring());
	    break;
	default:
	    break;
    }

    return TCL_OK;
}


int GT_Tcl::format_value (string& formatted,
    const GT_Key& key,
    const GT_Key& k,
    const Get_Mode mode)
{
    if (k.defined()) {
	switch (mode) {
	    case get :
		formatted += string ("%s",
		    k.name().cstring());
		break;
	    case configure:
		formatted += string ("{ %s %s } ",
		    key.name().cstring(),
		    k.name().cstring());
		break;
	    default:
		break;
	}
    }

    return TCL_OK;
}



//
// Convenient Wrappers for TCL Calls
//

char* GT_Tcl::SetVar2 (Tcl_Interp *interp,
    const string& array, const string& index,
    const string& new_value,
    int flags)
{
    char* value = Tcl_SetVar2 (interp,
	array.cstring(), index.cstring(), new_value.cstring(),
	flags);
    if (value == NULL) {
	string msg = string ("Cannot set ") + string (array) + string (index);
	Tcl_AddErrorInfo (interp, msg.cstring());
    }

    return value;
}



Tcl_Command GT_Tcl::CreateCommand (Tcl_Interp *interp,
    const string& name,
    Tcl_CmdProc* proc,
    void *client_data,
    Tcl_CmdDeleteProc* delete_proc)
{
    Tcl_Command cmd = Tcl_CreateCommand (interp,
	name.cstring(),
	proc,
	(ClientData)client_data,
	delete_proc);

    if (cmd == NULL) {
	string msg = string ("Cannot create command ") + string (name);
	Tcl_AddErrorInfo (interp, msg.cstring());		
    }

    return cmd;
}


//////////////////////////////////////////
//
// create the tcl representations of a graph/node/edge
//
//////////////////////////////////////////


string GT_Tcl::gt (const GT_Graph& g)
{
    return string ("GT:%d", g.gt().uid());
}

string GT_Tcl::gt (const GT_Graph& g, const node n)
{
    return string ("GT:%d", g.gt(n).uid());
}

string GT_Tcl::gt (const GT_Graph& g, const edge e)
{
    return string ("GT:%d", g.gt(e).uid());
}



//////////////////////////////////////////
//
// static string GT_Tcl::list_of_strings (const list<string>& strings)
// static void GT_Tcl::list_of_strings (const list<string>& strings,
//     string& result)
//
// Convert C++/LEDA list of strings to Tcl
//
//////////////////////////////////////////


void GT_Tcl::list_of_strings (const list<string>& strings,
    string& result)
{
    result = ("{ ");
    string s;
    forall (s, strings) {
	result += s + " "; 
    }
    result += "}";
}


string GT_Tcl::list_of_strings (const list<string>& strings)
{
    string result;
    list_of_strings (strings, result);
    return result;
}



//////////////////////////////////////////
//
// int GT_Tcl::get_int (GT_Tcl_info& info, const char* s, int& result)
// int GT_Tcl::get_double (GT_Tcl_info& info, const char* s, double& result);
// int GT_Tcl::get_boolean (GT_Tcl_info& info, const char* s, bool& result);
//
//////////////////////////////////////////


int GT_Tcl::get_int (GT_Tcl_info& info, const char* s, int& result)
{
    return Tcl_GetInt (info.interp(), (char*)s, &result);
}


int GT_Tcl::get_double (GT_Tcl_info& info, const char* s, double& result)
{
    return Tcl_GetDouble (info.interp(), (char*)s, &result);
}


int GT_Tcl::get_boolean (GT_Tcl_info& info, const char* s, bool& result)
{
    int i = 0;
    return Tcl_GetBoolean (info.interp(), (char*)s, &i);
    result = (i != 0);
}


int GT_Tcl::get_boolean (GT_Tcl_info& info, const char* s, int& result)
{
    return Tcl_GetBoolean (info.interp(), (char*)s, &result);
}
