//
// leda_algorithms.cc
//
// This file implements several LEDA Algorithms for use in GraphScript.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/leda_algorithms.cpp,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/06 08:41:13 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

#include <gt_base/Graphlet.h>
#include <gt_base/Graph.h>

#include <gt_tcl/Tcl_Algorithm.h>
#include <gt_tcl/Tcl_Graph.h>

#include "leda_algorithms.h"
#include "LEDA/graph_alg.h"


//////////////////////////////////////////
//
// class GT_Planarity_Test_Algorithm
//
//////////////////////////////////////////


GT_Planarity_Test_Algorithm::GT_Planarity_Test_Algorithm (const string& name) :
	GT_Algorithm (name)
{
    the_is_planar = false;
    the_self_loop = 0;
}


int GT_Planarity_Test_Algorithm::run (GT_Graph& g)
{
    graph leda = g.leda();

    is_planar (PLANAR(leda));
    
    return GT_OK;
}
	

int GT_Planarity_Test_Algorithm::check (GT_Graph& g, string& message)
{
    if (GT_Algorithm::find_self_loop(g)) {
	message = "graph contains self loop";
	return GT_ERROR;
    } else {
	message = "";
	return GT_OK;
    }
}


//////////////////////////////////////////
//
// GT_Tcl_Planarity_Test_Algorithm
//
//////////////////////////////////////////


GT_Tcl_Planarity_Test_Algorithm::GT_Tcl_Planarity_Test_Algorithm (
    const string& name) :
	GT_Tcl_Algorithm<GT_Planarity_Test_Algorithm> (name)
{
    reset_before_run (true);
    might_change_structure (false);
    might_change_coordinates (false);
}


GT_Tcl_Planarity_Test_Algorithm::~GT_Tcl_Planarity_Test_Algorithm ()
{
}


//
// parse
//

int GT_Tcl_Planarity_Test_Algorithm::parse (GT_Tcl_info& info, int& index,
    GT_Tcl_Graph* /* g */)
{
    info.msg (string ("Illegal Argument: %s", info[index]));
    return GT_ERROR;
}


//
// run
//

int GT_Tcl_Planarity_Test_Algorithm::run (GT_Graph& g)
{
    GT_Planarity_Test_Algorithm::run (g);

    if (is_planar()) {
	result ("1");
    } else {
	result ("0");
    }
    
    return GT_OK;
}


int GT_Tcl_Planarity_Test_Algorithm::check (GT_Graph& g, string& message)
{
    int code = GT_Planarity_Test_Algorithm::check (g, message);
    
    if (code == GT_ERROR) {
	assert (self_loop() != nil);
	result (GT_Tcl::gt (g, self_loop()));
    } else {
	assert (self_loop() == nil);
	result ("");
    }

    return code;
}

