//
// sample_cmd.cc
//
// This file implements a sample tcl command.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/sample_cmd.cpp,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/09 18:28:32 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

#include <gt_base/Graphlet.h>

#include <gt_tcl/Tcl_Graph.h>
#include <gt_tcl/Tcl_Algorithm.h>

#include "sample_cmd.h"


//////////////////////////////////////////
//
// class GT_Tcl_Sample_Command
//
// This is a sample tcl command which does nothing.
//
//////////////////////////////////////////


//
// This is the constructor for class GT_Tcl_Sample_Command.
//

GT_Tcl_Sample_Command::GT_Tcl_Sample_Command (
    const string& name) :
	GT_Tcl_Command (name, GT::keymapper.add (name))
{
    // No construction neccessary
}



//
// This is the destructor for class GT_Tcl_Sample_Command.
//

GT_Tcl_Sample_Command::~GT_Tcl_Sample_Command ()
{
    // No destruction neccessary
}



//
// The procedure parse is used for command line parsing.
//


int GT_Tcl_Sample_Command::cmd_parser (GT_Tcl_info& info, int& index)
{
    if (info.exists (index)) {
		
	// No parameters allowed
	info.msg (string ("Illegal parameter: %s", info.argv(index)));

	// Advance the index
	index ++;

	// Signal an error
	return TCL_ERROR;
		
    } else {

	//
	// This command does nothing.
	//
		
	return TCL_OK;
    }
}
