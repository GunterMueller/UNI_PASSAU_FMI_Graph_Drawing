//
// cfr_layout.cpp
//
// This is the implementation of the main-methods of the class
// FR_Constraint_Graph, which allows to layout a graph using an
// enhanced Fruchterman Reingold springembedder algorithm to
// layout a graph. Labels are interpreted as constraints.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/cfr_layout/cfr_layout.cpp,v $
// $Author: schirmer $
// $Revision: 1.3 $
// $Date: 1996/11/06 15:58:56 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#include <gt_base/Graph.h>

#include <math.h>

#include "cfr_layout.h"
#include "cfr_io.h"	


FR_Constraint_Graph::FR_Constraint_Graph(const GT_Graph gt_graph)
{
	this->the_graph = gt_graph;
	
	this->the_repulsive_factor.init(this->the_graph.leda(), 1);

	this->has_repulsive_factors(false);
}


FR_Constraint_Graph::~FR_Constraint_Graph()
{
	node n;

	forall (n, this->the_x_representative) {
		delete this->the_x_constraint[n];
	}

	forall (n, this->the_y_representative) {
		delete this->the_y_constraint[n];
	}
}


void FR_Constraint_Graph::reduce_constraints(
	node_array<FR_One_Dimensional_Constraint*>& constraint,
	list<node>& representative)
{
	node n;
	set<FR_One_Dimensional_Constraint*> empty_set;
	
	forall (n, representative) {
		constraint[n]->comp_num(0);
	}

	forall (n, representative) {
		if (constraint[n]->upper_constraints().empty())
		{
			constraint[n]->comp_num(-1);
			constraint[n]->reduce_dependants(empty_set);
		}
	}

	forall (n, representative) {
		constraint[n]->final_cut();
	}
}


void FR_Constraint_Graph::order_nodes(
	node_array<FR_One_Dimensional_Constraint*>& constraint,
	list<node>& representative,
	const double pitch)
{
	node n;

	forall (n, representative) {
		constraint[n]->comp_num(0);
	}
	
	forall (n, representative) {
		if (constraint[n]->upper_constraints().empty())
		{
			if (!(constraint[n]->lower_constraints().empty()))
			{
				constraint[n]->order_dependants(HUGE, pitch);
			}
		}
	}
}


void FR_Constraint_Graph::opposite_pair_heuristic(
	const node_array<FR_One_Dimensional_Constraint*>& constraint,
	const list<Pair_of_Nodes>& opposite_pairs,
	const double optimal_distance)
{
	Pair_of_Nodes pair;

	const double max_distance = 3 * optimal_distance;

	static int lock;
	
	forall (pair, opposite_pairs) {
		double delta_old = constraint[pair.node1()]->coord() -
			constraint[pair.node2()]->coord();

 		if (fabs(delta_old) < max_distance)
 		{
			double displacement_node1 =
				constraint[pair.node1()]->displacement();
				
			double displacement_node2 =
				constraint[pair.node2()]->displacement();				;
				
			double delta_new = delta_old + displacement_node1 -
				displacement_node2;

			if((fabs(delta_new) > (2 * fabs(delta_old))) &&
				(((delta_old < 0) && (delta_new > 0)) ||
					((delta_old > 0) && (delta_new < 0))))
			{
				if(--lock<=0)
				{
					lock = 4*this->has_opposite_pairs()-1;
					
 					double swap = constraint[pair.node2()]->coord();
 					constraint[pair.node2()]->coord(
 						constraint[pair.node1()]->coord());
 					constraint[pair.node1()]->coord(swap);
				
 					constraint[pair.node1()]->displacement(0);
 					constraint[pair.node2()]->displacement(0);
				}
			}
 		}	
	}
}


void FR_Constraint_Graph::calculate_repulsive_displacement(
	const double optimal_distance, const bool use_the_repulsive_factor)
{
	node n1, n2;

	double optimal_distance_2 = optimal_distance * optimal_distance;
        
	forall_nodes (n1, this->the_graph.leda()) {
		for (n2 = this->the_graph.leda().succ_node(n1);
			 n2 != nil;
			 n2 = this->the_graph.leda().succ_node(n2))
		{
			double scale = 1;

			if (use_the_repulsive_factor)
			{
				scale = this->the_repulsive_factor(n1, n2);
			}
                                
			if (scale)
			{
				double dx =
					this->the_x_constraint[n1]->coord() -
					this->the_x_constraint[n2]->coord();
				double dy =
					this->the_y_constraint[n1]->coord() -
					this->the_y_constraint[n2]->coord();
							
				double length_2 =  dx * dx + dy * dy;
							
				if (length_2)
				{
					scale *= optimal_distance_2 / length_2;
								
					dx *= scale;
					dy *= scale;
				}
				else
				{
					dx = rand();
					dy = rand();
				}
				this->the_x_constraint[n1]->add_displacement(dx);
				this->the_x_constraint[n2]->add_displacement(-dx);
				this->the_y_constraint[n1]->add_displacement(dy);
				this->the_y_constraint[n2]->add_displacement(-dy);
			}
		}
	}
}


void FR_Constraint_Graph::calculate_attractive_displacement(
	const double optimal_distance)
{
	edge e;
	
	forall (e, this->the_edges) {
		node n1 = the_graph.leda().source(e);
		node n2 = the_graph.leda().target(e);
		
		double dx = this->the_x_constraint[n1]->coord() -
			this->the_x_constraint[n2]->coord();
		double dy = this->the_y_constraint[n1]->coord() -
			this->the_y_constraint[n2]->coord();
			
		double length = hypot(dx, dy) / optimal_distance;

		dx *= length;
		dy *= length;
			
		this->the_x_constraint[n1]->add_displacement(-dx);
		this->the_y_constraint[n1]->add_displacement(-dy);
		this->the_x_constraint[n2]->add_displacement(dx);
		this->the_y_constraint[n2]->add_displacement(dy);
	}
}


void FR_Constraint_Graph::calculate_length_constraint_displacement()
{
	list<edge> group_list;

	forall (group_list, this->the_lengths_constraints) {

		edge e;
		double avg_length = 0;
		
		forall (e, group_list) {
			node n1 = this->the_graph.leda().source(e);
			node n2 = this->the_graph.leda().target(e);
		
			double dx = this->the_x_constraint[n1]->coord() -
				this->the_x_constraint[n2]->coord();
			double dy = this->the_y_constraint[n1]->coord() -
				this->the_y_constraint[n2]->coord();
			
			avg_length += hypot(dx, dy);
		}

		avg_length /= group_list.length();
		
		forall (e, group_list) {
			node n1 = this->the_graph.leda().source(e);
			node n2 = this->the_graph.leda().target(e);
		
			double dx = this->the_x_constraint[n1]->coord() -
				this->the_x_constraint[n2]->coord();
			double dy = this->the_y_constraint[n1]->coord() -
				this->the_y_constraint[n2]->coord();
			
			double length = hypot(dx, dy);
 			double force = (length - avg_length) / 3;

			dx *= force;
			dy *= force;

			this->the_x_constraint[n1]->add_displacement(-dx);
			this->the_y_constraint[n1]->add_displacement(-dy);
			this->the_x_constraint[n2]->add_displacement(dx);
			this->the_y_constraint[n2]->add_displacement(dy);	
		}
	}
}


void FR_Constraint_Graph::calculate_constraint_displacement(
	const double optimal_distance, const double pitch)
{
	node n;

	forall (n, this->the_x_representative) {
		this->the_x_constraint[n]->calculate_constraint_displacement(
			optimal_distance, pitch);
	}

	forall (n, this->the_y_representative) {
		this->the_y_constraint[n]->calculate_constraint_displacement(
			optimal_distance, pitch);
	}
}


void FR_Constraint_Graph::limit_displacement(
	double &max_force, double damp)
{
	node n;
	node_array<double> limit_force(this->the_graph.leda(), 1.0);

	max_force = 0;
	
	forall_nodes (n, this->the_graph.leda()) {

		double length = hypot(this->the_x_constraint[n]->displacement(),
			this->the_y_constraint[n]->displacement());
		
		if (length > max_force) max_force = length;
		
		double limit = 1 / damp / sqrt(length);
		
		if (limit < limit_force[n]) limit_force[n] = limit;
	}

	forall (n, this->the_x_representative) {
		double dx = this->the_x_constraint[n]->displacement();
		this->the_x_constraint[n]->displacement(dx * limit_force[n]);
	}

	forall (n, this->the_y_representative) {
		double dy = this->the_y_constraint[n]->displacement();
		this->the_y_constraint[n]->displacement(dy * limit_force[n]);
	}
}


void FR_Constraint_Graph::constraint_displace_nodes(const double pitch)
{
	node n;

	forall (n, this->the_x_representative) {
		this->the_x_constraint[n]->constraint_displace(pitch);
	}
	forall (n, this->the_y_representative) {
		this->the_y_constraint[n]->constraint_displace(pitch);
	}
}


void FR_Constraint_Graph::unconstraint_displace_nodes()
{
	node n;

	forall (n, this->the_x_representative) {
		this->the_x_constraint[n]->unconstraint_displace();
	}
	forall (n, this->the_y_representative) {
		this->the_y_constraint[n]->unconstraint_displace();
	}	
}


void FR_Constraint_Graph::group_initialization()
{
	int range_x = 0, range_y = 0;

	if (this->random_placement())
	{
		range_x = this->window_width();
		range_y = this->window_height();
	}

	this->init_group_constraints(
		this->the_x_constraint, this->the_x_representative, 'x', "x", range_x);
	this->init_group_constraints(
		this->the_y_constraint, this->the_y_representative, 'y', "y", range_y);
}


void FR_Constraint_Graph::force_directed_placement()
{
	double optimal_distance = this->optimal_distance();
	double pitch = this->minimal_distance();
	const int width = this->window_width();
	const int height = this->window_height();
	
	int iteration = 0, phase_iteration = 0, phase = 0;
	double force_4 = 0.0, force_3 = 0.0, force_2 = 0.0, force_1 = 0.0;
	double ratio_1, ratio_2;
	double damp = this->phase_damping[0];
	bool fit_graph = false;
	
	const int num_nodes = this->the_graph.leda().number_of_nodes();
	const int num_edges = this->the_graph.leda().number_of_edges();


	if (optimal_distance <= 0)
	{
 		optimal_distance = ((double)num_edges / (double)num_nodes) *
 			sqrt((double)width * (double)height / (double)num_nodes) / 3;
 		fit_graph = true;

		if(optimal_distance > 300)
		{
			optimal_distance = 300;
		}
	}
	
	if (pitch <= 0)
	{
		pitch = optimal_distance / 2;
	}
	else
	{
		fit_graph = false;
	}

	this->set_group_repulsive_factors(this->the_x_constraint, 'x');
	this->set_group_repulsive_factors(this->the_y_constraint, 'y');

	bool use_the_repulsive_factor = this->has_repulsive_factors();

	this->has_opposite_pairs(
		this->the_x_opposite_pairs.length() +
		this->the_y_opposite_pairs.length());
	
	
	this->read_lengths_constraints();

 	this->reduce_constraints(this->the_x_constraint,
 		this->the_x_representative);

 	this->reduce_constraints(this->the_y_constraint,
 		this->the_y_representative);

	this->order_nodes(this->the_x_constraint, this->the_x_representative,
		pitch);
	this->order_nodes(this->the_y_constraint, this->the_y_representative,
		pitch);

	while (phase < MAX_PHASE)
	{
		phase_iteration++;
		
		this->calculate_attractive_displacement(optimal_distance);

		if ((this->constraint_forces()) &&
			(this->has_geometric_constraints()))
		{
			this->calculate_constraint_displacement(
				optimal_distance, pitch);
		}

 		if ((phase == 0) && (this->has_opposite_pairs()))
 		{
 			this->opposite_pair_heuristic(the_y_constraint,
 				the_x_opposite_pairs, optimal_distance);
 			this->opposite_pair_heuristic(the_x_constraint,
 				the_y_opposite_pairs, optimal_distance);
 		}

		this->calculate_repulsive_displacement(
			optimal_distance, use_the_repulsive_factor);
		
		if ((phase > 1) && (this->has_lengths_constraints()))
		{
			this->calculate_length_constraint_displacement();
		}
		
		force_4 = force_3;
		force_3 = force_2;
		force_2 = force_1;
			
		this->limit_displacement(force_1, damp);

 		if (this->has_geometric_constraints())
 		{
 			this->constraint_displace_nodes(pitch);
 		}
 		else
 		{
 			this->unconstraint_displace_nodes();
 		}
			
		if (force_1)
		{
			ratio_1 = fabs((force_1 - force_3) / force_1);
		}
		else
		{
			ratio_1 = 0;
		}

		if (force_2)
		{
			ratio_2 = fabs((force_2 - force_4) / force_2);
		}
		else
		{
			ratio_2 = 0;
		}

		if ((phase_iteration >= this->max_iteration[phase]) ||
			((force_4 != 0.0) &&
				(ratio_1 < this->vibration_ratio()) &&
				(ratio_2 < this->vibration_ratio())))
		{
			if ((phase == 0) && (!this->has_opposite_pairs()))
			{
				phase++;
			}
			
			iteration += phase_iteration;
			phase_iteration = 0;
			
			force_4 = force_3 = force_2 = force_1 = 0;
			
			damp = this->phase_damping[++phase];			
			if (phase >= 2)
			{
				use_the_repulsive_factor = false;
			}
		}
	}

	if (this->colour_the_nodes())
	{
		this->calculate_attractive_displacement(optimal_distance);
		if ((this->constraint_forces()) &&
			(this->has_geometric_constraints()))
		{
			this->calculate_constraint_displacement(
				optimal_distance, pitch);
		}
		
		this->calculate_repulsive_displacement(
			optimal_distance, use_the_repulsive_factor);
		
		if (this->has_lengths_constraints())
		{
			this->calculate_length_constraint_displacement();
		}
		this->colour_nodes();
	}

	this->fit_graph_to_window(width, height, 15, fit_graph);
	
	this->update_gt_properties();
}



