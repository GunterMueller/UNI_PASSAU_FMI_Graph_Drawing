//
// cfr_layout.h
//
// Definitons of the class FR_Constraint_Graph.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/cfr_layout/cfr_layout.h,v $
// $Author: schirmer $
// $Revision: 1.3 $
// $Date: 1996/11/06 15:58:56 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#include <LEDA/list.h>
#include <LEDA/set.h>
#include <LEDA/node_matrix.h>

#include "cfr_one_dimension.h"


#define MAX_PHASE 3

inline void Read(class Pair_of_Nodes &, class istream &) {}

class Pair_of_Nodes
{
	GT_VARIABLE (node, node1);
	GT_VARIABLE (node, node2);
  public:
	Pair_of_Nodes() {};
	Pair_of_Nodes(node node1, node node2)
		{
			this->the_node1 = node1;
			this->the_node2 = node2;
		}
	virtual ~Pair_of_Nodes() {}
};


class FR_Constraint_Graph
{
  private:
	GT_VARIABLE (double, optimal_distance);
	GT_VARIABLE (double, minimal_distance);
	GT_VARIABLE (bool, constraint_forces);
	GT_VARIABLE (bool, colour_the_nodes);
	GT_VARIABLE (double, vibration_ratio);
	GT_VARIABLE (int, window_width);
	GT_VARIABLE (int, window_height);
	GT_VARIABLE (bool, random_placement);
	GT_VARIABLE (bool, default_constraint);
	
	GT_VARIABLE (bool, has_geometric_constraints);
	GT_VARIABLE (bool, has_lengths_constraints);
	GT_VARIABLE (bool, has_group_constraints);
	GT_VARIABLE (int, has_opposite_pairs);
	GT_VARIABLE (bool, has_repulsive_factors);
	
	GT_Graph the_graph;

	node_array<FR_One_Dimensional_Constraint*> the_x_constraint;
	node_array<FR_One_Dimensional_Constraint*> the_y_constraint;

 	list<edge> the_hidden_edges; 
 	list<edge> the_edges; 

	node_matrix<double> the_repulsive_factor;
		
	list < list<edge> > the_lengths_constraints;
	
	list <node> the_x_representative;
	list <node> the_y_representative;

	list <Pair_of_Nodes> the_x_opposite_pairs;
	list <Pair_of_Nodes> the_y_opposite_pairs;

	int max_iteration[MAX_PHASE];
	double phase_damping[MAX_PHASE];
	
//
//		private methods (alphabetical order)
//
		   
	void calculate_attractive_displacement(const double optimal_distance);
	void calculate_constraint_displacement(const double optimal_distance,
		const double pitch);
	void calculate_length_constraint_displacement();
	void calculate_repulsive_displacement(const double optimal_distance,
		const bool use_the_repulsive_factor);
	void colour_nodes();
	void constraint_displace_nodes(const double pitch);
	void count_constraints();
	void fit_graph_to_window(const int width, const int height,
		const int margin, bool do_scale);
	void group_initialization();
	void init_group_constraints(
		node_array<FR_One_Dimensional_Constraint*>& constraint,
        list<node>& representative,
		const char dimension,
		const string group_identifier,
		int random_coords);
	void limit_displacement(double &max_force, double damp);
	void make_readable_labels();
	void notify_errors(
		const node_array<FR_One_Dimensional_Constraint*>& constraint);
	void opposite_pair_heuristic(
		const node_array<FR_One_Dimensional_Constraint*>& constraint,
		const list<Pair_of_Nodes>& opposite_pairs,
		const double optimal_distance);
	void order_nodes(
		node_array<FR_One_Dimensional_Constraint*>& constraint,
		list<node>& representative,
		const double pitch);
	string parse_node_constraints(const string original,
		const bool source_node);
	void read_constraints();
	string read_label(const edge e);
	void read_lengths_constraints();
	void reduce_constraints(
		node_array<FR_One_Dimensional_Constraint*>& constraint,
		list<node>& representative);
	string remove_comment(const string original);
	void set_group_repulsive_factors(
		const node_array<FR_One_Dimensional_Constraint*>& constraint,
		const char dimension);
	void unconstraint_displace_nodes();
	void update_gt_properties();

//
//		public methods
//	
	
  public:
	FR_Constraint_Graph(const GT_Graph gt_graph);
	virtual ~FR_Constraint_Graph();
	string check();
	void force_directed_placement();
 	list<edge>& edges() 
 		{ return this->the_edges; }
	list< list<edge> >& lengths_constraints()
		{ return this->the_lengths_constraints; }
	void set_parameters(double optimal_distance, double minimal_distance,
		bool extra_forces, int phase1_max, int phase2_max, int phase3_max,
		double phase1_damping, double phase2_damping, double phase3_damping,
		double vibration_ratio, bool colour_the_nodes, int width, int height,
		int random, bool default_mode); 
	void create_subgraph();
};









