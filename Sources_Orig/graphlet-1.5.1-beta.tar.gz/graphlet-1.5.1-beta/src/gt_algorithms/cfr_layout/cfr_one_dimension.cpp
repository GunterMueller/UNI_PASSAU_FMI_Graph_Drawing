//
// cfr_one_dimension.cpp
//
// This is the implementation of the class FR_One_Dimensional_Constraint,
// which is used to build groups of nodes with the same coordinate
// in one dimension.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/cfr_layout/cfr_one_dimension.cpp,v $
// $Author: schirmer $
// $Revision: 1.2 $
// $Date: 1996/11/03 12:23:05 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#include <gt_base/Graph.h>
#include <LEDA/node_partition.h>
#include <math.h>

#include "cfr_one_dimension.h"

//
// FR_One_Dimensional_Constraint
//

FR_One_Dimensional_Constraint::FR_One_Dimensional_Constraint(
	const double coord)
{
	this->the_coord = coord;
	this->the_displacement = 0;
	this->the_group_count = 1;
}


void FR_One_Dimensional_Constraint::add_member(const double coord)
{
	double new_coord;
	
	new_coord = this->the_coord * this->the_group_count;
	new_coord += coord;
	this->the_group_count++;
	this->the_coord = new_coord / this->the_group_count;
}


bool FR_One_Dimensional_Constraint::has_constraints()
{
	if (this->the_group_count > 1)
	{
		return true;
	}
	
	if ((this->the_upper_constraints.empty() == false) ||
		(this->the_lower_constraints.empty() == false))
	{
		return true;
	}
	else
	{
		return false;
	}
}


void FR_One_Dimensional_Constraint::constraint_displace(const double pitch)
{
 	double up = HUGE, down = -HUGE;
	
 	FR_One_Dimensional_Constraint* constraint;

	double new_coord = this->the_coord + this->the_displacement;
	
	if(this->the_displacement > 0)
	{
		forall (constraint, this->the_upper_constraints) {
			if (constraint->coord() < up)
			{
				up = constraint->coord();
			}
		}
		if ((up - pitch)  < new_coord)
			new_coord = up - pitch;
	}
	else
	{
		forall (constraint, this->the_lower_constraints) {
			if (constraint->coord() > down)
			{
				down = constraint->coord();
			}
		}
		if ((down + pitch) > new_coord)
			new_coord = down + pitch;
	}
	
 	this->the_coord = new_coord;
 	this->the_displacement = 0;
}


void FR_One_Dimensional_Constraint::order_dependants(
	double coord, const double pitch)
{
	FR_One_Dimensional_Constraint* constraint;

	this->the_comp_num++;
	
	if (this->coord() > coord)
	{
		this->coord(coord);
	}
	else
	{
		coord = this->coord();
	}

	//
	// You might think the next >= should be a == 
	// BUT the '>' is needed for the top nodes.
	// 
	
	if (this->the_comp_num >= this->the_upper_constraints.size())
	{
		forall (constraint, this->lower_constraints()) {
			constraint->order_dependants(coord - pitch, pitch);
		}
	}
}


void FR_One_Dimensional_Constraint::add_upper_constraint(
	FR_One_Dimensional_Constraint* constraint)
{
	this->the_upper_constraints.insert(constraint);
	constraint->the_lower_constraints.insert(this);
}


void FR_One_Dimensional_Constraint::del_upper_constraint(
	FR_One_Dimensional_Constraint* constraint)
{
	this->the_upper_constraints.del(constraint);
	constraint->the_lower_constraints.del(this);
}


void FR_One_Dimensional_Constraint::add_lower_constraint(
	FR_One_Dimensional_Constraint* constraint)
{
	this->the_lower_constraints.insert(constraint);
	constraint->the_upper_constraints.insert(this);
}


void FR_One_Dimensional_Constraint::del_lower_constraint(
	FR_One_Dimensional_Constraint* constraint)
{
	this->the_lower_constraints.del(constraint);
	constraint->the_upper_constraints.del(this);
}


void FR_One_Dimensional_Constraint::calculate_constraint_displacement(
const double optimal_distance, const double pitch)
{
	FR_One_Dimensional_Constraint* constraint;

	forall (constraint, this->the_upper_constraints) {

		//
		// distance is always > 0, since this is a upper constraint 
		//

		double distance = constraint->coord() - this->the_coord - pitch + 1;

		double displacement = optimal_distance / distance;
		constraint->add_displacement(displacement);
		this->add_displacement(-displacement);
	}
}


void FR_One_Dimensional_Constraint::final_cut()
{
	FR_One_Dimensional_Constraint* constraint;

	set<FR_One_Dimensional_Constraint*> intersect =
		this->the_upper_constraints & this->the_all_upper_constraints;
	
	forall (constraint, intersect) {
		this->del_upper_constraint(constraint);
	}
}


void FR_One_Dimensional_Constraint::reduce_dependants(
	const set<FR_One_Dimensional_Constraint*>& global_upper)
{
	FR_One_Dimensional_Constraint* constraint;

	this->the_all_upper_constraints += global_upper;
	this->the_comp_num++;

	if (this->the_comp_num == this->the_upper_constraints.size())
	{
		set<FR_One_Dimensional_Constraint*> new_upper =
 			this->the_all_upper_constraints + this->the_upper_constraints;
		
 		forall (constraint, this->the_lower_constraints) {
			constraint->reduce_dependants(new_upper);
		}
	}
}


bool FR_One_Dimensional_Constraint::self_loop()
{
	if (this->the_upper_constraints.member(this))
	{
		return true;
	}
	else
	{
		return false;
	}
}


void FR_One_Dimensional_Constraint::check_dfs(
	int& check_dfs_num, int& check_comp_num, bool& cycle, bool& loop)
{
	FR_One_Dimensional_Constraint* constraint;

	forall (constraint, this->the_lower_constraints) {
		if(constraint == this)
		{
			this->group_count(ERR_LOOP);
			loop = true;
		}

		if (constraint->dfs_num() == UNMARKED)
		{
			constraint->dfs_num(++check_dfs_num);
			constraint->check_dfs(check_dfs_num, check_comp_num,
				cycle, loop);
			constraint->comp_num(++check_comp_num);
		}
		else
		{
			if ((this->dfs_num() > constraint->dfs_num()) &&
				(this->comp_num() >= constraint->comp_num()))
			{
				if(constraint->group_count() != ERR_LOOP)
				{
					constraint->group_count(ERR_CYCLE);
					cycle = true;
				}
			}
		}
	}
}





