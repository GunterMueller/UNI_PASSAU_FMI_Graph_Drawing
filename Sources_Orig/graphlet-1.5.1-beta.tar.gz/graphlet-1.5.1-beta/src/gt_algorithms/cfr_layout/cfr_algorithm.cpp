//
// cfr_algorithm.cpp
//
// This implements the class
// GT_Layout_Constraint_Fruchterman_Reingold_Algorithm
// which is the interface to the Constraint Fruchterman
// Reingold Layout Algorithm.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/cfr_layout/cfr_algorithm.cpp,v $
// $Author: schirmer $
// $Revision: 1.3 $
// $Date: 1996/11/06 15:58:54 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//


#include <gt_base/Graph.h>
#include <gt_tcl/Tcl_Algorithm.h>

#include <sys/times.h>

#include "cfr_layout.h"
#include "cfr_algorithm.h"


GT_Layout_Constraint_Fruchterman_Reingold_Algorithm::
GT_Layout_Constraint_Fruchterman_Reingold_Algorithm(const string& name)
	:GT_Algorithm (name)
{
	//
	// Some reasonable defaults. It might happen that
	// the Algorithm isn't called with all parameters.
	//
	this->optimal_distance(0);
	this->pitch(0);
	this->constraint_forces(false);
	this->phase1_max_iteration(300);
	this->phase2_max_iteration(300);
	this->phase3_max_iteration(300);
	this->phase1_damping(2);
	this->phase2_damping(4);
	this->phase3_damping(15);
	this->vibration_ratio(0.001);
	this->colour_nodes(false);
	this->window_width(640);
	this->window_height(480);
	this->random_placement(0);
	this->default_constraint(true);
}


int GT_Layout_Constraint_Fruchterman_Reingold_Algorithm::run(
	GT_Graph &g)
{
	FR_Constraint_Graph fr_constraint_graph(g);

	fr_constraint_graph.set_parameters(
		this->optimal_distance(),
		this->pitch(),
		this->constraint_forces(),
		this->phase1_max_iteration(),
		this->phase2_max_iteration(),
		this->phase3_max_iteration(),
		this->phase1_damping(),
		this->phase2_damping(),
		this->phase3_damping(),
		this->vibration_ratio(),
		this->colour_nodes(),
		this->window_width(),
		this->window_height(),
		this->random_placement(),
		this->default_constraint()
		);

	fr_constraint_graph.group_initialization();
	fr_constraint_graph.read_constraints();
	fr_constraint_graph.force_directed_placement();

	return GT_OK;
}


int GT_Layout_Constraint_Fruchterman_Reingold_Algorithm::
check (GT_Graph& /* g */, string& /* message */)
{
//  The check can only be done after the initilization
//  of the constraints. Additionally the errors should
//  be shown in the graph so we have to make the real
//  check later.  	
	
	return GT_OK;
}


GT_Tcl_Layout_Constraint_Fruchterman_Reingold_Algorithm::
GT_Tcl_Layout_Constraint_Fruchterman_Reingold_Algorithm (
 	const string& name) :
		GT_Tcl_Algorithm<GT_Layout_Constraint_Fruchterman_Reingold_Algorithm> (name)
{
}


int GT_Tcl_Layout_Constraint_Fruchterman_Reingold_Algorithm::parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* /* g */)
{
	int code = TCL_OK;
	int int_value;
	double double_value;

	if(info.argv(index)[0] == '-')
	{
		if(!strcmp(info.argv(index),"-optimal_distance"))
		{
			code = Tcl_GetInt (info.interp(),
				info.argv(++index), &int_value);
			if (code != TCL_OK) {
				return code;
			}
			this->optimal_distance(int_value);
		}
		else if(!strcmp(info.argv(index),"-constraint_pitch"))
		{
			code = Tcl_GetInt (info.interp(),
				info.argv(++index), &int_value);
			if (code != TCL_OK) {
				return code;
			}
			this->pitch(int_value);
		}
		else if(!strcmp(info.argv(index),"-constraint_forces"))
		{
			code = Tcl_GetBoolean (info.interp(),
				info.argv(++index), &int_value);
			if (code != TCL_OK) {
				return code;
			}
				
			if (int_value)
			{
				this->constraint_forces(true);
			}
			else
			{
				this->constraint_forces(false);
			}
		}
		else if(!strcmp(info.argv(index),"-iteration1"))
		{
			code = Tcl_GetInt (info.interp(),
				info.argv(++index), &int_value);
			if (code != TCL_OK) {
				return code;
			}
			this->phase1_max_iteration(int_value);
		}
		else if(!strcmp(info.argv(index),"-iteration2"))
		{
			code = Tcl_GetInt (info.interp(),
				info.argv(++index), &int_value);
			if (code != TCL_OK) {
				return code;
			}
			this->phase2_max_iteration(int_value);
		}
		else if(!strcmp(info.argv(index),"-iteration3"))
		{
			code = Tcl_GetInt (info.interp(),
				info.argv(++index), &int_value);
			if (code != TCL_OK) {
				return code;
			}
			this->phase3_max_iteration(int_value);
		}
		else if(!strcmp(info.argv(index),"-damping1"))
		{
			code = Tcl_GetDouble (info.interp(),
				info.argv(++index), &double_value);
			if (code != TCL_OK) {
				return code;
			}
			this->phase1_damping(double_value);
		}
		else if(!strcmp(info.argv(index),"-damping2"))
		{
			code = Tcl_GetDouble (info.interp(),
				info.argv(++index), &double_value);
			if (code != TCL_OK) {
				return code;
			}
			this->phase2_damping(double_value);
		}
		else if(!strcmp(info.argv(index),"-damping3"))
		{
			code = Tcl_GetDouble (info.interp(),
				info.argv(++index), &double_value);
			if (code != TCL_OK) {
				return code;
			}
			this->phase3_damping(double_value);
		}
		else if(!strcmp(info.argv(index),"-colour_nodes"))
		{
			code = Tcl_GetBoolean (info.interp(),
				info.argv(++index), &int_value);
			if (code != TCL_OK) {
				return code;
			}
			if (int_value)
			{
				this->colour_nodes(true);
			}
			else
			{
				this->colour_nodes(false);
			}
		}
		else if(!strcmp(info.argv(index),"-vibration_ratio"))
		{
			code = Tcl_GetDouble (info.interp(),
				info.argv(++index), &double_value);
			if (code != TCL_OK) {
				return code;
			}
			this->vibration_ratio(double_value);
		}
		else if(!strcmp(info.argv(index),"-width"))
		{
			code = Tcl_GetInt (info.interp(),
				info.argv(++index), &int_value);
			if (code != TCL_OK) {
				return code;
			}
			this->window_width(int_value);
		}
		else if(!strcmp(info.argv(index),"-heigth"))
		{
			code = Tcl_GetInt (info.interp(),
				info.argv(++index), &int_value);
			if (code != TCL_OK) {
				return code;
			}
			this->window_height(int_value);
		}
		else if(!strcmp(info.argv(index),"-random"))
		{
			code = Tcl_GetBoolean (info.interp(),
				info.argv(++index), &int_value);
			if (code != TCL_OK) {
				return code;
			}
				
			if (int_value)
			{
				this->random_placement(true);
			}
			else
			{
				this->random_placement(false);
			}
		}
		else if(!strcmp(info.argv(index),"-default_constraint"))
		{
			code = Tcl_GetBoolean (info.interp(), info.argv(++index),
				&int_value);
			if (code != TCL_OK) {
				return code;
			}
				
			if (int_value)
			{
				this->default_constraint(true);
			}
			else
			{
				this->default_constraint(false);
			}
		}
	}
	index++;

	return code;
}


int GT_Tcl_Layout_Constraint_Fruchterman_Reingold_Algorithm::run(
	GT_Graph &g)
{
	FR_Constraint_Graph fr_constraint_graph(g);

	fr_constraint_graph.set_parameters(
		this->optimal_distance(),
		this->pitch(),
		this->constraint_forces(),
		this->phase1_max_iteration(),
		this->phase2_max_iteration(),
		this->phase3_max_iteration(),
		this->phase1_damping(),
		this->phase2_damping(),
		this->phase3_damping(),
		this->vibration_ratio(),
		this->colour_nodes(),
		this->window_width(),
		this->window_height(),
		this->random_placement(),
		this->default_constraint()
		);

	fr_constraint_graph.group_initialization();
	fr_constraint_graph.read_constraints();
	string message = fr_constraint_graph.check();

	if (message != "ok")
	{
		this->result(message);
		return GT_ERROR;
	}

	fr_constraint_graph.force_directed_placement();

	return GT_OK;
}





