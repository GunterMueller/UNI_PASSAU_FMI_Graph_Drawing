//
// cfr_algorithm.h
//
// This defines the class
// GT_Layout_Constraint_Fruchterman_Reingold_Algorithm
// which is the interface to the Constraint Fruchterman
// Reingold Layout Algorithm.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/cfr_layout/cfr_algorithm.h,v $
// $Author: schirmer $
// $Revision: 1.2 $
// $Date: 1996/11/03 12:23:01 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//


class GT_Layout_Constraint_Fruchterman_Reingold_Algorithm :
public GT_Algorithm
{
	GT_CLASS (GT_Layout_Constraint_Fruchterman_Reingold_Algorithm,
		GT_Algorithm);
	GT_VARIABLE (double, optimal_distance);
	GT_VARIABLE (double, pitch);
	GT_VARIABLE (bool, constraint_forces);
	GT_VARIABLE (int, phase1_max_iteration);
	GT_VARIABLE (int, phase2_max_iteration);
	GT_VARIABLE (int, phase3_max_iteration);
	GT_VARIABLE (double, phase1_damping);
	GT_VARIABLE (double, phase2_damping);
	GT_VARIABLE (double, phase3_damping);
	GT_VARIABLE (bool, colour_nodes);
	GT_VARIABLE (double, vibration_ratio);
	GT_VARIABLE (int, window_width);
	GT_VARIABLE (int, window_height);
	GT_VARIABLE (bool, random_placement);
	GT_VARIABLE (bool, default_constraint);
  public:
	GT_Layout_Constraint_Fruchterman_Reingold_Algorithm(const string& name);
	virtual ~GT_Layout_Constraint_Fruchterman_Reingold_Algorithm() {};
	virtual int run (GT_Graph& g);
	virtual int check (GT_Graph& g, string& message);
};


class GT_Tcl_Layout_Constraint_Fruchterman_Reingold_Algorithm :
public GT_Tcl_Algorithm<GT_Layout_Constraint_Fruchterman_Reingold_Algorithm>
{
  public:
	GT_Tcl_Layout_Constraint_Fruchterman_Reingold_Algorithm(
			const string& name);
	virtual ~GT_Tcl_Layout_Constraint_Fruchterman_Reingold_Algorithm() {}
    virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
	virtual int run(GT_Graph &g);
};





