//
// cfr_io.cpp
//
// This is the implementation of the methods of the class
// FR_Constraint_Graph, which are used to read the constraints,
// initilize the algorithm or process the result.
//
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/cfr_layout/cfr_io.cpp,v $
// $Author: schirmer $
// $Revision: 1.3 $
// $Date: 1996/11/06 15:58:55 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#include <gt_base/Graph.h>

#include <LEDA/node_partition.h>
#include <LEDA/d_array.h>

#include "cfr_layout.h"


void FR_Constraint_Graph::set_parameters(
	double optimal, double pitch, bool extra_forces,
	int phase1_max, int phase2_max, int phase3_max,
	double phase1_damping, double phase2_damping, double phase3_damping,
	double vibration_ratio, bool colour_the_nodes, int width, int height,
	int random, bool default_mode)
{
	this->optimal_distance(optimal);
	this->minimal_distance(pitch);

	this->constraint_forces(extra_forces);
	
	this->max_iteration[0] = phase1_max;
	this->max_iteration[1] = phase2_max;
	this->max_iteration[2] = phase3_max;
 	
	this->phase_damping[0] = phase1_damping;
	this->phase_damping[1] = phase2_damping;
	this->phase_damping[2] = phase3_damping;

	this->vibration_ratio(vibration_ratio);
	this->colour_the_nodes(colour_the_nodes);

	this->window_width(width);
	this->window_height(height);

	this->random_placement(random);
	this->default_constraint(default_mode);
}


void FR_Constraint_Graph::notify_errors(
	const node_array<FR_One_Dimensional_Constraint*>& constraint)
{
	GT_Key ok_fill = GT::keymapper.add("white");
	GT_Key err_loop_fill = GT::keymapper.add("red");
	GT_Key err_cycle_fill = GT::keymapper.add("black");
	
	GT_Key ok_foreground = GT::keymapper.add("black");
	GT_Key err_loop_foreground = GT::keymapper.add("black");
	GT_Key err_cycle_foreground = GT::keymapper.add("white");
	
	node n;
	
	forall_nodes (n, this->the_graph.leda()) {
		if(constraint[n]->group_count() == ERR_LOOP)
		{
			this->the_graph.gt(n).graphics()
				->fill(err_loop_fill);
			this->the_graph.gt(n).label_graphics()
				->fill(err_loop_foreground);
		}
		else if(constraint[n]->group_count() == ERR_CYCLE)
		{
			this->the_graph.gt(n).graphics()
				->fill(err_cycle_fill);
			this->the_graph.gt(n).label_graphics()
				->fill(err_cycle_foreground);
		}
		else
		{
		this->the_graph.gt(n).graphics()
			->fill(ok_fill);
		this->the_graph.gt(n).label_graphics()
			->fill(ok_foreground);
		}
		// Force a redraw so that the colors will be updated
		this->the_graph.gt(n).set_changed
			(GT_Common_Attributes::tag_label);
	}
}


string FR_Constraint_Graph::check()
{
	node n;
	bool cycle = false, loop = false;
	int dfs_num = 1, comp_num = 1;

	forall (n, this->the_x_representative) {
		this->the_x_constraint[n]->dfs_num(UNMARKED);
		this->the_x_constraint[n]->comp_num(0);
	}

	forall (n, this->the_x_representative) {
		if(this->the_x_constraint[n]->dfs_num() == UNMARKED)
		{
			this->the_x_constraint[n]->dfs_num(++dfs_num);
			this->the_x_constraint[n]->check_dfs(
				dfs_num, comp_num, cycle, loop);
			this->the_x_constraint[n]->comp_num(++comp_num);
		}
	}

 	if((cycle)||(loop))
 	{
		string message = "\nUnsolvable X-Constraints.";

		if(loop)
		{
			message += "\nCheck the red nodes for illegal group-constraints combinations e.g. 'xr'.";
		}

		if(cycle)
		{
			message += "\nConsider the constraints of the black nodes to eliminate cycles.";
		}
		
		this->notify_errors(this->the_x_constraint);
 		return message;
 	}

	dfs_num = comp_num = 1;

	forall (n, this->the_y_representative) {
		this->the_y_constraint[n]->dfs_num(UNMARKED);
		this->the_y_constraint[n]->comp_num(0);
	}

	forall (n, this->the_y_representative) {
		if(this->the_y_constraint[n]->dfs_num() == UNMARKED)
		{
			this->the_y_constraint[n]->dfs_num(++dfs_num);

			this->the_y_constraint[n]->check_dfs(
				dfs_num, comp_num, cycle, loop);
			this->the_y_constraint[n]->comp_num(++comp_num);
		}
	}

	if((cycle)||(loop))
 	{
		string message = "\nUnsolvable Y-Constraints.";

		if(loop)
		{
			message += "\nCheck the red nodes for illegal group-constraints combinations e.g. 'yo'.";
		}

		if(cycle)
		{
			message += "\nConsider the constraints of the black nodes to eliminate cycles.";
		}
		
		this->notify_errors(this->the_y_constraint);
 		return message;
 	}
	
	return "ok";
}


string FR_Constraint_Graph::parse_node_constraints(
	const string original, const bool source_node)
{
	string result, label, effect;

	if (source_node)
	{
		label = "OAUBRL";
		effect = "oaubrl";
	}
	else // target_node
	{
		label = "OAUBRL";
		effect = "uboalr";
	}
		
	for (int i = 0; i < original.length(); i++)
	{
		string c = original[i];
		int pos = label.pos(c);
		
		if (pos != -1)
		{
			result += effect[pos];
		}
		else
		{
			result += c;
		}
	}
	
	return result;
}


string FR_Constraint_Graph::remove_comment(
	const string original)
{
	string result = original;
	int comment;

	if (!this->the_default_constraint)
	{
		if(result.pos(",") == -1)
		{
			return "";
		}
	}

	while ((comment = result.pos(",")) != -1)
	{
		result = result.del(0, comment);
	}

	return result;
}


string FR_Constraint_Graph::read_label(const edge e)
{
		node target = this->the_graph.leda().target(e);
		node source = this->the_graph.leda().source(e);

		string label = parse_node_constraints(
			remove_comment(this->the_graph.gt(source).label()), true);

		label += " " + parse_node_constraints(
			remove_comment(this->the_graph.gt(target).label()), false);

		label += " " + remove_comment(this->the_graph.gt(e).label());

		return label;
}


void FR_Constraint_Graph::read_constraints()
{
	edge e;

	this->has_geometric_constraints(false);
	
	forall_edges (e, this->the_graph.leda()) {
		bool hidden = false;
		
		node target = this->the_graph.leda().target(e);
		node source = this->the_graph.leda().source(e);

		string label = read_label(e);

		
		if (label)
		{
			for (int pos=0; pos < label.length(); pos++)	
			{
				switch (label[pos])
				{
					// 'o' and 'u' might be confusing but if you try to
					// understand this remember that (0,0) is above (0,100)
					case 'o': // o-berhalb
					case 'a': // a-bove
 						this->the_y_constraint[target]->
 							add_lower_constraint(the_y_constraint[source]);
						this->has_geometric_constraints(true);
						break;
					case 'u': // u-nterhalb
					case 'b': // b-elow
						this->the_y_constraint[source]->
							add_lower_constraint(the_y_constraint[target]);
						this->has_geometric_constraints(true);
						break;
					case 'r': // r-echts / r-ight
						this->the_x_constraint[source]
							->add_lower_constraint(the_x_constraint[target]);
						this->has_geometric_constraints(true);
						break;
					case 'l': // l-inks / l-eft
						this->the_x_constraint[source]->
							add_upper_constraint(the_x_constraint[target]);
						this->has_geometric_constraints(true);
						break;
					case '*': // This just a constraint edge - no graph edge
						hidden = true;
						break;
				}
			}
		}

		if(hidden)
		{
			this->the_hidden_edges.append(e);
		}
		else
		{
			this->the_edges.append(e);
		}
	}
}


void FR_Constraint_Graph::read_lengths_constraints()
{
	edge e;
	d_array <int, int> characteristic(-1);
	edge_array <int> lengths_group(this->the_graph.leda(), -1); 

	this->has_lengths_constraints(false);
	
	forall_edges (e, this->the_graph.leda()) {

		string label = read_label(e);
		string digits;

		for (int pos=0; pos <= label.length(); pos++)
		{
			if ((label[pos] >= '0') && (label[pos] <= '9'))
			{
				digits += label[pos];
			}
			else
			{
				int group = atoi(digits);
				digits = "";

				if (group > 0)
				{
					if (characteristic[group] < 0)
					{
						characteristic[group] = group;
					}
					
					if (lengths_group[e] < 0)
					{
						lengths_group[e] =  characteristic[group];
					}
					else // group for this edge already defined
					{
						edge e2;

						forall_edges (e2, this->the_graph.leda()) {
							if(lengths_group[e2] == characteristic[group])
							{
								lengths_group[e2] = lengths_group[e];
							}
						}

						characteristic[group] = lengths_group[e];
					}
				}
			}
		}
	}

	int group;
	
	forall_defined(group, characteristic) {
		list<edge> group_list;

		if(group == characteristic[group])
		{
			forall (e, this->the_edges)
				{
					if(lengths_group[e] == group)
					{
						group_list.append(e);
					}
				}

			if(group_list.length())
			{
				this->the_lengths_constraints.append(group_list);
				this->has_lengths_constraints(true);
			}
		}
	}
}


void FR_Constraint_Graph::set_group_repulsive_factors(
	const node_array<FR_One_Dimensional_Constraint*>& constraint,
	const char dimension)
{
	node n1, n2;

 	forall_nodes (n1, this->the_graph.leda()) {
 		for (n2 = this->the_graph.leda().succ_node(n1);
 			 n2 != nil;
 			 n2 = this->the_graph.leda().succ_node(n2))
 		{
 			if (constraint[n1] == constraint[n2])
 			{
 				this->the_repulsive_factor(n1, n2) = 0;
 			}
 		}
 	}

	node_array<int> adj_member(this->the_graph.leda(), 0);
	edge e;

 	forall (e, this->the_edges) {
 		node source = this->the_graph.leda().source(e);
 		node target = this->the_graph.leda().target(e);
		
 		if (constraint[source] == constraint[target]) 
 		{
 			adj_member[source]++;
 			adj_member[target]++;
 		}
 	}

	forall_nodes (n1, this->the_graph.leda()) {
		for (n2 = this->the_graph.leda().succ_node(n1);
			 n2 != nil;
			 n2 = this->the_graph.leda().succ_node(n2))
		{
 			if (constraint[n1] == constraint[n2])
			if(1)
			{
				if ((adj_member[n1] == 1) && (adj_member[n2] == 1))
				{
					double factor;
					
					factor = constraint[n1]->group_count() - 1;
					factor *= factor;

					this->the_repulsive_factor(n1, n2) = factor;
					
					Pair_of_Nodes opposite_pair(n1, n2);
					
					if(dimension == 'x')
					{
						this->the_x_opposite_pairs.append(opposite_pair);
					}
					else // if(dimension == 'y')
					{
						this->the_y_opposite_pairs.append(opposite_pair);
					}
				}
			}

			if(this->the_repulsive_factor(n1, n2) != 1)
			{
				this->has_repulsive_factors(true);
			}
		}
	}
}
	

void FR_Constraint_Graph::init_group_constraints(
	node_array<FR_One_Dimensional_Constraint*>& constraint,
	list<node>& representative,
	const char dimension,
	const string group_identifier,
	int random_coords)
{
	node n;
	edge e;
	node_partition group(this->the_graph.leda());
	constraint.init(this->the_graph.leda());
	
	forall_edges (e, this->the_graph.leda()) {
		string edge_label = read_label(e);

		if (edge_label.pos(group_identifier) != -1)
		{
			group.union_blocks(this->the_graph.leda().source(e),
				this->the_graph.leda().target(e));
		}
	}
	
	forall_nodes (n, this->the_graph.leda()) {
		if (group(n) == n)
		{
			double coord;
			
			if(random_coords)
			{
				coord = rand()%random_coords;
			}
			else
			{
				GT_Node_Attributes& node_attrs = this->the_graph.gt(n);
				
			
				if (dimension == 'x')
				{
					coord = node_attrs.graphics()->x();
				}
				else // if (dimension == 'y')
				{
					coord = node_attrs.graphics()->y();
				}
			}
			constraint[n] = new FR_One_Dimensional_Constraint(coord);
			representative.append(n);
		}
	}
		
	forall_nodes (n, this->the_graph.leda()) {
		if (group(n) != n)
		{
			double coord;
			
			if(random_coords)
			{
				coord = rand()%random_coords;
			}
			else
			{
				GT_Node_Attributes& node_attrs = this->the_graph.gt(n);
				
				if (dimension == 'x')
					coord = node_attrs.graphics()->x();
				else // if (dimension == 'y')
					coord = node_attrs.graphics()->y();
			}
			constraint[n] = constraint[group(n)];
			constraint[n]->add_member(coord);
		}
	}
}


void FR_Constraint_Graph::make_readable_labels()
{
	GT_Key white = GT::keymapper.add("white");
	GT_Key black = GT::keymapper.add("black");

	node n;
	
	forall_nodes (n, this->the_graph.leda()) {
		GT_Node_Attributes& node_attrs = this->the_graph.gt(n);
		
		node_attrs.graphics()->fill(white);
		node_attrs.label_graphics()->fill(black);

		// Force a redraw so that the colors will be updated
		this->the_graph.gt(n).set_changed
			(GT_Common_Attributes::tag_label);
	}

	edge e;

	forall_edges (e, this->the_graph.leda()) {
		GT_Edge_Attributes& edge_attrs = this->the_graph.gt(e);
		edge_attrs.label_graphics()->fill(black);
	}
}


void FR_Constraint_Graph::colour_nodes()
{
	node n;
	double max_force = 0, sum_forces = 0;
	node_array<double> force(this->the_graph.leda());
	GT_Key force_colour[11], white, black;

	force_colour[ 0] = GT::keymapper.add("white");
	force_colour[ 1] = GT::keymapper.add("grey90");
	force_colour[ 2] = GT::keymapper.add("grey80");
	force_colour[ 3] = GT::keymapper.add("grey70");
	force_colour[ 4] = GT::keymapper.add("grey60");
	force_colour[ 5] = GT::keymapper.add("grey40");
	force_colour[ 6] = GT::keymapper.add("grey30");
	force_colour[ 7] = GT::keymapper.add("grey20");
	force_colour[ 8] = GT::keymapper.add("grey10");
	force_colour[ 9] = GT::keymapper.add("black");
	force_colour[10] = GT::keymapper.add("red");

	black = GT::keymapper.add("black");
	white = GT::keymapper.add("white");
	
	forall_nodes (n, this->the_graph.leda()) {

		double dx = this->the_x_constraint[n]->displacement();
		double dy = this->the_y_constraint[n]->displacement();

		double length = hypot(dx ,dy);
		if (length > max_force) max_force = length;
		force[n] = length;
		sum_forces += length;
	}

	forall_nodes (n, this->the_graph.leda()) {
		GT_Node_Attributes& node_attrs = this->the_graph.gt(n);
		
		int colour = (int) (10.0 * force[n] / max_force); 
		node_attrs.graphics()->fill(force_colour[colour]);

		if(colour <= 4)
		{
			node_attrs.label_graphics()->fill(black);
		}
		else
		{
			node_attrs.label_graphics()->fill(white);
		}
		
		// Force a redraw so that the colors will be updated
		this->the_graph.gt(n).set_changed
			(GT_Common_Attributes::tag_label);
	}
}


void FR_Constraint_Graph::update_gt_properties()
{
	node n;
	double coord;
	
	forall_nodes (n, this->the_graph.leda()) {
		GT_Node_Attributes& node_attrs = this->the_graph.gt(n);
		
		coord = this->the_x_constraint[n]->coord();
		node_attrs.graphics()->x(coord);
		
		coord = this->the_y_constraint[n]->coord();
		node_attrs.graphics()->y(coord);
	}
}


void FR_Constraint_Graph::fit_graph_to_window(
	const int width, const int height, const int margin, bool do_scale)
{
	node n;
	double min_x = HUGE, min_y = HUGE, max_x = -HUGE, max_y = -HUGE;
	double scale_x, scale_y, scale;
	
	forall (n, this->the_x_representative) {
		if (this->the_x_constraint[n]->coord() < min_x)
			min_x = this->the_x_constraint[n]->coord();
		if (this->the_x_constraint[n]->coord() > max_x)
			max_x = this->the_x_constraint[n]->coord();
	}

	forall (n, this->the_y_representative) {
		if (this->the_y_constraint[n]->coord() < min_y)
			min_y = this->the_y_constraint[n]->coord();
		if (this->the_y_constraint[n]->coord() > max_y)
			max_y = this->the_y_constraint[n]->coord();
	}

	if(do_scale)
	{
		scale_x = (max_x - min_x + 2 * margin) / width;
		scale_y = (max_y - min_y + 2 * margin) / height; 

		if(scale_x > scale_y)
		{
			scale = scale_x;
		}
		else
		{
			scale = scale_y;
		}
	}
	else
	{
		scale = 1;
	}
	
	forall (n, this->the_x_representative) {
		double coord = (this->the_x_constraint[n]->coord() - min_x)
			/ scale + margin;
		this->the_x_constraint[n]->coord(coord);
	}
		
	forall (n, this->the_y_representative) {
		double coord = (this->the_y_constraint[n]->coord() - min_y)
			/ scale + margin;
		this->the_y_constraint[n]->coord(coord);
	}
}


void FR_Constraint_Graph::count_constraints()
{
	node n;
	int upper_x = 0, lower_x = 0, upper_y = 0, lower_y = 0;
	
	forall (n, this->the_x_representative) {
		upper_x += this->the_x_constraint[n]->upper_constraints().size();
		lower_x += this->the_x_constraint[n]->lower_constraints().size();
	}
		
	forall (n, this->the_y_representative) {
		upper_y += this->the_y_constraint[n]->upper_constraints().size();
		lower_y += this->the_y_constraint[n]->lower_constraints().size();
	}
}


void FR_Constraint_Graph::create_subgraph()
{
	double optimal_distance = this->optimal_distance();
	double pitch = this->minimal_distance();
	const int width = this->window_width();
	const int height = this->window_height();
	
	double num_nodes = this->the_graph.leda().number_of_nodes();
	double num_edges = this->the_graph.leda().number_of_edges();
	
	if(optimal_distance <= 0)
	{
		optimal_distance = (num_edges / num_nodes) *
			sqrt(width * height / num_nodes) / 3;
	}
	
	if(pitch <= 0)
	{
		pitch = optimal_distance / 2;
	}

	this->reduce_constraints(this->the_x_constraint,
 		this->the_x_representative);
	this->reduce_constraints(this->the_y_constraint,
 		this->the_y_representative);
	
	this->order_nodes(this->the_x_constraint, this->the_x_representative,
		pitch);
	this->order_nodes(this->the_y_constraint, this->the_y_representative,
		pitch);

	node n;
	list<node> unconstraint;
	
	forall_nodes (n, this->the_graph.leda()) {
		if((this->the_x_constraint[n]->has_constraints() == false) &&
			(this->the_y_constraint[n]->has_constraints() == false))
		{
			unconstraint.append(n);
		}
	}

	forall (n, unconstraint) {
		this->the_graph.leda().del_node(n);
	}
	
	edge e;
	list<edge> unimportant;
	forall_edges (e, this->the_graph.leda()) {
		bool important = false;
		node target = the_graph.leda().target(e);
		node source = the_graph.leda().source(e);
		
		string label = parse_node_constraints(
			this->the_graph.gt(source).label(), true);
		label += parse_node_constraints(
			this->the_graph.gt(target).label(), false);
		label += this->the_graph.gt(e).label();

		if (label)
		{
			for (int pos=0; pos < label.length(); pos++)    
			{
				switch (label[pos])
				{
					case 'o':
					case 'a':
					case 'u':
					case 'b':
					case 'r':
					case 'l':
					case 'x':
					case 'y':
					case '*':
						important = true;
                }
			}
		}
		if(!important)
		{
			unimportant.append(e);
		}
	}

	forall (e, unimportant) {
		this->the_graph.leda().del_edge(e);
	}

	this->update_gt_properties();
}







