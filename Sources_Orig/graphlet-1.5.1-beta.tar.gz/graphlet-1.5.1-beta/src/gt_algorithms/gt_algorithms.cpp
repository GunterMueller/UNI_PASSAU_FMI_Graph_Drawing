//
// algorithms.cc
//
// This file initializes the algorithms module.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/gt_algorithms.cpp,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/09 18:28:30 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

#include <gt_base/Graphlet.h>

#include <gt_tcl/Tcl_Graph.h>
#include <gt_tcl/Tcl_Algorithm.h>
#include <gt_tcl/GraphScript.h>

#include "gt_algorithms.h"

#if 0
#include "hierarchical_se/leda_main.h"
#endif

int GT_gt_algorithms_init (Tcl_Interp* interp,
    GT_GraphScript* /* graphscript */)
{
    int code;

    GT_Tcl_Command* sample_cmd = new GT_Tcl_Sample_Command ("sample_cmd");
    code = sample_cmd->install (interp);
    if (code ==  TCL_ERROR) {
	return code;
    }
    
    GT_Tcl_Algorithm<GT_Layout_Random_Algorithm>* layout_random =
	new GT_Tcl_Layout_Random_Algorithm ("layout_random");
    code = layout_random->install (interp);
    if (code == TCL_ERROR) {
	return code;
    }
	
    GT_Tcl_Algorithm<GT_Planarity_Test_Algorithm>* planarity_test =
	new GT_Tcl_Planarity_Test_Algorithm ("planar");
    code = planarity_test->install (interp);
    if (code == TCL_ERROR) {
	return code;
    }

#if 0
    GT_Tcl_Algorithm* layout_hispring =
	new GT_Layout_Hispring_Tcl_Algorithm ("layout_hispring");
    code = layout_hispring->install (interp);
    if (code == TCL_ERROR) {
	return code;
    }
#endif
    
    GT_Tcl_Algorithm<GT_Layout_Constraint_Fruchterman_Reingold_Algorithm>*
      layout_constraint_fr = 
      new GT_Tcl_Layout_Constraint_Fruchterman_Reingold_Algorithm
      ("layout_constraint_fr");
    code = layout_constraint_fr->install (interp);
    if (code == TCL_ERROR) {
      return code;
    }

    return code;
}
