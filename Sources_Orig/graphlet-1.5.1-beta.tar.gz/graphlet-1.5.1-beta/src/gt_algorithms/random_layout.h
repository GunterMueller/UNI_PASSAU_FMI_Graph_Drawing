#ifndef GT_RANDOM_LAYOUT_H
#define GT_RANDOM_LAYOUT_H

//
// random_layout.h
//
// This file defines a sample layout algorithm "random".
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/random_layout.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:34 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//


//////////////////////////////////////////
//
// class GT_Layout_Random_Algorithm
//
// This is a sample Tcl/LEDA algorithm wich assigns random
// coordinates to nodes and edges.
//
//////////////////////////////////////////


#include <LEDA/array.h>


class GT_Layout_Random_Algorithm : public GT_Algorithm {

    //
    // GT_CLASS is a macro which implements some Graphlet
    // standard definitions.
    //
    
    GT_CLASS (GT_Layout_Random_Algorithm, GT_Algorithm);
	
    //
    // Parameters
    //
    // GT_VARIABLE(type,name) is a macro which does the following:
    // - declare a private variable "the_name"
    // - declare a public accessor "type name() const", inlined
    // - declare a public accessor "void name(type)", virtual
    //
    // GT_COMPLEX_VARIABLE is similar to the above, but uses references.
    //
    
    GT_VARIABLE (double, min_x);
    GT_VARIABLE (double, min_y);
    GT_VARIABLE (double, max_x);
    GT_VARIABLE (double, max_y);

    //
    // Determines which parameters of the graph should be changed
    //
    
    GT_VARIABLE (bool, colorize);
    GT_VARIABLE (bool, coordinates);

    //
    // Array of colors
    //
    
    GT_COMPLEX_VARIABLE (array<GT_Key>, colors);
    
public:

    //
    // The constructor of this class.
    //
	
    GT_Layout_Random_Algorithm (const string& name);
    virtual ~GT_Layout_Random_Algorithm ()
    {
    }

    //
    // run executes the algorithm.
    //
    // Return is
    // - GT_OK or TCL_OK, if everything is ok
    // - GT_ERROR or TCL_ERROR otherwise
    //
	
    virtual int run (GT_Graph& g);

    //
    // Check wether the algorithm is applicable (e.g. whether it
    // is planar). Return codes like above.
    //
    // This is a no-op function in this example, but must be
    // declated as this is a pure virtual function in
    // GT_Algorithm.
    //
	
    virtual int check (GT_Graph& g, string& message);

};


class GT_Tcl_Layout_Random_Algorithm :
    public GT_Tcl_Algorithm<GT_Layout_Random_Algorithm>
{
    
public:

    //
    // Constructor & Destructor
    //
    
    GT_Tcl_Layout_Random_Algorithm (const string& name);
    virtual ~GT_Tcl_Layout_Random_Algorithm ();
 
    //
    // parse parses the individual arguments
    //

    virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
};


#endif
