//
// Datei mit den Konstanten
//

#ifndef TRUE
#define  FALSE   0
#define  TRUE    1
#endif


#define LEDA_CHECKING_OFF


// optedgelen ist Variable, die beim Makroaufruf gesetzt sein muss
// Faktoren, die die Kraefte beschraenken

#define DEFAULT_RADIUS  8
#define ELEN            (110)
#define ELENSQR         (ELEN*ELEN)
#define MAXTEMP         (max_temp)
#define MAXATTRACT      (64*optedgelen*optedgelen)  
#define MAXDISTRACT     (64*optedgelen*optedgelen)  
#define	NODEDISTSQR	(optedgelen*optedgelen)
#define HIGH_DISTRACT   (SQR(optedgelen))
// Initialisierungen
#define INITIAL_HEAT    (ELEN)
#define	GRAVITY		4
#define	SHAKE		(ELEN)

#define VARIABLE        1
#define CONSTANT        2

#define RC_HIERARCHIE               1
#define MY_HIERARCHIE               2
#define T1_HIERARCHIE               3
#define T2_HIERARCHIE               4
#define DG_HIERARCHIE               5

#define LAST_LAYOUTED               1
#define SAME_LEVEL                  2
#define PRESET                      1
#define FINETUNE                    2
#define UNDEF                       -1


#define GRAPH_TYPE                  GRAPH<node_info*, edge_info*>
#define SET_FIELD                   array2<adv_node_set*>
