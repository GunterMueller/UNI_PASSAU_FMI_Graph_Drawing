//
//
// File mit ein paar kleinen Hilfsfunktionen, die immer wieder mal benoetigt werden
//
//


#include "hispring.h"


//------------------------------------------------------------------------------
// Kopiert 'source_set' nach 'target_set'. 'target_set' wird dazu vorher geloescht
//------------------------------------------------------------------------------

void copie_set_to( adv_node_set *source_set, adv_node_set *target_set )
{
  node  n;
  target_set->clear();
  fornodes_in_set( source_set, n ) target_set->insert( n );
}

//------------------------------------------------------------------------------
// Vertauscht den Inhalt von 'set1' und 'set2'
//------------------------------------------------------------------------------

void interchange_nodesets( GRAPH_TYPE *g, adv_node_set *set1, adv_node_set *set2 )
{
  adv_node_set  buffer( g );
  
  copie_set_to( set1, &buffer );
  copie_set_to( set2, set1 );
  copie_set_to( &buffer, set2 );
}
