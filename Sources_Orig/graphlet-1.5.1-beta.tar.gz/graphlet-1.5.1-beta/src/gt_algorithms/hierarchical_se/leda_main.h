#ifndef GT_HISPRING_H
#define GT_HISPRING_H

//
// leda_main.h
//
// This file defines a layout algorithm "hispring".
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/hierarchical_se/leda_main.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:40 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//


//////////////////////////////////////////
//
// class GT_Tcl_Layout_Hispring_Algorithm
//
// This is a sample Tcl/LEDA algorithm wich assigns random
// coordinates to nodes and edges.
//
//////////////////////////////////////////


#include <LEDA/array.h>

#include <tcl_leda/globals.h>
#include <tcl_leda/LedaScript.h>
#include <tcl_leda/Tcl_Algorithm.h>
#include <gtbase/Error.h>


class GT_Layout_Hispring_Tcl_Algorithm : public GT_Tcl_Algorithm {

	//
	// Parameters
	//
private:
	int show_hierarchie, unite_edges, minimize_nodes;
	int variable_edgelen, force_GEM;
	int  what_hierarchie;

	int max_nodes_per_set, external_scaling;
	int nr_nodes, nr_edges;

public:

	//
	// The constructor of this class.
	//
	
	GT_Layout_Hispring_Tcl_Algorithm::GT_Layout_Hispring_Tcl_Algorithm (
		const string& name);

	//
	// run executes the algorithm.
	//
	// Return is 0 or true or TCL_OK, if everything is ok,
	// or other value (error code) otherwise.
	//
	
	virtual int run (GT_Graph& g);

	//
	// Check wether the algorithm is applicable (e.g. whether it
	// is planar). Return codes like above.
	//
	// This is a no-op function in this example, but must be
	// declated as this is a pure virtual function in
	// GT_Tcl_Algorithm.
	//
	
	virtual int check (GT_Graph& g, string& message);
	virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
};
#endif
