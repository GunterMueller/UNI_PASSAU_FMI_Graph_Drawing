//
// hierarchie.cc
//

#include "hispring.h"


//------------------------------------------------------------------------------
// Berechnet zuerst das Feld der Knotenabstaende Holt sich den Index des
// Knoten der Wurzel werden soll und erzeugt die Hierarchie 24.01.95
//------------------------------------------------------------------------------

void HiSpring::ComputeHierarchie()
{
  adv_node_set   *search_set;

  levels = new hierarchie_levelling();
  search_set = GetCenterNode();
  CreateGraphCenterHierarchie ( search_set );
  CreateHierarchieEdges       ();
  levels->CreateLevelling     ( hierarchie, max_level, the_graph );
}


void HiSpring::ComputeDirectedHierarchie()
{
  adv_node_set   *search_set;

  levels = new hierarchie_levelling();
  search_set = GetRootNodes();
  CreateGraphCenterHierarchie2 ( search_set );
  CreateHierarchieEdges       ();
  levels->CreateLevelling     ( hierarchie, max_level, the_graph );
}

adv_node_set *HiSpring::GetRootNodes()
{

  adv_node_set  *root_elems;
  node          cur_node;
  adv_node_set  *root_sons, *first_sons;
  node_info     *root_info, *first_info;
  node          root_node, first_node;

  root_info = new node_info();
  root_node = the_graph->new_node( root_info );
  root_sons = new adv_node_set( the_graph ); 
  root_info->SetSons( root_sons );

  first_info = new node_info();
  first_node = the_graph->new_node( first_info );
  first_sons = new adv_node_set( the_graph ); 
  first_info->SetSons( first_sons );
  first_info->SetFather( root_node );
  first_info->SetLevel( 1 );

  root_elems = new adv_node_set( the_graph );
  hierarchie = new adv_node_set( the_graph );
  hierarchie->insert( root_node );
  root_sons->insert( first_node );

  forall_nodes( cur_node, *the_graph )
  {
    if( (the_graph->indeg(cur_node) == 0) && (cur_node != root_node) && (cur_node != first_node) )
    {
      first_sons->insert( cur_node );
      root_elems->insert( cur_node );
      the_graph->inf(cur_node)->SetRepresented( TRUE );
      the_graph->inf(cur_node)->SetFather( first_node );
      the_graph->inf(cur_node)->SetLevel( 2 );
    }
  }
  return( root_elems );
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

adv_node_set *HiSpring::GetCenterNode()
{
  adv_node_set     node_list( the_graph ), *search_set;
  node_array<int>  node2int( *the_graph );
  array<node>      int2node( the_node_nr );
  node             cur_node;
  int              min_sum, sum, i, j, root_index;
  array2<int>      distance_field( the_node_nr, the_node_nr );

  i = 0;
  forall_nodes( cur_node, *the_graph )
  {
    node_list.insert( cur_node );
    node2int[cur_node] = i;
    int2node[i] = cur_node;
    distance_field( i, i ) = 0;
    i++;
  }
  ComputeNodedistances( &node_list, &distance_field, &node2int, the_graph );
  
  // search the root
  min_sum = UNDEF;
  for( i = 0; i < the_node_nr; i++ )
  {
    sum = 0;
    for( j = 0; j < the_node_nr; j++ )
    {
      sum+= distance_field( i, j );
    }
    if( (sum < min_sum) || (min_sum == UNDEF) )
    {
      min_sum    = sum;
      root_index = i;
    }
  }
  // Initialisiere Suchset
  search_set = new adv_node_set( the_graph );
  search_set->insert( int2node[root_index] );
  return( search_set );
}

//------------------------------------------------------------------------------
// Berechnet die Abstaende von jedem Knoten zu jedem anderen in cur_group und
// legt das Ergebnis in distance_field ab
//------------------------------------------------------------------------------

void ComputeNodedistances( adv_node_set *cur_group, array2<int> *distance_field,
			   node_array<int>  *node2int, GRAPH_TYPE *g )
{
  node          cur_node, n, neighbor, start_node;
  int           cur_nodedist, root_nr;
  adv_node_set  search_nodes(g), start_nodes(g), new_start_nodes(g);
  node_info     *info;

  fornodes_in_set( cur_group, n ) search_nodes.insert( n );

  fornodes_in_set( cur_group, cur_node ) 
  {
    cur_nodedist = 1;
    root_nr = (*node2int)[cur_node];
    search_nodes.del( cur_node );      
    start_nodes.insert( cur_node );

    while( FALSE == start_nodes.empty() ) 
    {
      start_node   = start_nodes.choose();
      start_nodes.del( start_node );

      forall_neighbor_nodes( neighbor, start_node )
      {
	info = g->inf(neighbor);
	if( FALSE == info->GetLayouted() && search_nodes.member(neighbor) )
	{
	  info->SetLayouted( TRUE );
	  (*distance_field)( root_nr, (*node2int)[neighbor] ) = cur_nodedist;
	  new_start_nodes.insert( neighbor );
	}
      }
      if( TRUE == start_nodes.empty() )
      {
	interchange_nodesets( g, &new_start_nodes, &start_nodes );
	cur_nodedist++;
      }
    }
    search_nodes.insert( cur_node );

    fornodes_in_set( cur_group, n ) g->inf(n)->SetLayouted( FALSE );
  }
}

//------------------------------------------------------------------------------
// Erhaelt Source- und Targetknoten und erzeugt eine Hierarchiekante 
// zwischen den Knoten. Macht auch Update bei den Knoten.
//------------------------------------------------------------------------------

void CreateTreeEdge( edge graph_edge, node source_node, 
		     node target_node, GRAPH_TYPE *the_graph )
{
	tree_edge          *new_edge;
	int                found;
	tree_edge          *cur_edge;
	node_info          *source, *target;
	list<tree_edge*>   cur_edges;

	source    = the_graph->inf( source_node );
	target    = the_graph->inf( target_node );
	found  = FALSE;
	// Wenn Kante schon existiert, dann nur Zaehler erhoehen
	//cur_edges = source->GetEdges();
	forall( cur_edge, *(source->GetEdges()) ) {
		if( cur_edge->target == target_node ) {
			cur_edge->edge_number += the_graph->inf( graph_edge )->GetCapacity();
			cur_edge->corresponding_edges->append( graph_edge );
			found = TRUE;
		}
	}

	if( TRUE == found ) {
		forall( cur_edge, *(target->GetEdges()) ) {
			if( cur_edge->source == source_node ) {
				cur_edge->edge_number += the_graph->inf( graph_edge )->GetCapacity();
				cur_edge->corresponding_edges->append( graph_edge );
				return;
			}
		}
	}
  
	new_edge = new tree_edge();
	new_edge->source        = source_node;
	new_edge->target        = target_node;
	new_edge->edge_number   = the_graph->inf( graph_edge )->GetCapacity();
	new_edge->corresponding_edges = new list<edge>(); 
	new_edge->corresponding_edges->append( graph_edge );
	source->GetEdges()->append( new_edge );

	new_edge = new tree_edge();
	new_edge->source        = source_node;
	new_edge->target        = target_node;
	new_edge->edge_number   = the_graph->inf( graph_edge )->GetCapacity();
	new_edge->corresponding_edges = new list<edge>(); 
	new_edge->corresponding_edges->append( graph_edge );
	target->GetEdges()->append( new_edge );
}


void CreateTreeEdge( list<edge> *graph_edges, node source_node, 
 		     node target_node, GRAPH_TYPE *the_graph )
{
	tree_edge          *new_edge;
	int                found;
	tree_edge          *cur_edge;
	node_info          *source;
	node_info          *target;
	edge               e;
	edge_set           buf( *the_graph );
	list<tree_edge*>   cur_edges;

	source    = the_graph->inf( source_node );
	target    = the_graph->inf( target_node );

	found = FALSE;
	// Wenn Kante schon existiert, dann nur Zaehler erhoehen
	forall( cur_edge, *(source->GetEdges()) ) {
		if( cur_edge->target == target_node ) {
			forall( e, *graph_edges ) {
				cur_edge->corresponding_edges->append( e );
				cur_edge->edge_number += the_graph->inf( e )->GetCapacity();
			}
			found = TRUE;
		}
	}

	if( TRUE == found ) {
		forall( cur_edge, *(target->GetEdges()) ) {
			if( cur_edge->source == source_node ) {
				forall( e, *graph_edges ) {
					cur_edge->corresponding_edges->append( e );
					cur_edge->edge_number += the_graph->inf( e )->GetCapacity();
				}
				return;
			}
		}
	}
  
	new_edge = new tree_edge();
	new_edge->source        = source_node;
	new_edge->target        = target_node;
	new_edge->corresponding_edges = new list<edge>();
	forall( e, *graph_edges ) {
		new_edge->corresponding_edges->append( e );
		new_edge->edge_number += the_graph->inf( e )->GetCapacity();
	}
	source->GetEdges()->append( new_edge );

	new_edge = new tree_edge();
	new_edge->source              = source_node;
	new_edge->target              = target_node;
	new_edge->corresponding_edges = new list<edge>( ); 
	forall( e, *graph_edges ) {
		new_edge->corresponding_edges->append( e );
		new_edge->edge_number += the_graph->inf( e )->GetCapacity();
	}
	target->GetEdges()->append( new_edge );
}


//------------------------------------------------------------------------------
// Erzeugt die Hierarchie ueber den Graph. Geht dabei rekursiv vor. Erhaelt dazu
// die Nummer des Vaters und sucht sich dazu alle Soehne. Ruft rekursiv fuer 
// alle Soehne auf.
//------------------------------------------------------------------------------

void HiSpring::CreateGraphCenterHierarchie(adv_node_set *cur_nodes )
{
  int         count;
  node        root;
  node        neighbor;
  adv_node_set    *new_set;
  adv_node_set    *father_set;
  adv_node_set    *new_start_nodes;
  node_info   *info_root;
  node_info   *info_cur;
  int         hierarchie_level;
  node        new_hierarchie_node;
  node_info   *new_info;
  node        n;
  adv_node_set  *hier;

  if( NULL == hierarchie )   /* Wir sind an der 'echten' Wurzel */
  {
    adv_node_set  *hier;
    hier = new adv_node_set( the_graph );
    hierarchie = hier;
    hier->insert( cur_nodes->choose() );
    (the_graph->inf(cur_nodes->choose()))->SetRepresented( TRUE );
    CreateGraphCenterHierarchie( cur_nodes );
    return;
  }

  new_start_nodes = new adv_node_set( the_graph );

  while( cur_nodes->empty() == FALSE ) {
      root = cur_nodes->choose();
      cur_nodes->del( root );
      info_root = the_graph->inf( root );
      if( NULL != info_root->GetFather(the_graph) ) {
		  hierarchie_level = info_root->GetLevel() + 1;
		  if( max_level < hierarchie_level ) {
			  max_level = hierarchie_level+1;
		  }
      } else {
		  hierarchie_level = 1;
		  max_level = 1;
      }
      count = 0;
	  
      forall_neighbor_nodes( neighbor, root ) {
		  if( FALSE == (the_graph->inf(neighbor))->GetRepresented() ) count++;
      }
      if( count != 0 )
      {
		  // Zuerst ein kleiner Trick, um alle hierarchischen
		  // Zerlegungen gleich zu machen:
		  // Mache aus dem Vater einen Hierarchieknoten und fuege den Vater 
		  // bei den eigenen Soehnen ein
		  new_hierarchie_node  = the_graph->new_node(info_root);
		  new_info             = new node_info();
		  if( NULL == info_root->GetFather(the_graph) ) {
			  hierarchie->~adv_node_set();
			  hierarchie = new adv_node_set( the_graph );
			  hierarchie->insert( new_hierarchie_node );
		  } else {
			  father_set = (info_root->GetFather(the_graph))->GetSons();
			  new_set = new adv_node_set( the_graph );
			  father_set->del( root );
			  while( FALSE == father_set->empty() ) {
				  n =  father_set->choose();
				  new_set->insert( n );
				  father_set->del( n );
			  }
			  new_set->insert( new_hierarchie_node );
			  father_set->~adv_node_set();
			  (info_root->GetFather(the_graph))->SetSons( new_set );
		  }
		  the_graph->assign( root, new_info );
		  new_info->SetLevel( hierarchie_level );
		  new_info->SetFather( new_hierarchie_node );
		  new_info->SetRadius( info_root->GetRadius() );
		  new_info->SetRepresented( TRUE );

		  hier = new adv_node_set( the_graph );
		  info_root->SetSons( hier );

		  hier->insert( root );
		  forall_neighbor_nodes( neighbor, root ) {
			  info_cur = the_graph->inf(neighbor);
			  if( FALSE == info_cur->GetRepresented() ) {
				  hier->insert( neighbor );
				  info_cur->SetLevel( hierarchie_level );
				  info_cur->SetFather( new_hierarchie_node );
				  info_cur->SetRepresented( TRUE );
				  new_start_nodes->insert( neighbor );
			  }
		  }
      }
  }
  cur_nodes->~adv_node_set();
  if( FALSE == new_start_nodes->empty() ) CreateGraphCenterHierarchie( new_start_nodes );
  else                                    new_start_nodes->~adv_node_set();
}

void HiSpring::CreateGraphCenterHierarchie2(adv_node_set *cur_nodes )
{
  adv_node_set    new_start_nodes( the_graph ), *first_sons;
  node_info       *first_info;
  node            first_node, root_node, root, neighbor, cur_node;
  int             count, create;
  max_level = 3;
  create = TRUE;

  root_node = hierarchie->choose();

  first_info = new node_info();
  first_node = the_graph->new_node( first_info );
  first_sons = new adv_node_set( the_graph ); 
  first_info->SetSons( first_sons );
  first_info->SetLevel( 1 );
  first_info->SetFather( root_node );
  copie_set_to( cur_nodes, first_sons );
  fornodes_in_set( cur_nodes , cur_node )
  {
	  // first_sons->insert( cur_node );
    the_graph->inf(cur_node)->SetRepresented( TRUE );
    the_graph->inf(cur_node)->SetFather( first_node );
    the_graph->inf(cur_node)->SetLevel( 2 );
  }
  the_graph->inf(root_node)->GetSons()->~adv_node_set();
  the_graph->inf(root_node)->SetSons(new adv_node_set(the_graph) );
  the_graph->inf(root_node)->GetSons()->insert(first_node);

  while( cur_nodes->empty() == FALSE )
  {
    root = cur_nodes->choose();
    cur_nodes->del( root );

    count = 0;
    forall_neighbor_nodes( neighbor, root )  
      if( FALSE == (the_graph->inf(neighbor))->GetRepresented() ) count++;
    if( count != 0 )
    {
      if( create )
      {
		  first_info = new node_info();
		  first_node = the_graph->new_node( first_info );
		  first_sons = new adv_node_set( the_graph ); 
		  first_info->SetSons( first_sons );
		  first_info->SetLevel( 1 );
		  first_info->SetFather( root_node );

		  adv_node_set buf( the_graph );
		  copie_set_to( the_graph->inf(root_node)->GetSons(), &buf );
		  buf.insert( first_node );
		  the_graph->inf(root_node)->GetSons()->~adv_node_set();
		  the_graph->inf(root_node)->SetSons(new adv_node_set(the_graph) );
		  copie_set_to( &buf, the_graph->inf(root_node)->GetSons() );
		  create = FALSE;
      }
      forall_neighbor_nodes( neighbor, root )
      {
	if( FALSE == (the_graph->inf(neighbor))->GetRepresented() )
	{
	  first_sons->insert( neighbor );
	  the_graph->inf(neighbor)->SetRepresented( TRUE );
	  the_graph->inf(neighbor)->SetFather( first_node );
	  the_graph->inf(neighbor)->SetLevel( 2 );
	  new_start_nodes.insert( neighbor );
	}
      }
    }
    if( TRUE == cur_nodes->empty() )
    {
      interchange_nodesets( the_graph, &new_start_nodes, cur_nodes );
      create = TRUE;
    }
  }
  cur_nodes->~adv_node_set();
}

