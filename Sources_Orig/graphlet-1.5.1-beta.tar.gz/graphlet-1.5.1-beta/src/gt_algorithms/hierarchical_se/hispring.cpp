//
// hispring.cc
//

#include "hispring.h"

#define MAIN           // This is necessary to include the
                       // algorithm to compute the node sizes
#include "typen.h"
#include "elzinga.h"
#include "fkt_dast.h"
#undef MAIN

// #include <tcl_leda/globals.h>
// #include <tcl_leda/LedaScript.h>
// #include <tcl_leda/Tcl_Algorithm.h>
// #include <gtbase/Error.h>

HiSpring::~HiSpring()
{
	node cn;
	edge ce;

	forall_nodes( cn, *the_graph ) { the_graph->inf( cn )->~node_info(); }
	forall_edges( ce, *the_graph ) { the_graph->inf( ce )->~edge_info(); }

	Myn2GR->~node_array();
	Mye2GR->~edge_array();
	
	hierarchie->~adv_node_set();
	the_graph->~GRAPH();
	levels->~hierarchie_levelling();
}

//-----------------------------------------------------------------------------
// Und hier die Funktion, die fuer den Programmierer nach aussen 
// sichtbar ist. Funktionsweise ist eigentlich klar.
//-----------------------------------------------------------------------------

void HiSpring::RunHiSpring()
{
	float_vec  displace;
  
	if( what_hierarchie == 0 )   ComputeRCHierarchie();
	if( what_hierarchie == 1 )   ComputeHierarchie();

	ComputeNodesizes( hierarchie ); 
	ComputeDistChartsForTree_KAM();

	if( TRUE == force_GEM ) {
		ComputeLayout   ( PRESET, 128 );
		ComputeDistChartsForTree_KAM();
		ComputeLayout   ( FINETUNE, 32 );

		if( TRUE == minimize_nodes ) {
			displace.x = 0.0;
			displace.y = 0.0;
			ReduceAllNodes_KAM( hierarchie );
			MoveNodesBack ( hierarchie, displace );
		}
		ComputeLayout ( FINETUNE, 32 );
		ComputeLayout ( FINETUNE, 16 );
	} else {
		ComputeLayout_KAM   ( PRESET, 0 );
		ComputeDistChartsForTree_KAM();
		ComputeLayout_KAM   ( FINETUNE, 32 );

		if( TRUE == minimize_nodes ) {
			displace.x = 0.0;
			displace.y = 0.0;
			ReduceAllNodes_KAM( hierarchie );
			MoveNodesBack ( hierarchie, displace );
		}
		ComputeLayout_KAM( FINETUNE, 16 );
		//ComputeLayout_KAM( FINETUNE, 16 );
	}
	
  ReduceGraph  ();
  if( TRUE == unite_edges )
  {
    ComputePlacesOnBorder();
  }
}

//------------------------------------------------------------------------------
// DIE Funktion, die die neuen Koordinaten berechnet.
// Gehe durch alle Hierarchiestufen und dort durch alle node_sets
// Berechne die Koordinaten der aktuellen Menge
// Gilt sowohl fuer Feintuning als auch fuer grobe Vorberechnung
//------------------------------------------------------------------------------

void HiSpring::ComputeLayout( int what_algorithm, int heat )
{
  adv_node_set *cur_set, buff( the_graph ), buff2( the_graph );
  node         n;
  node_info    *father_inf, *n_info;
  int          cur_level, max_radius;
  float_vec    node_center, null_vec, displace;
  double       l_opt;

  null_vec.x   = 0.0;
  null_vec.y   = 0.0;
  cur_level    = -1;
  actual_nodes = &buff;
  border_nodes = &buff2;

  while( UNDEF != (cur_level = levels->GetNextLevel(cur_level)) )
  {
    while( NULL != (cur_set = levels->GetNextSet(cur_level)) )
    {
      father_inf = (the_graph->inf(cur_set->choose()))->GetFather(the_graph);
      if( what_algorithm == PRESET ) 
      {
		  ComputeBorderNodes( father_inf, LAST_LAYOUTED );
		  PresetCoordinates( father_inf, cur_set );
		  fornodes_in_set( cur_set, n ) {
			  the_graph->inf(n)->SetImpulse( null_vec );
		  }
      } else {
		  ComputeBorderNodes( father_inf, LAST_LAYOUTED );
		  fornodes_in_set( cur_set, n ) {
			  the_graph->inf(n)->SetImpulse( null_vec );
			  the_graph->inf(n)->SetDir( 0 );
			  the_graph->inf(n)->SetHeat( heat );
			  the_graph->inf(n)->CopyPosToOldPos();
			  actual_nodes->insert( n );
		  }
      }
      if( father_inf && !((actual_nodes->size() == 2) &&
		  (border_nodes->empty() == TRUE)) ) {
		  node_center = father_inf->GetCenter();
		  if( what_algorithm == FINETUNE ) {
			  FinetuneCoordinates  ( father_inf->GetRadius(), node_center );
			  fornodes_in_set( cur_set, n ) {
				  n_info = the_graph->inf(n);
				  displace.x = n_info->GetOldX() - n_info->GetX();
				  displace.y = n_info->GetOldY() - n_info->GetY();
				  MoveAllSonsBack( n_info->GetSons(), displace );
			  }
		  } else {
			  PreComputeCoordinates( father_inf->GetRadius(), node_center );
			  fornodes_in_set( cur_set, n ) {
				  the_graph->inf(n)->SetHeat( heat );
				  the_graph->inf(n)->SetImpulse( null_vec );
				  the_graph->inf(n)->SetDir( 0 );
				  max_radius = MAX( max_radius,
					  the_graph->inf(n)->GetRadius() );
			  }

			  if( the_edgelen != VARIABLE )  l_opt = ELEN;
			  else            	             l_opt = MAX( ELEN, max_radius );

			  FinetuneCoordinates  ( father_inf->GetRadius(), node_center );
		  }
      }
      // Setzen, dass die Knoten gelayoutet wurden
      fornodes_in_set( cur_set, n )  the_graph->inf(n)->SetLayouted( TRUE );
      actual_nodes->clear();
      border_nodes->clear();
    }
  }
}

//-----------------------------------------------------------------------------
// Konstruktor fuer die Klasse HiSpring.
//-----------------------------------------------------------------------------

HiSpring::HiSpring()
{
  actual_nodes   = NULL;
  border_nodes   = NULL;
  hierarchie     = NULL;
  the_graph      = new GRAPH_TYPE();
  levels         = NULL;
  max_level      = 0;
  unite_edges    = TRUE;
}

//-----------------------------------------------------------------------------
// Setzen der Parameter
//-----------------------------------------------------------------------------

void  HiSpring::SetSettings(GT_Graph& g, int show_hier, int unite,
	int minimize, int variable_edges, int force, int what_hier,
	int max_nodes, int external_scal)
{
	node                cur_node, new_node, source, target;
	edge                cur_edge, new_edge;
	edge_info           *new_einfo;
	node_info           *new_ninfo;
	graph               *ledagraph;
	node_array<node>    GRn2MY( *(g.the_graph) );  // temporary copy-pointers
	
	show_hierarchie     = show_hier;
	what_hierarchie     = what_hier;
	unite_edges         = unite;
	minimize_nodes      = minimize;
	the_edgelen         = variable_edges;
	force_GEM           = force;
	max_nodes_per_set   = max_nodes;
	ext_scaling         = external_scal;
	

	ledagraph = g.the_graph;
	the_node_nr = ledagraph->number_of_nodes();

	// pointers to copy changes back
	Myn2GR  = new node_array<node>(
		*the_graph, ledagraph->number_of_nodes(), NULL );
	Mye2GR  = new edge_array<edge>(
		*the_graph, ledagraph->number_of_edges(), NULL );

	// copy the graph
	forall_nodes( cur_node, *ledagraph ) {
		new_ninfo = new node_info();
		// We use nodewidth as size
		new_ninfo->SetRadius( (int)g.gt(cur_node).graphics()->w()/2 );
		new_node = the_graph->new_node();
		(*Myn2GR)[new_node] = cur_node;
		GRn2MY[cur_node] = new_node;
		the_graph->assign( new_node, new_ninfo );
	}

	forall_edges( cur_edge, *ledagraph ) {
		if( ledagraph->source(cur_edge) != ledagraph->target(cur_edge) )
		{
			new_einfo = new edge_info();
			new_einfo->SetCapacity( MAX(1, atol(g.gt(cur_edge).label())) );
			//get source and target in the new graph
			source = GRn2MY[ledagraph->source(cur_edge)];
			target = GRn2MY[ledagraph->target(cur_edge)];
			new_edge = the_graph->new_edge(source, target);
			(*Mye2GR)[new_edge] = cur_edge;
			the_graph->assign( new_edge, new_einfo );
			clear_gt_line( g, cur_edge );
		}
	}
}

//-----------------------------------------------------------------------------
// This function is called to recompute the nodepositions of all sons of a
// node, which got a new position. (eg. in MinimizeNodes)
//-----------------------------------------------------------------------------

void  HiSpring::MoveAllSonsBack ( adv_node_set *head, float_vec displace )
{
  node         n;
  node_info    *n_info;

  if( NULL == head ) return;
  fornodes_in_set( head, n )
  {
    n_info = the_graph->inf(n);
    n_info->AddX( -displace.x ); 
    n_info->AddY( -displace.y );
    MoveAllSonsBack( n_info->GetSons(), displace );
  }
}

//------------------------------------------------------------------------------
// We use a very good function to compute the optimal distances between the
// nodes of a group for force-computation by kamada. So we only have a interface
// to this function.
//------------------------------------------------------------------------------

double HiSpring::GetLongestPath( adv_node_set *sons )
{
  DistanceField    *distances;
  adv_node_set     nodes( the_graph ), neighbors( the_graph );
  node             n;
  double           l_opt, max_radius, max_dist, akt_dist, r;
  int              i;

  max_radius = 0.0;
  fornodes_in_set( sons, n )
  {
    nodes.insert( n );
    max_radius = MAX( max_radius, the_graph->inf(n)->GetRadius() );
  }
  if( the_edgelen == VARIABLE )      l_opt = MAX( ELEN, max_radius );
  else                               l_opt = ELEN;

  max_dist = 0;
  fornodes_in_set( sons, n )
  {
    nodes.del(n);
    r = the_graph->inf(n)->GetRadius();
    distances = ComputeShortestPathWithNodesizes_KAM(the_graph, n,
		&nodes, &neighbors, l_opt );
    for( i = 0; i < distances->size; i++ )
    {
      akt_dist = distances->GetDistance( i ) + r + 
	         the_graph->inf(distances->GetNode(i))->GetRadius();
      max_dist = MAX( max_dist, akt_dist );
    }
    distances->~DistanceField();
    nodes.insert(n);
  }
  return( max_dist );
}

//------------------------------------------------------------------------------
// Hier werden die Groessen der Knoten, die noch expandiert werden
// sollen, ausgerechnet.
// Gehe dabei bottom up durch den Baum und berechne aus der Groesse der Soehne
// die Gr"o"se der V"ater. Dabei wird die Funktion verwendet, die f""ur eine
// Gruppe von Knoten die Optimalabst"ande gem"a"s Kamada-Kr"afteberechnung 
// berechnet.
//------------------------------------------------------------------------------

void HiSpring::ComputeNodesizes( adv_node_set *root_elems )
{
  node               n;
  node_info          *n_info;
  
  if( NULL == root_elems ) return;

  fornodes_in_set( root_elems, n )  ComputeNodesizes( the_graph->inf(n)->GetSons() );

  // Schaue dir die Soehne an und berechne daraus Knotengroesse
  fornodes_in_set( root_elems, n )
  {
    n_info = the_graph->inf(n);
    if( NULL != n_info->GetSons() )
    {
      //get the_longest path in sons
      n_info->SetRadius( (long int)(GetLongestPath(n_info->GetSons()) * 0.60) );
    }
  }
}

//-----------------------------------------------------------------------------
// Muesste jetzt (fast) ueberfluessig sein
//-----------------------------------------------------------------------------

bool IsFather( node father, node_info *son, GRAPH_TYPE *g )
{
  if( NULL == son->GetFather(g) )    return( FALSE );
  if( father == son->GetGraphFather() )  return( TRUE );
  return( IsFather(father, son->GetFather(g), g) );
}

void HiSpring::gtline_add_second( GT_Graph& g, edge ledaedge, int x, int y )
{
	list<GT_Point>  gt_line;
	GT_Point        point;

	point.x( x );
	point.y( y );
	
	gt_line = g.gt((*Mye2GR)[ledaedge]).graphics()->line();

	gt_line.insert( point, gt_line.first(), after );
	g.gt((*Mye2GR)[ledaedge]).graphics()->line(gt_line);
}

void HiSpring::gtline_add_beforelast( GT_Graph& g, edge ledaedge, int x, int y )
{
	list<GT_Point>  gt_line;
	GT_Point        point;

	point.x( x );
	point.y( y );
	gt_line = g.gt((*Mye2GR)[ledaedge]).graphics()->line();

	gt_line.insert( point, gt_line.last(), before );
	g.gt((*Mye2GR)[ledaedge]).graphics()->line(gt_line);
}

void HiSpring::clear_gt_line( GT_Graph& g, edge ledaedge )
{
	list<GT_Point>  gt_line;
	// delete all elements except the first and last
	gt_line = g.gt(ledaedge).graphics()->line();
	while ( gt_line.length() > 2 ) {
		gt_line.del_item( gt_line.succ( gt_line.first() ) );
	}
	g.gt(ledaedge).graphics()->line(gt_line);
}

void HiSpring::SetLayout(GT_Graph& g)
{
	node             cur_node, target_node, iso_node;
	graph            *ledagraph;
	tree_edge        *cur_edge;
	list<edge>       *graph_edge_set;
	edge             graph_edge;
	node_info        *cn_info, *ges_info ;
	int              cn_x, cn_y, cn_r, ges_x, ges_y, cur_level;
	adv_node_set    *cur_set;

	// setup pointers to nodes which we don't have,
	// because we have created new nodes.
	// Also set all nodeattributes which we need.
	// If we have corresponding nodes make an update of attributes.
	
	ledagraph = g.the_graph;
  
	forall_nodes( cur_node, *the_graph ) {
		if( the_graph->inf(cur_node)->GetIsHierarchie() == TRUE ) {
			if( show_hierarchie == TRUE ) {
				// Create a new node
				iso_node = ledagraph->new_node();
				g.gt(iso_node).graphics()->w(
					(float)the_graph->inf(cur_node)->GetRadius()*2 );
				g.gt(iso_node).graphics()->h(
					(float)the_graph->inf(cur_node)->GetRadius()*2 );
				g.gt(iso_node).graphics()->x(
					(float)the_graph->inf(cur_node)->GetX()+20 );
				g.gt(iso_node).graphics()->y(
					(float)the_graph->inf(cur_node)->GetY()+20 );
				g.gt(iso_node).graphics()->type( GT_Keys::type_oval );
			}
		} else {
			// Get the isomorphic
			iso_node = (*Myn2GR)[cur_node];
			// And set the attributes
			g.gt(iso_node).graphics()->w(
				(float)the_graph->inf(cur_node)->GetRadius()*2 );
			g.gt(iso_node).graphics()->h(
				(float)the_graph->inf(cur_node)->GetRadius()*2 );
			g.gt(iso_node).graphics()->x(
				(float)the_graph->inf(cur_node)->GetX()+20 );
			g.gt(iso_node).graphics()->y(
				(float)the_graph->inf(cur_node)->GetY()+20 );
			g.gt(iso_node).graphics()->type( GT_Keys::type_oval );
		}
	}


	if( unite_edges ) {
		cur_level = -1;
		while( UNDEF != (cur_level = levels->GetNextLevel(cur_level)) ) {
			while( NULL != (cur_set = levels->GetNextSet(cur_level)) ) {
				fornodes_in_set( cur_set, cur_node ) {
					cn_info = the_graph->inf( cur_node );
					if( cn_info->GetIsHierarchie() ) {
						cn_x    = (scalar)cn_info->GetX();
						cn_y    = (scalar)cn_info->GetY();
						cn_r    = cn_info->GetRadius();
						forall( cur_edge, *(the_graph->inf(cur_node)->GetEdges()) ) {
							target_node = TREE_EDGE_GET_OTHER_NODE(
								cur_edge, cn_info, the_graph );
							if( (the_graph->inf(cur_node)->GetLevel() ==
								the_graph->inf(target_node)->GetLevel()) ||
								(!the_graph->inf(target_node)->GetIsHierarchie() && 
									the_graph->inf(cur_node)->GetLevel() >
									the_graph->inf(target_node)->GetLevel()) )
							{
								graph_edge_set = cur_edge->corresponding_edges;
								forall( graph_edge, *graph_edge_set ) {
									ges_info = the_graph->inf(
										the_graph->source(graph_edge));
									ges_x = (scalar)ges_info->GetX();
									ges_y = (scalar)ges_info->GetY();

									// Wir tragen immer von dem Knoten aus ein,
									// der unter cur_node liegt
									if( IsFather(cur_node, ges_info, the_graph) ) {
										gtline_add_second(g, graph_edge,
											cur_edge->place_on_border.x+20,
											cur_edge->place_on_border.y+20 );
									} else {
										gtline_add_beforelast(g, graph_edge,
											cur_edge->place_on_border.x+20,
											cur_edge->place_on_border.y+20 );
									}
								}
							}
						}	    
					}
				}
			}
		}
	}
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void     HiSpring::ComputePlacesOnBorder()
{
  node_info   *n_info, *tn_info;
  node        cur_node, target_node;
  tree_edge   *cur_edge;
  double      alpha, x_pos, y_pos, radius;

  forall_nodes( cur_node, *the_graph )
  {
    n_info = the_graph->inf( cur_node );
    radius = n_info->GetRadius();
    x_pos  = n_info->GetX();
    y_pos  = n_info->GetY();
    forall( cur_edge, *n_info->GetEdges() )
    {
      target_node = TREE_EDGE_GET_OTHER_NODE( cur_edge, n_info, the_graph );
      tn_info = the_graph->inf( target_node );
 
      // Punkte am Rand setzen!!!!!!!
      if( (tn_info->GetY()-y_pos != 0.0) || (tn_info->GetX()-x_pos != 0.0) )
      {
	alpha = atan2( tn_info->GetY()-y_pos, tn_info->GetX()-x_pos );
	cur_edge->place_on_border.x = (scalar)( cos(alpha) * radius + x_pos );
	cur_edge->place_on_border.y = (scalar)( sin(alpha) * radius + y_pos );
      }
    }
  }
}

//------------------------------------------------------------------------------
// Funktioniert in drei Phasen (rekursiv)
// 1. Verkleinere Knoten eines ganzen Set
// 2. Berechne das Layout des Set neu
// 3. Verschiebe die Soehne gemaes der Verschiebung durch das Layouten der Vaeter
// Dabei muss so vorgegangen werden: Fange an den Soehnen eines Knoten an und
// verkleinere seine Kinder und dann ihn selbst. Danach layoute die eigene Stufe.
// Es gilt dann: von den Soehnen wurde ein neues Layout berechnet. Wenn die Wurzel
// erreicht ist, muessen alle Positionsaenderungen (aufaddiert) an die Kinder
// Weitergegeben werden.
//------------------------------------------------------------------------------

void  HiSpring::MoveNodesBack ( adv_node_set *head, float_vec displace )
{
  node         n;
  node_info    *n_info;
  float_vec    new_displace;

  if( NULL == head ) return;

  fornodes_in_set( head, n )
  {
    n_info = the_graph->inf(n);
    n_info->SetX( n_info->GetX() - displace.x); 
    n_info->SetY( n_info->GetY() - displace.y);
    new_displace.x = (n_info->GetOldX() - n_info->GetX());
    new_displace.y = (n_info->GetOldY() - n_info->GetY());

    if( NULL != n_info->GetSons() ) MoveNodesBack( n_info->GetSons(), new_displace );
  }
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void  HiSpring::ReduceGraph()
{
	double    UPPER_BOUND  = 1000;
	double    scale;
	node      cur_node, cn;
	node_info *n_info, *n_i;;
	double    x_max, y_max, d_x, d_y;

	if( show_hierarchie == FALSE ) {
		x_max = 0.0; y_max = 0.0;
		d_x = 100000.0; d_y = 100000.0;
		forall_nodes( cur_node, *the_graph ) {
			n_info = the_graph->inf( cur_node );
			if( n_info->GetIsHierarchie() == FALSE ) {
				d_x = MIN( d_x, n_info->GetX()-n_info->GetRadius() );
				d_y = MIN( d_y, n_info->GetY()-n_info->GetRadius() );

				forall_nodes( cn, *the_graph ) {
					n_i = the_graph->inf( cn );
					if( n_i->GetIsHierarchie() == FALSE ) {
						x_max = MAX( x_max,
							ABS(n_i->GetX()-n_info->GetX())+ n_i->GetRadius()+
							n_info->GetRadius() );
						y_max = MAX( y_max,
							ABS(n_i->GetY()-n_info->GetY())+ n_i->GetRadius()+
							n_info->GetRadius() );
					}
				}
			}
		}
		scale = MAX(x_max, y_max) / 1600.0;
		if( scale > 1.0 ) {
			forall_nodes( cur_node, *the_graph ) {
				n_info = the_graph->inf( cur_node );
				//n_info->SetRadius( MAX( 8, (int)((double)n_info->GetRadius()/scale)) );
				n_info->SetX     ( (n_info->GetX() - d_x)/scale );
				n_info->SetY     ( (n_info->GetY() - d_y)/scale );
			}
		} else
		{
			forall_nodes( cur_node, *the_graph ) {
				n_info = the_graph->inf( cur_node );
				n_info->SetX     ( n_info->GetX() - d_x );
				n_info->SetY     ( n_info->GetY() - d_y );
			}
		}

		return;
	}
	if( the_graph->inf( hierarchie->choose() )->GetRadius() > UPPER_BOUND ) {
		scale = the_graph->inf( hierarchie->choose() )->GetRadius() / UPPER_BOUND;
		forall_nodes( cur_node, *the_graph ) {
			n_info = the_graph->inf( cur_node );
			n_info->SetRadius( MAX( 8, (int)((double)n_info->GetRadius()/scale)) );
			n_info->SetX     ( n_info->GetX()/scale );
			n_info->SetY     ( n_info->GetY()/scale );
		}
	}
}

//------------------------------------------------------------------------------
// Algorithmus von Elzinga und Hearn. Loest Problem optimal in O(n*h^3), wobei
// h die Anzahl der Stuetzstellen des einbeschreibenden Polynoms ist.
// Es wird am Schluss auf den Radius noch eine kleine Sicherheitsreseve aufaddiert.
// Es wird hier KEINE Ruecksicht auf die Knotenradien genommen. Am Schluss wird
// der maximale Radius der Stuetzknoten des Vaterkreises auf den Vaterradius 
// aufaddiert. Was hier zuviel gemacht wird, zaehlt zur Sicherheitsreserve.
//------------------------------------------------------------------------------

void  HiSpring::ReduceNode( node father )
{
  adv_node_set    *sons;
  float_vec       pos;
  long int        i, max_rad, rad;
  struct kreis    kr;
  node            n;
  node_info       *n_info;
  GRAPH_TYPE      *g = the_graph;

  sons = g->inf(father)->GetSons();
  if( NULL == sons ) return;

  if( 1 == sons->size() )
  {
    g->inf(sons->choose())->SetX( g->inf(father)->GetX() );
    g->inf(sons->choose())->SetY( g->inf(father)->GetY() );
    g->inf(father)->SetRadius( g->inf(sons->choose())->GetRadius()+8 );
    return;
  }

  Anzahl_der_Punkte = sons->size()*4;

  pu=belege_Speicher_fuer_punkt( Anzahl_der_Punkte*4+1);
  i = 1;
  max_rad = 0;
  fornodes_in_set( sons, n )
  {
    n_info = g->inf( n );
    rad    = n_info->GetRadius();
    pos.x  = n_info->GetX();
    pos.y  = n_info->GetY();

    pu[i].x = pos.x + rad;
    pu[i].y = pos.y;

    pu[i+1].x = pos.x;
    pu[i+1].y = pos.y + rad;

    pu[i+2].x = pos.x - rad;
    pu[i+2].y = pos.y;

    pu[i+3].x = pos.x;
    pu[i+3].y = pos.y - rad;
    i+= 4;
    max_rad = MAX( max_rad, rad );
  }
  opt_Wert=100000000;

  kr=elzinga_hearn_algorithmus();
  free (pu);
  g->inf(father)->SetRadius( (long int)(kr.radius *1.10) + (int)(max_rad*0.2) );
  g->inf(father)->SetX( kr.mp.x );
  g->inf(father)->SetY( kr.mp.y );
}
  
//------------------------------------------------------------------------------
// Erspart eine komplizierte if-abfrage. Schaut nach, ob der Knoten gelayoutete
// Soehne hat und ob dem Knoten ueberhaupt schon eine Position zugewiesen wurde.
//------------------------------------------------------------------------------

int  IsInBorder( node_info *n_info, node_info *father_inf,
		 GRAPH_TYPE *g )
{

  if( n_info->GetLayouted() == FALSE ) return( FALSE );
  if( n_info->GetLevel() == father_inf->GetLevel()+1 ) return(TRUE );

  if( n_info->GetSons() == NULL ) return( TRUE );
  return( (!g->inf(n_info->GetSons()->choose())->GetLayouted()) );

  
//   if( LAST_LAYOUTED == what_border )
//   {
// //    return( (n_info->GetLevel() == father_inf->GetLevel()) );
//      if( n_info->GetLayouted() == FALSE ) return( FALSE );
//      if( n_info->GetSons() == NULL ) return( TRUE );
//      return( (!g->inf(n_info->GetSons()->choose())->GetLayouted()) );
//   }

//   return( (n_info->GetLevel() == father_inf->GetLevel()+1) );
}

//------------------------------------------------------------------------------
// Berechnet den Rand der neu zu zeichnenden Gruppe und macht 
// dort alle Vorinitialisierungen. Diese Berechnet fuer Layoutalgorithmus 1 UND 2.
// Der einzige Unterschied ist, welche Knoten in den Rand kommen.
// Und bei der zweiten Alternative muessen Punkte fuer Kantenverlaeufe 
// berechnet werden.
//------------------------------------------------------------------------------

void HiSpring::ComputeBorderNodes( node_info *father_inf, int /*what_border*/ )
{
  node        target_node;
  tree_edge   *cur_edge;
  node_info   *tn_info;
  scalar      father_radius;
  double      father_x, father_y, min_distance, max_distance;
  double      alpha, dist, distance;

  if( !father_inf )   return;

  min_distance  = 10000000000.0;
  max_distance  = UNDEF;
  father_x      = father_inf->GetX();
  father_y      = father_inf->GetY();
  father_radius = father_inf->GetRadius();

  forall( cur_edge, *father_inf->GetEdges() )
  {
    target_node = TREE_EDGE_GET_OTHER_NODE( cur_edge, father_inf, the_graph );
    tn_info = the_graph->inf( target_node );
    if( IsInBorder(tn_info, father_inf, the_graph) )
    {
      distance = sqrt( SQR(tn_info->GetY()-father_y) + SQR(tn_info->GetX()-father_x) );
      min_distance = MIN( min_distance, distance );
      max_distance = MAX( max_distance, distance );
      border_nodes->insert( target_node );
    }
  }
  if( min_distance == max_distance ) min_distance = min_distance/2;
  fornodes_in_set( border_nodes, target_node )
  {
    // Skalierte Koordinaten ausrechnen
    tn_info = the_graph->inf( target_node );
    distance = sqrt( SQR(tn_info->GetY()-father_y) + SQR(tn_info->GetX()-father_x) );
    dist     = (distance - min_distance)/(max_distance-min_distance);
    alpha    = atan2( tn_info->GetY()-father_y, tn_info->GetX()-father_x );
    tn_info->SetScaledX( cos(alpha)*(father_radius+ELEN*(0.5 + dist/4))+father_x );
    tn_info->SetScaledY( sin(alpha)*(father_radius+ELEN*(0.5 + dist/4))+father_y );
  }
}

//------------------------------------------------------------------------------
// Setze die Knoten entsprechend  den Kanten, die von aussen
// an ihnen ziehen, falls solche existieren. Wenn nicht, dann zufaellig in einer  
// Kugel um den Knotenmittelpunkt
// Rechne dazu einen Richtungvektor der externen Kanten aus und platziere in  
// kleinem Abstand vom Ersetzungsknotenrand.
//------------------------------------------------------------------------------

void  HiSpring::PresetCoordinates( node_info *father_inf, adv_node_set *cur_set )
{
  node           n, target_node;
  node_info      *n_info, *tn_info;
  double         father_x, father_y, father_size;
  float_vec     impulse, displace;
  tree_edge      *cur_edge;
  double         norm_dist, s;
  double         alpha;

  if( !father_inf )
  {
    n_info = the_graph->inf(cur_set->choose());
    n_info->SetX( n_info->GetRadius() );
    n_info->SetY( n_info->GetRadius() );
    return;
  }

  father_x      = father_inf->GetX();
  father_y      = father_inf->GetY();
  father_size   = father_inf->GetRadius();

  if( border_nodes->empty() == FALSE )
  {
	  fornodes_in_set( cur_set, n ) {
		  n_info = the_graph->inf(n);
		  impulse.x = 0;
		  impulse.y = 0;
		  forall( cur_edge, *(n_info->GetEdges()) )
      {
	target_node = TREE_EDGE_GET_OTHER_NODE( cur_edge, n_info, the_graph );
 	tn_info = the_graph->inf( target_node );

	if( border_nodes->member(target_node) )
	{  
	  displace.x = (father_x - tn_info->GetScaledX()) / 10;
	  displace.y = (father_y - tn_info->GetScaledY()) / 10;
	  norm_dist = MIN( QNORM (displace.x, displace.y),64*ELENSQR );
	  impulse.x -= (cur_edge->edge_number * ( displace.x * norm_dist / ELENSQR ));
	  impulse.y -= (cur_edge->edge_number * ( displace.y * norm_dist / ELENSQR ));
	}
      }
      if( impulse.x == 0 && impulse.y == 0 )
      {
	n_info->SetX( (rand()%1000) * (father_size/2) / 1000 - (father_size/4) + father_x );
	n_info->SetY( (rand()%1000) * (father_size/2) / 1000 - (father_size/4) + father_y );
      }
      else
      {
	alpha = atan2( impulse.y, impulse.x );
	n_info->SetX( cos(alpha)*( father_size*0.75 ) + father_x );
	n_info->SetY( sin(alpha)*( father_size*0.75 ) + father_y );
      }
      actual_nodes->insert( n );
    }
    return;
  }

  // Setze restliche Knoten
  if( cur_set->size() == 2 )
  {
    s = -1;
    fornodes_in_set( cur_set, n )
    {
      n_info = the_graph->inf(n);
      n_info->SetY( father_y - (s*(ELEN/2 + n_info->GetRadius())) );
      n_info->SetX( father_x );
      s = s+2;
      actual_nodes->insert( n );
     }
    return;
  }

  fornodes_in_set( cur_set, n )
  {
    n_info = the_graph->inf(n);
    n_info->SetX( (rand()%1000) * father_size / 1000 - father_size/2 + father_x );
    n_info->SetY( (rand()%1000) * father_size / 1000 - father_size/2 + father_y );
    actual_nodes->insert( n );
  }
}

