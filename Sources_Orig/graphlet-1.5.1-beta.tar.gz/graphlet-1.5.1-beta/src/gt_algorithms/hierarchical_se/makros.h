//
// Datei mit den Makros
//

#define SQR( x )                    ((double)(x)*(double)(x))
#define	NORM2(x,y)	            (sqrt( SQR((x)) + SQR((y)) ))
#define	QNORM(x,y)	            (SQR((x))+SQR((y)))
#define	MIN(x,y)	            ((x)<(y)?(x):(y))
#define	MAX(x,y)	            ((x)>(y)?(x):(y))
#define	ABS(x)		            ((x)<0?-(x):(x))
#define SIGN(x)                     ((x)<0?-1:1)
#define TREE_EDGE_GET_OTHER_NODE( te, sn, gr )          \
       ( ((gr)->inf((te)->source) == (sn))?(te)->target:(te)->source )



// #define forall_neighbor_nodes(u,v)\
// for(LEDA::loop_dummy = 0; LEDA::loop_dummy < 1; LEDA::loop_dummy++)\
// for(int adj_loop_index = 1; adj_loop_index>=0; adj_loop_index--)\
// for(edge adj_loop_e = First_Adj_Edge(v,adj_loop_index);\
// (adj_loop_e!=Leda_Nil_Edge(adj_loop_index))&&((u=opposite(v,adj_loop_e))||1);\
// adj_loop_e = Succ_Adj_Edge(adj_loop_e,adj_loop_index))

// #define forall_neighbor_nodes(u,v) forall_adj_nodes ((u),(v))

#define forall_neighbor_nodes(u,v)\
if (0); else \
for(int HSEleda_adj_index = 0; HSEleda_adj_index<2; HSEleda_adj_index++)\
for(edge HSEleda_adj_loop_e = First_Adj_Edge(v,HSEleda_adj_index);\
(HSEleda_adj_loop_e != nil) && ((u=opposite(v,HSEleda_adj_loop_e))||1);\
HSEleda_adj_loop_e = Succ_Adj_Edge(HSEleda_adj_loop_e,v))

// #define forall_inout_edges(e,v)\
// if (0); else \
// for(int leda_adj_index = 0; leda_adj_index<2; leda_adj_index++)\
// for(e = First_Adj_Edge(v,leda_adj_index); e != nil;\
// e = Succ_Adj_Edge(e,(v==terminal(e,leda_adj_index) ? leda_adj_index : 1-leda_adj_index)))
