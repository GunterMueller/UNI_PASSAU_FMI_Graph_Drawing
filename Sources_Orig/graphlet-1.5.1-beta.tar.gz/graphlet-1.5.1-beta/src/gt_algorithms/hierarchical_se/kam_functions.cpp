//
// compute_coordinates.cc
//

#include "hispring.h"

extern scalar     temperature;
extern long int   max_temp;

extern float_vec  node_center;
extern double     optedgelen;
extern double     ext_scale_down;

extern double   center_scale;
extern int  IsInBorder( node_info *n_info, node_info *father_inf, GRAPH_TYPE *g );
extern void displace_fn ( node cur_node, float_vec impulse, GRAPH_TYPE *g, int nr_nodes );
void   ComputeDistancesForGroup_KAM(  GRAPH_TYPE *g, adv_node_set *group, adv_node_set *neighbors, double l_opt );

//------------------------------------------------------------------------------
// Bottom -Up Verfahren (Vor einem Knoten werden seine S"ohne verkleinert)
// Berechnet f"ur jeden Knoten mit S"ohnen den Minimalen Kreis f"ur seine S"ohne
// L"a"st dann "uber die S"ohne den Layoutalg. und verkleinert dann den Vater
//------------------------------------------------------------------------------

void  HiSpring::ReduceAllNodes_KAM( adv_node_set *head )
{
  node         n;
  node_info    *n_info, *father_inf;
  int          s, max_radius, has_sons;;
  adv_node_set buf( the_graph ), buf2( the_graph );
  float_vec    null_impulse;
  double       l_opt;

  if( NULL == head ) return;
    
  max_radius = the_graph->inf(head->choose())->GetRadius();
  null_impulse.x = 0.0;
  null_impulse.y = 0.0;
  has_sons = FALSE;

  fornodes_in_set( head, n )
  {
    n_info = the_graph->inf(n);
    if( NULL != n_info->GetSons() )
    {
      ReduceAllNodes_KAM( n_info->GetSons() );
      ReduceNode( n );
      has_sons = TRUE;
    }
    max_radius = MAX( max_radius, n_info->GetRadius() );
  }

  if( the_edgelen != VARIABLE )      l_opt = ELEN;
  else            	             l_opt = MAX( ELEN, max_radius );

  actual_nodes = &buf;
  border_nodes = &buf2;
  fornodes_in_set( head, n )
  {
    the_graph->inf(n)->SetHeat(max_radius/4);
    the_graph->inf(n)->SetImpulse(null_impulse);
    the_graph->inf(n)->CopyPosToOldPos();
    actual_nodes->insert(n);
  }

  // compute the new layout
  father_inf = the_graph->inf(head->choose())->GetFather(the_graph);
  if( NULL == father_inf )
  {
    n_info = the_graph->inf(head->choose());
    n_info->CopyPosToOldPos();
    n_info->SetX( n_info->GetRadius() );
    n_info->SetY( n_info->GetRadius() );
    return;
  }

  if( TRUE == has_sons )
  {
    ComputeBorderNodes( father_inf, LAST_LAYOUTED );
    if( (actual_nodes->size() != 2) || (border_nodes->empty() == FALSE) )
    {
      ComputeDistancesForGroup_KAM(  the_graph, actual_nodes, border_nodes, l_opt );
      if( TRUE == force_GEM ) FinetuneCoordinates  ( father_inf->GetRadius(), father_inf->GetCenter() );
      else                    ComputeGroupLayout_KAM( father_inf->GetRadius(), father_inf->GetCenter() );
    }
    else
    {
      s = -1;
      fornodes_in_set( actual_nodes, n )
      {
	n_info = the_graph->inf(n);
	n_info->SetY( father_inf->GetY() - (s*(ELEN/2 + n_info->GetRadius())) );
	s = s+2;
      }
    }
  }
}

//------------------------------------------------------------------------------
// DIE Funktion, die die neuen Koordinaten berechnet.
// Gehe durch alle Hierarchiestufen und dort durch alle node_sets
// Berechne die Koordinaten der aktuellen Menge
// Gilt sowohl fuer Feintuning als auch fuer grobe Vorberechnung
//------------------------------------------------------------------------------

void HiSpring::ComputeLayout_KAM( int what_algorithm, int heat )
{
  adv_node_set *cur_set, buff( the_graph ), buff2( the_graph );
  node         n;
  node_info    *father_inf, *n_info;
  int          cur_level;
  float_vec    node_center, null_vec;
  float_vec    displace;

  null_vec.x   = 0.0;
  null_vec.y   = 0.0;
  cur_level    = -1;
  actual_nodes = &buff;
  border_nodes = &buff2;
  while( UNDEF != (cur_level = levels->GetNextLevel(cur_level)) )
  {
    while( NULL != (cur_set = levels->GetNextSet(cur_level)) )
    {
      father_inf = (the_graph->inf(cur_set->choose()))->GetFather(the_graph);
      ComputeBorderNodes( father_inf, LAST_LAYOUTED );
      if( what_algorithm == PRESET )  PresetCoordinates( father_inf, cur_set );
      fornodes_in_set( cur_set, n ) 
      {
	the_graph->inf(n)->SetImpulse( null_vec );
	the_graph->inf(n)->SetDir( 0 );
	the_graph->inf(n)->SetHeat( heat );
	the_graph->inf(n)->CopyPosToOldPos();
	actual_nodes->insert( n );
      }
      if( father_inf && !((actual_nodes->size() == 2) && (border_nodes->empty() == TRUE)) ) 
      {
	node_center = father_inf->GetCenter();
	ComputeGroupLayout_KAM  ( father_inf->GetRadius(), node_center );
	if( what_algorithm == FINETUNE )
	{
	  fornodes_in_set( cur_set, n )
	  {
	    n_info = the_graph->inf(n);
	    displace.x = n_info->GetOldX() - n_info->GetX();
	    displace.y = n_info->GetOldY() - n_info->GetY();
	    MoveAllSonsBack( n_info->GetSons(), displace );
	  }
	}
      }
      // Setzen, dass die Knoten gelayoutet wurden
      fornodes_in_set( cur_set, n )  the_graph->inf(n)->SetLayouted( TRUE );
      actual_nodes->clear();
      border_nodes->clear();
    }
  }
}

//------------------------------------------------------------------------------
// Berechnet f"ur eine Gruppe von Knoten die k"urzesten Wege von ihnen zu  source.
// Dabei werden alle Knotenradien mit ber"ucksichtigt.
// Gibt es keinen Pfad zu dem Knoten, wird als optimaler Abstand der Maximalabstand
// eingetragen.
// source MUSS vorher aus group entfernt werden
//------------------------------------------------------------------------------

DistanceField  *ComputeShortestPathWithNodesizes_KAM( GRAPH_TYPE *g,
   node source, adv_node_set *group, adv_node_set *neighbors, double l_opt )
{
  node          n, target_node, n_min;
  int           size, i;
  double        sum, sum_min, old_dist;
  node_info     *t_info;
  adv_node_set  nodes(g);
  tree_edge     *cur_edge;
  node_array<int>  node2int( *g );

  DistanceField   *distance_field;
  array<node>     *node_field;
  array<double>   *distances;
  array<bool>     *is_border;
  array<bool>     *has_edge;
  array<int>      *capacity;

  size = group->size() + neighbors->size();

  node_field     = new array<node>(size);
  distances      = new array<double>(size);
  is_border      = new array<bool>(size);
  has_edge       = new array<bool>(size);
  capacity       = new array<int>(size);
  distance_field = new DistanceField( node_field, distances, is_border, has_edge, capacity, size );
  i = 0;
  fornodes_in_set( group, n )
  {
    (*node_field)[i] = n;
    (*distances) [i] = UNDEF;
    (*is_border) [i] = FALSE;
    (*has_edge)  [i] = FALSE;
    node2int[n]      = i;
    i++;
    nodes.insert( n );
  }
  fornodes_in_set( neighbors, n )
  {
    (*node_field)[i] = n;
    (*distances)[i]  = UNDEF;
    (*is_border)[i]  = TRUE;
    (*has_edge)  [i] = FALSE;
    node2int[n]      = i;
    i++;
    nodes.insert( n );
  }
  // Now compute distances

  forall( cur_edge, *(g->inf(source)->GetEdges()) )
  {
    target_node = TREE_EDGE_GET_OTHER_NODE( cur_edge, g->inf(source), g );
    t_info = g->inf( target_node );

    if(  TRUE == group->member(target_node) )
    {
      sum = l_opt + g->inf(source)->GetRadius() + t_info->GetRadius();
      (*distances)[node2int[target_node]] = sum;
      (*has_edge)[node2int[target_node]]  = TRUE;
      (*capacity)[node2int[target_node]]  = cur_edge->edge_number;
    }
    if(  TRUE == neighbors->member(target_node) )   
    {
      sum = l_opt + g->inf(source)->GetRadius();
      (*distances)[node2int[target_node]] = sum;
      (*has_edge)[node2int[target_node]]  = TRUE;
      (*capacity)[node2int[target_node]]  = cur_edge->edge_number;
    }
  }
  // Aufpassen, falls source keine Nachbarn in der Gruppe hat
  n_min = source;

  while( FALSE == nodes.empty() )
  {
    sum_min = UNDEF;
    fornodes_in_set( &nodes, n )
    {
      if( UNDEF != (*distances)[node2int[n]] )
      {
	if( (sum_min == UNDEF) || (sum_min > (*distances)[node2int[n]]) )
	{
	  sum_min = (*distances)[node2int[n]];
	  n_min = n;
	}
      }
    }

    if( UNDEF == sum_min )
    {
      // Problem: Der Graph ist NICHT zusammenhaengend
      // Also suchen wir uns einen der restlichen Knoten aus, der kriegt eine Pseudokante zu n_min,
      // der ja noch nicht geaendert wurde
      CreateTreeEdge( new list<edge>(), n_min, nodes.choose(), g );
	  
    }


    nodes.del( n_min );

    forall( cur_edge, *(g->inf(n_min)->GetEdges()) )
    {
      target_node = TREE_EDGE_GET_OTHER_NODE( cur_edge, g->inf(n_min), g );
      if( TRUE == nodes.member(target_node) )
      {
	t_info = g->inf( target_node );

	if(  TRUE == group->member(target_node) )
        {
	  sum = l_opt + g->inf(n_min)->GetRadius() + t_info->GetRadius();
	  if( n_min == source )     old_dist = 0;
	  else                      old_dist = (*distances)[node2int[n_min]];
	  if( (*distances)[node2int[target_node]] != UNDEF )
	  {
	    (*distances)[node2int[target_node]] = MIN( sum + old_dist, 
						       (*distances)[node2int[target_node]]);
	  } else {
	    (*distances)[node2int[target_node]] = sum + old_dist;
	  }
	}
	if(  TRUE == neighbors->member(target_node) )   
	{
	  sum = l_opt + g->inf(n_min)->GetRadius();
	  if( n_min == source )     old_dist = 0;
	  else                      old_dist = (*distances)[node2int[n_min]];
	  if( (*distances)[node2int[target_node]] != UNDEF )
	  {
	    (*distances)[node2int[target_node]] = MIN( sum + old_dist, 
						       (*distances)[node2int[target_node]]);
	  } else {
	    (*distances)[node2int[target_node]] = sum + old_dist;
	  }
	  // We don't search from nodes from border
	  nodes.del( target_node );
	}
      }
    }
  }
  return( distance_field );
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void  ComputeDistancesForGroup_KAM(  GRAPH_TYPE *g,
   adv_node_set *group, adv_node_set *neighbors, double l_opt )
{
  list<node>  nodes;
  node        n;

  fornodes_in_set( group, n )   nodes.append( n );

  forall( n, nodes )
  {
    group->del(n);
    if( NULL != g->inf(n)->GetDistChart() )
    {
	g->inf(n)->GetDistChart()->~DistanceField();
    }

    //TreeOut2( hierarchie, g );

    g->inf(n)->SetDistChart( ComputeShortestPathWithNodesizes_KAM(g, n, group, neighbors, l_opt) );

    //TreeOut2( hierarchie, g );

    group->insert(n);
  }
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void HiSpring::ComputeDistChartsForTree_KAM()
{
	int           cur_level = -1;
	adv_node_set  *cur_set;
	adv_node_set  border( the_graph );
	node_info     *father_inf, *tn_info;
	tree_edge     *cur_edge;
	node          target_node, n;
	double        l_opt, r_max;

	while( UNDEF != (cur_level = levels->GetNextLevel(cur_level)) ) {
		while( NULL != (cur_set = levels->GetNextSet(cur_level)) ) {
			father_inf = (the_graph->inf(cur_set->choose()))
				->GetFather(the_graph);
			if( father_inf ) {
				forall( cur_edge, *father_inf->GetEdges() ) {
					target_node = TREE_EDGE_GET_OTHER_NODE(
						cur_edge, father_inf, the_graph );
					tn_info = the_graph->inf( target_node );
					if( IsInBorder(tn_info, father_inf, the_graph) ) {
						border.insert( target_node );
					}
				}
	
				if( the_edgelen != VARIABLE ) {
					l_opt = ELEN;
				}else {
					r_max = 0;
					fornodes_in_set( cur_set, n )  {
						r_max = MAX( r_max, (the_graph->inf(n))->GetRadius() );
					}
					l_opt = MAX( ELEN, r_max );
				}
				ComputeDistancesForGroup_KAM( the_graph, cur_set, &border, l_opt );
				border.clear();
			}
		}
	}
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

float_vec ComputeImpulse_KAM (
    node cur_node,
    adv_node_set* /* set1 */, 
    adv_node_set* /* border_nodes */,
    GRAPH_TYPE* my_graph)
{
  node                  target_node;
  node_info             *cn_info, *tn_info; //Uebergebener Knoten 
  register double       norm_dist;
  register float_vec    impulse, cn_position, displace;
  double                dist_opt, dist_rad, capacity;
  int                   i;
  bool                  is_border;
  DistanceField         *df;

  cn_info       = my_graph->inf( cur_node );
  cn_position.x = cn_info->GetX();
  cn_position.y = cn_info->GetY();

  impulse.x = rand()%(2 * SHAKE/4 + 1) - SHAKE/4;
  impulse.y = rand()%(2 * SHAKE/4 + 1) - SHAKE/4;
  impulse.x += (node_center.x - cn_position.x)*center_scale;
  impulse.y += (node_center.y - cn_position.y)*center_scale;


  df = my_graph->inf(cur_node)->GetDistChart();
  for( i = 0; i < df->size; i++ )
  {
    dist_opt    = df->GetDistance( i );
    target_node = df->GetNode( i );
    is_border   = df->GetIsBorder( i );
    tn_info     = my_graph->inf( target_node );
    if( df->GetHasEdge(i) ) capacity = df->GetCapacity(i);
    else                    capacity = 1.0;
    
    if( is_border )
    {
      displace.x = (double)(cn_position.x - tn_info->GetScaledX());
      displace.y = (double)(cn_position.y - tn_info->GetScaledY());

      norm_dist = MAX( NORM2(displace.x, displace.y), 1 );
      dist_rad  = optedgelen + cn_info->GetRadius();

      impulse.x -= capacity * displace.x * (norm_dist-dist_opt) * dist_rad/dist_opt /ext_scale_down/norm_dist; 
      impulse.y -= capacity * displace.y * (norm_dist-dist_opt) * dist_rad/dist_opt /ext_scale_down/norm_dist; 
    }
    else
    {
      displace.x = (double)(cn_position.x - tn_info->GetX());
      displace.y = (double)(cn_position.y - tn_info->GetY());

      norm_dist = MAX( NORM2(displace.x, displace.y), 1 );
      dist_rad  = optedgelen + cn_info->GetRadius() + tn_info->GetRadius();

      impulse.x -= capacity * displace.x * ( norm_dist - dist_opt ) * (dist_rad) / (dist_opt) / norm_dist; 
      impulse.y -= capacity * displace.y * ( norm_dist - dist_opt ) * (dist_rad) / (dist_opt) / norm_dist; 
    }
  }
  return( impulse );
}

//------------------------------------------------------------------------------
// Schleife zum Aufruf der Funktion, die die eigentliche Verschiebung
// durchfuehrt.
//------------------------------------------------------------------------------

void  HiSpring::ComputeGroupLayout_KAM( int cur_father_radius, float_vec cur_center )
{
  int           iteration;
  float_vec     impulse;
  double        overlap;
  node          cur_node;
  node_info     *cn_info;
  float_vec     movement;
  int           cur_node_nr;
  scalar        max_radius;
  double        alpha;
  node_center  = cur_center;
  iteration    = 0;
  cur_node_nr  = actual_nodes->size();
  ext_scale_down = ext_scaling;
  center_scale   = 128.0 / (double)cur_father_radius;

  temperature  = 0;
  max_radius   = 0;
  fornodes_in_set( actual_nodes, cur_node )
  {
    max_radius   = MAX( max_radius, (the_graph->inf(cur_node))->GetRadius() );
    temperature += (the_graph->inf(cur_node))->GetHeat();
  }

  if( 0 == temperature )
  {
    temperature = cur_node_nr * (max_radius + 128);
    fornodes_in_set( actual_nodes, cur_node )
    {
      (the_graph->inf(cur_node))->SetHeat( max_radius + 128);
    }
  }
  if( the_edgelen == VARIABLE )      optedgelen = MAX( ELEN, max_radius );
  else                               optedgelen = ELEN;

  max_temp = max_radius*2;

  srand( (int)(used_time()*1000) );
  // Solange kein Abbruch:Suche einen Knoten der verschoben werden soll und verschiebe
  while( (temperature/cur_node_nr > 3) && 
	 (iteration < 2*cur_node_nr*SQR(cur_node_nr)) )
  {
    iteration++;
    //DrawLayout();
    fornodes_in_set_random( actual_nodes, cur_node )
    {
      // DrawLayout();
      impulse  = ComputeImpulse_KAM( cur_node, actual_nodes, border_nodes, the_graph );
      displace_fn( cur_node, impulse, the_graph, cur_node_nr );
    }
  }
  movement.x = 0;
  movement.y = 0;
  fornodes_in_set( actual_nodes, cur_node )
  {
    cn_info    = the_graph->inf(cur_node);
    impulse.x  = cn_info->GetX() - cur_center.x + movement.x;
    impulse.y  = cn_info->GetY() - cur_center.y + movement.y;
    overlap    = (scalar)sqrt(SQR(impulse.x)+SQR(impulse.y))-cur_father_radius+cn_info->GetRadius();
    if( overlap > 0 )
    {
      alpha      = atan2( impulse.y, impulse.x );
      movement.x -= (scalar)(cos(alpha)*overlap);
      movement.y -= (scalar)(sin(alpha)*overlap);
    }
  }
  fornodes_in_set( actual_nodes, cur_node )
  {
    cn_info    = the_graph->inf(cur_node);
    cn_info->AddX( movement.x );
    cn_info->AddY( movement.y );
  }
}
