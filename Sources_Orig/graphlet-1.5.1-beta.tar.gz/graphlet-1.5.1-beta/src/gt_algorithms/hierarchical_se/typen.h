/**************************************************************************/
/**************************************************************************/
/**  Includes, Typen-, Variablen- und Funktionsdeklarationen  (typen.h)  **/
/**************************************************************************/
/**************************************************************************/


#include <stdlib.h>
#include <stdio.h>
#include <math.h>


#define epsilon1 0.0001                                /* um Rundungsfehler zu vermeiden */
#define epsilon2 0.0000001


struct punkt         {double x,y;};
struct kreis         {int p1,p2,p3;                    /* die Punkte, die den Kreis mitbestimmen */
		      struct punkt mp;                 /* der Mittelpunkt */
		      double radius;
		     };
struct int_speicher  {int zahl;
		      struct int_speicher *next;
		     };


#ifdef MAIN                                            /* im Hauptprogramm werden die unten stehenden Variablen global definiert, */
#define CLASS                                          /* in allen anderen Modulen werden sie 'extern' definiert                  */
#else
#define CLASS extern
#endif

CLASS int                     Anzahl_der_Punkte;       /* die Anzahl der zu �berdeckenden Punkte */
CLASS struct punkt            *pu;                     /* Zeiger auf das Array, das die Koordinaten der Punkte enthaelt */
CLASS int                     *rest_Punkte;            /* Zeiger auf das Array, das festlegt, ob die Punkte bereits ueberdeckt sind oder nicht */
CLASS struct int_speicher *   *hilfsspeicher;          /* Hilfsspeicher[i] zeigt auf die Liste der Punkte, die von Kreis i ueberdeckt werden */
CLASS struct kreis            *kreis_liste;            /* Zeiger auf die aktuelle Kreisliste (abgespeichert in einem Array) */
CLASS struct kreis            *gesicherte_kreis_liste; /* Zeiger auf die bisher beste Kreisliste (abgespeichert in einem Array) */
CLASS double                  opt_Wert;                /* das Optimum des m-center Problems, d.h. der maximale Kreisradius der m Kreise */

#undef CLASS

/************************************************************************/
/************************************************************************/
/**  Ende der Includes, Typen-, Variablen- und Funktionsdeklarationen  **/
/************************************************************************/
/************************************************************************/
