#include <LEDA/list.h>
#include <LEDA/graph.h>
#include <LEDA/edge_set.h>
#include <LEDA/node_set.h>
#include <LEDA/node_pq.h>
#include <LEDA/array2.h>
#include <LEDA/basic.h>
#include <LEDA/set.h>
#include <LEDA/window.h>
#include <LEDA/p_queue.h>
#include <stdio.h>
#include <string.h>
#include <iostream.h>
#include <fstream.h>
#include <strstream.h>
#include <math.h>

#include <gtbase/Graph.h>

#ifndef KONSTANTS
#define KONSTANTS


#include "constants.h"
#include "makros.h"

#endif

//------------------------------------------------------------------------------
// Typdefinitionen
//------------------------------------------------------------------------------

typedef	long int        	scalar;
typedef	struct { scalar x, y; }	longint_vec;
typedef struct { double x, y; } float_vec;

//------------------------------------------------------------------------------
// Allgemein Beschreibung der aufgebauten Datenstruktur
//
// Da mit Graphen mit Templates gearbietet wird, gilt:
// Es wird fuer jeden node eine Struktur node_info, 
// fuer jede Kante eine Struktur edge_info mit angelegt.
// Jede Information wird in der Struktur ...._info gespeichert.
// Hierarchieknoten := Knoten die zusaetzlich zu den Orginalgraphknoten
// eingefuegt wurden, um den Ableitungsbaum aufzubauen.
// Es gilt: Orginalgraphknoten haben keine Soehne.
//          Hierarchieknoten haben immer mind. einen Sohn.
//
// Ableitungsbaum:            hierarchie(ns)
//                                  |
//                                  V
//                                root(n)
//                                  |
//                                 (ns)
//                                  |
//                                  V
//               son1(n)    son2(n)     son3(n)     soni(n)
//                 |          |            |           |
//                 V          V            V           V
//     .....
//
// Zum Neuzeichnen soll der Ableitungsbaum Baumuntypisch nicht Ast fuer  
// Ast durchlaufen werden, sondern eine Hierarchiestufe nach der anderen.
// Dazu dient die Struktur Hierarchielevelling:
//
// levels ist 2-dim Array.
// In jeder Zeile sind die der Zeilennummer entsprechenden levels als
// Zeiger auf node_sets zusammengefasst.
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Klassendeklarationen und Funktionedeklarationen
//------------------------------------------------------------------------------

class node_info;
class edge_info;
class adv_node_set;
class IFn_info;
class IFe_info;
class DistanceField;

extern void   CreateTreeEdge              ( edge ge, node s, node t, GRAPH_TYPE *g );
extern void   CreateTreeEdge              ( list<edge> *ges, node s, node t, GRAPH_TYPE *g );
extern void   ComputeNodedistances        ( adv_node_set *cg, array2<int> *d, 
				           node_array<int> *n, GRAPH_TYPE *g );
extern void   copie_set_to                ( adv_node_set *s , adv_node_set *t );
extern void   interchange_nodesets        ( GRAPH_TYPE *g, adv_node_set *set1, adv_node_set *set2 );
extern void   ComputeDistancesForGroup_KAM( GRAPH_TYPE *g, adv_node_set *gr, adv_node_set *n, double l );
DistanceField *ComputeShortestPathWithNodesizes_KAM( GRAPH_TYPE *g, node s, adv_node_set *, 
						      adv_node_set *n, double l );

//------------------------------------------------------------------------------
// Fuer jede Kante im Graph gibt es mind. 1 Entsprechung im Ableitungs-
// baum: Kante zwischen den zwei Knoten, die den Graphknoten entsprechen.
//------------------------------------------------------------------------------

class  tree_edge
{
public:
  node           target;               // Startknoten der Kante
  node           source;               // Zielknoten der Kante
  int            edge_number;          // Wieviele Kanten gibt es
  longint_vec    place_on_border;      // Wo schneidet die Kante mit dem Knotenrand
  list<edge>     *corresponding_edges; // Welche Graph-Kanten werden durch diese Kante
                                   // Repr"asentiert (wird beim Kantenzusammenfassen
                                   // benoetigt)

  tree_edge()  { edge_number = 0; };
  ~tree_edge() { corresponding_edges->~list();};
};

//------------------------------------------------------------------------------
// Ein Nodeset erweitert um die Moeglichkeit, alle Knoten zu durchlaufen.
// Aus leda uebernommen. Nur erweitert dadurch, dass jetzt L public ist.
// Zus"atzlich besteht die M"oglichkeit, das Set in einer Zuf""alligen Reihen-
// folge zu durchlaufen.
//------------------------------------------------------------------------------
class adv_node_set 
{
	graph* g;
	node_array<list_item> A;
	int sz;
public:
	list<node> L;
	list<node> rL;
	
	adv_node_set(const graph* G) : A(*G,nil) { g = (graph*)G; sz= g->number_of_nodes();}
	~adv_node_set() {}

	void insert(node x)  { if (A[x] == nil) A[x] = L.append(x); }

	void del(node x)     { if (A[x] != nil) { L.del(A[x]); A[x] = nil;} }

	bool member(node x)  { if( index(x) > sz-1) return FALSE; return (A[x] != nil); }

	node choose()  const { return L.head(); }

	int  size()    const { return L.length(); }

	bool empty()   const { return L.empty(); }

	void clear()         { L.clear(); A.init(*g,nil); }

	inline void random_setup();
};


#define fornodes_in_set( ans, cn )                   \
       forall( (cn), (ans)->L)     
 
#define fornodes_in_set_random( ans, cn )            \
       (ans)->random_setup();                        \
       forall( (cn), (ans)->rL)      

//------------------------------------------------------------------------------
// Klasse Kanteninformation
// Es werden Graphen mit Templates verwendet. edge_info ist die Struktur, 
// die zu jeder Kante mit angelegt wird
//------------------------------------------------------------------------------

class edge_info
{
  scalar   the_capacity;
public:

          edge_info    ()             {};
          ~edge_info   ()             {};

  scalar  GetCapacity  ()             { return ( the_capacity ); };
  void    SetCapacity  ( scalar cap ) { the_capacity = cap; };
};

//------------------------------------------------------------------------------
// Klasse Knoteninformation
// Es werden Graphen mit Templates verwendet. node_info ist die Struktur, 
// die zu jedem Knoten mit angelegt wird
//------------------------------------------------------------------------------

typedef	struct 
{
  float_vec    coordinates;
  int          node_radius;
  bool         is_layouted;
  bool         is_represented;
}	general_attributes;

typedef	struct 
{
  int         node_heat;
  int         node_dir;
  float_vec   scaled_coordinates;
  float_vec   old_coordinates;
}	gem_attributes;

typedef	struct 
{
  node                   the_father;
  adv_node_set           *the_sons;
  list<tree_edge*>       *tree_edges;
  int                    hier_level;

}	hierarchie_attributes;


class node_info
{
  general_attributes       gen_a;
  gem_attributes           gem_a;
  hierarchie_attributes    hie_a;
  DistanceField            *dist_chart;  // Optimaler Abstand zu anderen Knoten, die
                                         // bei der Layoutberechnung zu beruecksichtigen sind.
public:


	node_info      ();
	~node_info     () {
		tree_edge *te;

		forall( te, *(hie_a.tree_edges) ) {
			te->~tree_edge();
		}
		if( hie_a.the_sons != NULL ) hie_a.the_sons->~adv_node_set();
		if( hie_a.tree_edges != NULL ) hie_a.tree_edges->~list();
		if( dist_chart != NULL ) dist_chart->~DistanceField();
	}

  inline void SetDistChart   ( DistanceField *d )     { dist_chart = d; }
  inline void SetScaledX     ( double x )             { gem_a.scaled_coordinates.x = x; }
  inline void SetScaledY     ( double y )             { gem_a.scaled_coordinates.y = y; }
  inline void SetEdges       ( list<tree_edge*> *e  ) { hie_a.tree_edges = e; }
  inline void SetRadius      ( int r )                { gen_a.node_radius = r; }
  inline void SetRepresented (int r )                 { gen_a.is_represented = r; }
  inline void SetFather      ( node father )          { hie_a.the_father = father; }
  inline void SetSons        ( adv_node_set *sons )   { hie_a.the_sons = sons; }
  inline void SetLayouted    ( int layouted )         { gen_a.is_layouted = layouted; }
  inline void SetLevel       ( int level )            { hie_a.hier_level = level; }
  inline void SetImpulse     ( float_vec i )          { gem_a.scaled_coordinates = i; }
  inline void SetHeat        ( int h )                { gem_a.node_heat = h; }
  inline void AddX           ( double x_plus )        { gen_a.coordinates.x += x_plus; }
  inline void AddY           ( double y_plus )        { gen_a.coordinates.y += y_plus; }
  inline void SetX           ( double x )             { gen_a.coordinates.x = x; }
  inline void SetY           ( double y )             { gen_a.coordinates.y = y; }
  inline void SetDir         ( int dir )              { gem_a.node_dir = dir; }

  inline DistanceField    *GetDistChart()   { return( dist_chart ); }
  inline list<tree_edge*> *GetEdges()       { return( hie_a.tree_edges ); }
  inline int              GetDir()          { return( gem_a.node_dir ); }
  inline double           GetX()            { return( gen_a.coordinates.x ); }
  inline double           GetY()            { return( gen_a.coordinates.y ); }
  inline int              GetHeat()         { return( gem_a.node_heat ); }
  inline adv_node_set*    GetSons()         { return( hie_a.the_sons ); }
  inline float_vec        GetImpulse()      { return( gem_a.scaled_coordinates ); }
  inline node             GetGraphFather()  { return( hie_a.the_father ); }
  inline int              GetRepresented()  { return( gen_a.is_represented ); }
  inline double           GetOldX()         { return( gem_a.old_coordinates.x ); }
  inline double           GetOldY()         { return( gem_a.old_coordinates.y ); }
  inline float_vec        GetCenter()       { return( gen_a.coordinates ); }
  inline double           GetScaledX()      { return( gem_a.scaled_coordinates.x ); }
  inline double           GetScaledY()      { return( gem_a.scaled_coordinates.y ); }
  inline int              GetRadius()       { return( gen_a.node_radius ); }
  inline int              GetLayouted()     { return( gen_a.is_layouted ); }
  inline int              GetIsHierarchie() { return( hie_a.the_sons != NULL ); }
  inline int              GetLevel()        { return( hie_a.hier_level ); }
  inline int              GetNrSons()       { if (!hie_a.the_sons)       return( 0 );
                                              return( hie_a.the_sons->size() ); }
  inline void             CopyPosToOldPos() { gem_a.old_coordinates.x = gen_a.coordinates.x;
                                              gem_a.old_coordinates.y = gen_a.coordinates.y; }

  inline node_info*       GetFather( GRAPH_TYPE  *the_graph ) {
             if( NULL != hie_a.the_father ) return( the_graph->inf(hie_a.the_father) );
             return( NULL ); }
};

							   
//------------------------------------------------------------------------------
// Meine Hierarchie soll spaeter nicht, wie fuer einen Baum normal, so
// durchlaufen werden, dass zuerst ein Teilbaum ganz abgearbeitet wird,
// sondern es sollen die verschiedenen Stufen des Baumes nach der Reihe
// abgearbeitet werden. Diese Struktur ist eigentlich nur ein zwei-
// dimensionales Feld von Zeigern auf die node_sets des Baumes. Dabei
// verweist eine Zeile jeweils auf die sets einer Stufe der Hierarchie
// Die Funktionen GetNextLevel und GetNextSet dienen zum uebersicht-
// lichen Durchlaufen des Ableitungsbaumes gemaess obiger Beschreibung.
//------------------------------------------------------------------------------

class hierarchie_levelling
{
  int                      nr_levels;
  int                      *nr_sets_in_level;
  SET_FIELD                *mapping;
  int                      last_index;

public:
                hierarchie_levelling  ();
                ~hierarchie_levelling ( ) {
					free(nr_sets_in_level);
					mapping->~array2();
				};
	
  void          CreateLevelling       ( adv_node_set *hierarchie, int nr_levels,
					GRAPH_TYPE *graph );
  int           GetNextLevel          ( int last_level );
  adv_node_set* GetNextSet            ( int cur_level );
};



//------------------------------------------------------------------------------
// Die Hauptklasse. Enthaelt ein paar wichtige Variablen und die Funk-
// tionsaufrufe um den Graph zu laden, neu zu zeichnen und dann 
// auszugeben.
//------------------------------------------------------------------------------

class HiSpring
{
  node_array<node>         *Myn2GR;    // isomorphy pointers to copy the graph
  edge_array<edge>         *Mye2GR;    // this pointers are from the copied graph to the
                                       // input-graph

  adv_node_set              *actual_nodes;     // Information used during Layoutcomputation
  adv_node_set              *border_nodes;

  int                       max_level;         // Information for tree and graph
  adv_node_set              *hierarchie;
  GRAPH_TYPE                *the_graph;
  int                       the_node_nr;
  hierarchie_levelling      *levels;

  int                       what_hierarchie;   // Settings read in by interface
  int                       show_hierarchie;
  int                       max_nodes_per_set;
  int                       ext_scaling;
  int                       unite_edges;
  int                       minimize_nodes;
  int                       the_edgelen;
  int                       force_GEM;


public:
	void  SetLayout              (GT_Graph& g);
	void  SetSettings            (GT_Graph& g, int show_hier, int unite,
		int minimize, int variable_edges, int force, int what_hier,
		int max_nodes, int external_scal);
private:
	// layoutcomputation
  void  ComputeLayout_KAM      ( int what_alg, int heat);
  void	ComputeGroupLayout_KAM ( int father_radius, float_vec center );
  void  ReduceAllNodes_KAM     ( adv_node_set *head );
  void  ComputeDistChartsForTree_KAM();

  void  ComputeBorderNodes     ( node_info *father_inf, int what_border );
  void  PreComputeCoordinates  ( int father_radius, float_vec center );
  void	FinetuneCoordinates    ( int father_radius, float_vec center );
  void  ComputeNodesizes       ( adv_node_set *root_elems );
  double GetLongestPath         ( adv_node_set *sons );
  void  PresetCoordinates      ( node_info *father_inf, adv_node_set *cur_set );
  void  ComputeLayout          ( int what_alg, int heat);
  void	DistributeNodes        ( int father_radius, float_vec center, int level );
	void gtline_add_second( GT_Graph& g, edge ledaedge, int x, int y );
	void gtline_add_beforelast( GT_Graph& g, edge ledaedge, int x, int y );
	void clear_gt_line( GT_Graph& g, edge ledaedge );
	void  ComputePlacesOnBorder  ();

  // my hierarchie
  void          ComputeHierarchie             ();
  adv_node_set  *GetCenterNode         ();
  void          CreateGraphCenterHierarchie   ( adv_node_set *upper_nodes );
  void          CreateGraphCenterHierarchie2   ( adv_node_set *upper_nodes );
  void          CreateHierarchieEdges         ();

  // RC hierarchie
  void  ComputeRCHierarchie       ();
  void  CopyEdgesToTreeEdges      ();
  void  SetValidHierarchieLevels  ( adv_node_set *nodes );
  void  ComputeDirectedHierarchie();
  adv_node_set *GetRootNodes();

  // reduce Nodesizes
  void  ReduceNode             ( node n );
  void  MoveNodesBack          ( adv_node_set *head, float_vec displace );
  void  MoveAllSonsBack        ( adv_node_set *head, float_vec displace );
  void  ReduceGraph            ();

public:


// Funktionen, die zur Schnittstelle gehoeren
  void      CopyDerivation           ( GRAPH<IFn_info*, IFe_info*> *g, adv_node_set *root );
  void      DoLayoutComputation      ();
  void      CopyOutSizesAndPositions ( GRAPH<IFn_info*, IFe_info*> *g );

        HiSpring               ();
        ~HiSpring              ();
  void  RunHiSpring            ();
};


//------------------------------------------------------------------------------
// Eine Klasse, um nach dem Ratio-Cut Verfahren eine Partitionierung zu erhalten
//------------------------------------------------------------------------------

class Partitioning
{
  // Merken des Optimum
  double        the_optimal_value;
  int           the_optimal_edge_cut;
  adv_node_set  *the_optimal_left_list, *the_optimal_right_list;

  // Die Aktuellen Listen
  node          the_left_seed, the_right_seed;
  adv_node_set  *the_left_list, *the_right_list;
  int           the_cur_edge_cut;                         //#Zerschnittene Kanten
  GRAPH_TYPE    *the_graph;

  adv_node_set  *the_partition_nodes;

  public:

  int         improvement;

  Partitioning            ( GRAPH_TYPE *g, adv_node_set *valid_nodes,
			    node left_seed, node right_seed );
  ~Partitioning           ();

  inline node ChooseOptimalNode  ( int* value );
  void Shifting           ();
  void SetCurSets         ( int how_to_set );
  
  adv_node_set *GetLeftList    ();
  adv_node_set *GetRightList   ();
};

class OneLevelPartition
{
  p_queue<scalar, adv_node_set*> *the_partitions;
  int                            max_size;
  int                            nr_sets;
  int                            max_set_nr;


  public:

  OneLevelPartition                    ( int size );
  ~OneLevelPartition                   ();

  void          InsertSet              ( adv_node_set *new_set, GRAPH_TYPE *g );
  adv_node_set  *GetSet                ( GRAPH_TYPE *g );
  adv_node_set  *CreateHierarchieNodes ( GRAPH_TYPE *g );
};


class DistanceField
{
  array<node>     *nodes;
  array<double>   *distances;
  array<bool>     *is_border;
  array<bool>     *has_edge;
  array<int>      *capacity;

  public:

  int             size;

  DistanceField() { nodes=NULL; distances=NULL; };
  DistanceField( array<node> *n, array<double> *d, 
		 array<bool> *b, array<bool> *e, array<int> *c, int s )  
                          { nodes=n; distances=d; is_border = b, has_edge = e; capacity = c; size = s; };
  ~DistanceField()   {nodes->~array(); distances->~array();is_border->~array();
                      has_edge->~array();capacity->~array(); };


  void    SetNodes( array<node> *n )                       { nodes = n; };
  void    SetDistance( int entry, double value, node n )   { (*distances)[entry] = value; (*nodes)[entry] = n; };

  node    GetNode    ( int entry )                         { return( (*nodes)[entry] ); }
  double  GetDistance( int entry )                         { return( (*distances)[entry] ); }
  bool    GetIsBorder( int entry )                         { return( (*is_border)[entry] ); }
  bool    GetHasEdge ( int entry )                         { return( (*has_edge)[entry] ); }
  int     GetCapacity( int entry )                         { return( (*capacity)[entry] ); }
};

#include "inlines.icc"
