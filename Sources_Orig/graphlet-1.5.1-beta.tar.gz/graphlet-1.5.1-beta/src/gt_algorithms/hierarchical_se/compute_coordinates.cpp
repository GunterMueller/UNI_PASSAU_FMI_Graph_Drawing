//
// compute_coordinates.cc
//

#include "hispring.h"

//extern int random();

scalar     HSEtemperature;
float_vec  node_center;
double     optedgelen;
double     scale_up;
long int   max_temp;
double     father_rad;
double     ext_scale_down;
double     attr_factor;
double     dist_factor;
double     dist_factor_ext;
extern double   center_scale;

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

float_vec ComputeDisplace( node_info *n_info, float_vec cn_position, double cn_radius, bool is_border )
{
  register float_vec  displace;
  register double     node_size_sum;
  register double     norm_dist;
  register double     alpha;


  // Im Gegensatz zum Orginalalgorithmus haben wir hier verschiedene Knotengroessen
  if( is_border )
  {
    node_size_sum = cn_radius;
    displace.x = (double)(cn_position.x - n_info->GetScaledX());
    displace.y = (double)(cn_position.y - n_info->GetScaledY());
  }
  else 
  {
    node_size_sum = (double)n_info->GetRadius() + cn_radius;
    displace.x = (double)(cn_position.x - n_info->GetX());
    displace.y = (double)(cn_position.y - n_info->GetY());
  }
  if( displace.x == 0.0 && displace.y == 0.0 ) displace.x = 1;
  alpha = atan2( displace.y, displace.x );

  if( (SQR(displace.x) + SQR(displace.y)) < SQR(node_size_sum) )
  {
    //Ueberlappung
    displace.x -= cos(alpha)*node_size_sum;
    displace.y -= sin(alpha)*node_size_sum;  // dreht Vorzeichen um !!!
    norm_dist = QNORM (displace.x, displace.y);
    norm_dist = MAX( norm_dist, 1 );
    displace.x = SIGN(-displace.x)*HIGH_DISTRACT + -displace.x * attr_factor / norm_dist;
    displace.y = SIGN(-displace.y)*HIGH_DISTRACT + -displace.y * attr_factor / norm_dist;
    return( displace );
  }

  displace.x -= cos(alpha)*node_size_sum;
  displace.y -= sin(alpha)*node_size_sum;
  norm_dist = QNORM(displace.x, displace.y);
  if( norm_dist < 1 )
  {
    displace.x = HIGH_DISTRACT * scale_up;
    displace.y = HIGH_DISTRACT * scale_up;
    return( displace );
  }
  displace.x = displace.x * attr_factor / norm_dist;
  displace.y = displace.y * attr_factor / norm_dist;
  return( displace );
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

float_vec ComputeImpulse( node cur_node, adv_node_set */*set1*/, 
			   adv_node_set */*border_nodes*/, GRAPH_TYPE *my_graph )
{
  node                  target_node;
  node_info             *tn_info, *cn_info; //Uebergebener Knoten 
  double                node_size_sum;
  register double       norm_dist;
  register float_vec    impulse, cn_position, displace;
  register double       cn_radius, alpha;
  DistanceField         *df;
  int                   i, is_border, capacity;

  cn_info       = my_graph->inf( cur_node );
  cn_position.x = cn_info->GetX();
  cn_position.y = cn_info->GetY();
  cn_radius     = cn_info->GetRadius();

  impulse.x = rand()%(2 * SHAKE/4 + 1) - SHAKE/4;
  impulse.y = rand()%(2 * SHAKE/4 + 1) - SHAKE/4;
  impulse.x += (node_center.x - cn_position.x)*center_scale;
  impulse.y += (node_center.y - cn_position.y)*center_scale;

  df = my_graph->inf(cur_node)->GetDistChart();
  for( i = 0; i < df->size; i++ )
  {
    target_node = df->GetNode( i );
    tn_info     = my_graph->inf( target_node );
    is_border   = df->GetIsBorder( i );

    displace  = ComputeDisplace( tn_info, cn_position, cn_radius, is_border );
    if( TRUE == is_border )
    {
      impulse.x += displace.x / ext_scale_down;
      impulse.y += displace.y / ext_scale_down;
    }
    else
    {
      impulse.x += displace.x;
      impulse.y += displace.y;
    }

    if( TRUE == df->GetHasEdge(i) )
    {
      capacity      = df->GetCapacity( i );

      if( TRUE != is_border )
      {
	node_size_sum = tn_info->GetRadius() + cn_info->GetRadius();
	displace.x    = cn_position.x - tn_info->GetX();
	displace.y    = cn_position.y - tn_info->GetY();
      }
      else 
      {
	node_size_sum = cn_radius;
	displace.x    = cn_position.x - tn_info->GetScaledX();
	displace.y    = cn_position.y - tn_info->GetScaledY();
      }
      if(!( ((displace.x == 0) && (displace.y == 0))  ||
	    (SQR(displace.x) + SQR(displace.y) < SQR(node_size_sum))) )
      {
	alpha       = atan2( displace.y, displace.x );
	displace.x -= cos(alpha)*(node_size_sum);
	displace.y -= sin(alpha)*(node_size_sum);
	norm_dist = QNORM(displace.x, displace.y);
	if( norm_dist > 1.0 )
	{
	  if( TRUE == is_border )
	  {
	    impulse.x -= displace.x * norm_dist / dist_factor_ext;
	    impulse.y -= displace.y * norm_dist / dist_factor_ext;
	  }
	  else
	  {
	    impulse.x -= capacity*displace.x*norm_dist/dist_factor;
	    impulse.y -= capacity*displace.y*norm_dist/dist_factor;
	    // Kantengewichte: also die abstossende Kraft auch noch
	    impulse.x += (capacity-1)*displace.x*attr_factor/norm_dist;
	    impulse.y += (capacity-1)*displace.y*attr_factor/norm_dist;
	  }
	}
      }
    }
  }
  return( impulse );
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void displace_fn ( node cur_node, float_vec impulse,
		GRAPH_TYPE *g, int nr_nodes )
{
   node_info  *n_info;
   double     n;
   scalar     n_heat;
   float_vec  n_impulse;
   scalar     n_dir;

   n_info    = g->inf( cur_node );
   n_heat    = n_info->GetHeat();
   n_impulse = n_info->GetImpulse();
   n_dir     = n_info->GetDir();

   if (ABS(impulse.x) > 1 || ABS(impulse.y) > 1)
   {  
     // I. avoid integer overflow 
     n = MAX(ABS(impulse.x),ABS(impulse.y)) / (scalar)16384;
     if (n > 1)
     {
       impulse.x /= n;
       impulse.y /= n;
     }  
     // II. scale and apply impulse vector
     n = NORM2( impulse.x, impulse.y );
     impulse.x = impulse.x  * n_heat / n;
     impulse.y = impulse.y  * n_heat / n;
     n_info->AddX( impulse.x );
     n_info->AddY( impulse.y );

     // III. calculate new HSEtemperature
     if (n_impulse.x || n_impulse.y)
     {
       n = n_heat * NORM2( n_impulse.x, n_impulse.y );
       HSEtemperature -= n_heat;
       // IIIa. oscillations
       n_heat += (long int)(n_heat * (impulse.x * n_impulse.x + impulse.y * n_impulse.y) / (3 * n));
       // IIIb. rotations 
       n_dir += (long int)(15 * (impulse.x * n_impulse.y - impulse.y * n_impulse.x) / (8 * n));
       n_heat -= n_heat * ABS(n_dir) / (2 * nr_nodes);
       n_heat = MIN( (long int)n_heat, 2*MAXTEMP );
       n_heat = MAX( n_heat, 3 );
       HSEtemperature += n_heat;
       n_info->SetHeat( n_heat );
       n_info->SetDir ( n_dir );
     }
     n_impulse.x = impulse.x;
     n_impulse.y = impulse.y;
     n_info->SetImpulse( n_impulse );
   }
 }

//------------------------------------------------------------------------------
// Schleife zum Aufruf der Funktion, die die eigentliche Verschiebung
// durchfuehrt.
//------------------------------------------------------------------------------

void  HiSpring::FinetuneCoordinates( int cur_father_radius, float_vec cur_center )
{
  int           iteration;
  float_vec     impulse;
  double        overlap;
  node          cur_node;
  node_info     *cn_info;
  double        alpha;
  float_vec   movement;
  int           cur_node_nr;
  scalar        max_radius;

  node_center  = cur_center;
  iteration    = 0;
  cur_node_nr  = actual_nodes->size();
  HSEtemperature  = 0;
  max_radius   = 0;
  ext_scale_down = ext_scaling;
  father_rad     = cur_father_radius;
  center_scale   = 256.0 / (double)father_rad;

  fornodes_in_set( actual_nodes, cur_node )
  {
    max_radius   = MAX( max_radius, (the_graph->inf(cur_node))->GetRadius() );
    HSEtemperature += (the_graph->inf(cur_node))->GetHeat();
  }

  if( the_edgelen == VARIABLE )      optedgelen = MAX( ELEN, max_radius );
  else                               optedgelen = ELEN;

  max_temp = max_radius*2;
  attr_factor     = NODEDISTSQR;
  dist_factor     = NODEDISTSQR;
  dist_factor_ext = NODEDISTSQR * ext_scale_down;

  //srand( (int)(used_time()*1000) );
  // Solange kein Abbruch:Suche einen Knoten der verschoben werden soll und verschiebe
  while( (HSEtemperature/cur_node_nr > 3) && 
	 (iteration < 2*cur_node_nr*SQR(cur_node_nr)) )
  {
    iteration++;
    fornodes_in_set_random( actual_nodes, cur_node )
    {
      //DrawLayout();
      impulse  = ComputeImpulse( cur_node, actual_nodes, border_nodes, the_graph );
      displace_fn( cur_node, impulse, the_graph, cur_node_nr );
    }
  }
  movement.x = 0;
  movement.y = 0;
  fornodes_in_set( actual_nodes, cur_node )
  {
    cn_info    = the_graph->inf(cur_node);
    impulse.x  = cn_info->GetX() - cur_center.x + movement.x;
    impulse.y  = cn_info->GetY() - cur_center.y + movement.y;
    overlap    = (scalar)sqrt(SQR(impulse.x)+SQR(impulse.y))-cur_father_radius+cn_info->GetRadius();
    if( overlap > 0 )
    {
      alpha      = atan2( impulse.y, impulse.x );
      movement.x -= (scalar)(cos(alpha)*overlap);
      movement.y -= (scalar)(sin(alpha)*overlap);
    }
  }
  fornodes_in_set( actual_nodes, cur_node )
  {
    cn_info    = the_graph->inf(cur_node);
    cn_info->AddX( movement.x );
    cn_info->AddY( movement.y );
  }
}
