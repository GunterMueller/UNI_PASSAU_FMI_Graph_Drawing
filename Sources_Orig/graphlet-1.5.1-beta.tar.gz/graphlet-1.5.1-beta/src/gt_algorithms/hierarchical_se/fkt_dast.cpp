/***************************************************************************/
/***************************************************************************/
/**  Funktionen zur Verwaltung der globalen_Datenstrukturen (fkt_dast.c)  **/
/***************************************************************************/
/***************************************************************************/


#include "typen.h"
#include "fkt_dast.h"


/**********************************/
/**  belege_Speicher_fuer_punkt  **/
/**********************************/
struct punkt * belege_Speicher_fuer_punkt(int i)
{struct punkt *hizei;

 hizei=(struct punkt *) malloc(i*sizeof(struct punkt));
 if (hizei==NULL)
    {printf("\n\n Nicht genug Speicher vorhanden ! (hizei in 'belege_Speicher_fuer_punkt')\n");
     exit(1);                /* wird ziemlich sicher nie eintreten */
    }
 return(hizei);
} /* Ende belege_Speicher_fuer_punkt */


/***************/
/**  abstand  **/
/***************/
extern double abstand(struct punkt a,struct punkt b)
/* Diese Funktion berechnet den euklidischen Abstand zweier Punkte */
{return( sqrt( (a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y) ) );
} /* Ende abstand */


/**********************************/
/**  Mittelpunkt_fuer_gleiche_y  **/
/**********************************/
static void Mittelpunkt_fuer_gleiche_y(struct kreis *kr_zei,int a,int b,int c)
/* Diese Funktion berechnet die Koordinaten des Mittelpunkts des Kreises, */
/* der durch die Punkte pu[a], pu[b] und pu[c] bestimmt wird.             */
/* Zwei dieser Punkte haben dabei gleiche y-Koordinaten.                  */
/* Aufgerufen wird diese Funktion von 'berechne_Mittelpunkt_und_Radius'.  */
/* Sie ist deshalb nicht nach aussen sichtbar.                            */
{double zaehler,nenner,x1,x2,x3,y2,y3;           /* y1 wird nicht benoetigt */

 x1=pu[a].x;
 x2=pu[b].x;
 x3=pu[c].x;
 /* y1=pu[a].y; */
 y2=pu[b].y;
 y3=pu[c].y;
 zaehler=(x2-x3)*(x1+x2)+x3*x3-x2*x2+y3*y3-y2*y2;
 nenner=2*(y3-y2);
 (kr_zei->mp).x=(x1+x2)/2;
 (kr_zei->mp).y=zaehler/nenner;
} /* Ende Mittelpunkt_fuer_gleiche_y */


/***************************************/
/**  Mittelpunkt_fuer_verschiedene_y  **/
/***************************************/
static void Mittelpunkt_fuer_verschiedene_y(struct kreis *kr_zei,int a,int b,int c)
/* Diese Funktion berechnet die Koordinaten des Mittelpunkts des Kreises, */
/* der durch die Punkte pu[a], pu[b] und pu[c] bestimmt wird.             */
/* Die Punkte haben dabei paarweise verschiedene y-Koordinaten.           */
/* Aufgerufen wird diese Funktion von 'berechne_Mittelpunkt_und_Radius'.  */
/* Sie ist deshalb nicht nach aussen sichtbar.                            */
{double zaehler,nenner,x1,x2,x3,y1,y2,y3;

 x1=pu[a].x;x2=pu[b].x;x3=pu[c].x;
 y1=pu[a].y;y2=pu[b].y;y3=pu[c].y;
 zaehler=(x3*x3-x2*x2)*(y1-y2)+(y3-y2)*( (y3+y2)*(y1-y2)+x2*x2-x1*x1+y2*y2-y1*y1 );
 nenner=2*(x2-x1)*(y3-y2)+2*(x3-x2)*(y1-y2);
 (kr_zei->mp).x=zaehler/nenner;
 (kr_zei->mp).y=( (x2-x1)*(kr_zei->mp).x+0.5*(x1-x2)*(x1+x2)+0.5*(y1-y2)*(y1+y2) )/(y1-y2);
} /* Ende Mittelpunkt_fuer_verschiedene_y */


/***************************************/
/**  berechne_Mittelpunkt_und_Radius  **/
/***************************************/
extern void berechne_Mittelpunkt_und_Radius(struct kreis *kr_zei,int a,int b,int c)
/* Diese Funktion berechnet die Koordinaten des Mittelpunkts des Kreises, */
/* der durch die Punkte pu[a], pu[b] und pu[c] bestimmt wird.             */
/* Zusaetzlich wird der Radius diese Kreises berechnet.                   */
{int hi;

 if (pu[a].y==pu[b].y)
    {Mittelpunkt_fuer_gleiche_y(kr_zei,a,b,c);}
 else {if (pu[b].y==pu[c].y)
	  {hi=a;
	   a=c;
	   c=hi;
	   Mittelpunkt_fuer_gleiche_y(kr_zei,a,b,c);
	  }
       else {if (pu[a].y==pu[c].y)
		{hi=b;
		 b=c;
		 c=hi;
		 Mittelpunkt_fuer_gleiche_y(kr_zei,a,b,c);
		}
	     else Mittelpunkt_fuer_verschiedene_y(kr_zei,a,b,c);
	    }
      }
 kr_zei->radius=abstand(pu[a],kr_zei->mp);
} /* Ende berechne_Mittelpunkt_und_Radius */


/*******************************/
/** berechne_weitesten_Punkt  **/
/*******************************/
/* Diese Funktion berechnet den Punkt, der von einem gegebenen Suchpunkt,  */
/* meist handelt es sich dabei um einen Kreismittelpunkt, den groessten    */
/* Abstand hat. Um nicht alle Punkte ueberpruefen zu muessen, kann man mit */
/* 'anfang' den Start der Suche festlegen.                                 */

extern int berechne_weitesten_Punkt(struct punkt suchpunkt,double kreis_radius,int anfang)
{
  double max_Abstand,hilf;
  int    j,weitester_Punkt;

  weitester_Punkt=0;                              /* wichtig fuer Crystal_Peirce, falls rest_Punkte[j] alle 0 sind */
  max_Abstand=kreis_radius+epsilon2;              /* sonst Rundungsfehler moeglich, falls z.B. 4 Punkte auf einem Kreis liegen ! */
  for (j=anfang;j<=Anzahl_der_Punkte;j++)
  {
    hilf=abstand(pu[j],suchpunkt);
    if (hilf>max_Abstand)
    {
      max_Abstand=hilf;
      weitester_Punkt=j;
    }
  }
  return(weitester_Punkt);
} /* Ende berechne_weitesten_Punkt */



/*************************/
/**  update_Kreisliste  **/
/*************************/
extern void update_Kreisliste(int rek_stufe,int m)
/* Diese Funktion ist vor allem fuer den rekursiven Algorithmus (siehe 'rekursiv.c')     */
/* wichtig. Sie loescht alle Kreise mit Nummern<='rek_stufe' aus der Kreisliste          */
/* und stellt die Kreise mit hoeheren Nummern wieder aus der gesicherten Kreisliste her. */
{int i;

 for (i=1;i<=rek_stufe;i++)
   {kreis_liste[i].p1=0;}                        /* Mache kreis[i] ungueltig. */
 for (i=rek_stufe+1;i<=m;i++)
   {if (kreis_liste[i].p1==0)
       {kreis_liste[i]=gesicherte_kreis_liste[i];}
   }
} /* Ende update_Kreisliste */


/*******************************/
/**  einfuegen_in_Kreisliste  **/
/*******************************/
extern void einfuegen_in_Kreisliste(struct kreis neuer_kr,int pegel)
/* Diese Funktion fuegt 'neuer_kr' in das Array 'kreis_liste' an der Stelle 'pegel' ein. */
{kreis_liste[pegel]=neuer_kr;
} /* Ende einfuegen_in_Kreisliste */


/*******************************************/
/**  einfuegen_in_gesicherte_kreis_liste  **/
/*******************************************/
extern void einfuegen_in_gesicherte_kreis_liste(struct kreis neuer_kr,int pegel)
/* Diese Funktion fuegt 'neuer_kr' in das Array 'gesicherte_kreis_liste' an der Stelle 'pegel' ein. */
{gesicherte_kreis_liste[pegel]=neuer_kr;
} /* Ende einfuegen_in_gesicherte_kreis_liste */


/**************************/
/**  sichere_Kreisliste  **/
/**************************/
static void sichere_Kreisliste(int m)
/* Diese Funktion sichert die Kreise der 'kreis_liste' nach 'gesicherte_kreis_liste'.    */
/* Sie wird nur von 'endbehandlung' aufgerufen und ist daher nicht nach aussen sichtbar. */
{struct kreis *hizei;

 hizei=kreis_liste;
 kreis_liste=gesicherte_kreis_liste;   /* oder : Schritt f�r Schritt den Inhalt des Arrays kopieren */
 gesicherte_kreis_liste=hizei;
 update_Kreisliste(m,m);               /* Loescht alle Kreise in 'kreis_liste. */
} /* Ende sichere_Kreisliste */


/******************/
/**  max_Radius  **/
/******************/
extern double max_Radius(int m)
/* Diese Funktion berechnet den maximalen Radius aller Kreise, die in der Kreisliste abgespeichert sind. */
{double max;
 int    i;

 max=0;
 for (i=1;i<=m;i++)
   {if ( (kreis_liste[i].p1!=0) && (kreis_liste[i].radius>max)  )
       {max=kreis_liste[i].radius;}
   }
 return(max);
} /* Ende max_Radius */


/********************/
/**  summe_Radius  **/
/********************/
static double summe_Radius(struct kreis *z,int m)
/* Diese Funktion berechnet die Summe der Radien der Kreise, die im                      */
/* Array abgespeichert sind, auf das 'z' zeigt.                                          */
/* Moegliche Parameter fuer 'z' sind 'kreis_liste' oder 'gesicherte_kreis_liste'.        */
/* Sie wird nur von 'endbehandlung' aufgerufen und ist daher nicht nach aussen sichtbar. */
{double summe;
 int    i;

 summe=0;
 for (i=1;i<=m;i++)
   {if (z[i].p1!=0)
       {summe=summe+z[i].radius;}
   }
 return(summe);
} /* Ende summe_Radius */


/*********************/
/**  endbehandlung  **/
/*********************/
extern void endbehandlung(struct kreis kr,int m)
/* Diese Funktion ueberprueft, ob die derzeit in 'kreis_liste' abgespeicherte Situation besser als die  */
/* bisher beste gefundene Loesung ist. Wenn ja, so wird sie in 'gesicherte_kreis_liste' abgespeichert.  */
/* Falls der unwahrscheinliche Fall eintritt, dass der maximale Radius der Situation in 'kreis_liste'   */
/* mit dem maximalen Radius der Situation in 'gesicherte_kreis_liste' uebereinstimmt, so wird           */
/* anschliessend die Summe der Kreisradien minimiert.                                                   */
{double hi,summe_ges_Liste;

 einfuegen_in_Kreisliste(kr,1);
 hi=max_Radius(m);
 if (hi<opt_Wert-epsilon2)                                 /* sonst waeren Rundungsfehler moeglich */
    {opt_Wert=hi;
     sichere_Kreisliste(m);
    }
 else {if (fabs(hi-opt_Wert)<=epsilon2)                    /* sonst waeren Rundungsfehler moeglich */
	  {summe_ges_Liste=summe_Radius(gesicherte_kreis_liste,m);
	   hi=summe_Radius(kreis_liste,m);
	   if (hi<summe_ges_Liste-epsilon2)                /* sonst waeren Rundungsfehler moeglich */
	      {sichere_Kreisliste(m);}
	  }
      }
} /* Ende endbehandlung */


/**********************************************************************/
/**********************************************************************/
/**  Ende der Funktionen zur Verwaltung der globalen Datenstrukturen **/
/**********************************************************************/
/**********************************************************************/
