//
// rc_hierarchie.cc
//

#include "hispring.h"

#define   FROM_SEED_1                     1
#define   FROM_SEED_2                     2
#define   FROM_OPTIMUM_LEFT_SHIFTING      3
#define   FROM_OPTIMUM_RIGHT_SHIFTING     4


//------------------------------------------------------------------------------
// Konstruktor der Klasse Partitioning
// Allokiert vor allem Speicher f"ur die Knotenlisten
//------------------------------------------------------------------------------

Partitioning::Partitioning( GRAPH_TYPE *g, adv_node_set *valid_nodes,
			    node seed1, node seed2 )
{
  the_left_list           = new adv_node_set(g);
  the_right_list          = new adv_node_set(g);
  the_optimal_left_list   = new adv_node_set(g);
  the_optimal_right_list  = new adv_node_set(g);
  the_left_seed           = seed1;
  the_right_seed          = seed2;
  the_graph               = g;
  the_partition_nodes     = valid_nodes;
  improvement             = TRUE;
}

//------------------------------------------------------------------------------
// Destruktor f"ur Klasse Partitioning
//------------------------------------------------------------------------------

Partitioning::~Partitioning()
{
  the_left_list->~adv_node_set();

  the_right_list->~adv_node_set();
  the_optimal_left_list->~adv_node_set();
  the_optimal_right_list->~adv_node_set();
  the_partition_nodes->~adv_node_set();
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

adv_node_set*   Partitioning::GetLeftList()
{
  return( the_left_list );
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

adv_node_set*   Partitioning::GetRightList()
{
  return( the_right_list );
}

//------------------------------------------------------------------------------
// Eigentlich gibt es beim Algorithmus left- und rightshifting Operationen
// Ich spare mir das und vertausche die Mengen dafuer immer entsprechend.
// Diese Funktion setzt 
//     the_left_list
//     the_right_list
//     the_left_seed
//     the_right_seed
// entsprechend der n"achsten Aktion. Sie macht auch die Initialisierung f"ur 
// den Start der Schiebeaktionen ausgehend von den zwei Senken.
// ACHTUNG: Im Gegensatz zum Orginal wollen wir in jeder Liste mindestens 2 
//          Knoten. Deshalb wird sofort einer zugef"ugt.
//------------------------------------------------------------------------------

void  Partitioning::SetCurSets( int how_to_set )
{
  node          n;
  int           i;
  tree_edge     *cur_edge;
  node          target_node;
  node_info     *n_info;
  list<tree_edge*> cur_edges;

  switch( how_to_set )
  {
    case FROM_SEED_1:
      // Linkes seed bleibt alleine-Rest in rechte Liste
      // Optimum vorbelegen und Knotenzahl ausrechnen
      the_left_list->clear();
      the_right_list->clear();
      the_partition_nodes->del     ( the_left_seed );
      the_left_list->insert        ( the_left_seed );
      the_optimal_left_list->insert( the_left_seed );

      fornodes_in_set( the_partition_nodes, n )
      {
	the_right_list->insert( n );
	the_optimal_right_list->insert( n );
      }
      the_partition_nodes->insert( the_left_seed );

      //die Kosten ausrechnen
      the_cur_edge_cut = 0;
      n_info = the_graph->inf(the_left_seed);
      forall( cur_edge, *(n_info->GetEdges())  )
      {
	target_node = TREE_EDGE_GET_OTHER_NODE( cur_edge, n_info, the_graph );
	if( the_right_list->member(target_node) ) the_cur_edge_cut += cur_edge->edge_number;
      }
      the_optimal_value = (double)the_cur_edge_cut/(double)(the_right_list->size());
      the_optimal_edge_cut = the_cur_edge_cut;

      // Und noch einen zweiten Knoten dazu
      n = ChooseOptimalNode( &i );
      the_cur_edge_cut += i;
      the_right_list->del          ( n );
      the_optimal_right_list->del  ( n );
      the_left_list->insert        ( n );
      the_optimal_left_list->insert( n );

      the_optimal_edge_cut = the_cur_edge_cut;
      the_optimal_value = (double)the_cur_edge_cut/(double)((the_partition_nodes->size()-2)*2.0);
     break;
      
    case FROM_SEED_2:    // Rechtes seed bleibt alleine-Rest in rechte Liste
      the_left_list->clear();
      the_right_list->clear();
      the_partition_nodes->del     ( the_right_seed );
      the_left_list->insert        ( the_right_seed );

      fornodes_in_set( the_partition_nodes, n )
      {
	the_right_list->insert( n );
      }
      the_partition_nodes->insert( the_right_seed );

      the_cur_edge_cut = 0;
      n_info = the_graph->inf(the_right_seed);
      forall( cur_edge, *(n_info->GetEdges()) )
      {
	target_node = TREE_EDGE_GET_OTHER_NODE( cur_edge, n_info, the_graph );
	if( the_right_list->member(target_node) ) the_cur_edge_cut += cur_edge->edge_number;
      }
      // Und noch einen zweiten Knoten dazu
      n = ChooseOptimalNode( &i );
      the_cur_edge_cut += i;
      the_right_list->del   ( n );
      the_left_list->insert ( n );
 
      if( (double)(the_cur_edge_cut/((double)(the_partition_nodes->size()-2)*2.0)) < the_optimal_value )
      {
	the_optimal_value = (double)the_cur_edge_cut/(double)(the_right_list->size());
	the_optimal_edge_cut = the_cur_edge_cut;
	copie_set_to( the_left_list, the_optimal_left_list );
	copie_set_to( the_right_list, the_optimal_right_list );
      }
      break;
    case FROM_OPTIMUM_LEFT_SHIFTING: 
      // Kopiere nach Left-Shifting die Knoten aus dem Optimum in die allgemeinen Listen
      // Ist das gleiche wie nach Right_shifting, da die Listen nur vertauscht werden muessen
    case FROM_OPTIMUM_RIGHT_SHIFTING:
      // Kopiere nach Right-Shifting die Knoten aus dem Optimum in die allgemeinen Listen
      copie_set_to( the_optimal_right_list, the_left_list );
      copie_set_to( the_optimal_left_list, the_right_list );
      the_cur_edge_cut = the_optimal_edge_cut;
      break;
  }
}

//------------------------------------------------------------------------------
// Suche in der Rechten Liste den Knoten, der beim Vertauschen den besten
// Wert produziert Kostenfunktion: #Zerschnittene Kanten / (#left_list*#right_list)
// Es reicht hier aber, den Knoten zu suchen, der den besten Wert fuer Kantenschnitte
// hat, da ja immer ein Knoten ausgetauscht wird
//------------------------------------------------------------------------------

inline node  Partitioning::ChooseOptimalNode( int* value )
{
  node          n;
  register node_info     *n_info;
  tree_edge     *cur_edge;
  register node          target_node;
  register int           cur_costs, opt_costs;
  register node          opt_node;

  opt_costs = 600000; 
  opt_node  = NULL;
  if( the_right_list->size() < 3 ) return( NULL );

  fornodes_in_set( the_right_list, n )
  {
    n_info = the_graph->inf( n );
    cur_costs = 0;
    //compute costs
    forall( cur_edge, *(n_info->GetEdges()) )
    {
      if( the_graph->inf(cur_edge->source) == n_info ) target_node = cur_edge->target;
      else                                             target_node = cur_edge->source;

      if( the_left_list->member (target_node) ) cur_costs -= cur_edge->edge_number;
      if( the_right_list->member(target_node) ) cur_costs += cur_edge->edge_number;
    }
    //update optimum
    if( opt_costs > cur_costs )
    {
      opt_costs = cur_costs;
      opt_node = n;
    }
  }
  *value = opt_costs;
  return( opt_node );
}

//------------------------------------------------------------------------------
// Die Shiebefunktion. Waehlt aus der rechten Liste den Optimalen Knoten bis die
// Liste nur noch zwei Knoten hat.
// Falls dabei ein neuer Optimaler Schnitt gefunden wird, werden alle Updates 
// gemacht.
//------------------------------------------------------------------------------

void  Partitioning::Shifting()
{
  node    opt_node;
  register int value;
  register double  nr_nodes_left;
  register double  new_opt;

  // Get Node with optimal Value
  while( (opt_node = ChooseOptimalNode( &value )) )
  {
    the_cur_edge_cut += value;

    the_right_list->del  ( opt_node );
    the_left_list->insert( opt_node );

    nr_nodes_left = the_left_list->size();
    if( the_partition_nodes->size() > nr_nodes_left )
    {
      new_opt = (double)the_cur_edge_cut/(((double)the_partition_nodes->size()
					       -(double)nr_nodes_left)*nr_nodes_left);
      if( new_opt < the_optimal_value )
      {
	improvement = TRUE;
	the_optimal_edge_cut = the_cur_edge_cut;
	the_optimal_value = new_opt;
	copie_set_to( the_left_list, the_optimal_left_list );
	copie_set_to( the_right_list, the_optimal_right_list );
      }
    }
  }
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

OneLevelPartition::OneLevelPartition( int size )
{
  the_partitions = new p_queue<scalar, adv_node_set*>;
  max_size       = size;
  max_set_nr     = 0;
}

OneLevelPartition::~OneLevelPartition()
{
  the_partitions->~p_queue();
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void       OneLevelPartition::InsertSet( adv_node_set *new_set, GRAPH_TYPE *g )
{
  adv_node_set  *copied_set;
  node          cur_node;

  copied_set = new adv_node_set( g );

  fornodes_in_set( new_set, cur_node )   copied_set->insert( cur_node );
  the_partitions->insert( -copied_set->size(), copied_set );
}

//------------------------------------------------------------------------------
// Erhaelt node_set und p_queue ueber node_sets und maximale Anzahl Knoten. 
// Ueberprueft, ob node_set zusammenhaengend ist. Wenn nein zersplittern in 
// 2 Komponenten. Die erste ist dabei zusammenhaengend
// Falls die erste Komponente groesser als max_size ist, wird diese zurueckgegeben.
// Falls keine zersplitterung erfolgt, wird das eingabeset zurueckgegeben.
// Sonst wird NULL zurueckgegeben.
//------------------------------------------------------------------------------

adv_node_set* split_in_unconnected_sets( adv_node_set *nodes, 
					  p_queue<scalar, adv_node_set*> *sets,
					  int  max_size, GRAPH_TYPE *g )
{
  node          target_node, start_node, n;
  tree_edge     *cur_edge;
  adv_node_set  start_nodes(g), *new_set;
  node_info     *s_info, *t_info;
  bool          unconnected;

  fornodes_in_set( nodes, n )  g->inf(n)->SetRepresented( FALSE );
  start_node = nodes->choose();
  g->inf(start_node)->SetRepresented( TRUE );
  start_nodes.insert( start_node );
  while( FALSE == start_nodes.empty() ) 
  {
    start_node   = start_nodes.choose();
    start_nodes.del( start_node );
    s_info = g->inf( start_node );

    forall( cur_edge, *(s_info->GetEdges()) )
    {
      target_node = TREE_EDGE_GET_OTHER_NODE( cur_edge, s_info, g );
      t_info = g->inf( target_node );
      if( FALSE == t_info->GetRepresented() && nodes->member(target_node) )
      {
	t_info->SetRepresented( TRUE );
	start_nodes.insert( target_node );
      }
    }
  }
  // test ob es unmarkierte Knoten gibt
  unconnected = FALSE;
  fornodes_in_set( nodes, n ) if( FALSE == g->inf(n)->GetRepresented() ) unconnected = TRUE;

  if( unconnected )
  {
    new_set = new adv_node_set( g );
    fornodes_in_set( nodes, n ) 
    {
      if( FALSE == g->inf(n)->GetRepresented() ) new_set->insert( n );
    }

    fornodes_in_set( new_set, n )  nodes->del( n );

    fornodes_in_set( nodes, n ) g->inf(n)->SetRepresented( FALSE );
    sets->insert( -new_set->size(), new_set );
    if( nodes->size() > max_size ) return( nodes );
    sets->insert( -nodes->size(), nodes );
    return( NULL );
  }
  return( nodes );
}

//------------------------------------------------------------------------------
// Sucht einen Set, dessen Groesse groesser als das Maximum ist. Ausserdem wird
// bei jedem set das zurueckgegeben werden soll, zuerst geschaut, ob es 
// zusammenhaengend ist. Wenn nein, wird es entsprechend aufgesplittet
//------------------------------------------------------------------------------

adv_node_set*  OneLevelPartition::GetSet( GRAPH_TYPE *g)
{
  adv_node_set   *back_set;

  if( -the_partitions->prio(the_partitions->find_min()) > max_size )
  {
    back_set = the_partitions->inf(the_partitions->find_min());
    the_partitions->del_min();
    back_set = split_in_unconnected_sets(back_set, the_partitions, max_size, g);
    //rekursiver Aufruf, falls Zersplitterung zu zu kleinen Sets fuehrt
    if( !back_set ) return( GetSet(g) ); 
    return( back_set );
  }
  return( NULL );
}


//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

adv_node_set*  OneLevelPartition::CreateHierarchieNodes( GRAPH_TYPE *g )
{
  node_info         *new_info, *son_info;
  adv_node_set      *cur_set;
  node              cur_node, new_node;
  tree_edge         *cur_edge;
  node              target_node;
  node_info         *target_info;
  adv_node_set      *new_group;
  list<edge>        *edges;
  list<tree_edge*>  cur_edges;
  list<node>        buffer;
  list<adv_node_set*> set_buffer;

  max_set_nr++;
  // Als erstes mal die Knoten erzeugen
  while( FALSE == the_partitions->empty() )
  {
    cur_set = the_partitions->inf(the_partitions->find_min());
    the_partitions->del_min();
    set_buffer.push(cur_set );

    new_info = new node_info();
    new_info->SetSons        ( cur_set );
    new_node = g->new_node( new_info );
    buffer.push( new_node );

    max_set_nr++;
    fornodes_in_set( cur_set, cur_node )
    {
      son_info = g->inf( cur_node );
      son_info->SetFather( new_node );
      son_info->SetRepresented( TRUE );
    }
  }

  new_group = new adv_node_set( g );
  forall( cur_node, buffer ) {   new_group->insert( cur_node );  }

  // und die Kanten erzeugen
  forall(cur_set, set_buffer )
  {
    fornodes_in_set( cur_set, cur_node )
    {
      son_info = g->inf( cur_node );
      son_info->SetRepresented( FALSE );
      // Jetzt alle Kanten durchlaufen
      forall( cur_edge, *(son_info->GetEdges()) )
      {
	if( g->inf(cur_edge->source) == son_info ) target_node = cur_edge->target;
	else                                       target_node = cur_edge->source;
	target_info = g->inf( target_node );
	if( target_info->GetRepresented() == TRUE )
	{
	  if( target_info->GetFather(g) != son_info->GetFather(g) )
	  {
	    edges = cur_edge->corresponding_edges;
	    CreateTreeEdge( edges, cur_node, target_info->GetGraphFather(), g );
	    CreateTreeEdge( edges, son_info->GetGraphFather(), target_node, g );
	    CreateTreeEdge( edges, son_info->GetGraphFather(), target_info->GetGraphFather(), g );
	  }
	}
      }
    }
  }
  return( new_group );
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void  GetSeeds( GRAPH_TYPE *g, adv_node_set *cur_set, node *seed1, node *seed2 )
{
  int           cur_nodedist;
  node_info     *startn_info;
  node          neighbor, n, start_node, last_neighbor;
  node_info     *neighbor_info;
  adv_node_set  start_nodes( g ), new_start_nodes( g );
  tree_edge     *cur_edge;
  list<tree_edge*>  cur_edges;

  *seed1 = cur_set->choose();
  cur_nodedist = 1;
  (g->inf(*seed1))->SetLayouted( TRUE );
  start_nodes.insert( *seed1 );

  while( FALSE == start_nodes.empty() ) 
  {
    start_node = start_nodes.choose();
    start_nodes.del( start_node );
    startn_info = g->inf( start_node );
    forall( cur_edge, *(startn_info->GetEdges()) )
    {
      neighbor = TREE_EDGE_GET_OTHER_NODE( cur_edge, startn_info, g );
      neighbor_info = g->inf( neighbor );

      if( (FALSE == neighbor_info->GetLayouted())    &&
	  (TRUE == cur_set->member(neighbor))        )
      {
	last_neighbor = neighbor;
	neighbor_info->SetLayouted( TRUE );
	new_start_nodes.insert( neighbor );
      }
    }

    if( TRUE == start_nodes.empty() )
    {
      while( FALSE == new_start_nodes.empty() )
      {
	n = new_start_nodes.choose();
	start_nodes.insert( n );
	new_start_nodes.del( n );
      }
      cur_nodedist++;
    }
  }
  // jetzt steht in neighbor noch ein Knoten. Das ist die zweite Senke
  *seed2 = last_neighbor;

  forall_nodes( n, *g ) (g->inf(n))->SetLayouted( FALSE );
}

//------------------------------------------------------------------------------
// Funktion erhaelt eine Liste von Knoten, fuer die eine Partition erstellt 
// werden soll. Erstellt dafuer rekursiv alle Partitionen. d.h. auch fuer die 
// Partitionen wieder neue Partitionen 
//------------------------------------------------------------------------------

adv_node_set* ComputePartitioning( GRAPH_TYPE *g, adv_node_set *cur_nodes, int size )
{
	node               seed1;
	node               seed2;
	adv_node_set       *cur_set;
	Partitioning       *this_set_partition;
	OneLevelPartition  *this_level_partition;

	// Solange keine Wurzel gefunden wurde
	while( FALSE == cur_nodes->empty() ) {
		this_level_partition = new OneLevelPartition( size );
		this_level_partition->InsertSet( cur_nodes, g );
		cur_nodes->~adv_node_set();
		// Diese Schleife zerlegt eine Menge von Knoten so lange, bis die Anzahl der
		// Knoten in jeder Partition < max_size ist
		while( NULL != (cur_set = this_level_partition->GetSet(g)) ) {
			GetSeeds( g, cur_set, &seed1, &seed2 );
			this_set_partition = new Partitioning( g, cur_set, seed1, seed2 );
  
			this_set_partition->SetCurSets( FROM_SEED_1 );
			this_set_partition->Shifting();
			this_set_partition->SetCurSets( FROM_SEED_2 );
			this_set_partition->Shifting();
			this_set_partition->SetCurSets( FROM_OPTIMUM_RIGHT_SHIFTING );
			while( this_set_partition->improvement ) {
				this_set_partition->improvement = FALSE;
				this_set_partition->Shifting();
				this_set_partition->SetCurSets( FROM_OPTIMUM_LEFT_SHIFTING );
				this_set_partition->Shifting();
				this_set_partition->SetCurSets( FROM_OPTIMUM_RIGHT_SHIFTING );
			}
			this_level_partition->InsertSet( this_set_partition->GetLeftList(), g );
			this_level_partition->InsertSet( this_set_partition->GetRightList(), g );
			this_set_partition->~Partitioning();
		}
		cur_nodes = this_level_partition->CreateHierarchieNodes( g );
		this_level_partition->~OneLevelPartition();
		// wenn es einelementig ist, dann hoeren wir hier auf und
		// schicken die Wurzel zurueck
		if( 1 == cur_nodes->size() )   return( cur_nodes );
	}
	return( NULL );
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void HiSpring::CopyEdgesToTreeEdges()
{
  node        cur_node;
  edge        cur_edge;

  forall_nodes( cur_node, *the_graph )
  {
   forall_out_edges( cur_edge, cur_node )
    {
      CreateTreeEdge( cur_edge, cur_node,
		  the_graph->target(cur_edge), the_graph );
    }
  }
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void HiSpring::SetValidHierarchieLevels( adv_node_set *nodes )
{
  adv_node_set   buffer( the_graph );
  node_info      *father_inf;
  node           n;
  int            cur_level;

  if( NULL == nodes )  return;

  father_inf = (the_graph->inf(nodes->choose()))->GetFather(the_graph);
  if( father_inf )          cur_level = father_inf->GetLevel()+1;
  else                      cur_level = 0;

  if( max_level < cur_level) max_level = cur_level;

  fornodes_in_set( nodes, n )
  {
    (the_graph->inf(n))->SetLevel( cur_level );
    SetValidHierarchieLevels( (the_graph->inf(n))->GetSons() );
  }
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void HiSpring::ComputeRCHierarchie()
{
  adv_node_set  *node_list;
  node          cur_node;

  // Make node_set of nodes
  node_list = new adv_node_set( the_graph );
  forall_nodes( cur_node, *the_graph )     node_list->insert( cur_node );

  // copy edges to Tree_edges
  CopyEdgesToTreeEdges();

  hierarchie = ComputePartitioning( the_graph, node_list, max_nodes_per_set );
  SetValidHierarchieLevels( hierarchie );
  max_level++;
  levels = new hierarchie_levelling();
  levels->CreateLevelling     ( hierarchie, max_level, the_graph );
}
