/*************************************************************************/
/*************************************************************************/
/**  Elzinga-Hearn-Algorithmus und zugehoerige Funktionen  (elzinga.c)  **/
/*************************************************************************/
/*************************************************************************/


#include "typen.h"
#include "fkt_dast.h"
#include "elzinga.h"

#include "hispring.h"

/*****************/
/**  kollinear  **/
/*****************/
extern int kollinear(int j,int k,int l)
/* Diese Funktion ueberprueft, ob pu[j],pu[k] und pu[l] kollinear sind */
{double x2,x3,y2,y3;

 /* x1=0;y1=0;                                   Verschieben von pu[j] in den Nullpunkt */
 x2=pu[k].x-pu[j].x;y2=pu[k].y-pu[j].y;
 x3=pu[l].x-pu[j].x;y3=pu[l].y-pu[j].y;
 if (x3*y2==y3*x2)
    {return(1);}                                 /* die Punkte sind kollinear */
 else {return(0);}                               /* die Punkte sind nicht kollinear */
} /* Ende kollinear */


/**************************/
/** alle_Punkte_bedeckt  **/
/**************************/
static int alle_Punkte_bedeckt(struct kreis kr )
{
  int i,neuer_Punkt;

  for (i=1;i<=Anzahl_der_Punkte;i++)
  {
    if( (i != kr.p1) && (i != kr.p2) && (i !=kr.p3) &&
	abstand(pu[i],kr.mp)>kr.radius+epsilon2 )
    {
	     /* sonst Rundungsfehler moeglich, falls 4 Punkte auf einem Kreis liegen ! */
      neuer_Punkt=berechne_weitesten_Punkt(kr.mp,kr.radius,i);
      return(neuer_Punkt);                 /* gib einen Punkt zurueck, der noch nicht ueberdeckt wird */
    }
  }
  return(0);                                      /* d.h. alle Punkte sind bedeckt */
} /* Ende alle_Punkte_bedeckt */


/**************/
/**  step_0  **/
/**************/
static struct kreis step_0()
{
  struct kreis kr;
  double       dist, d_neu;
  int          i, j, opt_i, opt_j;

  dist = 1;

  for (i=1;i<=Anzahl_der_Punkte;i++)
  {
    for ( j = i+1; j <= Anzahl_der_Punkte; j++)
    {
      d_neu = SQR( pu[i].x-pu[j].x ) + SQR( pu[i].y-pu[j].y );
      if( d_neu > dist )
      {
	dist = d_neu;
	opt_i  = i;
	opt_j  = j;
      }
    }
  }
  kr.p1 = opt_i;
  kr.p2 = opt_j;
  kr.p3=0;

  return(kr);
}/*
static struct kreis step_0()
{
  struct kreis kr;
  double       dist, d_neu;
  int          i, opt;

  kr.p1 = 1;
  dist  = SQR( pu[1].x-pu[2].x ) + SQR( pu[1].y-pu[2].y );
  opt   = 2;


  for (i=3;i<=Anzahl_der_Punkte;i++)
  {
    d_neu = SQR( pu[1].x-pu[i].x ) + SQR( pu[1].y-pu[i].y );
    if( d_neu > dist )
    {
      dist = d_neu;
      opt  = i;
    }
  }
  kr.p2 = opt;
  kr.p3=0;

  return(kr);
}*/ /* Ende step_0 */


/**************/
/**  step_1  **/
/**************/
static void step_1(struct kreis *kr_zei)
{
  kr_zei->radius=(abstand(pu[kr_zei->p1],pu[kr_zei->p2]))/2;
  (kr_zei->mp).x=(pu[kr_zei->p1].x+pu[kr_zei->p2].x)/2;
  (kr_zei->mp).y=(pu[kr_zei->p1].y+pu[kr_zei->p2].y)/2;
} /* Ende step_1 */


/**************/
/**  step_2  **/
/**************/
static void step_2(struct kreis *kr_zei,int neuer_Punkt,int *schritt1)
{double       r_hi;
 struct punkt m_hi;

 kr_zei->p3=neuer_Punkt;
 /* Test, ob p2 in K(p1,p3) enthalten ist */
 r_hi=abstand(pu[kr_zei->p1],pu[kr_zei->p3])/2;
 m_hi.x=(pu[kr_zei->p1].x+pu[kr_zei->p3].x)/2;
 m_hi.y=(pu[kr_zei->p1].y+pu[kr_zei->p3].y)/2;
 if (abstand(pu[kr_zei->p2],m_hi)<=r_hi+epsilon2)          /* sonst Rundungsfehler moeglich */
    {*schritt1=1;
     kr_zei->p2=kr_zei->p3;
     kr_zei->p3=0;
    }
 else { /* Test, ob p1 in K(p2,p3) enthalten ist */
       r_hi=abstand(pu[kr_zei->p2],pu[kr_zei->p3])/2;
       m_hi.x=(pu[kr_zei->p2].x+pu[kr_zei->p3].x)/2;
       m_hi.y=(pu[kr_zei->p2].y+pu[kr_zei->p3].y)/2;
       if (abstand(pu[kr_zei->p1],m_hi)<=r_hi+epsilon2)    /* sonst Rundungsfehler moeglich */
	  {*schritt1=1;
	   kr_zei->p1=kr_zei->p3;
	   kr_zei->p3=0;
	  }
      }
} /*Ende step_2 */


/**************/
/**  step_3  **/
/**************/
static int step_3(struct kreis *kr_zei)
{
 int          neuer_Punkt;

 /* kr_zei->p1,kr_zei->p2,kr->p3 sind wegen step_2 nicht kollinear bzw. identisch */
 berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p1,kr_zei->p2,kr_zei->p3);
 neuer_Punkt=alle_Punkte_bedeckt(*kr_zei);
 return(neuer_Punkt);
} /* Ende step_3 */


/**************/
/**  step_4  **/
/**************/
static void step_4(struct kreis *kr_zei,int *neuer_Punkt,int *schritt1,int *fertig)
{struct punkt m_ad,m1,m2,m3;
 int          p4,hi,kand1,kand2,kand3,koll;
 double       hilf,ad,bd,cd,r1,r2,r3;


 p4=*neuer_Punkt;
 ad=abstand(pu[kr_zei->p1],pu[p4]);
 bd=abstand(pu[kr_zei->p2],pu[p4]);
 cd=abstand(pu[kr_zei->p3],pu[p4]);
 if (ad<bd)
    {hilf=ad;
     ad=bd;
     bd=hilf;
     hi=kr_zei->p1;
     kr_zei->p1=kr_zei->p2;
     kr_zei->p2=hi;
    }
 if (ad<cd)
    {hilf=ad;
     ad=cd;
     cd=hilf;
     hi=kr_zei->p1;
     kr_zei->p1=kr_zei->p3;
     kr_zei->p3=hi;
    }
 m_ad.x=(pu[kr_zei->p1].x+pu[p4].x)/2;
 m_ad.y=(pu[kr_zei->p1].y+pu[p4].y)/2;
 kr_zei->radius=ad/2;
 if (abstand(pu[kr_zei->p2],m_ad)<=kr_zei->radius)         /* Kreis(a,d) bedeckt B */
    {if (abstand(pu[kr_zei->p3],m_ad)<=kr_zei->radius)     /* Kreis(a,d) bedeckt C */
	{kr_zei->p2=p4;
	 kr_zei->p3=0;
	 p4=0;
	 kr_zei->mp=m_ad;
	 kr_zei->radius=ad/2;
	 *schritt1=1;
	 return;                                           /* 'step_4' ist fertig */
	}
     else {/* Kreis(a,d) bedeckt C nicht */
	   koll=kollinear(kr_zei->p1,kr_zei->p3,p4);
	   if (koll==1)
	      {berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p2,kr_zei->p3,p4);
	       kr_zei->p1=p4;
	       p4=0;
	      }
	   else {koll=kollinear(kr_zei->p2,kr_zei->p3,p4);
		 if (koll==1)
		    {berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p1,kr_zei->p3,p4);
		     kr_zei->p2=p4;
		     p4=0;
		    }
		 else {berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p1,kr_zei->p3,p4);
		       m1.x=(kr_zei->mp).x;
		       m1.y=(kr_zei->mp).y;
		       r1=kr_zei->radius;
		       berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p2,kr_zei->p3,p4);
		       m2.x=(kr_zei->mp).x;
		       m2.y=(kr_zei->mp).y;
		       r2=kr_zei->radius;
		       if (    ( (abstand(pu[kr_zei->p2],m1)<=r1)&&(abstand(pu[kr_zei->p1],m2)<=r2)&&(r1<=r2) )
			    || ( (abstand(pu[kr_zei->p2],m1)<=r1)&&(abstand(pu[kr_zei->p1],m2)>r2) )
			  )
			  {(kr_zei->mp).x=m1.x;            /* der gesuchte Kreis wird durch p1,p3 und p4 bestimmt */
			   (kr_zei->mp).y=m1.y;
			   kr_zei->radius=r1;
			   kr_zei->p2=p4;
			   p4=0;
			  }
		       else {(kr_zei->mp).x=m2.x;          /* der gesuchte Kreis wird durch p2,p3 und p4 bestimmt */
			     (kr_zei->mp).y=m2.y;
			     kr_zei->radius=r2;
			     kr_zei->p1=p4;
			     p4=0;
			    }
		      }
		}
	  }
    }
 else {/* Kreis(a,d) bedeckt B nicht */
       if (abstand(pu[kr_zei->p3],m_ad)<=kr_zei->radius)   /* Kreis(a,d) bedeckt C */
	  {koll=kollinear(kr_zei->p1,kr_zei->p2,p4);
	   if (koll==1)
	      {berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p2,kr_zei->p3,p4);
	       kr_zei->p1=p4;
	       p4=0;
	      }
	   else {koll=kollinear(kr_zei->p2,kr_zei->p3,p4);
		 if (koll==1)
		    {berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p1,kr_zei->p2,p4);
		     kr_zei->p3=p4;
		     p4=0;
		    }
		 else {berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p1,kr_zei->p2,p4);
		       m1.x=(kr_zei->mp).x;
		       m1.y=(kr_zei->mp).y;
		       r1=kr_zei->radius;
		       berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p2,kr_zei->p3,p4);
		       m2.x=(kr_zei->mp).x;
		       m2.y=(kr_zei->mp).y;
		       r2=kr_zei->radius;
		       if (    ( (abstand(pu[kr_zei->p3],m1)<=r1)&&(abstand(pu[kr_zei->p1],m2)<=r2)&&(r1<=r2) )
			    || ( (abstand(pu[kr_zei->p3],m1)<=r1)&&(abstand(pu[kr_zei->p1],m2)>r2) )
			  )
			  {(kr_zei->mp).x=m1.x;            /* der gesuchte Kreis wird durch p1,p2 und p4 bestimmt */
			   (kr_zei->mp).y=m1.y;
			   kr_zei->radius=r1;
			   kr_zei->p3=p4;
			   p4=0;
			  }
		       else {(kr_zei->mp).x=m2.x;          /* der gesuchte Kreis wird durch p2,p3 und p4 bestimmt */
			     (kr_zei->mp).y=m2.y;
			     kr_zei->radius=r2;
			     kr_zei->p1=p4;
			     p4=0;
			    }
		      }
		}
	  }
       else {/* Kreis(a,d) bedeckt C nicht */
	     kand1=0;
	     kand2=0;
	     kand3=0;
	     koll=kollinear(kr_zei->p1,kr_zei->p2,p4);
	     if (koll==0)
		{berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p1,kr_zei->p2,p4);
		 m1.x=(kr_zei->mp).x;
		 m1.y=(kr_zei->mp).y;
		 r1=kr_zei->radius;
		 if (abstand(pu[kr_zei->p3],m1)<=r1)       /* Kreis 1 bedeckt p3 */
		    {kand1=1;}
		}
	     koll=kollinear(kr_zei->p1,kr_zei->p3,p4);
	     if (koll==0)
		{berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p1,kr_zei->p3,p4);
		 m2.x=(kr_zei->mp).x;
		 m2.y=(kr_zei->mp).y;
		 r2=kr_zei->radius;
		 if (abstand(pu[kr_zei->p2],m2)<=r2)       /* Kreis 2 bedeckt p2 */
		    {kand2=2;}
		}
	     koll=kollinear(kr_zei->p2,kr_zei->p3,p4);
	     if (koll==0)
		{berechne_Mittelpunkt_und_Radius(kr_zei,kr_zei->p2,kr_zei->p3,p4);
		 m3.x=(kr_zei->mp).x;
		 m3.y=(kr_zei->mp).y;
		 r3=kr_zei->radius;
		 if (abstand(pu[kr_zei->p1],m3)<=r3)       /* Kreis 3 bedeckt p1 */
		    {kand3=3;}
		}
	     if (    ( (kand1==0)&&(kand2==0) ) || ( (kand2==2)&&(kand3==3)&&(r3<r2) ) || ( (kand1==1)&&(kand3==3)&&(r3<r1) )
		  || ( (kand1==1)&&(kand2==2)&&(kand3==3)&&(r3<r1)&&(r3<r2) )
		)
		{(kr_zei->mp).x=m3.x;                      /* der gesuchte Kreis wird von p2,p3 und p4 bestimmt */
		 (kr_zei->mp).y=m3.y;
		 kr_zei->radius=r3;
		 kr_zei->p1=p4;
		 p4=0;
		}
	     else {if (    ( (kand1==0)&&(kand3==0) ) || ( (kand2==2)&&(kand3==3)&&(r2<=r3) ) || ( (kand2==2)&&(kand1==1)&&(r2<r1) )
			|| ( (kand1==1)&&(kand2==2)&&(kand3==3)&&(r2<r1)&&(r2<=r3) )
		      )
		      {(kr_zei->mp).x=m2.x;                /* der gesuchte Kreis wird von p1,p3 und p4 bestimmt */
		       (kr_zei->mp).y=m2.y;
		       kr_zei->radius=r2;
		       kr_zei->p2=p4;
		       p4=0;
		      }
		   else {(kr_zei->mp).x=m1.x;              /* der gesuchte Kreis wird von p1,p2 und p4 bestimmt */
			 (kr_zei->mp).y=m1.y;
			 kr_zei->radius=r1;
			 kr_zei->p3=p4;
			 p4=0;
			}
		  }
	    }
      }
 *neuer_Punkt=alle_Punkte_bedeckt(*kr_zei);
 if (*neuer_Punkt==0)
    {*fertig=1;}
}


/*********************************/
/**  elzinga_hearn_algorithmus  **/
/*********************************/
extern struct kreis elzinga_hearn_algorithmus()
/* Diese Funktion berechnet den kleinsten Kreis, der alle gegebenen Punkte ueberdeckt.        */
/* Entscheidend ist dabei, ob die Punkte gueltig sind, d.h. ob i==i gilt.        */
/* Punkte fuer die i==0 gilt, werden beim Ueberdecken vernachlaessigt.           */
/* 'version'==1 bedeutet, dass zum Iterieren der am weitesten entfernte Punkt verwendet wird; */
/* 'version'==2 bedeutet, dass zum Iterieren ein beliebiger Punkt verwendet wird.             */
{struct kreis kr;
 int          fertig,schritt1,neuer_Punkt;

    fertig=0;
    kr=step_0();
 l1:schritt1=0;
    step_1(&kr);
    neuer_Punkt=alle_Punkte_bedeckt(kr);      /* ==0, falls alle Punkte ueberdeckt werden */
    if (neuer_Punkt==0)
       {fertig=1;}
    if (fertig==1)
       {return(kr);}
    step_2(&kr,neuer_Punkt,&schritt1);
    if (schritt1==1)
       {goto l1;}
    neuer_Punkt=step_3(&kr);                  /* ==0, falls alle Punkte ueberdeckt werden */
    if (neuer_Punkt==0)
       {fertig=1;}
 l3:if (fertig==1)
       {return(kr);}
    step_4(&kr,&neuer_Punkt,&schritt1,&fertig);
    if (schritt1==1)
       {goto l1;}
    else {goto l3;}
} /* Ende elzinga_hearn_algorithmus */


/****************************************************************/
/****************************************************************/
/**  Ende des Elzinga-Hearn-Algorithmus und seiner Funktionen  **/
/****************************************************************/
/****************************************************************/
