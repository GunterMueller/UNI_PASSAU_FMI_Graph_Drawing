#include "hispring.h"
#include <LEDA/queue.h>

  extern void TreeOut( adv_node_set *root_elems, GRAPH_TYPE *the_graph );

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

hierarchie_levelling::hierarchie_levelling()
{
  mapping = NULL;
  nr_sets_in_level = NULL;
}

//-----------------------------------------------------------------------------
// Rekursive Funktion zum Berechnen der Anzahl Sets je Hierarchiestufe
//-----------------------------------------------------------------------------

void  GetNrSets( adv_node_set *hierarchie, int *set_nr, GRAPH_TYPE *the_graph )
{
  adv_node_set    *group1; 
  adv_node_set    group2(the_graph); 
  node        n;
  int         level;

  if( NULL == hierarchie ) return;

  group1 = hierarchie;
  level = (the_graph->inf(group1->choose()))->GetLevel();

  set_nr[level] = set_nr[level] +1;

  while( FALSE == group1->empty() )
  {
    n = group1->choose();
    group2.insert( n );
    group1->del( n );
  }

  // Rekursiver Aufruf fuer alle Soehne 
  while( FALSE == group2.empty() )
  {
    n = group2.choose();
    if( NULL != (the_graph->inf(n))->GetSons() )
    {
      GetNrSets( (the_graph->inf(n))->GetSons(), set_nr, the_graph );
    }
    group1->insert( n );
    group2.del( n );
  }  
}

//------------------------------------------------------------------------------
// Sucht sich einen Knoten der Gruppe, f"uhrt dann Breitensuche aus und ordnet
// Knoten gem"a"s Breitensuche neu an
//------------------------------------------------------------------------------

void SortGroup( adv_node_set *cur_set, GRAPH_TYPE *the_graph )
{
  adv_node_set  start_nodes( the_graph ), new_start_nodes( the_graph );
  queue<node>   result;
  tree_edge     *cur_edge;
  node          n, neighbor;

  n = cur_set->choose();
  cur_set->del( n );
  start_nodes.insert( n );

  while( !cur_set->empty() || !start_nodes.empty() )
  {
    n = start_nodes.choose();
    start_nodes.del( n );
    result.append( n );

    forall( cur_edge, *(the_graph->inf(n)->GetEdges()) )
    {
      neighbor = TREE_EDGE_GET_OTHER_NODE(
		  cur_edge, the_graph->inf(n), the_graph );
      if( TRUE == cur_set->member(neighbor) )
      {
	  new_start_nodes.insert( neighbor );
	  cur_set->del( neighbor );
      }
   }

    if( TRUE == start_nodes.empty() )
    {
      copie_set_to( &new_start_nodes, &start_nodes );
      new_start_nodes.clear();
    }
    if( start_nodes.empty() && !cur_set->empty() )
    {
      n = cur_set->choose();
      cur_set->del( n );
      start_nodes.insert( n );
    }
  }

  while( FALSE == result.empty() )
  {
    n = result.pop();
    cur_set->insert( n );
  }
}

//------------------------------------------------------------------------------
// Rekursive Funktion, die die Zeiger vom 2-dim Feld auf die node_sets setzt.
//------------------------------------------------------------------------------

void  SetSetsInMapping( adv_node_set *hierarchie, int *set_nr, 
			SET_FIELD *mapping, GRAPH_TYPE *the_graph )
{
	node        n;
	int         cur_index;
	int         cur_level;

	if( NULL == hierarchie ) return;
	cur_level         = (the_graph->inf(hierarchie->choose()))->GetLevel();
	cur_index         = set_nr[cur_level];

	set_nr[cur_level] = set_nr[cur_level] + 1;

	(*mapping)(cur_level, cur_index) = hierarchie;

	SortGroup( hierarchie, the_graph );

	fornodes_in_set( hierarchie, n ) {
		if( NULL != (the_graph->inf(n))->GetSons() ) {
			SetSetsInMapping(
				(the_graph->inf(n))->GetSons(), set_nr, mapping, the_graph );
		}
	}
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

void hierarchie_levelling::CreateLevelling( adv_node_set *hierarchie, 
					    int levels, GRAPH_TYPE *the_graph )
{
  int  max_sets, i;


  nr_levels = levels;
  last_index = -1;

  max_sets = 0;
  nr_sets_in_level = (int*) calloc( sizeof(int), levels );

  for( i= 0; i < levels; i++ ) nr_sets_in_level[i] = 0;
  
  GetNrSets( hierarchie,nr_sets_in_level, the_graph  );

  for( i= 0; i < levels; i++ )
  {
    if( max_sets < nr_sets_in_level[i] )   max_sets = nr_sets_in_level[i];
    nr_sets_in_level[i] = 0;
  }

  mapping = new SET_FIELD(nr_levels, max_sets );
  SetSetsInMapping( hierarchie, nr_sets_in_level, mapping, the_graph );
}

//------------------------------------------------------------------------------
// Funktion zum Durchlaufen aller Hierarchielevel
//------------------------------------------------------------------------------

int hierarchie_levelling::GetNextLevel( int last_level )
{
  if( last_level == nr_levels-1 ) return( -1 );
  return( last_level + 1);
}

//------------------------------------------------------------------------------
// Funktion zum Durchlaufen aller Sets in einem Gegebenen Level
//------------------------------------------------------------------------------

adv_node_set*  hierarchie_levelling::GetNextSet( int cur_level )
{
  last_index++;
  if( nr_sets_in_level[cur_level] == last_index )
  {
    last_index = -1;
    return( NULL );
  }
  return( (*mapping)(cur_level, last_index) );
}

//------------------------------------------------------------------------------
// Konstruktor fuer Klasse node_info
//------------------------------------------------------------------------------

node_info::node_info()
{
  gen_a.node_radius        = DEFAULT_RADIUS;
  gen_a.is_layouted        = FALSE;
  gen_a.is_represented     = FALSE;
  gen_a.coordinates.x      = 0;
  gen_a.coordinates.y      = 0;

  gem_a.scaled_coordinates.x = 0;
  gem_a.scaled_coordinates.y = 0;
  gem_a.node_heat          = INITIAL_HEAT;
  gem_a.node_dir           = 0;

  hie_a.tree_edges         = NULL;
  hie_a.hier_level         = 0;
  hie_a.the_father         = NULL;
  hie_a.the_sons           = NULL;
  hie_a.tree_edges         = new list<tree_edge*>;
  dist_chart               = NULL;
}
