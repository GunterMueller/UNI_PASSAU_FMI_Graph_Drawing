/***************************************************************************/
/***************************************************************************/
/**  Funktionen zur Verwaltung der globalen_Datenstrukturen (fkt_dast.h)  **/
/***************************************************************************/
/***************************************************************************/


extern struct int_speicher *   belege_Speicher_fuer_int_speicher();
extern struct int_speicher * * belege_Speicher_fuer_Zeiger_auf_int_speicher(int i);
extern int *                   belege_Speicher_fuer_int(int i);
extern struct punkt *          belege_Speicher_fuer_punkt(int i);
extern struct kreis *          belege_Speicher_fuer_kreis(int i);
extern double                  abstand(struct punkt a,struct punkt b);
extern void                    berechne_Mittelpunkt_und_Radius(struct kreis *kr_zei,int a,int b,int c);
extern int                     berechne_weitesten_Punkt(struct punkt suchpunkt,double kreis_radius,int anfang);
extern void                    einfuegen_in_Hilfsspeicher(int ueberdeckter_Punkt,int kr_anzahl);
extern void                    kopiere_Liste_von_qu_nach_zi(struct int_speicher *quelle,struct int_speicher ** ziel);
extern void                    kopiere_Liste_von_qu_nach_zi_und_fuege_ein
				       (struct int_speicher *quelle,struct int_speicher ** ziel,int neuer_Punkt);
extern void                    update_Kreisliste(int rek_stufe,int m);
extern void                    einfuegen_in_Kreisliste(struct kreis neuer_kr,int pegel);
extern void                    einfuegen_in_gesicherte_kreis_liste(struct kreis neuer_kr,int pegel);
extern double                  max_Radius(int m);
extern void                    endbehandlung(struct kreis kr,int m);


/**********************************************************************/
/**********************************************************************/
/**  Ende der Funktionen zur Verwaltung der globalen Datenstrukturen **/
/**********************************************************************/
/**********************************************************************/
