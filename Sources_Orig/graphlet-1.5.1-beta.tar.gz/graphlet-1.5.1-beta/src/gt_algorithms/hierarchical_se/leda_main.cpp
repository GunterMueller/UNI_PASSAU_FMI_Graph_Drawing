#include "hispring.h"
#include "leda_main.h"

extern void HiSpring_InterfaceExample();

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Main Class. Tcl calls it. Create one instance of typ HiSpring, do some
// settings and execute the layout-algorithm.
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//
// Constructor
//

GT_Layout_Hispring_Tcl_Algorithm::GT_Layout_Hispring_Tcl_Algorithm (
	const string& name) :
		GT_Tcl_Algorithm (name)
{
}

//
// Execute the algorithm
//

int GT_Layout_Hispring_Tcl_Algorithm::run (GT_Graph& g)
{
	HiSpring   hier_springembedder;
	// hier_springembedder = new HiSpring();

	hier_springembedder.SetSettings( g, show_hierarchie, unite_edges,
		minimize_nodes, variable_edgelen, force_GEM, what_hierarchie,
		max_nodes_per_set, external_scaling );
	
	hier_springembedder.RunHiSpring();
	hier_springembedder.SetLayout( g );
	
	// hier_springembedder->~HiSpring();
   
	return true;
}

int GT_Layout_Hispring_Tcl_Algorithm::check (GT_Graph& /* g */, string& message)
{
	message = "unnecessary";
	return true;
}

int GT_Layout_Hispring_Tcl_Algorithm::parse (GT_Tcl_info& info,
	int& index, GT_Tcl_Graph*/* g*/)
{
	int code = TCL_OK;

	code = Tcl_GetInt( info.interp(), info.argv(index++), &show_hierarchie );
	if(code != TCL_OK) { return code; }

	code = Tcl_GetInt( info.interp(), info.argv(index++), &unite_edges );
	if(code != TCL_OK) { return code; }

	code = Tcl_GetInt( info.interp(), info.argv(index++), &minimize_nodes );
	if(code != TCL_OK) { return code; }

	code = Tcl_GetInt( info.interp(), info.argv(index++), &variable_edgelen );
	if(code != TCL_OK) { return code; }

	code = Tcl_GetInt( info.interp(), info.argv(index++), &force_GEM );
	if(code != TCL_OK) { return code; }

	code = Tcl_GetInt( info.interp(), info.argv(index++), &what_hierarchie );
	if(code != TCL_OK) { return code; }

	code = Tcl_GetInt( info.interp(), info.argv(index++), &max_nodes_per_set );
	if(code != TCL_OK) { return code; }

	code = Tcl_GetInt( info.interp(), info.argv(index++), &external_scaling );
	if(code != TCL_OK) { return code; }

	
	return code;
}

//------------------------------------------------------------------------------
// Erzeugt fuer die gesammte Hierarchie alle Hierarchiekanten.
// Gehe dazu durch alle Kanten im Orginalgraph, erzeuge eine Hierarchiekante 
// zwischen den beiden Knoten und mache das gleiche paarweise mit den Vaetern
// bis eine gemeinsame Wurzel gefunden wurde.
//------------------------------------------------------------------------------

void HiSpring::CreateHierarchieEdges()
{
  edge        cur_edge;
  node        t_node, s_node;
  node_info   *info_source, *info_target;

  forall_edges( cur_edge, *the_graph )
  {
    s_node      = the_graph->source(cur_edge);
    t_node      = the_graph->target(cur_edge);
    info_source = the_graph->inf( s_node );
    info_target = the_graph->inf( t_node );

    if( (info_source->GetFather(the_graph) == info_target) || 
	(info_target->GetFather(the_graph) == info_source) )
    {
      CreateTreeEdge( cur_edge, s_node, t_node, the_graph );
    }
    while( (info_source != info_target) &&
	   (info_source->GetFather(the_graph) != info_target) &&
	   (info_target->GetFather(the_graph) != info_source) )
    {
      CreateTreeEdge( cur_edge, s_node, t_node, the_graph );
      if( info_source->GetLevel() > info_target->GetLevel() )
      {
	s_node      = info_source->GetGraphFather();
	info_source = info_source->GetFather(the_graph);
      } 
      else if( info_source->GetLevel() < info_target->GetLevel() )
      {
	t_node      = info_target->GetGraphFather();
	info_target = info_target->GetFather(the_graph);
      }
      else
      {
	if( (info_source->GetFather(the_graph) != info_target->GetFather(the_graph)) &&
	    info_source->GetFather(the_graph) && info_target->GetFather(the_graph) )
	{
	  CreateTreeEdge( cur_edge, info_source->GetGraphFather(), t_node, the_graph );
	  CreateTreeEdge( cur_edge, s_node, info_target->GetGraphFather(), the_graph );
	}
	s_node      = info_source->GetGraphFather();
	t_node      = info_target->GetGraphFather();
	info_source = info_source->GetFather(the_graph);
	info_target = info_target->GetFather(the_graph);
      }
    }
  }
}

