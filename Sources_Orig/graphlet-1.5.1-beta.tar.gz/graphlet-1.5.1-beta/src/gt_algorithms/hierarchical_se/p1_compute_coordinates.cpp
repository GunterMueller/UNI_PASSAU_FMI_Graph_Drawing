//
// p1_compute_coordinates.cc
//
#include "hispring.h"

float_vec        p1node_center;
double           center_scale;

extern scalar    HSEtemperature;
extern long int  max_temp;
extern double    optedgelen;
extern double    scale_up;
extern double    father_rad;

extern double    ext_scale_down;
extern double    attr_factor;
extern double    dist_factor;
extern double    dist_factor_ext;

extern void displace_fn ( node cur_node, float_vec impulse, GRAPH_TYPE *g, int nr_nodes );

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

float_vec P1ComputeDisplace( node_info *n_info, float_vec cn_position, bool is_border )
{
  register float_vec   displace;
  register double      norm_dist;

  if( is_border )
  {
    displace.x = cn_position.x - (double)n_info->GetScaledX();
    displace.y = cn_position.y - (double)n_info->GetScaledY();
  }
  else
  {
    displace.x = cn_position.x - (double)n_info->GetX();
    displace.y = cn_position.y - (double)n_info->GetY();
  }
  if( (displace.x == 0.0) && (displace.y == 0.0) )   displace.x = 1;

  norm_dist = QNORM(displace.x, displace.y);
  if( norm_dist < 1 )
  {
    displace.x = HIGH_DISTRACT * scale_up;
    displace.y = HIGH_DISTRACT * scale_up;
    return( displace );
  }
  displace.x = displace.x * attr_factor / norm_dist;
  displace.y = displace.y * attr_factor / norm_dist;
  return( displace );
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
float_vec P1ComputeImpulse (node cur_node,
    adv_node_set* /* set1 */,
    adv_node_set* /* border_nodes */,
    GRAPH_TYPE *my_graph)
{
  node                  target_node;
  node_info             *tn_info, *cn_info; 
  register double       norm_dist, capacity;
  register float_vec    cn_position, impulse, displace;
  DistanceField         *df;
  int                   i, is_border;

  cn_info       = my_graph->inf( cur_node );
  cn_position.x = cn_info->GetX();
  cn_position.y = cn_info->GetY();

  impulse.x = rand()%(2 * SHAKE/2 + 1) - SHAKE/2;
  impulse.y = rand()%(2 * SHAKE/2 + 1) - SHAKE/2;
  impulse.x += (p1node_center.x - cn_position.x)*center_scale;
  impulse.y += (p1node_center.y - cn_position.y)*center_scale;

  df = my_graph->inf(cur_node)->GetDistChart();
  for( i = 0; i < df->size; i++ )
  {
    target_node = df->GetNode( i );
    tn_info     = my_graph->inf( target_node );
    is_border   = df->GetIsBorder( i );

    displace  = P1ComputeDisplace( tn_info, cn_position, is_border );
    if( TRUE == is_border )
    {
      impulse.x += displace.x/2.0; //ext_scale_down;
      impulse.y += displace.y/2.0;
    }
    else
    {
      impulse.x += displace.x;
      impulse.y += displace.y;
    }

    if( TRUE == df->GetHasEdge(i) )
    {
      if( TRUE == is_border )
      {
	displace.x    = cn_position.x - tn_info->GetScaledX();
	displace.y    = cn_position.y - tn_info->GetScaledY();
      }
      else
      {
	displace.x    = cn_position.x - tn_info->GetX();
	displace.y    = cn_position.y - tn_info->GetY();
      }
      norm_dist = QNORM(displace.x, displace.y);

      if( norm_dist > 1.0 )
      {
	if( TRUE == is_border )
	{
	  impulse.x -= displace.x * norm_dist / dist_factor_ext;
	  impulse.y -= displace.y * norm_dist / dist_factor_ext;
	}
	else
	{
	  capacity      = (double)df->GetCapacity( i );
	  impulse.x -= capacity*displace.x*norm_dist/dist_factor;
	  impulse.y -= capacity*displace.y*norm_dist/dist_factor;
	  // Kantengewichte: also die abstossende Kraft auch noch
	  impulse.x += (capacity-1.0)*displace.x*attr_factor/norm_dist;
	  impulse.y += (capacity-1.0)*displace.y*attr_factor/norm_dist;
	}
      }
    }
  }
  return( impulse );
}

//------------------------------------------------------------------------------
// Die Funktion zum Vorlayouten des Graphen. Eine 1:1 Uebertragung des Orginals
// auf meine Datenstrukturen
// Schleife zum Aufruf der Funktion, die die eigentliche Verschiebung
// durchfuehrt.
//------------------------------------------------------------------------------

void  HiSpring::PreComputeCoordinates( int cur_father_radius, float_vec cur_center )
{
  int           iteration;
  float_vec     impulse;
  node          cur_node, n;
  int           max_radius;
  int           cur_node_nr;
  double        alpha;
  longint_vec    movement;
  node_info     *cn_info;
  int           overlap;


  p1node_center  = cur_center;
  iteration      = 0;
  cur_node_nr    = actual_nodes->size();
  father_rad     = cur_father_radius;
  ext_scale_down = ext_scaling;
  center_scale   = 256.0 / (double)father_rad;

  max_radius     = 0;
  fornodes_in_set( actual_nodes, n ) max_radius = MAX( max_radius, (the_graph->inf(n))->GetRadius() );

  if( the_edgelen == VARIABLE )      optedgelen = MAX( ELEN, max_radius ) + max_radius*2;
  else                               optedgelen = ELEN + max_radius*2;

  fornodes_in_set( actual_nodes, n ) the_graph->inf(n)->SetHeat( (long int)optedgelen/2 );

  max_temp      = MAX( max_radius*2, ELEN*2 );
  HSEtemperature = cur_node_nr * (long int)optedgelen/2;

  scale_up        = MAX( SQR(max_radius) / SQR(ELEN), 1.0 );
  attr_factor     = NODEDISTSQR * scale_up;
  dist_factor     = NODEDISTSQR / scale_up;
  dist_factor_ext = NODEDISTSQR / scale_up * ext_scale_down;

  //srand( (int)(used_time()*1000) );
  // Solange kein Abbruch:Suche einen Knoten der verschoben werden soll und verschiebe
  while( (HSEtemperature/cur_node_nr > 7) && 
	 (iteration < 2*cur_node_nr*SQR(cur_node_nr)) )
  {
    iteration++;
    fornodes_in_set_random( actual_nodes, cur_node )
    {
      //DrawLayout();
      impulse  = P1ComputeImpulse( cur_node, actual_nodes, border_nodes, the_graph );
      displace_fn( cur_node, impulse, the_graph, cur_node_nr );
    }
  }

  movement.x = 0;
  movement.y = 0;
  fornodes_in_set( actual_nodes, cur_node )
  {
    cn_info    = the_graph->inf(cur_node);
    impulse.x  = cn_info->GetX() - cur_center.x + movement.x;
    impulse.y  = cn_info->GetY() - cur_center.y + movement.y;
    overlap    = (int)(sqrt(SQR(impulse.x) + SQR(impulse.y))+cn_info->GetRadius()
                 - cur_father_radius);
    if( overlap > 0 )
    {
      alpha      = atan2( impulse.y, impulse.x );
      movement.x -= (int)(cos(alpha)*overlap);
      movement.y -= (int)(sin(alpha)*overlap);
    }
  }
  fornodes_in_set( actual_nodes, cur_node )
  {
    cn_info    = the_graph->inf(cur_node);
    cn_info->AddX( movement.x );
    cn_info->AddY( movement.y );
  }
}
