#ifndef GT_LEDA_ALGORITHMS_H
#define GT_LEDA_ALGORITHMS_H

//
// leda_algorithms.h
//
// This file defines several LEDA Algorithms for use in GraphScript.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/leda_algorithms.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:34 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//


//////////////////////////////////////////
//
// class GT_Planarity_Test_Algorithm
//
//////////////////////////////////////////


#include <LEDA/array.h>


class GT_Planarity_Test_Algorithm : public GT_Algorithm {

    GT_CLASS (GT_Planarity_Test_Algorithm, GT_Algorithm);

    GT_VARIABLE (bool, is_planar);
    GT_VARIABLE (edge, self_loop);
    
public:

    GT_Planarity_Test_Algorithm (const string& name);
    virtual ~GT_Planarity_Test_Algorithm ()
    {
    }

    virtual int run (GT_Graph& g);
    virtual int check (GT_Graph& g, string& message);
};



class GT_Tcl_Planarity_Test_Algorithm :
    public GT_Tcl_Algorithm<GT_Planarity_Test_Algorithm>
{
public:
    GT_Tcl_Planarity_Test_Algorithm (const string& name);
    virtual ~GT_Tcl_Planarity_Test_Algorithm ();
 
    virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);

    virtual int check (GT_Graph& g, string& message);
    virtual int run (GT_Graph& g);
};


#endif
