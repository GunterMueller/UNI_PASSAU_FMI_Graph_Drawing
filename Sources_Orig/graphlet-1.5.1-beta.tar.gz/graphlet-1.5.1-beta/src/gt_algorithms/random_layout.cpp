//
// random_layout.cc
//
// This file implements a sample layout algorithm "random".
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/random_layout.cpp,v $
// $Author: himsolt $
// $Revision: 1.4 $
// $Date: 1996/11/17 16:12:33 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

#include <gt_base/Graphlet.h>

#include <gt_tcl/Tcl_Graph.h>
#include <gt_tcl/Tcl_Algorithm.h>

#include "random_layout.h"


//////////////////////////////////////////
//
// class GT_Layout_Random_Algorithm
//
// This is a sample Tcl/LEDA algorithm wich assigns random
// coordinates to nodes and edges.
//
//////////////////////////////////////////


//
// This is the constructor of class GT_Layout_Random_Algorithm.
//
// The parameter name is both used as the name of the
// algorithm and the name of the GraphScript command.
//

GT_Layout_Random_Algorithm::GT_Layout_Random_Algorithm (
    const string& name) :
	GT_Algorithm (name), the_colors (1,4)
{
    the_min_x = 0.0;
    the_min_y = 0.0;
    the_max_x = 250.0;
    the_max_y = 250.0;
			
    GT_Key white = GT::keymapper.add ("#FFFFFF");
    GT_Key black = GT::keymapper.add ("#000000");
    GT_Key red   = GT::keymapper.add ("#FF0000");
    GT_Key green = GT::keymapper.add ("#00FF00");
    GT_Key blue  = GT::keymapper.add ("#0000FF");

    the_colors[1] = black;
    the_colors[2] = red;
    the_colors[3] = green;
    the_colors[4] = blue;

    // colorizing only at our request
    the_colorize = false;
}



//
// int GT_Layout_Random_Algorithm::run (GT_Graph& g)
//
// This is a small algorithm which assigns random coordinates and
// colors to all nodes of a graph.


int GT_Layout_Random_Algorithm::run (GT_Graph& g)
{
    graph leda = g.leda();
    GT_Key white = GT::keymapper.add ("#FFFFFF");
	
    random_source random;
    node n;

    remove_all_bends (g);
    
    forall_nodes (n, g.leda()) { // g.leda() is the LEDA graph

	// change coordinates
	g.gt(n).graphics()->x (random (int(the_min_x), int(the_max_x)));
	g.gt(n).graphics()->y (random (int(the_min_y), int(the_max_y)));

	// change the color of the node
	// g.gt(n).label_graphics()->fill (white);

	if (the_colorize) {
	    // change the color of the label
	    g.gt(n).graphics()->fill (the_colors[random(1,4)]);
	}
    }
    
    // We are done.
	
    return GT_OK;
}
	

//
// We dont need to check conditions here, our algorithm runs on
// all graphs.
//

int GT_Layout_Random_Algorithm::check (GT_Graph& /* g */, string& message)
{
    message = "Dont worry, be happy";
    return GT_OK;
}



//////////////////////////////////////////
//
// GT_Tcl_Layout_Random_Algorithm
//
//////////////////////////////////////////


GT_Tcl_Layout_Random_Algorithm::GT_Tcl_Layout_Random_Algorithm (
    const string& name) :
	GT_Tcl_Algorithm<GT_Layout_Random_Algorithm> (name)
{
}


GT_Tcl_Layout_Random_Algorithm::~GT_Tcl_Layout_Random_Algorithm ()
{
}


//
// parse
//

int GT_Tcl_Layout_Random_Algorithm::parse (GT_Tcl_info& info, int& index,
    GT_Tcl_Graph* /* g */)
{
    int code;

    if (streq (info[index], "-colorize") && !info.is_last_arg(index)) {

	index ++; // Next argument is the value
    
	int do_colorize;
	code = Tcl_GetBoolean (info.interp(), info[index++], &do_colorize);
	if (code != TCL_ERROR) {
	    colorize (bool(do_colorize));
	} else {
	    return code;
	}
	
    } else if (streq (info[index], "-coordinates") &&
	!info.is_last_arg(index)) {
	
	index ++;

	int do_coordinates;
	code = Tcl_GetBoolean (info.interp(), info[index++], &do_coordinates);
	if (code != TCL_ERROR) {
	    coordinates (bool(do_coordinates));
	} else {
	    return code;
	}

    } else if (streq (info[index], "-bbox") &&
	// This one requires 4 arguments
	info.args_left_at_least (index, 4)) {
	
	index ++;

	// This one takes 4 arguments
	double minx;
	double miny;
	double maxx;
	double maxy;
	
	code = Tcl_GetDouble (info.interp(), info[index++], &minx);
	if (code != TCL_ERROR) {
	    min_x (minx);
	} else {
	    return code;
	}
	
	code = Tcl_GetDouble (info.interp(), info[index++], &miny);
	if (code != TCL_ERROR) {
	    min_y (miny);
	} else {
	    return code;
	}
	
	code = Tcl_GetDouble (info.interp(), info[index++], &maxx);
	if (code != TCL_ERROR) {
	    max_x (maxx);
	} else {
	    return code;
	}
	
	code = Tcl_GetDouble (info.interp(), info[index++], &maxy);
	if (code != TCL_ERROR) {
	    max_y (maxy) ;
	} else {
	    return code;
	}

	
    } else {
	string msg ("Unrecognized argument %s", info[index]);
	info.msg (msg);
	return TCL_ERROR;
    }

    return TCL_OK;
}
