#ifndef GT_SAMPLE_CMD_H
#define GT_ALGORITHMS_EXPORT_H

//
// sample_cmd.h
//
// This file defines a sample tcl command.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_algorithms/sample_cmd.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/09 18:28:32 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

//////////////////////////////////////////
//
// class GT_Tcl_Sample_Command
//
// This is a sample tcl command which does nothing.
//
//////////////////////////////////////////


class GT_Tcl_Sample_Command : public GT_Tcl_Command {

public:
    GT_Tcl_Sample_Command (const string& name);
    ~GT_Tcl_Sample_Command ();
	
    virtual int cmd_parser (GT_Tcl_info& info, int& index);
};


#endif
