#ifndef GT_KEYMAPPER_H
#define GT_KEYMAPPER_H

//
// Keymapper.h
//
// This module defines the class GT_Keymapper.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Keymapper.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/06 08:41:26 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//


#include "Graphlet.h"

#include <LEDA/dictionary.h>
#include <LEDA/list.h>

//
// GT_Key_class
// GT_Key
//


class GT_Key_class;

class GT_Key {

    GT_BASE_CLASS (GT_Key);

private:
    GT_Key_class* the_key;

    GT_Key_class* description () {
	return the_key;
    }

public:
	
    GT_Key () {
	the_key = 0;
    }
	
    GT_Key (GT_Key_class* k) {
	the_key = k;
    }
	
    ~GT_Key () {
    };

    const bool defined() const {
	return (the_key != 0);
    }

    const bool active() const;

    const string& name() const;

    const GT_Key_class* description () const {
	return the_key;
    }

    const bool operator== (const GT_Key& other_key) const {
	return (the_key == other_key.the_key);
    }
    const bool operator!= (const GT_Key& other_key) const {
	return (the_key != other_key.the_key);
    }

    friend class GT_Keymapper;
    friend ostream& operator<< (ostream &out,
	const GT_Keymapper& keymapper);
};


//
// The next two operators are neccessary for the new LEDA
//

ostream& operator<< (ostream &out, const GT_Key& keymapper);
istream& operator>> (istream &out, const GT_Key& keymapper);
    


class GT_Key_class {

    GT_BASE_CLASS (GT_Key_class);

    GT_COMPLEX_VARIABLE (string, name);
    GT_VARIABLE (bool, ispath);
    GT_VARIABLE (bool, visible);
    GT_VARIABLE (bool, safe);
    GT_COMPLEX_VARIABLE (list<GT_Key>, path);
	
public:
	
    GT_Key_class (const string& name) : the_name (name) {
	the_ispath = false;
	the_visible = true;
	the_safe = true;
    };
	
    GT_Key_class () {
	the_ispath = false;
	the_visible = true;
	the_safe = true;
    };
	
    virtual ~GT_Key_class () {
    };

    operator const string& () {
	return the_name;
    }

    friend class GT_Keymapper; // can acces _ref
};


ostream& operator<< (ostream &out, const GT_Key_class& key);

inline ostream& operator<< (ostream &out, const GT_Key_class* key)
{
    return out << (*key);
}



//
// GT_Keymapper
//

class GT_Keymapper {

    GT_BASE_CLASS (GT_Keymapper);
	
    dictionary<string,GT_Key> keys;
    GT_VARIABLE (int, count);

protected:
    void split (const GT_Key key, list<GT_Key>& path);

public:

    GT_Keymapper();
    virtual ~GT_Keymapper();
	
    GT_Key add (const string& s);
    
    friend ostream& operator<< (ostream &out, const GT_Keymapper& key);
};

ostream& operator<< (ostream &out, const GT_Keymapper& key);


//
// inlined defintions
//

// inline bool GT_Keymapper::defined (const string& s) const
// {
//     return (keys.lookup (s) != nil);
// };

#endif
