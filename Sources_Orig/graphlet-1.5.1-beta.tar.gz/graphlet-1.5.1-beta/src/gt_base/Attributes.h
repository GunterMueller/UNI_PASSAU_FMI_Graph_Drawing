#ifndef GT_Attribute_H
#define GT_Attribute_H

//
// Attributes.h
//
// This file defines the classes
//   GT_Attribute_Base
//   GT_Attribut<T>
//   GT_List_of_Attributes
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Attributes.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:41 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//


//
// LEDA Includes
//

#include <LEDA/list.h>


//////////////////////////////////////////
//
// GT_Attribute_Base
//
//////////////////////////////////////////


class GT_List_of_Attributes;


class GT_Attribute_Base
{
    GT_BASE_CLASS (GT_Attribute_Base);

protected:
    unsigned the_flags;
    GT_Key the_key;    
	
public:
    enum {
	is_a_pointer = (1 << 0),
	is_safe = (1 << 1)
    } Attribute_Flag;
	
public:

    GT_Attribute_Base (const GT_Key key);
    virtual ~GT_Attribute_Base();
	
    inline GT_Key key() const;
    
    static void print (ostream& out, const GT_Key& k);
    virtual void print (ostream& out) const;

    virtual const char* attribute_classname () = 0;
    virtual GT_Attribute_Base* deep_copy () const = 0;

    void set_safe() {
	the_flags |= is_safe;
    }

    bool safe() {
	return (the_flags & is_safe) ? true : false ;
    }
};

ostream& operator<< (ostream &out, const GT_Attribute_Base* v);


//
// inline definitions
//


inline GT_Key GT_Attribute_Base::key() const
{
    return the_key;
};



//////////////////////////////////////////
//
// GT_Attribute<T>
//
//////////////////////////////////////////


template<class T>
class GT_Attribute : public GT_Attribute_Base {

    GT_TEMPLATE_CLASS (GT_Attribute, GT_Attribute_Base);
	
private:
    T the_value;
    static const char* classname;
public:

    GT_Attribute (const GT_Key key, const T& t,
	const unsigned flags = 0);
    // GT_Attribute ();
    virtual ~GT_Attribute();

    void value (const T& t)
    {
	the_value = t;
    }
	
    const T& value() const
    {
	return the_value;
    }

    T& value()
    {
	return the_value;
    }

    virtual const char* attribute_classname ()
    {
	return classname;
    };

    virtual void print (ostream &out) const;
    virtual GT_Attribute_Base* deep_copy () const;
};


template<class T>
GT_Attribute<T>::GT_Attribute (
    const GT_Key key, const T& t, const unsigned flags) :
	GT_Attribute_Base (key)
{
    the_value = t;
    the_flags |= flags;
}


template<class T>
GT_Attribute<T>::~GT_Attribute()
{
}


template<class T>
GT_Attribute_Base* GT_Attribute<T>::deep_copy () const
{
    return new GT_Attribute<T> (the_key, the_value);
}


//
// printing
//


template<class T>
void GT_Attribute<T>::print (ostream &out) const
{
    if (the_key.description()->safe() ||(the_flags & is_safe)) {
	baseclass::print (out);
	GT_print (out, value());
    }
}


template<class T> void GT_print (ostream& out, const GT_Key key, const T& t)
{
    GT_Attribute_Base::print (out, key);
    GT_print (out, t);
}



//
// Conversion
//


template<class T>
bool convert (GT_Attribute_Base* base, GT_Attribute<T>*& converted)
{
    converted = (GT_Attribute<T>*) base;

    if (streq (base->attribute_classname(),
	converted->attribute_classname())) {
	return true;
    } else {
	cout << "Illegal type conversion:"
	     << endl
	     << base->attribute_classname()
	     << " -> "
	     << converted->attribute_classname()
	     << endl;
	abort ();
	return false;
    }
}



//////////////////////////////////////////
//
// int Attributes
//
//////////////////////////////////////////


extern void GT_print (ostream&,
    const int);


//////////////////////////////////////////
//
// double Attributes
//
//////////////////////////////////////////


extern void GT_print (ostream&,
    const double);


//////////////////////////////////////////
//
// string Attributes
//
//////////////////////////////////////////


extern void GT_print (ostream&,
    const string& s);

extern void GT_print (ostream&,
    const GT_Key key);



//////////////////////////////////////////
//
// GT_Attributes
//
//////////////////////////////////////////



class GT_Attributes : public GT_Attribute<GT_List_of_Attributes*> {

    GT_CLASS (GT_Attributes, GT_Attribute<GT_List_of_Attributes*>);
	
public:
    GT_Attributes (const GT_Key key, GT_List_of_Attributes* l,
	const unsigned flags = 0);
    virtual ~GT_Attributes ();

    virtual GT_Attribute_Base* deep_copy () const;
};




//////////////////////////////////////////
//
// list<GT_Attribute_Base*> Attributes
//
//////////////////////////////////////////



class GT_List_of_Attributes : public list<GT_Attribute_Base*> {

public:
	
    GT_List_of_Attributes ();
    virtual ~GT_List_of_Attributes ();

    static void print_list_head (ostream& out, const GT_Key key);
    virtual void print (ostream& out) const;
    static void print_list_tail (ostream& out);
};


extern void GT_print (ostream &out, const GT_List_of_Attributes* attrs_list);


//////////////////////////////////////////
//
// extract_value
// find_value
// set_value
//
//////////////////////////////////////////


extern const list_item find (const GT_List_of_Attributes* attrs_list,
    const GT_Key key);

template<class T> bool extract_value (GT_List_of_Attributes* attrs_list,
    const GT_Key key,
    T& value,
    bool del = true)
{
    list_item it = find (attrs_list, key);
	
    if (it) {
	GT_Attribute<T>* attr_T;
	if (convert (attrs_list->contents(it), attr_T)) {
	    value = attr_T->value();
	    if (del) {
		attrs_list->del_item (it);
	    }
	    return true;
	} else {
	    return false;
	}
    } else {
	return false;
    }
}


#define find_value(list,key,value) \
extract_value ((list), (key), (value), (false))


template<class T>  bool set_value (GT_List_of_Attributes* attrs_list,
    GT_Key key,
    T& value)
{
    list_item it = find (attrs_list, key);
	
    if (it) {
	GT_Attribute<T>* attr_T;
	if (convert (list->attrs.contents(it), attr_T)) {
	    attr_T->value(value);
	    return true;
	} else {
	    return false;
	}
    } else {
	return false;
    }
}

#define GT_EXTRACT(list,key,type,name)			\
{							\
    type GTI_##name;					\
    if (extract_value ((list), (key), GTI_##name)) {	\
	name (GTI_##name);				\
    }							\
}


#define GT_EXTRACT2(list,key1,type1,key2,type2,name)		\
{								\
    type1 GTI_##name1;						\
    type2 GTI_##name2;						\
    if (extract_value ((list), (key1), GTI_##name1) &&		\
	extract_value ((list), (key2), GTI_##name2)) {		\
	name (GTI_TYPE_OF(name) (GTI_##name1, GTI_##name2));	\
    }								\
}


#endif
