#ifndef GT_GRAPHLET_h
#define GT_GRAPHLET_h

//
// Graphlet.h
//
// This file defines the class Graphlet.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Graphlet.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/06 08:41:25 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//


//
// Some standard includes
//

// #include <std.h>
#include <assert.h>
#include <stdio.h>
#include <fstream.h>
#include <math.h>
#include <limits.h>

#ifndef DBL_MIN
#define DBL_MIN MINDOUBLE
#endif

#ifndef DBL_MAX
#define DBL_MAX MAXDOUBLE
#endif

//
// Some standard macros
//

// #define Ref(x) x&
// #define Ptr(x) x*

// #define GT_UNUSED(x)

// #define GT_typecast(t,v) ((t)(v))

enum GT_Status {
    GT_OK = 0,
    GT_ERROR = 1
};


//
// Small floating value to shield against precision problems ... rude guess !
//

const double GT_epsilon = 0.0001;

//////////////////////////////////////////
//
// Common class definitions
//
//////////////////////////////////////////


//
// Common defs for all classes (currently unused)
//


#define GT_CLASS_COMMON(Class)			\
private:					\
    typedef Class thisclass

//
// Base class
//

#define GT_BASE_CLASS(Class)			\
GT_CLASS_COMMON(Class)



//
// Derived class
//

#define GT_CLASS(Class,Baseclass)		\
private:					\
typedef Baseclass baseclass;			\
GT_CLASS_COMMON(Class)

	
//
// Template class
//

	
#define GT_TEMPLATE_CLASS(Class, Baseclass)	\
private:					\
typedef Baseclass baseclass;			\
GT_CLASS_COMMON (Class)


//
// Class implementation 
//

#define GT_CLASS_IMPLEMENTATION(Class)
#define GT_TEMPLATE_CLASSIMPL(Class)


//////////////////////////////////////////	
//
// Automatic variable declaration
//
//////////////////////////////////////////	


//
// Auxiliary Definitions
//
	
#define GTI_PRIVATE_VARIABLE(name) the_##name
#define GTI_TYPE_OF(name) GTI_typeof_##name


//
// Declaration
//
	
#define GT_VARIABLE_DECLARE(type,variable)	\
private:					\
type GTI_PRIVATE_VARIABLE (variable);		\
typedef type GTI_typeof_##variable;


//
// Access
//
	
#define GT_VARIABLE_GET(variable,name)		\
public:						\
GTI_TYPE_OF(name) name() const			\
{						\
    return GTI_PRIVATE_VARIABLE (variable);	\
}


//
// Access to complex Variables
//
	

#define GT_COMPLEX_VARIABLE_GET(variable,name)	\
public:						\
const GTI_TYPE_OF(name)& name() const		\
{						\
    return GTI_PRIVATE_VARIABLE (variable);	\
}


//
// Set
//

#define GT_VARIABLE_SET(variable,name)		\
public:						\
virtual void name (GTI_TYPE_OF(name) param)	\
{						\
    GTI_PRIVATE_VARIABLE (variable) = param;	\
}						\


//
// Set (Complex)
//

#define GT_COMPLEX_VARIABLE_SET(variable,name)		\
public:							\
virtual void name (const GTI_TYPE_OF(name)& param)	\
{							\
    GTI_PRIVATE_VARIABLE (variable) = param;		\
}



#define GT_VARIABLE(type,variable)			\
GT_VARIABLE_DECLARE (type,variable)			\
GT_VARIABLE_SET (variable,variable)			\
GT_VARIABLE_GET (variable,variable)

#define GT_COMPLEX_VARIABLE(type,variable)		\
GT_VARIABLE_DECLARE (type,variable)			\
GT_COMPLEX_VARIABLE_SET (variable,variable)		\
GT_COMPLEX_VARIABLE_GET (variable,variable)


//////////////////////////////////////////
//
// Some additions to the standard library
//
//////////////////////////////////////////

#include "string.h"

inline int streq (const char *s1, const char *s2)
{
    return !strcmp (s1,s2);
}


//////////////////////////////////////////
//
// Graphlet is the mother of all classes ...
//
//////////////////////////////////////////


#include "Keymapper.h"
#include "Keys.h"

class FileFormat {
	
    GT_BASE_CLASS (FileFormat);
	
public:
    FileFormat();
    virtual ~FileFormat();

private:
    static const max_indent_level;
    GT_VARIABLE (int, indent_spaces_per_level);
    char** indent_strings;

public:

    //
    // Help for indentation
    //
	
    const char* indent (int level);
	
    //
    // Help for read/write escape strings with special characters
    //
	
    static const char escape_character;
    char* remove_escape_characters_from_text (const char *text,
	int length);
    ostream& write_escaped (ostream &out, const char* text);
    ostream& write_quoted (ostream &out, const char* text);

    //
    // Format details
    //

    static const char begin_list_delimeter;
    static const char end_list_delimeter;
};

extern FileFormat fileformat;


#include "Id.h"
#include "Error.h"

class GT_Parser;

class GT
{

    GT_BASE_CLASS (GT);
    
public:

    // Constructor

    GT();
    virtual ~GT();

    static void init();
	
    //
    // String utilites
    //
	
    static char* strsave (const char* s, int max_length = 0);

    //
    // open / close file (with error handling)
    //

    FILE* fopen (const char *filename, const char* mode = "r");
    void fclose (FILE* file);

    static GT_Id id;
    static GT_Error error;
    static GT_Parser* parser;
    static GT_Keymapper keymapper;

};

extern GT graphlet;

#endif
