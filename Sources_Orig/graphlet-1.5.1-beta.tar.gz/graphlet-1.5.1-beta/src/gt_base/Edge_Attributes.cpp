//
// Edge_Attributes.cc
//
// This file implements the class GT_Edge_Attributes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Edge_Attributes.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:42 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//

#include "Graphlet.h"
#include "Graph.h"
#include "Edge_Attributes.h"




GT_Edge_Attributes::GT_Edge_Attributes (GT_Graph* g, const edge e)
{
    the_g = g;
    the_e = e;
	
    the_source = 0;
    the_target = 0;

    the_graphics = 0;
    the_label_graphics = 0;
}


GT_Edge_Attributes::~GT_Edge_Attributes()
{
}



GT_TAGGED_VARIABLE (GT_Edge_Attributes, g, g);
GT_TAGGED_VARIABLE (GT_Edge_Attributes, e, e);
	
GT_TAGGED_VARIABLE (GT_Edge_Attributes, source, source);
GT_TAGGED_VARIABLE (GT_Edge_Attributes, target, source);



//
// Graphics, LabelGraphics assignments
//


void GT_Edge_Attributes::graphics (GT_Edge_Graphics* graphics)
{
    assert (find (the_g->attrs (the_e), GT_Keys::graphics) == 0);
    this->the_graphics = graphics;

    the_g->attrs (the_e)->append (
	new GT_Attributes (GT_Keys::graphics, the_graphics));

    this->the_changed |= tag_graphics;
    this->the_initialized |= tag_graphics;	
}



void GT_Edge_Attributes::label_graphics (GT_Edge_Graphics* label_graphics)
{
    assert (find (the_g->attrs (the_e), GT_Keys::label_graphics) == 0);
    this->the_label_graphics = label_graphics;

    the_g->attrs (the_e)->append (
	new GT_Attributes (GT_Keys::label_graphics, the_label_graphics));

    this->the_changed |= tag_label_graphics;
    this->the_initialized |= tag_label_graphics;	
}



//
// extract
//


int GT_Edge_Attributes::extract (GT_List_of_Attributes* current_list,
    string& message)
{
    int code;
    code = baseclass::extract (current_list, message);
    if (code != GT_OK) {
	return GT_ERROR;
    }
	
    GT_List_of_Attributes* graphics_list;
    if (extract_value (current_list, GT_Keys::graphics,
	graphics_list)) {

	if (the_graphics == 0) {
	    graphics (the_g->new_edge_graphics());
	}
		
	code = the_graphics->extract (graphics_list, message);
	if (code != GT_OK) {
	    return GT_ERROR;
	}
	
	the_graphics->conc (*graphics_list);
    }

    GT_List_of_Attributes* label_graphics_list;
    if (extract_value (current_list, GT_Keys::label_graphics,
	label_graphics_list)) {

	if (the_label_graphics == 0) {
	    label_graphics (the_g->new_edge_label_graphics());
	}
		
	code = the_label_graphics->extract (label_graphics_list, message);
	if (code != GT_OK) {
	    return GT_ERROR;
	}
	
	the_label_graphics->conc (*label_graphics_list);
    }

    return GT_OK;
}



//
// print
//


void GT_Edge_Attributes::print (ostream& out) const
{	
    GT_print (out, GT_Keys::source, g()->gt(source()).id());
    GT_print (out, GT_Keys::target, g()->gt(target()).id());

    baseclass::print (out);
}
