//
// Common_Graphics.cc
//
// This file defines the class GT_Common_Graphics.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Common_Graphics.cpp,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/04 08:46:00 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//

#include "Graphlet.h"
#include "Graph.h"
#include "Common_Graphics.h"


//////////////////////////////////////////
//
// class GT_Common_Graphics
//
//////////////////////////////////////////


#ifdef __GNUC__
// template class GT_Attribute<GT_Common_Graphics>;
#endif

//
// Constructor
//

GT_Common_Graphics::GT_Common_Graphics() :
	the_old_center (0.0, 0.0, 0.0, 0.0),
	the_center (0.0, 0.0, 0.0, 0.0)
{
    the_initialized = 0;
    the_changed = 0;
    the_updated = 0;
	
    // 	the_w = 0.0;
    // 	the_h = 0.0;

    the_smooth = false;
    the_splinesteps = -1;
    the_extent = 0.0;
    the_start = 0.0;
    the_width = 0.0;
}


//
// Destructor
//

GT_Common_Graphics::~GT_Common_Graphics()
{
}


//
// Attribute set
//


// GT_TAGGED_COMPLEX_VARIABLE (GT_Common_Graphics, center, geometry);
GT_TAGGED_COMPLEX_VARIABLE (GT_Common_Graphics, line, line);

GT_TAGGED_VARIABLE (GT_Common_Graphics, type, type);
GT_TAGGED_VARIABLE (GT_Common_Graphics, visible, visible);

GT_TAGGED_VARIABLE (GT_Common_Graphics, fill, fill);
GT_TAGGED_VARIABLE (GT_Common_Graphics, outline, outline);
GT_TAGGED_VARIABLE (GT_Common_Graphics, stipple, stipple);
GT_TAGGED_VARIABLE (GT_Common_Graphics, anchor, anchor);
GT_TAGGED_VARIABLE (GT_Common_Graphics, width, width);
GT_TAGGED_VARIABLE (GT_Common_Graphics, extent, extent);
GT_TAGGED_VARIABLE (GT_Common_Graphics, start, start);
GT_TAGGED_VARIABLE (GT_Common_Graphics, style, style);
GT_TAGGED_VARIABLE (GT_Common_Graphics, background, background);
GT_TAGGED_VARIABLE (GT_Common_Graphics, foreground, foreground);
GT_TAGGED_VARIABLE (GT_Common_Graphics, bitmap, bitmap);
GT_TAGGED_VARIABLE (GT_Common_Graphics, image, image);
GT_TAGGED_VARIABLE (GT_Common_Graphics, arrow, arrow);
GT_TAGGED_VARIABLE (GT_Common_Graphics, arrowshape, arrowshape);
GT_TAGGED_VARIABLE (GT_Common_Graphics, capstyle, capstyle);
GT_TAGGED_VARIABLE (GT_Common_Graphics, joinstyle, joinstyle);
GT_TAGGED_VARIABLE (GT_Common_Graphics, smooth, smooth);
GT_TAGGED_VARIABLE (GT_Common_Graphics, splinesteps, splinesteps);
GT_TAGGED_VARIABLE (GT_Common_Graphics, justify, justify);
GT_TAGGED_VARIABLE (GT_Common_Graphics, font, font);


	
void GT_Common_Graphics::center (const GT_Rectangle& c)
{
    // this->the_old_center = this->the_center;
    
    this->the_center = c;
    this->the_changed |= tag_geometry;
    this->the_initialized |= tag_geometry;
}


void GT_Common_Graphics::x (const double x)
{
    // Save previous value
    // the_old_center.x (the_center.x());

    // Set value
    the_center.x (x);
    
    // Set initialized & changed
    set_initialized (tag_geometry);
    set_changed (tag_geometry);
}


void GT_Common_Graphics::y (const double y)
{
    // Save previous value
    // the_old_center.y (the_center.y());

    // Set value
    the_center.y (y);

    // Set initialized & changed
    set_initialized (tag_geometry);
    set_changed (tag_geometry);
}


void GT_Common_Graphics::w (const double w)
{
    // Save previous value
    // the_old_center.w (the_center.w());
    
    // Set value
    the_center.w (w);
    
    // Set initialized & changed
    set_initialized (tag_geometry);
    set_changed (tag_geometry);
}


void GT_Common_Graphics::h (const double h)
{
    // Save previous value
    // the_old_center.h (the_center.h());
    
    // Set value
    the_center.h (h);
    
    // Set initialized & changed
    set_initialized (tag_geometry);
    set_changed (tag_geometry);
}


//
// extract
//

int GT_Common_Graphics::extract (GT_List_of_Attributes* graphics_list,
    string& /* message */)
{
    GT_List_of_Attributes* center_list;
    if (extract_value (graphics_list, GT_Keys::center, center_list)) {
		
	double xtr_x;
	if (extract_value (center_list, GT_Keys::x, xtr_x)) {
	    x (xtr_x);
	}
		
	double xtr_y;
	if (extract_value (center_list, GT_Keys::y, xtr_y)) {
	    y (xtr_y);
	}
    }

    double xtr_x;
    if (extract_value (graphics_list, GT_Keys::x, xtr_x)) {
	x (xtr_x);
    }
		
    double xtr_y;
    if (extract_value (graphics_list, GT_Keys::y, xtr_y)) {
	y (xtr_y);
    }

    double xtr_h;
    if (extract_value (graphics_list, GT_Keys::h, xtr_h)) {
	h (xtr_h);
    }
	
    double xtr_w;
    if (extract_value (graphics_list, GT_Keys::w, xtr_w)) {
	w (xtr_w);
    }
	
    string xtr_type;
    if (extract_value (graphics_list, GT_Keys::type, xtr_type)) {
	GT_Key key_type = GT::keymapper.add (xtr_type);
	type (key_type);
    }
	
    string xtr_fill;
    if (extract_value (graphics_list, GT_Keys::fill, xtr_fill)) {
	GT_Key key_fill = GT::keymapper.add (xtr_fill);
	fill (key_fill);
    }
	
    string xtr_outline;
    if (extract_value (graphics_list, GT_Keys::outline, xtr_outline)) {
	GT_Key key_outline = GT::keymapper.add (xtr_outline);
	outline (key_outline);
    }

    string xtr_stipple;
    if (extract_value (graphics_list, GT_Keys::stipple, xtr_stipple)) {
	GT_Key stipple_key = GT::keymapper.add (xtr_stipple);
	stipple (stipple_key);
    }
	
    string xtr_anchor;
    if (extract_value (graphics_list, GT_Keys::anchor, xtr_anchor)) {
	GT_Key anchor_key = GT::keymapper.add (xtr_anchor);
	anchor (anchor_key);
    }
	
    double xtr_width;
    if (extract_value (graphics_list, GT_Keys::width, xtr_width)) {
	width (xtr_width);
    }
	
    double xtr_extent;
    if (extract_value (graphics_list, GT_Keys::extent, xtr_extent)) {
	extent (xtr_extent);
    }
	
    double xtr_start;
    if (extract_value (graphics_list, GT_Keys::start, xtr_start)) {
	start (xtr_start);
    }
	
    string xtr_style;
    if (extract_value (graphics_list, GT_Keys::style, xtr_style)) {
	GT_Key key_style = GT::keymapper.add (xtr_style);
	style (key_style);
    }
	
    string xtr_background;
    if (extract_value (graphics_list, GT_Keys::background,
	xtr_background)) {
	GT_Key key_background = GT::keymapper.add (xtr_background);
	background (key_background);
    }
	
    string xtr_foreground;
    if (extract_value (graphics_list, GT_Keys::foreground,
	xtr_foreground)) {
	GT_Key key_foreground = GT::keymapper.add (xtr_foreground);
	foreground (key_foreground);
    }
	
    string xtr_bitmap;
    if (extract_value (graphics_list, GT_Keys::bitmap, xtr_bitmap)) {
	GT_Key key_bitmap = GT::keymapper.add (xtr_bitmap);
	bitmap (key_bitmap);
    }

    string xtr_image;
    if (extract_value (graphics_list, GT_Keys::image, xtr_image)) {
	GT_Key key_image = GT::keymapper.add (xtr_image);
	image (key_image);
    }
	
    string xtr_arrow;
    if (extract_value (graphics_list, GT_Keys::arrow, xtr_arrow)) {
	GT_Key key_arrow = GT::keymapper.add (xtr_arrow);
	arrow (key_arrow);
    }

    string xtr_arrowshape;
    if (extract_value (graphics_list, GT_Keys::arrowshape,
	xtr_arrowshape)) {
	GT_Key key_arrowshape = GT::keymapper.add (xtr_arrowshape);
	arrowshape (key_arrowshape);
    }

    string xtr_capstyle;
    if (extract_value (graphics_list, GT_Keys::capstyle,
	xtr_capstyle)) {
	GT_Key key_capstyle = GT::keymapper.add (xtr_capstyle);
	capstyle (key_capstyle);
    }

    string xtr_joinstyle;
    if (extract_value (graphics_list, GT_Keys::joinstyle, xtr_joinstyle)) {
	GT_Key key_joinstyle = GT::keymapper.add (xtr_joinstyle);
	joinstyle (key_joinstyle);
    }

    int xtr_smooth;
    if (extract_value (graphics_list, GT_Keys::smooth, xtr_smooth)) {
	smooth (xtr_smooth);
    }

    int xtr_splinesteps;
    if (extract_value (graphics_list, GT_Keys::splinesteps,
	xtr_splinesteps)) {
	splinesteps (xtr_splinesteps);
    }

    string xtr_justify;
    if (extract_value (graphics_list, GT_Keys::justify, xtr_justify)) {
	GT_Key key_justify = GT::keymapper.add (xtr_justify);
	justify (key_justify);
    }

    string xtr_xfont;
    if (extract_value (graphics_list, GT_Keys::xfont, xtr_xfont)) {
	GT_Key key_xfont = GT::keymapper.add (xtr_xfont);
	font (key_xfont);
    }

    GT_List_of_Attributes* line_list;
    if (extract_value (graphics_list, GT_Keys::line, line_list)) {

	GT_Polyline xtr_line;

	GT_List_of_Attributes* point_list;
	while (extract_value (line_list, GT_Keys::point, point_list)) {
				
	    GT_Point p;
					
	    double xtr_x;
	    if (extract_value (point_list, GT_Keys::x, xtr_x)) {
		p.x (xtr_x);
	    }

	    double xtr_y;
	    if (extract_value (point_list, GT_Keys::y, xtr_y)) {
		p.y (xtr_y);
	    }

	    xtr_line.append (GT_Point(p));
	}

	line (xtr_line);
    }
	
    return GT_OK;
}



void GT_Common_Graphics::print (ostream& out) const
{
    if (is_initialized (GT_Common_Graphics::tag_geometry)) {

	if (x() > 0.0) {
	    GT_print (out, GT_Keys::x, x());
	}
	if (y() > 0.0) {
	    GT_print (out, GT_Keys::y, y());
	}

	if (w() > 0.0) {
	    GT_print (out, GT_Keys::w, w());
	}
	if (h() > 0.0) {
	    GT_print (out, GT_Keys::h, h());
	}
    }
	
    if (is_initialized (tag_type) && type().active()){
	GT_print (out, GT_Keys::type, type());
    }
	
    if (is_initialized (tag_fill) && fill().active()){
	GT_print (out, GT_Keys::fill, fill());
    }
	
    if (is_initialized (tag_outline) && outline().active()){
	GT_print (out, GT_Keys::outline, outline());
    }
	
    if (is_initialized (tag_stipple) && stipple().active()){
	GT_print (out, GT_Keys::stipple, stipple());
    }

    if (is_initialized (tag_anchor) && anchor().active()){
	GT_print (out, GT_Keys::anchor, anchor());
    }
	
    if (is_initialized (tag_width) && width() > 0){
	GT_print (out, GT_Keys::width, width());
    }
	
    if (is_initialized (tag_extent) && extent() != 0.0) {
	GT_print (out, GT_Keys::extent, extent());
    }
	
    if (is_initialized (tag_start) && start() != 0.0) {
	GT_print (out, GT_Keys::start, start());
    }
	
    if (is_initialized (tag_style) && style().active()) {
	GT_print (out, GT_Keys::style, style());
    }
	
    if (is_initialized (tag_background) && background().active()) {
	GT_print (out, GT_Keys::background, background());
    }

    if (is_initialized (tag_foreground) && foreground().active()) {
	GT_print (out, GT_Keys::foreground, foreground());
    }

    if (is_initialized (tag_bitmap) && bitmap().active()) {
	GT_print (out, GT_Keys::bitmap, bitmap());
    }

    if (is_initialized (tag_image) && image().active()) {
	GT_print (out, GT_Keys::image, image());
    }

    if (is_initialized (tag_arrow) && arrow().active()) {
	GT_print (out, GT_Keys::arrow, arrow());
    }

    if (is_initialized (tag_arrowshape) && arrowshape().active()) {
	GT_print (out, GT_Keys::arrowshape, arrowshape());
    }

    if (is_initialized (tag_capstyle) && capstyle().active()) {
	GT_print (out, GT_Keys::capstyle, capstyle());
    }

    if (is_initialized (tag_joinstyle) && joinstyle().active()) {
	GT_print (out, GT_Keys::joinstyle, joinstyle());
    }

    if (is_initialized (tag_smooth) && smooth() == true) {
	GT_print (out, GT_Keys::smooth, smooth());
    }

    if (is_initialized (tag_splinesteps) && splinesteps() > 0){
	GT_print (out, GT_Keys::splinesteps, splinesteps());
    }

    if (is_initialized (tag_justify) && justify().active()) {
	GT_print (out, GT_Keys::justify, justify());
    }

    if (is_initialized (tag_font) && font().active()) {
	GT_print (out, GT_Keys::xfont, font());
    }

    if (line().length() > 0) 
    {
	GT_List_of_Attributes::print_list_head (out, GT_Keys::line);
	GT_Point p;
	forall (p, line()) {
	    GT_List_of_Attributes::print_list_head (out, GT_Keys::point);
	    GT_print (out, GT_Keys::x, p.x());
	    GT_print (out, GT_Keys::y, p.y());
	    GT_List_of_Attributes::print_list_tail (out);
	}
	GT_List_of_Attributes::print_list_tail (out);
    }

    GT_List_of_Attributes::print (out);
}



void GT_Common_Graphics::reset ()
{
    for (unsigned tag = common_graphics_tag_min;
	 tag != common_graphics_tag_max;
	 tag = tag << 1) {

	if (is_initialized(tag)) {
	    set_changed (tag);
	}
    }
}



//
// Utilities
//

void GT_Common_Graphics::move (const vector& move_xy)
{
    the_center.move (move_xy);
    
    if (the_line.length() > 0) {
	GT_Point p;
	the_line.move (move_xy);
    }
}


