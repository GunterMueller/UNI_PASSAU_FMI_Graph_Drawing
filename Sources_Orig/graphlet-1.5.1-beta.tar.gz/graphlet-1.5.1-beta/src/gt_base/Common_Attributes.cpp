//
// Common_Attributes.cc
//
// This file defines the class GT_Common_Attributes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Common_Attributes.cpp,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/06 08:41:16 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//

#include "Graphlet.h"
#include "Graph.h"
#include "Common_Attributes.h"


//////////////////////////////////////////
//
// class GT_Node_Graphics
//
//////////////////////////////////////////


#ifdef __GNUC__
// template class GT_Attribute<GT_Common_Attributes>;
#endif



//////////////////////////////////////////
//
// class GT_Common_Attributes
//
//////////////////////////////////////////


GT_Common_Attributes::GT_Common_Attributes()
{
    the_id = -1;

    the_uid = -1;
    the_label_uid = -1;
}


GT_Common_Attributes::~GT_Common_Attributes()
{
}


GT_TAGGED_VARIABLE (GT_Common_Attributes, id, id);
GT_TAGGED_COMPLEX_VARIABLE (GT_Common_Attributes, label, label);

GT_TAGGED_VARIABLE (GT_Common_Attributes, edge_anchor, edge_anchor);
GT_TAGGED_VARIABLE (GT_Common_Attributes, label_anchor, label_anchor);


int GT_Common_Attributes::extract (GT_List_of_Attributes* current_list,
    string& /* message */)
{
    int xtr_id;
    if (extract_value (current_list, GT_Keys::id, xtr_id)) {
	id (xtr_id);
    }

    string xtr_label;
    if (extract_value (current_list, GT_Keys::label, xtr_label)) {
	label (xtr_label);
    }

    string xtr_edge_anchor;
    if (extract_value (current_list, GT_Keys::edge_anchor,
	xtr_edge_anchor)) {
	edge_anchor (GT::keymapper.add (xtr_edge_anchor));
    }

    string xtr_label_anchor;
    if (extract_value (current_list, GT_Keys::label_anchor,
	xtr_label_anchor)) {
	label_anchor (GT::keymapper.add (xtr_label_anchor));
    }

    return GT_OK;
}	



void GT_Common_Attributes::print (ostream& out) const
{
    if (is_initialized (tag_id)) {
	GT_print (out, GT_Keys::id, id());
    }

    if (is_initialized (tag_label) && the_label.length() > 0) {
	GT_print (out, GT_Keys::label, label());
    }

    if (edge_anchor().active()) {
	GT_print (out, GT_Keys::edge_anchor, edge_anchor());
    }
	
    if (label_anchor().active()) {
	GT_print (out, GT_Keys::label_anchor, label_anchor());
    }

    GT_List_of_Attributes::print (out);
}
