#ifndef GT_EDGE_ATTRIBUTES_H
#define GT_EDGE_ATTRIBUTES_H

//
// Edge_Attributes.h
//
// This file implements the class GT_Edge_Attributes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Edge_Attributes.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:42 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//

#include "Graphlet.h"
#include "Attributes.h"

#include "Common_Graphics.h"
#include "Common_Attributes.h"

#include <LEDA/graph.h>


//////////////////////////////////////////
//
// class GT_Edge_Graphics
//
//////////////////////////////////////////

class GT_Edge_Graphics : public GT_Common_Graphics {

    GT_CLASS (GT_Edge_Graphics, GT_Common_Graphics);
	
};


//////////////////////////////////////////
//
// class GT_Edge_Attributes
//
//////////////////////////////////////////

class GT_Edge_Attributes : public GT_Common_Attributes {
	
    GT_CLASS (GT_Edge_Attributes, GT_Common_Attributes);

    GT_DECLARE_TAGGED_VARIABLE (GT_Graph*, g);
    GT_DECLARE_TAGGED_VARIABLE (edge, e);
	
    GT_DECLARE_TAGGED_VARIABLE (node, source);
    GT_DECLARE_TAGGED_VARIABLE (node, target);

    GT_DECLARE_TAGGED_VARIABLE (GT_Edge_Graphics*, graphics);
    GT_DECLARE_TAGGED_VARIABLE (GT_Edge_Graphics*, label_graphics);

public:
	
    GT_Edge_Attributes (GT_Graph* g, const edge e);
    virtual ~GT_Edge_Attributes();
	
    virtual int extract (GT_List_of_Attributes* list, string& message);
    virtual void print (ostream& out) const;

    enum {
	tag_g = common_attributes_tag_max << 1,
	tag_e = tag_g << 1,
	tag_source = tag_e << 1,
	tag_target = tag_source << 1,
	tag_graphics = tag_target << 1,
	tag_label_graphics = tag_graphics << 1,

	edge_attributes_tag_max = tag_label_graphics
    };
};


#endif
