//
// Attributes.cc
//
// This file implements the classes
//   GT_Attribute_Base
//   GT_Attribut<T>
//   GT_List_of_Attributes
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Attributes.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:41 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Graphlet.h"

#include "Attributes.h"


//
// Declaration of templates
//

#if defined(__GNUC__) && defined(GT_NO_IMPLICIT_TEMPLATES)

// Template Functions
template GT_print(ostream &, GT_Key, GT_Key const &);
template GT_print(ostream &, GT_Key, bool const &);
template GT_print(ostream &, GT_Key, double const &);
template GT_print(ostream &, GT_Key, int const &);
template GT_print(ostream &, GT_Key, string const &);
template extract_value(GT_List_of_Attributes *, GT_Key, GT_List_of_Attributes *&, bool);
template extract_value(GT_List_of_Attributes *, GT_Key, double &, bool);
template extract_value(GT_List_of_Attributes *, GT_Key, int &, bool);
template extract_value(GT_List_of_Attributes *, GT_Key, string &, bool);

template compare(GT_Attribute_Base *const &,
    GT_Attribute_Base *const &);
template convert(GT_Attribute_Base *,
    GT_Attribute<GT_List_of_Attributes *> *&);
template convert(GT_Attribute_Base *,
    GT_Attribute<double> *&);
template convert(GT_Attribute_Base *,
    GT_Attribute<int> *&);
template convert(GT_Attribute_Base *,
    GT_Attribute<string> *&);

//
// Attributes
//
template class GT_Attribute<GT_List_of_Attributes*>;
template class GT_Attribute<int>;
template class GT_Attribute<double>;
template class GT_Attribute<string>;
template class list<GT_Attribute_Base *>;

// ??
template Print(GT_Attribute_Base *const &, ostream &);
template Read(GT_Attribute_Base *&, istream &);
template leda_access(GT_Attribute_Base *const *, void *const &);
template leda_cast(GT_Attribute_Base *const &);
template leda_clear(GT_Attribute_Base *&);
template leda_copy(GT_Attribute_Base *const &);
template leda_itype(GT_Attribute_Base *const *);
#endif



//////////////////////////////////////////
//
// class GT_Attribute_Base
//
//////////////////////////////////////////


GT_CLASS_IMPLEMENTATION (GT_Attribute_Base);


//
// Constructor && Destructor
//


GT_Attribute_Base::GT_Attribute_Base (const GT_Key key)
{
    the_key = key;
    the_flags = 0;

    if (key.description()->safe()) {
	the_flags |= is_safe;
    }
};



GT_Attribute_Base::~GT_Attribute_Base()
{
    ;
};



//
// Print Function
//


void GT_Attribute_Base::print (ostream &out, const GT_Key& key)
{
    assert (key.defined());

    if (key.description()->visible()) {
	out << key.description()->name() << ' ';
    }
}



void GT_Attribute_Base::print (ostream &out) const
{
    print (out, the_key);
}



//
// Output operator << defaults to print
//

ostream& operator<< (ostream& out, const GT_Attribute_Base* attr)
{
    if (attr != nil) {
        attr->print (out);
    }
    return out;
}


const list_item find (const GT_List_of_Attributes* attrs_list,
    const GT_Key key)
{
    list_item it;
    forall_items (it, *attrs_list) {
	if (attrs_list->contents(it)->key() == key) {
	    return it;
	}
    }
    return 0;
}


//////////////////////////////////////////
//
// GT_Attribute<> template class
//
//////////////////////////////////////////


const char* GT_Attribute<int>::classname = "GT_Attribute<int>";
const char* GT_Attribute<double>::classname = "GT_Attribute<double>";
const char* GT_Attribute<string>::classname = "GT_Attribute<string>";
const char* GT_Attribute<GT_List_of_Attributes*>::classname =
"GT_Attribute<GT_List_of_Attributes>";


//////////////////////////////////////////
//
// int Attributes
//
//////////////////////////////////////////


void GT_print (ostream& out, const int i)
{
    out << i << '\n';
}



//////////////////////////////////////////
//
// double Attributes
//
//////////////////////////////////////////

#include "iostream.h"

void GT_print (ostream& out, const double d)
{
    out.flags (ios::showpoint);
    out << d << endl;
}



//////////////////////////////////////////
//
// string Attributes
//
//////////////////////////////////////////


void GT_print (ostream& out, const string& s)
{
    fileformat.write_quoted (out, s);
    out << '\n';
}



void GT_print (ostream& out, const GT_Key k)
{
    fileformat.write_quoted (out, k.description()->name());
    out << '\n';
}



//////////////////////////////////////////
//
// list<GT_Attribute_Base*> Attributes
//
//////////////////////////////////////////


GT_List_of_Attributes::GT_List_of_Attributes ()
{
}



GT_List_of_Attributes::~GT_List_of_Attributes ()
{
}



void GT_print (ostream& out, const GT_List_of_Attributes* attrs)
{
    out << FileFormat::begin_list_delimeter << '\n';
    attrs->print (out);
    out << FileFormat::end_list_delimeter << '\n';
}



void GT_List_of_Attributes::print_list_head (ostream& out,
    const GT_Key key)
{
    GT_Attribute_Base::print (out, key);
    out << FileFormat::begin_list_delimeter << '\n';	
}
	


void GT_List_of_Attributes::print (ostream& out) const
{
    list_item i;
    forall_items (i, *this) {
	out << contents (i);
    }
}
	


void GT_List_of_Attributes::print_list_tail (ostream& out)
{
    out << FileFormat::end_list_delimeter << '\n';	
}



//////////////////////////////////////////
//
// GT_Attributes
//
//////////////////////////////////////////


GT_Attributes::GT_Attributes (const GT_Key key, GT_List_of_Attributes* l,
    const unsigned flags) :
	GT_Attribute<GT_List_of_Attributes*> (key, l,
	    (flags | is_a_pointer))
{
}


GT_Attributes::~GT_Attributes ()
{
}


GT_Attribute_Base* GT_Attributes::deep_copy () const
{
    return 0;
}

