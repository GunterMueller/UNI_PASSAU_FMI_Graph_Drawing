#ifndef GT_UIOBJECT_H
#define GT_UIOBJECT_H

//
// UIObject.h
//
// This file defines the class GT_UIObject.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/UIObject.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:44 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

class GT_Device;


class GT_UIObject {
	
    GT_BASE_CLASS (GT_UIObject);

    GT_VARIABLE (int, uid);
    GT_VARIABLE (GT_Device*, device);
    GT_VARIABLE (GT_UIObject*, parent);
    GT_VARIABLE (GT_Common_Graphics*, graphics);
	
public:
    GT_UIObject (const int uid,
	GT_Device* const device,
	GT_UIObject* parent);
    virtual ~GT_UIObject ();

    virtual const GT_Key& type () const;

    virtual bool create () = 0;
    virtual bool move (const double move_x, const double move_y) = 0;
    virtual bool update () = 0;
    virtual bool update_attrs () = 0;
    virtual bool update_coords () = 0;
    virtual bool del () = 0;
};

#endif
