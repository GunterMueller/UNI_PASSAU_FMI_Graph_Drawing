//
// UIObject.cc
//
// This file implements the class GT_UIObject.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/UIObject.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:44 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Graphlet.h"
#include "Common_Graphics.h"
#include "Device.h"

#include "UIObject.h"


//
// GT_UIObject
//

GT_UIObject::GT_UIObject (const int uid,
    GT_Device* const device,
    GT_UIObject* parent) :
	the_uid (uid), the_device (device), the_parent (parent)
{
    the_graphics = 0;
}


GT_UIObject::~GT_UIObject ()
{
}


const GT_Key& GT_UIObject::type() const
{
    return GT_Keys::uiobject_unknown;
}
