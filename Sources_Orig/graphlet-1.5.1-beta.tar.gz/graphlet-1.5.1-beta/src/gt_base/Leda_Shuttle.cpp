//
// Leda_Shuttle.cc
//
// This file implements the class GT_Leda_Shuttle
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Leda_Shuttle.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:43 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Graphlet.h"

#include "Leda_Shuttle.h"

