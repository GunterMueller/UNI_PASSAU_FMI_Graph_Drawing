#ifndef Geometry_h
#define Geometry_h

//
// Geometry.h
//
// This file defines several geometry related classes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Geometry.h,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/06 08:41:21 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//

#include <LEDA/point.h>


//////////////////////////////////////////
//
// GT_Point: a wrapper for point with some extras
//
//////////////////////////////////////////


class GT_Point : public point {

    GT_BASE_CLASS (GT_Point);
	
public:
	
    GT_Point () {
    };

    GT_Point (const double x, const double y) : point (x,y) {
    };

    GT_Point (const point& p) : point (p) {
    };

    GT_Point (const vector& v) : point (v) {
    };

    // 	~GT_Point () {
    // 	};

    //
    // Graphlet conform accessors
    //
	
    void x (const double x) {
	*this = GT_Point (x, ycoord());
    };

    void y (const double y) {
	*this = GT_Point (xcoord(), y);
    };

    double x () const { return xcoord(); }
    double y () const { return ycoord(); }

    //
    // Utilities
    //

    void move (const vector& move_xy);
};



//////////////////////////////////////////
//
// GT_Polyline: a list of GT_Point objects
//
//////////////////////////////////////////


class GT_Polyline : public list<GT_Point> {

    GT_BASE_CLASS (GT_Point);
	
public:
    GT_Polyline () {
    };
	
    GT_Polyline (const GT_Polyline& l) : list<GT_Point> (l) {
    };

    GT_Polyline (const list<GT_Point>& l) : list<GT_Point> (l) {
    };

    virtual ~GT_Polyline ();

    segment nth_segment (const int n) const;

    void move (const vector& move_xy);
};



//////////////////////////////////////////
//
// class GT_Rectangle: a GT_Point at the center + width and height
//
//////////////////////////////////////////


#include <LEDA/segment.h>


class GT_Rectangle : public GT_Point {

    GT_CLASS (GT_Rectangle, GT_Point);
	
    GT_VARIABLE (double, w);
    GT_VARIABLE (double, h);
	
public:

    GT_Rectangle () : GT_Point (0,0)
    {
	the_w = 0;
	the_h = 0;
    }

    GT_Rectangle (const point& p, double w, double h) :
	    GT_Point (p)
    {
	the_w = w;
	the_h = h;
    }
	
    GT_Rectangle (double x, double y, double w, double h) :
	    GT_Point (x,y)
    {
	the_w = w;
	the_h = h;
    }
	
    bool includes (const point& p) const;

    //
    // Tk anchor conformant positions
    //
	
    point anchor_c() const;
    point anchor_n() const;
    point anchor_ne() const;
    point anchor_e() const;
    point anchor_se() const;
    point anchor_s() const;
    point anchor_sw() const;
    point anchor_w() const;
    point anchor_nw() const;

    //
    // max/min coordinates (note: NOT Tcl/Tk anchor conformant)
    //
	
    double top() const
    {
	return y() - h() / 2;
    };
	
    double right() const
    {
	return x() +  w() / 2;
    };
	
    double bottom() const
    {
	return y() + h() / 2;
    };
	
    double left() const
    {
	return x() - w() / 2;
    }
};


#endif
