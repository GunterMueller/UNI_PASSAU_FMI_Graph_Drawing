// This file is generated automatically
#define GT_MODULE_GT_LSD
#define GT_MODULE_GT_ALGORITHMS
#define GT_MODULE_GT_GRID_ALGORITHMS
#define GT_MODULE_GT_TCL
#define GT_MODULE_GT_BASE
#define GT_MAJOR_VERSION 1
#define GT_MINOR_VERSION 5
#define GT_MINI_VERSION 0
#define GT_RELEASE "beta"
#define GT_GRAPHLET_DIR "/home/graphed/himsolt/public-Solaris/graphlet/graphlet-1.5.0-beta-CC"
#define GT_MODULE_GT_SPRINGEMBEDDER_FR
#define GT_MODULE_GT_SPRINGEMBEDDER_KAMADA
#define GT_MODULE_GT_GEM
#define GT_MODULE_GT_TUNKELANG
#define GT_MODULE_GT_TREE_WALKER
#define GT_MODULE_GT_DAG
