#ifndef GT_GRAPH_ATTRIBUTES_H
#define GT_GRAPH_ATTRIBUTES_H

//
// Graph_Attributes.h
//
// This module defines the class GT_Graph_Attributes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Graph_Attributes.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/06 08:41:24 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//


#include "Graphlet.h"
#include "Attributes.h"

#include "Common_Graphics.h"
#include "Common_Attributes.h"



class GT_Graph;

class GT_Graph_Graphics : public GT_Common_Graphics {
};


class GT_Graph_Attributes : public GT_Common_Attributes {
	
    GT_CLASS (GT_Graph_Attributes, GT_Common_Attributes);

    GT_DECLARE_TAGGED_VARIABLE (GT_Graph*, g);

    GT_DECLARE_TAGGED_VARIABLE (int, version);
    GT_DECLARE_TAGGED_COMPLEX_VARIABLE (string, creator);

    GT_DECLARE_TAGGED_VARIABLE (GT_Graph_Graphics*, graphics);
    GT_DECLARE_TAGGED_VARIABLE (GT_Graph_Graphics*, label_graphics);

public:

    GT_Graph_Attributes (GT_Graph* g);
    virtual ~GT_Graph_Attributes();

    virtual int extract (GT_List_of_Attributes* list, string& message);
    virtual void print (ostream& out) const;

    enum {
	tag_g = common_attributes_tag_max << 1,
	tag_version = tag_g << 1,
	tag_creator = tag_version << 1,
	tag_graphics = tag_creator << 1,
	tag_label_graphics = tag_graphics << 1,
	graph_attributes_tag_max = tag_label_graphics
    };
};


#endif
