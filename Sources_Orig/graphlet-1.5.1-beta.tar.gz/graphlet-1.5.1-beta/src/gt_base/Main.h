#ifndef GT_MAIN_H
#define GT_MAIN_H

//
// filename
//
// The description of filename goes HERE.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Main.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/06 08:41:27 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Algorithm.h"


class GT_Main
{
    GT_BASE_CLASS (GT_Main);

    GT_VARIABLE (int, argc);
    GT_VARIABLE (char**, argv);
    GT_VARIABLE (GT_Algorithm*, algorithm);
    GT_VARIABLE (int, error_code);

    GT_COMPLEX_VARIABLE (string, usage);
    GT_COMPLEX_VARIABLE (string, program_name);
    GT_COMPLEX_VARIABLE (string, algorithm_name);
    GT_COMPLEX_VARIABLE (string, output_filename);
    GT_COMPLEX_VARIABLE (string, input_filename);
    GT_COMPLEX_VARIABLE (string, detailled_error_message);
	
public:
	
    GT_Main(int argc, char *argv[], GT_Algorithm& algorithm);
    virtual ~GT_Main();
	
    virtual int main ();
    virtual int parse (int& index);
    virtual int parse ();
    virtual ostream& error_message (ostream& out);
	
    enum return_codes {
	rc_ok = 0,
	rc_illegal_argument,
	rc_no_graph_found,
	rc_cannot_run_algorithm
    };

    //
    // Utility
    //

    string argv (const int index) const {
	return string (the_argv [index]);
    }
};

#endif
