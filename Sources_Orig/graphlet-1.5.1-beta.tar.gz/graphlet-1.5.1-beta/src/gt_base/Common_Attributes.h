#ifndef COMMON_ATTRIBUTES_H
#define COMMON_ATTRIBUTES_H

//
// Common_Attributes.h
//
// This file defines the class GT_Common_Attributes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Common_Attributes.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/06 08:41:17 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//

#include "Graphlet.h"
#include "Attributes.h"

#include <LEDA/graph.h>



//////////////////////////////////////////
//
// class GT_Common_Attributes
//
//////////////////////////////////////////


#define GT_DECLARE_TAGGED_COMPLEX_VARIABLE(type,name)	\
	GT_VARIABLE_DECLARE (type, name)		\
	GT_COMPLEX_VARIABLE_GET (name, name)		\
public:							\
	virtual void name (const type& name)
	
#define GT_DECLARE_TAGGED_VARIABLE(type,name)	\
	GT_VARIABLE_DECLARE (type, name)	\
	GT_VARIABLE_GET (name, name)		\
public:						\
	virtual void name (type name)


#define GT_TAGGED_COMPLEX_VARIABLE(class,name,c)	\
void class::name (const GTI_TYPE_OF(name)& name)	\
{							\
    this->GTI_PRIVATE_VARIABLE (name) = name;		\
    this->the_changed |= tag_##c;			\
    this->the_initialized |= tag_##c;			\
}

#define GT_TAGGED_VARIABLE(class,name,c)	\
void class::name (GTI_TYPE_OF(name) name)	\
{						\
    this->GTI_PRIVATE_VARIABLE (name) = name;	\
    this->the_changed |= tag_##c;		\
    this->the_initialized |= tag_##c;		\
}



class GT_Tagged_Attributes {

    GT_BASE_CLASS (GT_Tagged_Attributes);

protected:	
    unsigned the_initialized;
    unsigned the_changed;
    unsigned the_updated;

public:
	
    GT_Tagged_Attributes()
    {
	the_initialized = 0;
	the_changed = 0;
	the_updated = 0;
    }

    //
    // Initialized
    //
	
    virtual void set_initialized (const unsigned tag) {
	// assert (is_initialized(tag));
	the_initialized |= tag;
    }

    bool is_initialized (const unsigned tag) const {
	return (the_initialized & tag) != 0;
    }

    void reset_initialized (const unsigned tag) {
	the_initialized &= ~tag;
    }

    unsigned initialized() const {
	return the_initialized;
    }

    bool nothing_initialized () const {
	return the_initialized == 0;
    }
    
    
    //
    // Changed
    //
	
    virtual void set_changed (const unsigned tag) {
	// assert (is_initialized(tag));
	the_changed |= tag;
    }

    bool is_changed (const unsigned tag) const {
	return (the_changed & tag) != 0;
    }

    void reset_changed (const unsigned tag) {
	the_changed &= ~tag;
    }

    unsigned changed() const {
	return the_changed;
    }

    bool nothing_changed () const {
	return the_changed == 0;
    }

    
    //
    // Updated
    //
	
    virtual void set_updated (const unsigned tag) {
	// assert (is_initialized(tag));
	the_updated |= tag;
    }

    bool is_updated (const unsigned tag) const {
	return (the_updated & tag) != 0;
    }

    void reset_updated (const unsigned tag) {
	the_updated &= ~tag;
    }	

    unsigned updated() const {
	return the_updated;
    }

    bool nothing_updated () const {
	return the_updated == 0;
    }
};




class GT_Common_Attributes : public GT_Tagged_Attributes,
			     public GT_List_of_Attributes
{
	
    GT_CLASS (GT_Common_Attributes, GT_Tagged_Attributes);

    GT_DECLARE_TAGGED_VARIABLE (int, id);
    GT_DECLARE_TAGGED_COMPLEX_VARIABLE (string, label);

    GT_DECLARE_TAGGED_VARIABLE (GT_Key, edge_anchor);
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, label_anchor);
	
    GT_VARIABLE (int, uid);
    GT_VARIABLE (int, label_uid);

public:

    GT_Common_Attributes();
    virtual ~GT_Common_Attributes();
	
    virtual int extract (GT_List_of_Attributes* list, string& message);
    virtual void print (ostream& out) const;

public:
    enum {
	tag_id = 1,
	tag_label = (tag_id<<1),
	tag_edge_anchor = (tag_label<<1),
	tag_label_anchor = (tag_edge_anchor<<1),
	common_attributes_tag_max = tag_label_anchor
    };
};

#endif
