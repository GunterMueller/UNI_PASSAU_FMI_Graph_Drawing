//
// filename
//
// The description of filename goes HERE.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Main.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:43 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Graphlet.h"
#include "Graph.h"

#include "Leda_Shuttle.h"
#include "Parser.h"

#include "Main.h"


//
// Constructor & Desctructor
//



GT_Main::GT_Main (int argc, char *argv[],
    GT_Algorithm& algorithm)
{
    the_argc = argc;
    the_argv = argv;


    the_algorithm = &algorithm;
    the_usage =  "[-file file] [-in file] [-out file] [-]";
	
    the_program_name = argv[0];
}


GT_Main::~GT_Main ()
{
}



//
// main ()
//
// is a utility to create a simple command line program which
// runs the algorithm.
//


int GT_Main::main ()
{
    // First, evaluate the arguments

    the_error_code = parse ();
    if (the_error_code != rc_ok) {
	return the_error_code;
    }


    //
    // Extract the list of attributes from the file
    //
    GT_List_of_Attributes* attrs;
    attrs = GT::parser->parser (the_input_filename.cstring());

	//
	// Extract a graph from the attributes
	//
	
    GT_Graph g;
    if (attrs != 0 && attrs->length() > 0) {
		
	GT_Leda_Shuttle<graph> leda_shuttle;
	g.attach (leda_shuttle);

	string message;
	int code;
	code = g.extract (attrs, message);

	if (the_algorithm->check (g, message)) {
	    the_algorithm->run (g);
	    the_algorithm->adjust_coordinates (g, 0,0);
	    cout << g;
	} else {
	    the_detailled_error_message = message;
	    return (the_error_code = rc_cannot_run_algorithm);
	}

    } else {
	return (the_error_code = rc_no_graph_found);
    }

    return (the_error_code = rc_ok);
}


//
// bool GT_Main::parse (int& index)
// bool GT_Main::parses ()
//
// May be used by an application to interpret the command line
// arguments.
//


int GT_Main::parse (int& index)
{
    const string argument = argv (index);
	
    if (argument == "-") {
		
	the_input_filename = "";

    } else if (argument == "-file" || argument == "-in" ) {
		
	the_input_filename = argv (++index);
		
    } else if (argument == "-out") {
		
	the_output_filename = argv (++index);

    } else if (index == the_argc-1) {

	if (argument[0] != '-') {
	    the_input_filename = argument;
	} else {
	    return rc_illegal_argument;
	}
				
    } else {
	return rc_illegal_argument;
    }

    return rc_ok;
}


int GT_Main::parse ()
{
    // Load the file on the command line, or read from stdin

    if (the_argc > 1) {
		
	for (int index = 1; index < the_argc; index++) {
			
	    int code = parse (index);
	    if (code != rc_ok) {
		return code;
	    }
			
	}
    } else {
	the_input_filename = "";
    }

    return rc_ok;
}


//
// ostream& GT_Main::error_message (ostream& out)
//
// Prints the error message to out.
//

ostream& GT_Main::error_message (ostream& out)
{
    switch (the_error_code) {
	case rc_ok:
	    break;
	case rc_illegal_argument:
	    if (the_detailled_error_message.length() > 0) {
		out << the_program_name << ": "
		    << the_detailled_error_message
		    << endl;
	    }
	    out << "Usage : "
		<< the_program_name << " "
		<< the_usage
		<< " [-]"
		<< endl;
	    break;
	case rc_no_graph_found:
	    out << the_program_name << ": No graph found in "
		<< '"' << the_input_filename << '"'
		<< endl;
	    break;
	case rc_cannot_run_algorithm:
	    out << the_program_name << ": "
		<< "Cannot run algorithm"
		<< endl;
	    if (the_detailled_error_message.length() > 0) {
		out << the_program_name << ": "
		    << the_detailled_error_message
		    << endl;
	    }
	    break;
    }

    return out;
}	
