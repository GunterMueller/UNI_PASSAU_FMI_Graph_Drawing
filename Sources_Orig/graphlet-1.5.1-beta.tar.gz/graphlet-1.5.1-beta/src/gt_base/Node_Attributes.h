#ifndef GT_NODE_ATTRIBUTES_H
#define GT_NODE_ATTRIBUTES_H

//
// Node_Attributes.h
//
// This file defines the class GT_Node_Attributes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Node_Attributes.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:44 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//

#include "Graphlet.h"
#include "Attributes.h"

#include "Common_Graphics.h"
#include "Common_Attributes.h"

#include <LEDA/graph.h>



//////////////////////////////////////////
//
// class GT_Node_Graphics
//
//////////////////////////////////////////


class GT_Node_Graphics : public GT_Common_Graphics {

    GT_CLASS (GT_Node_Graphics, GT_Common_Graphics);
	
};


//////////////////////////////////////////
//
// class GT_Node_Attributes
//
//////////////////////////////////////////


class GT_Graph;

class GT_Node_Attributes : public GT_Common_Attributes {
	
    GT_CLASS (GT_Node_Attributes, GT_Common_Attributes);

    GT_DECLARE_TAGGED_VARIABLE (GT_Graph*, g);
    GT_DECLARE_TAGGED_VARIABLE (node, n);

    GT_DECLARE_TAGGED_VARIABLE (GT_Node_Graphics*, graphics);
    GT_DECLARE_TAGGED_VARIABLE (GT_Node_Graphics*, label_graphics);

public:

    GT_Node_Attributes (GT_Graph* g, const node n);
    virtual ~GT_Node_Attributes();
	
    virtual int extract (GT_List_of_Attributes* list, string& message);
    virtual void print (ostream& out) const;

    enum {
	tag_g = common_attributes_tag_max << 1,
	tag_n = tag_g << 1,
	tag_graphics = tag_n << 1,
	tag_label_graphics = tag_graphics << 1,

	node_attributes_tag_max = tag_label_graphics
    };
};

#endif
