//
// Graph.cc
//
// This module implements the class GT_Graph.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Graph.cpp,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/17 16:12:34 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#include "Graphlet.h"
#include "Graph.h"
#include "Leda_Shuttle.h"


//
//  class GT_Graph
//

GT_CLASS_IMPLEMENTATION (GT_Graph);

GT_Graph::GT_Graph()
{
    the_graph = 0;
}


//
// Destructor of GT_Graph
//

GT_Graph::~GT_Graph()
{
    the_graph = 0;
}


//
// Attatch a LEDA Graph to a GT_Graph
//


void GT_Graph::attach (graph* g)
{
    assert (the_graph == 0);
	
    the_graph = g;

    the_node_attrs.init (*g, 0);
    the_edge_attrs.init (*g, 0);
    the_graph_attrs = new_graph_attributes();
}


void GT_Graph::attach (GT_Shuttle& g)
{
    leda (g.leda());
    g.attach (*this);
}



//////////////////////////////////////////
//
// new attribute constructors
//
//////////////////////////////////////////


GT_Graph_Attributes* GT_Graph::new_graph_attributes ()
{
    return new GT_Graph_Attributes (this);
}


GT_Node_Attributes* GT_Graph::new_node_attributes (const node n)
{
    return new GT_Node_Attributes (this, n);
}


GT_Edge_Attributes* GT_Graph::new_edge_attributes (const edge e)
{
    return new GT_Edge_Attributes (this, e);
}

	
//////////////////////////////////////////
//
// graphics customization
//
//////////////////////////////////////////


GT_Graph_Graphics* GT_Graph::new_graph_graphics ()
{
    return new GT_Graph_Graphics;
}

GT_Graph_Graphics* GT_Graph::new_graph_label_graphics ()
{
    return new GT_Graph_Graphics;
}


GT_Node_Graphics* GT_Graph::new_node_graphics ()
{
    return new GT_Node_Graphics;
}


GT_Node_Graphics* GT_Graph::new_node_label_graphics ()
{
    return new GT_Node_Graphics;
}

GT_Edge_Graphics* GT_Graph::new_edge_graphics ()
{
    return new GT_Edge_Graphics;
}


GT_Edge_Graphics* GT_Graph::new_edge_label_graphics ()
{
    return new GT_Edge_Graphics;
}


//////////////////////////////////////////
//
// Update Nodes
//
//////////////////////////////////////////


void GT_Graph::new_node_action (node n)
{
    GT_Node_Attributes* node_attrs = new_node_attributes(n);

    node_attrs->id (GT::id.next_id());

    the_node_attrs[n] = node_attrs;
}


void GT_Graph::del_node_action (node n)
{
    if (the_node_attrs[n] != 0) {
	the_node_attrs[n]->clear();
	delete the_node_attrs[n];
	the_node_attrs[n] = 0;
    }
}


void GT_Graph::new_edge_action (edge e)
{
    GT_Edge_Attributes* edge_attrs = new_edge_attributes(e);

    edge_attrs->id (GT::id.next_id());
    edge_attrs->source (the_graph->source(e));
    edge_attrs->target (the_graph->target(e));

    the_edge_attrs[e] = edge_attrs;
}


void GT_Graph::del_edge_action (edge e)
{
    if (the_edge_attrs[e] != 0) {
	the_edge_attrs[e]->clear();
	delete the_edge_attrs[e];
	the_edge_attrs[e] = 0;
    }
}


void GT_Graph::rev_edge_action (edge /* e */)
{
}


void GT_Graph::clear_action ()
{
    if (the_graph_attrs != 0) {
	the_graph_attrs->clear ();
	delete the_graph_attrs;
	the_graph_attrs = 0;
    }
}



//
// Utilities
//

node GT_Graph::find_node (const int id)
{
    const graph& g = *the_graph;
	
    node n;
    forall_nodes (n, g) {
	if (gt(n).id() == id) {
	    return n;
	}
    }
    return 0;
}


edge GT_Graph::find_edge (const int id)
{
    const graph& g = *(the_graph);

    edge e;
    forall_edges (e, g) {
	if (gt(e).id() == id) {
	    return e;
	}
    }
    return 0;
}



//
// gt_attrs
//

GT_Graph_Attributes& GT_Graph::gt()
{
    assert (the_graph != 0);
    assert (the_graph_attrs != 0);

    return *the_graph_attrs;
}


GT_Node_Attributes& GT_Graph::gt(node n)
{
    assert (the_graph != 0);
    assert (the_node_attrs(n) != 0);

    return *the_node_attrs[n];
}

GT_Edge_Attributes& GT_Graph::gt(edge e)
{
    assert (the_graph != 0);
    assert (the_edge_attrs(e) != 0);

    return *the_edge_attrs[e];
}



const GT_Graph_Attributes& GT_Graph::gt() const
{
    assert (the_graph != 0);
    assert (the_graph_attrs != 0);

    return *the_graph_attrs;
}



const GT_Node_Attributes& GT_Graph::gt(const node n) const
{
    assert (the_graph != 0);
    assert (the_node_attrs(n) != 0);

    return *the_node_attrs(n);
}



const GT_Edge_Attributes& GT_Graph::gt(const edge e) const
{
    assert (the_graph != 0);
    assert (the_edge_attrs(e) != 0);

    return *the_edge_attrs(e);
}



//
// output
//


ostream& operator<< (ostream& out, const GT_Graph& g)
{
    GT_List_of_Attributes::print_list_head (out, GT_Keys::graph);

    if (g.attrs() != 0) {
	g.gt().print (out);
    }

    GT_print (out, GT_Keys::directed, g.leda().is_directed() ? 1 : 0);
		
    node n;
    forall_nodes (n, g.leda()) {
	GT_Attribute_Base::print (out, GT_Keys::node);
	GT_print (out, g.attrs(n));
    }

    edge e;
    forall_edges (e, g.leda()) {
	GT_Attribute_Base::print (out, GT_Keys::edge);
	GT_print (out, g.attrs(e));
    }

    GT_List_of_Attributes::print_list_tail (out);
    return out;
}



//////////////////////////////////////////
//
// bool GT_Graph::extract
//
//////////////////////////////////////////


int GT_Graph::extract (GT_List_of_Attributes* top_attrs, string& message)
{
    int max_id = 0;
    int code;
    
    GT_List_of_Attributes* graph_list;
    if (extract_value (top_attrs, GT_Keys::graph, graph_list)) {

	//
	// Create and attach a new LEDA graph
	//
	
	if (the_graph == 0) {
	    attach (new graph);
	}
	graph& leda = this->leda();

	//
	// extract "directed" information
	//
	
	int xtr_directed;
	if (extract_value (graph_list, GT_Keys::directed, xtr_directed)) {
	    if (xtr_directed == 0) {
		leda.make_undirected();
	    } else {
		leda.make_directed();
	    }
	} else {
	    leda.make_undirected();
	}

	//
	// Map for node -> numbers and reverse
	//
	
	node_map<int> number_of_node (*the_graph);
	map<int,node> node_with_number;

	//
	// Extract the nodes
	//
	
	GT_List_of_Attributes* node_list;
	while (extract_value (graph_list, GT_Keys::node, node_list)) {

	    // Create a new node and extract its attributes
	    
	    node n = leda.new_node();
	    code = the_node_attrs[n]->extract (node_list, message);
	    if (code != GT_OK) {
		return code;
	    }
	    the_node_attrs[n]->conc (*node_list);

	    // Adjust the maximum id
	    
	    if (gt(n).id() != -1) {
		max_id = Max (gt(n).id(), max_id);
	    }

	    // Assign an id if the node does not already have an one
	    
	    if (gt(n).id() != -1) {
		number_of_node[n] = gt(n).id();
		node_with_number[gt(n).id()] = n;
	    }
	}

	//
	// Extract the edges
	//
	
	GT_List_of_Attributes* edge_list;
	while (extract_value (graph_list, GT_Keys::edge, edge_list)) {
			
	    int source;
	    int target;

	    //
	    // Extract source and target and check numbers
	    //
	    
	    if (!extract_value (edge_list, GT_Keys::source, source)) {
		message = "Edge missing source";
		return GT_ERROR;
	    } else if (!extract_value (edge_list, GT_Keys::target, target)) {
		message = "Edge missing target";
		return GT_ERROR;
	    } else if (!node_with_number.defined (source)) {
		message = string ("Undefined source number %d", source);
		return GT_ERROR;
	    } else if (!node_with_number.defined (target)) {
		message = string ("Undefined target number %d", target);
		return GT_ERROR;
	    } else {

		// Create a new edge
		
		edge e = leda.new_edge (
		    node_with_number[source],
		    node_with_number[target]);

		// Extract attributes
		
		code = the_edge_attrs[e]->extract (edge_list, message);
		if (code != GT_OK) {
		    return code;
		}
		the_edge_attrs[e]->conc (*edge_list);

		// Initialize Attributes
		
		gt(e).source (node_with_number[source]);
		gt(e).target (node_with_number[target]);
		
		// Adjust the maximum id
		
		if (gt(e).id() != -1) {
		    max_id = Max (gt(e).id(), max_id);
		}

	    }
	}

	the_graph_attrs->extract (graph_list, message);
	the_graph_attrs->conc (*graph_list);

	if (gt().id() != -1) {
	    max_id = Max (gt().id(), max_id);
	}
				
	GT::id.adjust_maximum_id (max_id);

	return GT_OK;
    }

    return GT_ERROR;
}



//////////////////////////////////////////
//
// Drawing operations
//
//////////////////////////////////////////


int GT_Graph::draw ()
{
    return GT_OK;
}

int GT_Graph::draw (node /* n */)
{
    return GT_OK;
}

int GT_Graph::draw (edge /* e */)
{
    return GT_OK;
}


int GT_Graph::begin_draw ()
{
    return GT_OK;
}

int GT_Graph::end_draw ()
{
    return GT_OK;
}



//////////////////////////////////////////
//
// int GT_Graph::move_node (node n, const double move_x, const double move_y)
//
// Device independend part of fast node moving
//
//////////////////////////////////////////


int GT_Graph::move_node (node n,
    const double move_x,
    const double move_y)
{
    vector move_xy (move_x, move_y);
    GT_Node_Attributes& node_attrs = gt(n);

    node_attrs.graphics()->move (move_xy);
    
    if (node_attrs.label_graphics() != 0) {
	node_attrs.label_graphics()->move (move_xy);
    }

    return GT_OK;
}



int GT_Graph::move_nodes (const list<node>& nodes,
    const double move_x,
    const double move_y)
{
    node n;
    forall (n, nodes) {
	move_node (n, move_x, move_y);
    }
    
    return GT_OK;
}



int GT_Graph::move_edge (edge e,
    const double move_x,
    const double move_y)
{
    vector move_xy (move_x, move_y);
    GT_Edge_Attributes& edge_attrs = gt(e);

    edge_attrs.graphics()->move (move_xy);
    
    if (edge_attrs.label_graphics() != 0) {
	edge_attrs.label_graphics()->move (move_xy);
    }

    return GT_OK;
}



//////////////////////////////////////////
//
// Update Operations 
//
//////////////////////////////////////////


void GT_Graph::update ()
{
    return;
}

void GT_Graph::update (node /* n */)
{
    return;
}

void GT_Graph::update (edge /* e */)
{
    return;
}
	

void GT_Graph::update_coordinates ()
{
    return;
}
	
void GT_Graph::update_coordinates (node /* n */)
{
    return;
}
	
void GT_Graph::update_coordinates (edge /* e */)
{
    return;
}


void GT_Graph::update_label_coordinates ()
{
    return;
}
	
void GT_Graph::update_label_coordinates (node /* n */)
{
    return;
}
	
void GT_Graph::update_label_coordinates (edge /* e */)
{
    return;
}
