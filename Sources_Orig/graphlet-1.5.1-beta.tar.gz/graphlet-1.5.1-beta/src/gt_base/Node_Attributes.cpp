//
// Node_Attributes.cc
//
// This file defines the class GT_Node_Attributes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Node_Attributes.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:43 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//

#include "Graphlet.h"
#include "Graph.h"
#include "Node_Attributes.h"


//////////////////////////////////////////
//
// class GT_Node_Graphics
//
//////////////////////////////////////////



//////////////////////////////////////////
//
// class GT_Node_Attributes
//
//////////////////////////////////////////


GT_Node_Attributes::GT_Node_Attributes (GT_Graph* g, const node n)
{
    the_g = g;
    the_n = n;

    the_graphics = 0;
    the_label_graphics = 0;
}



GT_Node_Attributes::~GT_Node_Attributes()
{
}



GT_TAGGED_VARIABLE (GT_Node_Attributes, g, g);
GT_TAGGED_VARIABLE (GT_Node_Attributes, n, n);



//
// Graphics, LabelGraphics assignments
//


void GT_Node_Attributes::graphics (GT_Node_Graphics* graphics)
{
    assert (find (the_g->attrs (the_n), GT_Keys::graphics) == 0);
    this->the_graphics = graphics;

    the_g->attrs (the_n)->append (
	new GT_Attributes (GT_Keys::graphics, the_graphics));
    
    this->the_changed |= tag_graphics;
    this->the_initialized |= tag_graphics;	
}



void GT_Node_Attributes::label_graphics (GT_Node_Graphics* label_graphics)
{
    assert (find (the_g->attrs (the_n), GT_Keys::label_graphics) == 0);
    this->the_label_graphics = label_graphics;

    the_g->attrs (the_n)->append (
	new GT_Attributes (GT_Keys::label_graphics, the_label_graphics));
    the_g->attrs (the_n)->tail()->set_safe();

    this->the_changed |= tag_label_graphics;
    this->the_initialized |= tag_label_graphics;	
}



//
// extract
//


int GT_Node_Attributes::extract (GT_List_of_Attributes* current_list,
    string& message)
{
    int code;
    code = baseclass::extract (current_list, message);
    if (code != GT_OK) {
	return GT_ERROR;
    }
	

    GT_List_of_Attributes* graphics_list;
    if (extract_value (current_list, GT_Keys::graphics,
	graphics_list)) {

	if (the_graphics == 0) {
	    graphics (the_g->new_node_graphics());
	}

	code = the_graphics->extract (graphics_list, message);
	if (code != GT_OK) {
	    return GT_ERROR;
	}

	the_graphics->conc (*graphics_list);
    }

    GT_List_of_Attributes* label_graphics_list;
    if (extract_value (current_list, GT_Keys::label_graphics,
	label_graphics_list)) {

	if (the_label_graphics == 0) {
	    label_graphics (the_g->new_node_label_graphics());
	}
		
	code = the_label_graphics->extract (label_graphics_list, message);
	if (code != GT_OK) {
	    return GT_ERROR;
	}
	

	the_label_graphics->conc (*label_graphics_list);
    }

    return GT_OK;
}	



//
// print
//


void GT_Node_Attributes::print (ostream& out) const
{	
    baseclass::print (out);
}
