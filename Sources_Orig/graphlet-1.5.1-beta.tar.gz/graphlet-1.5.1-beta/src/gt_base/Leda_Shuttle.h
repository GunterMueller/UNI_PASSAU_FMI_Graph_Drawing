#ifndef GT_LEDA_SHUTTLE_H
#define GT_LEDA_SHUTTLE_H

//
// Leda_Shuttle.h
//
// This file defines the class GT_Leda_Shuttle
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Leda_Shuttle.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:43 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Shuttle.h"



template<class T>
class GT_Leda_Shuttle : protected T, public GT_Shuttle {

    GT_CLASS (GT_Leda_Shuttle, GT_Shuttle);

public:
	
    GT_Leda_Shuttle ()
    {
    }
	
    virtual graph& leda()
    {
	return *this;
    }
	
	
    //
    // _action
    //
	
    virtual void new_node_action (node n);
    virtual void del_node_action (node n);
    virtual void new_edge_action (edge e);
    virtual void del_edge_action (edge e);
    virtual void rev_edge_action (edge e);
    virtual void clear_action ();
};


//
// _action
//

template<class T>
void GT_Leda_Shuttle<T>::new_node_action (node n)
{
#ifdef GT_SHUTTLE_DEBUG
    cout << "GT_Leda_Shuttle::new_node_action" << endl;
#endif
	
    the_graph->new_node_action (n);
}

template<class T>
void GT_Leda_Shuttle<T>::del_node_action (node n)
{
#ifdef GT_SHUTTLE_DEBUG
    cout << "GT_Leda_Shuttle::del_node_action" << endl;
#endif
	
    the_graph->del_node_action (n);
} 

template<class T>
void GT_Leda_Shuttle<T>::new_edge_action (edge e)
{
#ifdef GT_SHUTTLE_DEBUG
    cout << "GT_Leda_Shuttle::new_edge_action" << endl;
#endif
	
    the_graph->new_edge_action (e);
}

template<class T>
void GT_Leda_Shuttle<T>::del_edge_action (edge e)
{
#ifdef GT_SHUTTLE_DEBUG
    cout << "GT_Leda_Shuttle::del_edge_action" << endl;
#endif

    the_graph->del_edge_action (e);
}

template<class T>
void GT_Leda_Shuttle<T>::rev_edge_action (edge e)
{
#ifdef GT_SHUTTLE_DEBUG
    cout << "GT_Leda_Shuttle::rev_edge_action" << endl;
#endif

    the_graph->rev_edge_action (e);
} 

template<class T>
void GT_Leda_Shuttle<T>::clear_action ()
{
#ifdef GT_SHUTTLE_DEBUG
    cout << "GT_Leda_Shuttle::clear_action" << endl;
#endif

    the_graph->clear_action ();
}


#endif
