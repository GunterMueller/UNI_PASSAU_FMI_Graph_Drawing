#ifndef GT_COMMON_GRAPHICS_H
#define GT_COMMON_GRAPHICS_H

//
// Common_Graphics.h
//
// This file defines the class GT_Common_Graphics.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Common_Graphics.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/04 08:46:02 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//

#include "Graphlet.h"
#include "Attributes.h"

#include "Common_Attributes.h"

// #include <LEDA/point.h>
// #include <LEDA/list.h>

#include "Geometry.h"


//////////////////////////////////////////
//
// class GT_Common_Graphics
//
//////////////////////////////////////////



class GT_Common_Graphics : public GT_Tagged_Attributes,
			   public GT_List_of_Attributes
{

    GT_BASE_CLASS (GT_Common_Graphics);

public:
	
    enum Graphics {

	tag_geometry = (1<<0), // x,y,w,h
	tag_type = (tag_geometry<<1),

	tag_anchor = (tag_type<<1),
	tag_arrow = (tag_anchor<<1),
	tag_arrowshape = (tag_arrow<<1),
	tag_background = (tag_arrowshape<<1),
	tag_bitmap = (tag_background<<1),
	tag_capstyle = (tag_bitmap<<1),
	tag_extent = (tag_capstyle<<1),
	tag_fill = (tag_extent<<1),
	tag_font = (tag_fill<<1),
	tag_foreground = (tag_font<<1),
	tag_image = (tag_foreground<<1),
	tag_joinstyle = (tag_image<<1),
	tag_justify = (tag_joinstyle<<1),
	tag_line = (tag_justify<<1),
	tag_outline = (tag_line<<1),
	tag_smooth = (tag_outline<<1),
	tag_splinesteps = (tag_smooth<<1),
	tag_start = (tag_splinesteps<<1),
	tag_stipple = (tag_start<<1),
	tag_style = (tag_stipple<<1),
	tag_visible = (tag_style<<1),
	tag_width = (tag_visible<<1),

	common_graphics_tag_min = tag_geometry,
	common_graphics_tag_max = tag_width
    };


    GT_COMPLEX_VARIABLE (GT_Rectangle, old_center);
    GT_DECLARE_TAGGED_COMPLEX_VARIABLE (GT_Rectangle, center);
    GT_DECLARE_TAGGED_COMPLEX_VARIABLE (GT_Polyline, line);

    // Tk Graphics
	
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, type);
    GT_DECLARE_TAGGED_VARIABLE (bool, visible);
	
    // Global
	
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, fill);
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, outline);
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, stipple);
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, anchor);
    GT_DECLARE_TAGGED_VARIABLE (double, width);

    //
    // Arc
    //
	
    GT_DECLARE_TAGGED_VARIABLE (double, extent);
    GT_DECLARE_TAGGED_VARIABLE (double, start);
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, style);

    //
    // Bitmap
    //
	
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, background);
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, foreground);
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, bitmap);

    //
    // Image
    //
	
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, image);

    //
    // Line
    //
	
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, arrow);
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, arrowshape);
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, capstyle);
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, joinstyle);

    //
    // Polygon
    //
	
    GT_DECLARE_TAGGED_VARIABLE (bool, smooth);
    GT_DECLARE_TAGGED_VARIABLE (int, splinesteps);

    //
    // Text
    //
	
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, justify);
    GT_DECLARE_TAGGED_VARIABLE (GT_Key, font);

	
public:
	
    GT_Common_Graphics();
    virtual ~GT_Common_Graphics();

    //
    // extract
    //
	
    virtual int extract (GT_List_of_Attributes* list, string& message);

    //
    // print
    //
    
    virtual void print (ostream& out) const;

    //
    // reset
    //

    virtual void reset ();
    
    //
    // convenient x/y/w/h access
    //
	
    const double x () const {
	return the_center.x();
    }

    const double y () const {
	return the_center.y();
    }

    const double w () const {
	return the_center.w();
    }

    const double h () const {
	return the_center.h();
    }

	
    void x (const double x);
    void y (const double y);
    void w (const double w);
    void h (const double h);

    //
    // Utilities
    //

    virtual void move (const vector& move_xy);
};


#endif
