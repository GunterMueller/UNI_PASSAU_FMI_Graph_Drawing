//
// Device.cc
//
// This file implements the classes GT_Device and GT_Device.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Device.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:41 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//

#include "Graphlet.h"
#include "Device.h"


//////////////////////////////////////////
//
// GT_Device
//
//////////////////////////////////////////



GT_Device::GT_Device (const string& name) : the_name (name)
{
}


GT_Device::~GT_Device ()
{
}
    


GT_UIObject* GT_Device::insert (const int uid, GT_UIObject* uiobject)
{
    assert (uid >= 0);
    assert (uiobject != 0);

    the_objects.insert (uid, uiobject);

    return uiobject;
}


GT_UIObject* GT_Device::get (const int id) const
{
    dic_item it = the_objects.lookup (id);

    if (it != 0) {
	return the_objects.inf (it);
    } else {
	return 0;
    }
}


const bool GT_Device::defined (const int id) const
{
    return the_objects.lookup (id) != 0;
}


void GT_Device::del (const int id)
{
    the_objects.del (id);
}
