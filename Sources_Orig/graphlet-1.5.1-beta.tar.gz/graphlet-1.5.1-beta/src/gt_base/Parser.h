#ifndef GT_Parser_H
#define GT_Parser_H

//
// Parser.h
//
// This file dcefines the classes GT_Parser and GT_Parser_yacc.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Parser.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:44 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//


// #include "Graphlet.h"
// #include "Attributes.h"


//////////////////////////////////////////
//
// class GT_Parser
//
// This is the pure virtual baseclass for implementing parsers.
//
//////////////////////////////////////////

class GT_List_of_Attributes;


class GT_Parser {

    GT_BASE_CLASS (GT_Parser);

public:
    GT_Parser();
    virtual ~GT_Parser();

    virtual GT_List_of_Attributes* parser (const char* filename = 0) = 0;
    virtual int error (int line_number, const char *message) = 0;

    GT_VARIABLE (GT_List_of_Attributes*, parsed_attrs);
    GT_VARIABLE (int, line_number);
};



//////////////////////////////////////////
//
// class GT_Parser_yacc
//
//////////////////////////////////////////

class GT_Parser_yacc : public GT_Parser {

    GT_CLASS (GT_Parser_yacc, GT_Parser);

public:
    GT_Parser_yacc();
    ~GT_Parser_yacc();
	
    virtual GT_List_of_Attributes* parser (const char* filename = 0);
    virtual int error (int line_number, const char *message);
};



#endif
