//
// Geometry.cc
//
// This file implements several geometry related classes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Geometry.cpp,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/06 08:41:20 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//


#include "Graphlet.h"

#include "Geometry.h"


GT_CLASS_IMPLEMENTATION (GT_Point);
GT_CLASS_IMPLEMENTATION (GT_Polyline);
GT_CLASS_IMPLEMENTATION (GT_Rectangle);


//////////////////////////////////////////
//
// GT_Point
//
//////////////////////////////////////////


void GT_Point::move (const vector& move_xy)
{
    *this = translate (move_xy);
}



//////////////////////////////////////////
//
// GT_Polyline
//
//////////////////////////////////////////


segment GT_Polyline::nth_segment (const int n) const
{
    assert (n < length());
	
    list_item it = item (n);
    const point& p1 = contents (it);
    const point& p2 = contents (succ(it));

    return segment (p1, p2);
}


void GT_Polyline::move (const vector& move_xy)
{
    list_item it;
    forall_items (it, *this) {
	this->operator[](it).move (move_xy);	
    }
}


GT_Polyline::~GT_Polyline ()
{
}



//////////////////////////////////////////
//
// Rectangle utilities
//
//////////////////////////////////////////


bool GT_Rectangle::includes (const point& p) const
{
    double x_dist = fabs (p.xcoord() - xcoord());
    double y_dist = fabs (p.ycoord() - ycoord());

    return (x_dist <= the_w/2) && (y_dist < the_h/2);
}


//
// The following procedures are modelled after Tcl/Tk anchor
// positions.
//

point GT_Rectangle::anchor_c() const
{
    return *this;
}


point GT_Rectangle::anchor_n() const
{
    return point (x(), y() + h() / 2);
}


point GT_Rectangle::anchor_ne() const
{
    return point (x() - w() / 2, y() + h() / 2);
}


point GT_Rectangle::anchor_e() const
{
    return point (x() - w() / 2, y());
}


point GT_Rectangle::anchor_se() const
{
    return point (x() - w() / 2, y() - h() / 2);
}


point GT_Rectangle::anchor_s() const
{
    return point (x(), y() - h() / 2);
}


point GT_Rectangle::anchor_sw() const
{
    return point (x() + w() / 2, y() - h() / 2);
}


point GT_Rectangle::anchor_w() const
{
    return point (x() + w() / 2, y());
}


point GT_Rectangle::anchor_nw() const
{
    return point (x() + w() / 2, y() + h() / 2);
}



//////////////////////////////////////////
//
// Geometry utilities rescued from the dark ages of GraphEd
//
//////////////////////////////////////////


void clip_line_out_of_node (const GT_Rectangle& r,
    const point& fix,
    point& adjust)
{
    double x = r.x();
    double y = r.y();
    double width  = r.w();
    double height = r.h();

    double dx = fix.xcoord() - x;
    double dy = fix.ycoord() - y;	
    double adx = fabs(dx);
    double ady = fabs(dy);

    double xadjust;
    double yadjust;
	
    if ( (adx > width/2) || (ady > height/2) ) {
	// fix outside r
	if (adx * height >= ady * width ) {
	    if (dx >0) {
		xadjust = x + (width - width/2);
		yadjust = y + ((width -width/2) * dy) / dx;
	    } else {
		xadjust = x - width/2;
		yadjust = y - (width/2 * dy) / dx;
	    }
	} else {
	    if (dy >0) {
		xadjust = x + ((height - height/2) * dx) / dy;
		yadjust = y + (height - height/2);
	    } else {
		xadjust = x - (height/2 * dx) / dy;
		yadjust = y - height/2;
	    }
	}
		
	adjust = point (xadjust, yadjust);
		
    } else {
	// fix inside r; nothing to do
    }
}



#ifdef OLD_GRAPHED_CODE

static	void	clip_straight_line_nei (Node node, int *x1, int *y1, int x2, int y2)
{
    register int	x = node_x (node),
	y   = node_y (node),
	dx  = x2 - x,
	dy  = y2 - y,
	adx = abs(dx),
	ady = abs(dy),
	width  = node_width  (node),
	height = node_height (node);
	
    if ( (adx > width/2) || (ady > height/2) ) {
	/* (x2,y2) ausserhalb des Knotens	*/
	if (dx > 0) {
	    *x1 = minimum (x2, x + (width - width/2));
	} else {
	    *x1 = maximum (x2, x - width/2);
	}
	if (dy > 0) {
	    *y1 = minimum (y2, y + (height - height/2));
	} else {
	    *y1 = maximum (y2, y - height/2);
	}
    } else {
	/* (x2,y2) innerhalb des Knotens	*/
	*x1 = x2;
	*y1 = y2;
    }
}



int	line_line_intersection (int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, int *x, int *y)
/* first line				*/
/* second line				*/
/* *the* return point if result is TRUE	*/
{
    /* Note : this procedure does NOT check whether the	*/
    /* intersection point lies in [x1,x2]*[x3,x4] and	*/
    /* [y1,y2]*[y3,y4].					*/
	
    double	dx12 = x2 - x1,
	dy12 = y2 - y1,
	dx34 = x4 - x3,
	dy34 = y4 - y3;
		
    if (dx12 == 0 && dx34 == 0) {
	if (x1 == x3) {
	    *x = x1; *y = y1; return TRUE;
	} else {
	    return FALSE;
	}
    } else if (dx12 == 0) /* dx34 != 0 */ {
	*y = y3 + dy34/dx34 * (x1 - x3);
	*x = x1;
	return TRUE;
    } else if (dx34 == 0) /* dx12 != 0 */ {
	*y = y1 + dy12/dx12 * (x3 - x1);
	*x = x3;
	return TRUE;
    } else /* dx12 !=0 && dx34 != 0 */ {
	double	m12 = dy12 / dx12,	/* Slopes	*/
	    m34 = dy34 / dx34;
	*x = (y3-y1 - (m34*x3 - m12*x1)) / (m12 - m34);
	*y = y1 + (*x-x1)*m12;
	return TRUE;
    }	
}





void	adjust_edgeline_to_elliptical_node (Node node, int *x1,int *y1, int x2, int y2)
{
    double	x,y, m, a,b, xx,yy,aa,bb;
	
    a = (double)node_width(node)  / 2.0;	/* Halbachsen der	*/
    b = (double)node_height(node) / 2.0;	/* Ellipse		*/
    x = x2 - node_x(node);	/* (x2,y2) im Koordinatensystem	*/
    y = y2 - node_y(node);	/* des Knotens			*/
    aa = a*a; bb = b*b;
    xx = x*x; yy = y*y;
	
    if ( xx/aa + yy/bb < 1 ) {
	x = 0;
	y = 0;
    } else if (x != 0) {
	m = y/x;
	if (x>0)
	    x =   a*b * sqrt ( 1 / (bb + aa * m*m) );
	else
	    x = - a*b * sqrt ( 1 / (bb + aa * m*m) );
	y = m * x;
    } else /* x == 0 */ {
	x = 0;
	y = iif (y2 >= node_y(node), b, -b);
    }
	
    *x1 = node_x(node) + x;
    *y1 = node_y(node) + y;
}


#endif
