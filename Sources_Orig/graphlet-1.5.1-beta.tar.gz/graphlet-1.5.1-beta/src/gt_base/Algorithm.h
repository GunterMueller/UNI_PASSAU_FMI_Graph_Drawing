#ifndef GT_ALGORITHM_H
#define GT_ALGORITHM_H

//
// filename
//
// The description of filename goes HERE.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Algorithm.h,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/09 18:28:35 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//


//
// class GT_Algorithm
//
// This is an abstract base class.
//

// class GT_Graph;

class GT_Algorithm
{
    GT_BASE_CLASS (GT_Algorithm);

    GT_COMPLEX_VARIABLE (string, name);
    
public:

    GT_Algorithm (const string& name);
    virtual ~GT_Algorithm ();
    
    virtual int run (GT_Graph& g) = 0;
    virtual int check (GT_Graph& g, string& message) = 0;
    virtual void reset ();
    
    //
    // Utilities
    //
	
    static edge find_self_loop (GT_Graph& g);
    static bool remove_all_bends (GT_Graph& g);
    virtual void adjust_coordinates (GT_Graph& g,
	double min_x,
	double min_y) const;
};



//
// class GT_No_Algorithm
//
// This is a dummy algorithm which does noything.
//



class GT_No_Algorithm : public GT_Algorithm
{
    GT_CLASS (GT_No_Algorithm, GT_Algorithm);

public:
    virtual int run (GT_Graph& g);
    virtual int check (GT_Graph& g, string& message);

    GT_No_Algorithm () : GT_Algorithm ("No")
    {
    }
	
    ~GT_No_Algorithm ()
    {
    }
	
};


#endif
