//
// Graph_Attributes.cc
//
// This module implements the class GT_Graph_Attributes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Graph_Attributes.cpp,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/06 08:41:22 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//


#include "Graphlet.h"
#include "Graph.h"
#include "Graph_Attributes.h"



//////////////////////////////////////////
//
// class GT_Graph_Attributes
//
//////////////////////////////////////////


GT_Graph_Attributes::GT_Graph_Attributes (GT_Graph* g)
{
    the_g = g;
    the_version = 0;

    the_graphics = 0;
    the_label_graphics = 0;
}


GT_Graph_Attributes::~GT_Graph_Attributes()
{
}



GT_TAGGED_VARIABLE (GT_Graph_Attributes, g, g);

GT_TAGGED_VARIABLE (GT_Graph_Attributes, version, version);
GT_TAGGED_COMPLEX_VARIABLE (GT_Graph_Attributes, creator, creator);




//
// Graphics, LabelGraphics assignments
//


void GT_Graph_Attributes::graphics (GT_Graph_Graphics* graphics)
{
    assert (find (the_g->attrs(), GT_Keys::graphics) == 0);
    this->the_graphics = graphics;

    the_g->attrs()->append (
	new GT_Attributes (GT_Keys::graphics, the_graphics));

    this->the_changed |= tag_graphics;
    this->the_initialized |= tag_graphics;	
}



void GT_Graph_Attributes::label_graphics (GT_Graph_Graphics* label_graphics)
{
    assert (find (the_g->attrs(), GT_Keys::label_graphics) == 0);
    this->the_label_graphics = label_graphics;

    the_g->attrs()->append (
	new GT_Attributes (GT_Keys::label_graphics, the_label_graphics));

    this->the_changed |= tag_label_graphics;
    this->the_initialized |= tag_label_graphics;	
}



//
// extract
//


int GT_Graph_Attributes::extract (GT_List_of_Attributes* current_list,
    string& message)
{
    int code;
    code = baseclass::extract (current_list, message);
    if (code != GT_OK) {
	return GT_ERROR;
    }
	
    GT_EXTRACT (current_list, GT_Keys::version, int, version);
    GT_EXTRACT (current_list, GT_Keys::creator, string, creator);

    GT_List_of_Attributes* graphics_list;
    if (extract_value (current_list, GT_Keys::graphics,
	graphics_list)) {

	if (the_graphics == 0) {
	    graphics (the_g->new_graph_graphics());
	}
		
	code = the_graphics->extract (graphics_list, message);
	if (code != GT_OK) {
	    return GT_ERROR;
	}
	
	the_graphics->conc (*graphics_list);
    }

    GT_List_of_Attributes* label_graphics_list;
    if (extract_value (current_list, GT_Keys::label_graphics,
	label_graphics_list)) {

	if (the_label_graphics == 0) {
	    label_graphics (the_g->new_graph_label_graphics());
	}
		
	code = the_label_graphics->extract (label_graphics_list, message);
	if (code != GT_OK) {
	    return GT_ERROR;
	}
	

	the_label_graphics->conc (*label_graphics_list);
    }

    return GT_OK;
}



//
// print
//


void GT_Graph_Attributes::print (ostream& out) const
{
    if (is_initialized (tag_version)) {
	GT_print (out, GT_Keys::version, the_version);
    }

    if (is_initialized (tag_creator) && the_creator.length() > 0) {
	GT_print (out, GT_Keys::creator, the_creator);
    }

    baseclass::print(out);	
}
