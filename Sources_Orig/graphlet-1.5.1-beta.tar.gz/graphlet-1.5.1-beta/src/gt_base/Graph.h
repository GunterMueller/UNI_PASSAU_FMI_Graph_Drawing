#ifndef GT_Graph_H
#define GT_Graph_H

//
// Graph.h
//
// This module defines the class GT_Graph.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Graph.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/04 08:46:07 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//

#include "Graphlet.h"
#include "Attributes.h"

#include "Graph_Attributes.h"
#include "Node_Attributes.h"
#include "Edge_Attributes.h"


//
// LEDA Includes
//

#include <LEDA/graph.h>
#include <LEDA/map.h>


//////////////////////////////////////////
//
// GT_Graph;
//
//////////////////////////////////////////

#include "Shuttle.h"

class GT_Graph {

    GT_BASE_CLASS (GT_Graph);
    
    graph* the_graph;
	
    GT_Graph_Attributes*          the_graph_attrs;
    node_map<GT_Node_Attributes*> the_node_attrs;
    edge_map<GT_Edge_Attributes*> the_edge_attrs;

public:

    //
    // Constructors and Accessors
    //
	
    GT_Graph();
    virtual ~GT_Graph();

    //
    // Attached (LEDA) graph
    //
	
    inline graph* GT_Graph::attached() const;
    virtual void attach (graph* g);
    virtual void attach (GT_Shuttle& g);

    //
    // leda
    //
    // leda is a synomym for the attached graph. The leda methods
    // access the graph through references, while attach uses
    // pointers.
    //

    inline void GT_Graph::leda (graph* g);
    inline void GT_Graph::leda (graph& g);
    inline void GT_Graph::leda (GT_Shuttle& g);
    inline graph& GT_Graph::leda ();
    inline const graph& GT_Graph::leda () const;

    //
    // graph/node/edge attributes
    //

    virtual GT_Graph_Attributes* new_graph_attributes ();
    virtual GT_Node_Attributes* new_node_attributes (const node n);
    virtual GT_Edge_Attributes* new_edge_attributes (const edge e);
	
    //
    // graphics customization
    //

    virtual GT_Graph_Graphics* new_graph_graphics ();
    virtual GT_Node_Graphics* new_node_graphics ();
    virtual GT_Edge_Graphics* new_edge_graphics ();
	
    virtual GT_Graph_Graphics* new_graph_label_graphics ();
    virtual GT_Node_Graphics* new_node_label_graphics ();
    virtual GT_Edge_Graphics* new_edge_label_graphics ();

    //
    // Virtual update operations
    //
	
    virtual void new_node_action (node n);
    virtual void del_node_action (node n);
    virtual void new_edge_action (edge e);
    virtual void del_edge_action (edge e);
    virtual void rev_edge_action (edge e);
    virtual void clear_action ();
	
    //
    // Utilities
    //

    node find_node (const int id);
    edge find_edge (const int id);

    //
    // attrs accessors for attribute lists
    //
	
    inline GT_List_of_Attributes* attrs (const node v);
    inline GT_List_of_Attributes* attrs (const edge e);
    inline GT_List_of_Attributes* attrs();

    inline const GT_List_of_Attributes* attrs (const node v) const;
    inline const GT_List_of_Attributes* attrs (const edge e) const;
    inline const GT_List_of_Attributes* attrs() const;

    //
    // gt accessors
    //
	
    GT_Node_Attributes& gt(node v);
    GT_Edge_Attributes& gt(edge e);
    GT_Graph_Attributes& gt();

    const GT_Node_Attributes& gt(const node v) const;
    const GT_Edge_Attributes& gt(const edge e) const;
    const GT_Graph_Attributes& gt() const;

    //
    // extract
    //
	
    virtual int extract (GT_List_of_Attributes* list, string& message);

    //
    // Graph drawing operations
    //
	
    virtual int draw ();	
    virtual int draw (node n);
    virtual int draw (edge e);	

    virtual int move_node (node n,
	const double x_diff,
	const double y_diff);
    virtual int move_edge (edge e,
	const double x_diff,
	const double y_diff);
    virtual int move_nodes (const list<node>& nodes,
	const double x_diff,
	const double y_diff);
    
    virtual int begin_draw ();
    virtual int end_draw ();

    //
    // update
    //
	
    virtual void update ();
    virtual void update (node n);
    virtual void update (edge e);
	
    virtual void update_label_coordinates (); // unused
    virtual void update_label_coordinates (node n);
    virtual void update_label_coordinates (edge e);

    virtual void update_coordinates (); // unused
    virtual void update_coordinates (node n);
    virtual void update_coordinates (edge e);

};

ostream& operator<< (ostream& out, const GT_Graph& G);


//
// inline definitions
//

//
// attached
//

inline graph* GT_Graph::attached() const
{
    return the_graph;
}



//
// leda
//


inline void GT_Graph::leda (graph* g)
{
    attach (g);
}


inline void GT_Graph::leda (graph& g)
{
    attach (&g);
}


inline void GT_Graph::leda (GT_Shuttle& g)
{
    attach (g);
    g.attach (this);
}


inline graph& GT_Graph::leda ()
{
    assert (the_graph != 0);
    return *(the_graph);
}
	

inline const graph& GT_Graph::leda () const
{
    assert (the_graph != 0);
    return *(the_graph);
}



//
// attrs
//

inline GT_List_of_Attributes* GT_Graph::attrs()
{
    assert (the_graph != 0);
    return the_graph_attrs;
}

inline GT_List_of_Attributes* GT_Graph::attrs (const node v)
{
    assert (the_graph != 0);
    return the_node_attrs[v];
}

inline GT_List_of_Attributes* GT_Graph::attrs (const edge e)
{
    assert (the_graph != 0);
    return the_edge_attrs[e];
}



inline const GT_List_of_Attributes* GT_Graph::attrs() const
{
    assert (the_graph != 0);
    return the_graph_attrs;
}

inline const GT_List_of_Attributes* GT_Graph::attrs (const node n) const
{
    assert (the_graph != 0);
    return the_node_attrs (n);
}

inline const GT_List_of_Attributes* GT_Graph::attrs (const edge e) const
{
    assert (the_graph != 0);
    return the_edge_attrs (e);
}



#endif
