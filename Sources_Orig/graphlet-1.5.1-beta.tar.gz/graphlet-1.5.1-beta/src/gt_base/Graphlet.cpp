//
// Graphlet.cc
//
// This file implements the class Graphlet.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Graphlet.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:43 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//


#include "Graphlet.h"
#include "Parser.h"


GT_CLASS_IMPLEMENTATION (GT);


GT::GT()
{
    parser = new GT_Parser_yacc;
}

GT::~GT()
{
}


void GT::init ()
{
    GT_Keys::init();
}


//
// declare static members of GT
//

GT_Id        GT::id;
GT_Error     GT::error;
GT_Parser*   GT::parser;
GT_Keymapper GT::keymapper;


//
// Global variable graphlet
//

GT graphlet;


//
// strsave (s) returns a copy of s allocated with malloc. An
// optional parameters controls the length of the string.
//

#include <string.h>

char* GT::strsave (const char* s, int max_length)
{
    assert (s != 0);

    int length = 0;
    char* new_string = 0;
    
    if (max_length == 0) {
        
        length = strlen (s);
        new_string = new char[length+1];
        assert (new_string != 0);
        strcpy (new_string, s);
        
    } else {

        length = max_length;
        new_string = (char*) malloc (length+1);
        assert (new_string != 0);
        strncpy (new_string, s, length);
    }
    
    new_string[length] = '\0';

    return new_string;
}


//
// File utilities
//

FILE* GT::fopen (const char *filename, const char* mode)
{
    return ::fopen (filename, mode);
}

void GT::fclose (FILE* file)
{
    ::fclose (file);
}


//////////////////////////////////////////
//
// FileFormat
//
//////////////////////////////////////////


FileFormat::FileFormat()
{
    typedef char* Char_Pointer;
    indent_strings = new Char_Pointer [max_indent_level];
    
    indent_spaces_per_level (2);
}

FileFormat::~FileFormat()
{
    delete[] indent_strings;
}

const int  FileFormat::max_indent_level = 100;
const char FileFormat::escape_character = '\\';

const char FileFormat::begin_list_delimeter = '[';
const char FileFormat::end_list_delimeter = ']';

FileFormat fileformat;


//
// indent returns a string that consists of
//   level * indent_spaces_per_level
// blanks. This function is useful for output of indented lists. 
//

const char* FileFormat::indent (int level)
{
    if (level > max_indent_level) {
	level = max_indent_level;
    }

    if (indent_strings[level] == 0) {
		
	int length = level * indent_spaces_per_level();

	indent_strings[level] = new char[level+1];
	for (int i=0; i<length; i++) {
	    indent_strings[level][i] = ' ';
	}
	indent_strings[level][length] = '\0';
    }

    return indent_strings[level];
}


//
//
// remove_escape_characters_from_text
//
// deletes escaped characters text and returns a new string. This
// is (except for the outer quites) the inverse of write_quoted
// (see below).
//
// Taken from GraphEd 4.* source code, slightly updates to C++.
//

char* FileFormat::remove_escape_characters_from_text (
    const char *text,
    int length)
{
    int		i,j;
    int		length_without_escapes = 0;
    char	*text_without_escapes;
	
    /* Compute length without escapes	*/
    for (i = 0; i < length; i++) {
	if (text[i] == escape_character) {
	    i ++;
	}
	length_without_escapes ++;
    }

    text_without_escapes = new char[length_without_escapes+1];
	
    /* i = index in text;				*/
    /* j = index in text_without_escapes		*/
    for (i=0,j=0; i<length; i++,j++) {
	if (text[i] == escape_character) {
	    switch (text[i+1]) {
		case 'n':
		    text_without_escapes[j] = '\n';
		    break;
		case 'r':
		    text_without_escapes[j] = '\r';
		    break;
		case 't':
		    text_without_escapes[j] = '\t';
		    break;
		default:
		    text_without_escapes[j] = text[i+1];
		    break;
	    }
	    i++;
	} else {
	    text_without_escapes[j] = text[i];
	}
    }
    text_without_escapes [length_without_escapes] = '\0';
	
    return	text_without_escapes;
}


//
// write_escaped writes a string; all non-printable characters
// (and " { } ) are escaped.
//
// Taken from GraphEd source code, slightly adapted.
//

ostream& FileFormat::write_escaped (ostream &out, const char* text)
{
    // Taken from GraphEd 4.0 source code

    int i, length;

    length = strlen (text);
    for (i = 0; i<length; i++) {
        switch (text[i]) {
            case '"' :
                out << escape_character << text[i];
                break;
            case '\015' :
            case '\n' :
                out << escape_character << '\n';
                break;
            case '\t' :
                out << escape_character << 't';
                break;
            case escape_character :
                out << escape_character << escape_character;
                break;
            default :
                out << text[i];
                break;
        }
    }
    return out;
}


//
// write_qoted writes a string sourronded by double quotes. All
// non-printable characters (and " { } ) are escaped.
//

ostream& FileFormat::write_quoted (ostream &out, const char* text)
{
    out << '"';
    write_escaped (out, text);
    out << '"';

    return out;
}
