#ifndef GT_DEVICES_H
#define GT_DEVICES_H

//
// Devices.h
//
// This file defines the classes GT_Device.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Device.h,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/06 08:41:18 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//


class GT_UIObject;

class GT_Device {
    
    GT_BASE_CLASS (GT_Device);
    dictionary<int, GT_UIObject*> the_objects;
    GT_COMPLEX_VARIABLE (string, name);
	
public:
	
    GT_Device (const string& name);
    virtual ~GT_Device ();
    
    inline GT_UIObject* operator[] (const int id) {
	return get (id);
    }

    inline GT_UIObject* object (const int id) {
	return get (id);
    }

    GT_UIObject* insert (const int id, GT_UIObject* uiobject);
    GT_UIObject* get (const int id) const;
    void del (const int id);
	
    const bool defined (const int id) const;
};

#endif
