//
// Graph.cc
//
// This module implements the class GT_Keys.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Keys.cpp,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/11/04 08:46:08 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#include "Graphlet.h"


GT_CLASS_IMPLEMENTATION (GT_Keys);

GT_Keys::GT_Keys()
{
}


void GT_Keys::init()
{
    //
    // Management
    //
	
    GT_Keys::def = GT::keymapper.add ("-default-");
    GT_Keys::empty = GT::keymapper.add ("");

    //
    // General
    //
    
    GT_Keys::graph = GT::keymapper.add ("graph");
    GT_Keys::node = GT::keymapper.add ("node");
    GT_Keys::edge = GT::keymapper.add ("edge");
    GT_Keys::graphics = GT::keymapper.add ("graphics");
    GT_Keys::label_graphics = GT::keymapper.add ("LabelGraphics");

    GT_Keys::version = GT::keymapper.add ("version");
    GT_Keys::option_version = GT::keymapper.add ("-version");

    GT_Keys::creator = GT::keymapper.add ("Creator");
    GT_Keys::option_creator = GT::keymapper.add ("-creator");

    GT_Keys::id = GT::keymapper.add ("id");
    GT_Keys::option_id = GT::keymapper.add ("-id");

    GT_Keys::name = GT::keymapper.add ("name");
    GT_Keys::option_name = GT::keymapper.add ("-name");

    GT_Keys::label = GT::keymapper.add ("label");
    GT_Keys::option_label = GT::keymapper.add ("-label");

    GT_Keys::center = GT::keymapper.add ("center");
    GT_Keys::option_center = GT::keymapper.add ("-center");

    GT_Keys::directed = GT::keymapper.add ("directed");
    GT_Keys::option_directed = GT::keymapper.add ("-directed");


    //
    // Graphics
    //
	
    GT_Keys::type = GT::keymapper.add ("type");
    GT_Keys::option_type = GT::keymapper.add ("-type");

    GT_Keys::type_arc = GT::keymapper.add ("arc");
    GT_Keys::type_bitmap = GT::keymapper.add ("bitmap");
    GT_Keys::type_image = GT::keymapper.add ("image");
    GT_Keys::type_line = GT::keymapper.add ("line");
    GT_Keys::type_oval = GT::keymapper.add ("oval");
    GT_Keys::type_polygon = GT::keymapper.add ("polygon");
    GT_Keys::type_rectangle = GT::keymapper.add ("rectangle");
    GT_Keys::type_text = GT::keymapper.add ("text");

    GT_Keys::x = GT::keymapper.add ("x");
    GT_Keys::y = GT::keymapper.add ("y");
    GT_Keys::w = GT::keymapper.add ("w");
    GT_Keys::h = GT::keymapper.add ("h");

    GT_Keys::option_w = GT::keymapper.add ("-w");
    GT_Keys::option_h = GT::keymapper.add ("-h");
    GT_Keys::option_x = GT::keymapper.add ("-x");
    GT_Keys::option_y = GT::keymapper.add ("-y");

    GT_Keys::anchor = GT::keymapper.add ("anchor");
    GT_Keys::arrow = GT::keymapper.add ("arrow");
    GT_Keys::arrowshape = GT::keymapper.add ("arrowshape");
    GT_Keys::background = GT::keymapper.add ("background");
    GT_Keys::bitmap = GT::keymapper.add ("bitmap");
    GT_Keys::capstyle = GT::keymapper.add ("capstyle");
    GT_Keys::extent = GT::keymapper.add ("extent");
    GT_Keys::fill = GT::keymapper.add ("fill");
    GT_Keys::foreground = GT::keymapper.add ("foreground");
    GT_Keys::image = GT::keymapper.add ("image");
    GT_Keys::joinstyle = GT::keymapper.add ("joinstyle");
    GT_Keys::justify = GT::keymapper.add ("justify");
    GT_Keys::line = GT::keymapper.add ("Line");
    GT_Keys::outline = GT::keymapper.add ("outline");
    GT_Keys::point = GT::keymapper.add ("point");
    GT_Keys::smooth = GT::keymapper.add ("smooth");
    GT_Keys::source = GT::keymapper.add ("source");
    GT_Keys::splinesteps = GT::keymapper.add ("splinesteps");
    GT_Keys::start = GT::keymapper.add ("start");
    GT_Keys::stipple = GT::keymapper.add ("stipple");
    GT_Keys::style = GT::keymapper.add ("style");
    GT_Keys::target = GT::keymapper.add ("target");
    GT_Keys::visible = GT::keymapper.add ("visible");
    GT_Keys::width = GT::keymapper.add ("width");
    GT_Keys::xfont = GT::keymapper.add ("xfont");
	
    GT_Keys::edge_anchor = GT::keymapper.add ("edgeAnchor");
    GT_Keys::label_anchor = GT::keymapper.add ("labelAnchor");

    GT_Keys::option_anchor = GT::keymapper.add ("-anchor");
    GT_Keys::option_arrow = GT::keymapper.add ("-arrow");
    GT_Keys::option_arrowshape = GT::keymapper.add ("-arrowshape");
    GT_Keys::option_background = GT::keymapper.add ("-background");
    GT_Keys::option_bitmap = GT::keymapper.add ("-bitmap");
    GT_Keys::option_capstyle = GT::keymapper.add ("-capstyle");
    GT_Keys::option_extent = GT::keymapper.add ("-extent");
    GT_Keys::option_fill = GT::keymapper.add ("-fill");
    GT_Keys::option_foreground = GT::keymapper.add ("-foreground");
    GT_Keys::option_image = GT::keymapper.add ("-image");
    GT_Keys::option_joinstyle = GT::keymapper.add ("-joinstyle");
    GT_Keys::option_justify = GT::keymapper.add ("-justify");
    GT_Keys::option_line = GT::keymapper.add ("-line");
    GT_Keys::option_outline = GT::keymapper.add ("-outline");
    GT_Keys::option_point = GT::keymapper.add ("-point");
    GT_Keys::option_smooth = GT::keymapper.add ("-smooth");
    GT_Keys::option_source = GT::keymapper.add ("-source");
    GT_Keys::option_splinesteps = GT::keymapper.add ("-splinesteps");
    GT_Keys::option_start = GT::keymapper.add ("-start");
    GT_Keys::option_stipple = GT::keymapper.add ("-stipple");
    GT_Keys::option_style = GT::keymapper.add ("-style");
    GT_Keys::option_target = GT::keymapper.add ("-target");
    GT_Keys::option_visible = GT::keymapper.add ("-visible");
    GT_Keys::option_width = GT::keymapper.add ("-width");
    GT_Keys::option_xfont = GT::keymapper.add ("-font");
	
    GT_Keys::option_edge_anchor = GT::keymapper.add ("-edge_anchor");
    GT_Keys::option_label_anchor = GT::keymapper.add ("-label_anchor");

    //
    // Anchors
    //
	
    GT_Keys::anchor_center = GT::keymapper.add ("c");
    GT_Keys::anchor_n = GT::keymapper.add ("n");
    GT_Keys::anchor_ne = GT::keymapper.add ("ne");
    GT_Keys::anchor_e = GT::keymapper.add ("e");
    GT_Keys::anchor_se = GT::keymapper.add ("se");
    GT_Keys::anchor_s = GT::keymapper.add ("s");
    GT_Keys::anchor_sw = GT::keymapper.add ("sw");
    GT_Keys::anchor_w = GT::keymapper.add ("w");
    GT_Keys::anchor_nw = GT::keymapper.add ("nw");

    GT_Keys::anchor_first = GT::keymapper.add ("first");
    GT_Keys::anchor_last = GT::keymapper.add ("last");
    
    GT_Keys::anchor_clip = GT::keymapper.add ("clip");
    GT_Keys::anchor_corners = GT::keymapper.add ("corners");
    GT_Keys::anchor_middle = GT::keymapper.add ("middle");
    GT_Keys::anchor_8 = GT::keymapper.add ("corner_8");

    //
    // Keys for internals
    //
	
    GT_Keys::graph_attrs = GT::keymapper.add ("@graph_attrs");
    GT_Keys::node_attrs = GT::keymapper.add ("@node_attrs");
    GT_Keys::edge_attrs = GT::keymapper.add ("@edge_attrs");
	
    //
    // Keys for paths (optional)
    //
	
    GT_Keys::graphics_center_x = GT::keymapper.add (".graphics.center.x");
    GT_Keys::graphics_center_y = GT::keymapper.add (".graphics.center.y");
    GT_Keys::graphics_w = GT::keymapper.add (".graphics.w");
    GT_Keys::graphics_h = GT::keymapper.add (".graphics.h");
    GT_Keys::graphics_image = GT::keymapper.add (".graphics.image");


    //
    // Types of UIObject's
    //
	
    GT_Keys::uiobject_unknown = GT::keymapper.add ("unknown");
    GT_Keys::uiobject_node = GT::keymapper.add ("node");
    GT_Keys::uiobject_edge = GT::keymapper.add ("edge");
    GT_Keys::uiobject_graph = GT::keymapper.add ("graph");
    GT_Keys::uiobject_label = GT::keymapper.add ("label");
    GT_Keys::uiobject_node_label = GT::keymapper.add ("node:label");
    GT_Keys::uiobject_edge_label = GT::keymapper.add ("edge:label");
    GT_Keys::uiobject_graph_label = GT::keymapper.add ("graph:label");

    //
    // Color names
    //

    GT_Keys::white = GT::keymapper.add ("#FFFFFF");
    GT_Keys::black = GT::keymapper.add ("#000000");
    GT_Keys::red = GT::keymapper.add ("#FF0000");
    GT_Keys::green = GT::keymapper.add ("0000FF");
    GT_Keys::blue = GT::keymapper.add ("#00FF00");

    //
    // Actions
    //

    GT_Keys::action_new_node = GT::keymapper.add ("new_node");
    GT_Keys::action_new_edge = GT::keymapper.add ("new_edge");
    GT_Keys::action_del_node = GT::keymapper.add ("del_node");
    GT_Keys::action_del_edge = GT::keymapper.add ("del_edge");
    GT_Keys::action_rev_edge = GT::keymapper.add ("rev_edge");
    GT_Keys::action_clear = GT::keymapper.add ("clear");
}


GT_Key GT_Keys::def;
GT_Key GT_Keys::undefined (0);
GT_Key GT_Keys::empty;

GT_Key GT_Keys::graph;
GT_Key GT_Keys::node;
GT_Key GT_Keys::edge;
GT_Key GT_Keys::graphics;
GT_Key GT_Keys::label_graphics;

GT_Key GT_Keys::version,	GT_Keys::option_version;
GT_Key GT_Keys::creator,	GT_Keys::option_creator;
GT_Key GT_Keys::id,		GT_Keys::option_id;
GT_Key GT_Keys::name, 		GT_Keys::option_name;
GT_Key GT_Keys::label, 		GT_Keys::option_label;
GT_Key GT_Keys::center,		GT_Keys::option_center;
GT_Key GT_Keys::directed,	GT_Keys::option_directed;

GT_Key GT_Keys::type,		GT_Keys::option_type;
GT_Key GT_Keys::x,		GT_Keys::option_x;
GT_Key GT_Keys::y,		GT_Keys::option_y;
GT_Key GT_Keys::w,		GT_Keys::option_w;
GT_Key GT_Keys::h,		GT_Keys::option_h;

GT_Key GT_Keys::anchor,		GT_Keys::option_anchor;
GT_Key GT_Keys::arrow,		GT_Keys::option_arrow;
GT_Key GT_Keys::arrowshape,	GT_Keys::option_arrowshape;
GT_Key GT_Keys::background,	GT_Keys::option_background;
GT_Key GT_Keys::bitmap,		GT_Keys::option_bitmap;
GT_Key GT_Keys::capstyle,	GT_Keys::option_capstyle;
GT_Key GT_Keys::extent,		GT_Keys::option_extent;
GT_Key GT_Keys::fill,		GT_Keys::option_fill;
GT_Key GT_Keys::foreground,	GT_Keys::option_foreground;
GT_Key GT_Keys::image,		GT_Keys::option_image;
GT_Key GT_Keys::joinstyle,	GT_Keys::option_joinstyle;
GT_Key GT_Keys::justify,	GT_Keys::option_justify;
GT_Key GT_Keys::line,		GT_Keys::option_line;
GT_Key GT_Keys::outline,	GT_Keys::option_outline;
GT_Key GT_Keys::point,		GT_Keys::option_point;
GT_Key GT_Keys::smooth,		GT_Keys::option_smooth;
GT_Key GT_Keys::source,		GT_Keys::option_source;
GT_Key GT_Keys::splinesteps,	GT_Keys::option_splinesteps;
GT_Key GT_Keys::start,		GT_Keys::option_start;
GT_Key GT_Keys::stipple,	GT_Keys::option_stipple;
GT_Key GT_Keys::style,		GT_Keys::option_style;
GT_Key GT_Keys::target,		GT_Keys::option_target;
GT_Key GT_Keys::visible,	GT_Keys::option_visible;
GT_Key GT_Keys::width,		GT_Keys::option_width;
GT_Key GT_Keys::xfont,		GT_Keys::option_xfont;

GT_Key GT_Keys::edge_anchor,    GT_Keys::option_edge_anchor;
GT_Key GT_Keys::label_anchor,   GT_Keys::option_label_anchor;
	
GT_Key GT_Keys::anchor_center;
GT_Key GT_Keys::anchor_n;
GT_Key GT_Keys::anchor_ne;
GT_Key GT_Keys::anchor_e;
GT_Key GT_Keys::anchor_se;
GT_Key GT_Keys::anchor_s;
GT_Key GT_Keys::anchor_sw;
GT_Key GT_Keys::anchor_w;
GT_Key GT_Keys::anchor_nw;

GT_Key GT_Keys::anchor_first;
GT_Key GT_Keys::anchor_last;

GT_Key GT_Keys::anchor_clip;
GT_Key GT_Keys::anchor_corners;
GT_Key GT_Keys::anchor_middle;
GT_Key GT_Keys::anchor_8;

GT_Key GT_Keys::graph_attrs;
GT_Key GT_Keys::node_attrs;
GT_Key GT_Keys::edge_attrs;
GT_Key GT_Keys::graphics_center_x;
GT_Key GT_Keys::graphics_center_y;
GT_Key GT_Keys::graphics_w;
GT_Key GT_Keys::graphics_h;
GT_Key GT_Keys::graphics_image;


GT_Key GT_Keys::type_arc;
GT_Key GT_Keys::type_bitmap;
GT_Key GT_Keys::type_image;
GT_Key GT_Keys::type_line;
GT_Key GT_Keys::type_oval;
GT_Key GT_Keys::type_polygon;
GT_Key GT_Keys::type_rectangle;
GT_Key GT_Keys::type_text;


GT_Key GT_Keys::uiobject_unknown;
GT_Key GT_Keys::uiobject_node;
GT_Key GT_Keys::uiobject_edge;
GT_Key GT_Keys::uiobject_graph;
GT_Key GT_Keys::uiobject_label;
GT_Key GT_Keys::uiobject_node_label;
GT_Key GT_Keys::uiobject_edge_label;
GT_Key GT_Keys::uiobject_graph_label;

//
// Color names
//

GT_Key GT_Keys::white;
GT_Key GT_Keys::black;
GT_Key GT_Keys::red;
GT_Key GT_Keys::green;
GT_Key GT_Keys::blue;

//
// Actions
//

GT_Key GT_Keys::action_new_node;
GT_Key GT_Keys::action_new_edge;
GT_Key GT_Keys::action_del_node;
GT_Key GT_Keys::action_del_edge;
GT_Key GT_Keys::action_rev_edge;
GT_Key GT_Keys::action_clear;

GT_Keys::~GT_Keys()
{
}
