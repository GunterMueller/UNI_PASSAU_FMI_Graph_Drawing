//
// Error.cc
//
// This file implements the class GT_Error.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Error.cpp,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:42 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet Project
//
//

#include "Graphlet.h"
#include "Error.h"

GT_Error::GT_Error ()
{
    error_dict.insert(
	GT_Error::wrong_number_of_args, "Wrong number of arguments");
    error_dict.insert(
	GT_Error::wrong_keyword, "Wrong keyword");
    error_dict.insert(
	GT_Error::wrong_int_val, "Wrong integer value");
    error_dict.insert(
	GT_Error::wrong_double_val, "Wrong double value");
    error_dict.insert(
	GT_Error::wrong_id, "Wrong id");
    error_dict.insert(
	GT_Error::internal_error, "Internal error");
    error_dict.insert(
	GT_Error::no_id, "No such id");
    error_dict.insert(
	GT_Error::no_command, "No such command");	
    error_dict.insert(
	GT_Error::id_exists, "Identifier already exists");
    error_dict.insert(
	GT_Error::name_exists, "Name already exists");
    error_dict.insert(
	GT_Error::id_greater_zero, "Identifier must be greater zero");
    error_dict.insert(
	GT_Error::fileopen_error, "Cannot open file");
    error_dict.insert(
	GT_Error::no_graph, "No graph exists");
    error_dict.insert(
	GT_Error::no_filename, "No filename specified");
    error_dict.insert(
	GT_Error::no_canvas, "No such canvas specified");
}

GT_Error::~GT_Error ()
{
}

string GT_Error::msg (const int msg_id)
{
    dic_item it;
	
    it = error_dict.lookup (msg_id);
    assert (it != 0);
	
    return (error_dict.inf (it));
}

string GT_Error::msg (const int msg_id, const string& text)
{
    dic_item it;
    it = error_dict.lookup (msg_id);
    assert (it != 0);

    string s ("%s '%s'.",
	error_dict.inf(it).cstring(),
	text.cstring());
	
    return (s);
}

string GT_Error::msg (const int msg_id, const int number)
{
    dic_item it;
    it = error_dict.lookup (msg_id);
    assert (it != 0);

    string s ("%s '%d'.",
	error_dict.inf(it).cstring(),
	number);
	
    return (s);
}


