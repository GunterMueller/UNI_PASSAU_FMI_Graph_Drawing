#include "Graphlet.h"
#include "Keymapper.h"

#include <ctype.h> // isupper .

//
// Keymapper.cc
//
// This module defines the classes GT_Key_class and GT_Keymapper.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_base/Keymapper.cpp,v $
// $Author: himsolt $
// $Revision: 1.2 $
// $Date: 1996/10/25 16:41:54 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//
// (C) University of Passau 1995-1996, graphlet project
//


GT_CLASS_IMPLEMENTATION (GT_Key);
GT_CLASS_IMPLEMENTATION (GT_Key_class);
GT_CLASS_IMPLEMENTATION (GT_Keymapper);


//
// Class GT_Key
//

const string& GT_Key::name() const
{
    assert (the_key != 0);
    return the_key->name();
}

const bool GT_Key::active() const
{
    return defined() &&
	// 		(the_key != GT_Keys::none.the_key) &&
	// 		(the_key != GT_Keys::empty.the_key) &&
	(the_key != GT_Keys::def.the_key);
}


//
// Constructor for class GT_Keymapper
//

GT_Keymapper::GT_Keymapper() {
    the_count = 0;
    GT_Keys::init();
};


//
// Descructor for class GT_Keymapper
//

GT_Keymapper::~GT_Keymapper()
{
    ;
};



GT_Key GT_Keymapper::add (const string& s)
{
    dic_item it = keys.lookup (s);
	
    if (it != nil) {
        return keys.inf (it);
    } else {

	GT_Key new_key (new GT_Key_class(s));

	// Examine key
	if (s.length() > 0) {

	    char head = s[0];
	    new_key.description()->visible (head != '@');
	    new_key.description()->safe (
		!(('A' <= head) && (head <= 'Z')));
			
	    new_key.description()->ispath(head == '.');
	    if (head == '.') {
		new_key.description()->ispath (true);
		split (new_key, new_key.description()->the_path);
	    }
	}
		
        keys.insert (s, new_key);

        return new_key;
    }
};


void GT_Keymapper::split (const GT_Key key, list<GT_Key>& path)
{
    int start; // overread the first '.';
    int end;

    if (key.description()->ispath()) {
	start = 1;
    } else {
	start = 0;
    }
	
    const string& name = key.description()->name();
    while (start < name.length()) {
		
	end = name.pos ('.',start);
	if (end == -1) {
	    end = name.length() + 1; // virtual '.' at end of string
	}
		
	path.append (add (name(start,end-1)));

	start = end+1;
    }		
}



ostream& operator<< (ostream &out, const GT_Key_class& key)
{
    out << "Name: " << key.name() << endl;
    out << "visible: " << key.visible() << endl;
    out << "safe: " << key.safe() << endl;
    out << "ispath: " << key.ispath() << endl;
	
    if (key.ispath()) {
		
	out << "Path description ";
	GT_Key k;
	forall (k, key.path()) {
	    out  << " . " << k.name();
	}
	out << endl;
    }

    return out;
}

ostream& operator<< (ostream &out, const GT_Keymapper& keymapper)
{
    dic_item it;

    forall_items (it, keymapper.keys) {
	out << "Key: " << keymapper.keys.key(it) << endl;
	out << keymapper.keys.inf(it).description();
    }

    return out;
}


//
// The next two operators are neccessary for the new LEDA
//
// << outputs the name of the key.
// >> is a dummy.
//

ostream& operator<< (ostream &out, const GT_Key& key)
{
    assert (key.description() != nil);
    
    return out << *(key.description());
}


istream& operator>> (istream &in, const GT_Key& /* key */)
{
    // unused
    return in;
}
