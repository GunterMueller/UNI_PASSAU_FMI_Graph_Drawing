#ifndef LEDASH_H
#define LEDASH_H

// ----------------------------------------------------------------------
// ledash.h
//
// Headerfile for ledash.cc
//
// ---------------------------------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/graphscript/graphscript.h,v $
// $Author: himsolt $
// $Revision: 1.1.1.1 $
// $Date: 1996/10/24 17:40:33 $
// $Locker:  $
// $State: Exp $
// ----------------------------------------------------------------------
//
// (C) University of Passau 1995-1996, Graphlet Project
//

#define GT_ADD_MODULE(name)				\
extern int GT_##name##_init (Tcl_Interp* interp,	\
    GT_GraphScript* graphscript);				\
code = GT_##name##_init (interp, graphscript);		\
if (code == TCL_ERROR) {				\
    return code;					\
}

#endif
