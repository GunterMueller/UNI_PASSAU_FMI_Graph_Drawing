//
// ledash.cc
//
// This is a sample GraphScript main file. This file declares and
// implements a sample layout algorithm and creates a GraphScript
// interpreter.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/graphscript/graphscript.cpp,v $
// $Author: himsolt $
// $Revision: 1.4 $
// $Date: 1996/10/31 18:12:12 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

#include <gt_base/Graphlet.h>
#include <gt_base/config.h>

#include <gt_tcl/Tcl.h>
#include <gt_tcl/GraphScript.h>
#include <tk.h>

#include "graphscript.h"

//////////////////////////////////////////
//
// static int application_init (Tcl_Interp *interp)
//
//
// This is a sample Tk application initialization procedure.
//
//////////////////////////////////////////

static int application_init (Tcl_Interp *interp)
{
    //
    // Create a GraphScript handler. For customization, initialize
    // graphscript with a derived class.
    //

    GT_GraphScript* graphscript = new GT_GraphScript (interp);

    //
    // Initialize Tcl, Tk and GraphScript
    //
    int code = graphscript->application_init (interp);
    if (code == TCL_ERROR) {
	return code;
    }

#ifdef GT_MODULE_GT_ALGORITHMS
    GT_ADD_MODULE(gt_algorithms)
#endif

#ifdef GT_MODULE_GT_LSD
    GT_ADD_MODULE(gt_lsd)
#endif
    
#ifdef GT_MODULE_GT_GRID_ALGORITHMS
    GT_ADD_MODULE(gt_grid_algorithms)
#endif
    
    //
    // Add your own initializations and commands here if neccessary
    //

    //
    // We are finished for now.
    //
	
    return code;
}


//
// This is the (minimum) main program.
//


int main (int argc, char **argv) 
{
    return GT_GraphScript::main (argc, argv,
	application_init);
}
