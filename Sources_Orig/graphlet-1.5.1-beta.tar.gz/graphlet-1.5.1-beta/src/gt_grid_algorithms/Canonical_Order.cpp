//
// Canonical_Order.cpp
//
// This file implements the Canonical_Order class.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/grid_algorithms/
//	Canonical_Order.cpp,v $
// $Author: himsolt $
// $Revision: 1.4 $
// $Date: 1996/11/09 18:28:37 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//


#include "Canonical_Order.h"
#include <LEDA/edge_array.h>
#include <LEDA/face_array.h>
#include <LEDA/b_stack.h>


//
// I/O Operators for struct nd as required by LEDA 3.4 (dummy only)
//


ostream& operator<< (ostream& out, nd)
{
	return out;
}

istream& operator>> (istream& in, nd)
{
	return in;
}


Canonical_Order::Canonical_Order (Undirected_Graph &g,
	Canonical_Order_Type co_type,
	bool max_outer,	bool prefer_nodes)
{
	list<Order_Set> c_order;

	switch (co_type) {
	case CO_TRICONNECTED:
		comp_tric_co (g, c_order, max_outer, prefer_nodes);
		break;
	case CO_BICONNECTED:
		comp_bic_co (g, c_order, max_outer, prefer_nodes);
		break;
	}

	int i, m = c_order.length();
	list_item it;
	V = array<Order_Set> (1, m);

	i = 1;
	forall_items (it, c_order) {
		V[i++] = c_order[it];
	}

	init_rank (g);
}


Lmc_Order::Lmc_Order (Undirected_Graph &g, Canonical_Order_Type co_type,
	bool max_outer, bool prefer_nodes)
{
	list<Order_Set> c_order;

	switch (co_type) {
	case CO_TRICONNECTED:
		comp_tric_co (g, c_order, max_outer, prefer_nodes);
		break;
	case CO_BICONNECTED:
	  comp_bic_co (g, c_order, max_outer, prefer_nodes);
		break;
	}

	node_array< list<Order_Set *> > cr_sets (g);
	b_stack<node>	Outerface_Stack (g.number_of_nodes());

	list_item it;
	node	  cr;
	int 	  i, j, m = c_order.length();

	V = array<Order_Set> (1, m);
	forall_items (it, c_order) {
		cr = c_order [it].right();
		if (cr != nil)
			cr_sets [cr].append (& c_order [it]);
	}
	Order_Set &V1 = c_order [c_order.first()];
	Outerface_Stack.push (V1 [2]);

	V [1] = V1;

	i = 2;
	while (!Outerface_Stack.empty()) {
		cr = Outerface_Stack.top();
		if (cr_sets [cr].empty())
			Outerface_Stack.pop();
		else {
			V [i] = *(cr_sets [cr].pop());
			for (j = len(i); j >= 1; j--)
				Outerface_Stack.push ( (V[i])[j] );
			i++;
		}
	}

	init_rank (g);
}


void Canonical_Order::init_rank (Undirected_Graph& g)
{
	int i, j;

	the_rank.init (g);

	for (i = 1; i <= length(); i++) {
		for (j = 1; j <= V[i].len(); j++) {
			the_rank [(V[i])[j]] = i;
		}
	}
}

//////////////////////////////////////////////////////////////////////////////
// Die Klasse CompOrder unterst�tzt die Berechnung der kanonoschen Ordnung
// Sie enth�lt die Felder sepf und visited, sowie die Listen der m�glichen
// Knoten bzw. Kanten. Au�erdem unterst�tzt sie das Erh�hen, Erniedrigen, und
// Aktualisieren der Variablen sepf, visited, outv, oute

class CompOrder {
public:
	// Konstruktor
	CompOrder (Undirected_Graph &G, bool pref_nodes) {
		prefer_nodes = pref_nodes;
		g = &G;
		// Initialisierung der Felder
		visited    .init (G, 0);
		sepf       .init (G, 0);
		v_update   .init (G, false);
		v_link     .init (G, nil);
		outv       .init (G, 0);
		oute       .init (G, 0);
		f_link     .init (G, nil);
		is_sep_face.init (G, false);
		f_update   .init (G, false);
		outer_nodes.init (G);
	}
	~CompOrder () // Destruktor (nichts zu tun)
		{ }

	void init_outer_nodes (face F_out, node v1, node v2);
	void init_outer_edges (face F_out, edge e_2_1);
	// Initialisierung der possible-Listen: vn einziger m�glicher Knoten
	void init_possible (node vn) {
		v_link [vn] = possible_nodes.append (vn);
	}
	// Gibt es noch m�gliche Knoten oder Kanten ?
	bool is_possible () {
		return !(possible_nodes.empty() && possible_faces.empty());
	}
	// Ist beim letzten Aufruf von get_next_possible ein Knoten ausgew�hlt
	// worden ? (sonst Fl�che)
	bool is_node () {
		return next_is_node;
	}
	// Testet, ob F nur noch eine Kante (u,w) an der Au�enfl�che besitzt und
	// damit keine Seperationsfl�che mehr ist
	bool is_only_edge (face f) {
		return (outv [f] == 2 && oute [f] == 1);
	}
	// Bestimme n�chsten Knoten oder n�chste Fl�che (siehe auch is_node() oben)
	void get_next_possible (node &vk, face &Fk) {
		// Falls Knoten und Fl�chen m�glich, werden Fl�chen bevorzugt
		if (possible_nodes.empty() || (!possible_faces.empty() &&
			prefer_nodes == false))
		{
			next_is_node = false;
			Fk = possible_faces.pop ();
		} else {
			next_is_node = true;
			vk = possible_nodes.pop ();
		}
	}
	void add_outer_node (node v, face f) {
		inc_outv (f);
		outer_nodes[f].append (v);
		if (is_sep_face[f]) sepf [v] ++;
	}
	// Erh�he visited[v]
	void inc_visited (node v) {
		visited [v] ++;
		set_update (v);
	}
	// Erh�he sepf[v]
	void inc_sepf (node v) {
		sepf [v] ++;
		set_update (v);
	}
	// Erniedrige sepf[v]
	void dec_sepf (node v) {
		sepf [v] --;
		set_update (v);
	}
	// Erh�he outv[f]
	void inc_outv (face f) {
		outv [f] ++;
		set_update (f);
	}
	// Erh�he oute[f]
	void inc_oute (face f) {
		oute [f] ++;
		set_update (f);
	}
	node get_outer_deg_2 (face f, Undirected_Graph &G,
		node_array<edge> &e_pred, node_array<edge> &e_succ);

	int get_outv (face f) {
		return outv [f];
	}

	void do_update ();

private:
	void set_update (node v);
	void set_update (face f);

	node_array<int>			visited, sepf;
	node_array<list_item>	v_link;           // link[v] ist das Item in possible_nodes, das v enth�lt, falls

	face_array<int>			outv, oute;
	face_array<list_item>	f_link;
	face_array<bool>		is_sep_face, f_update;
	face_array<list<node> > outer_nodes;
														 // v in possible_nodes ist, sonst nil
	list<node>	possible_nodes; // alle Knoten, die im n�chsten Schritt weggenommen werden k�nnen
	list<face>	possible_faces; // alle Fl�chen,                     - " -

	node_array<bool>	v_update;     // update[v] = true <=> v in Liste update_nodes
	list<node>			update_nodes; // enth�lt alle Knoten, deren Variablen im aktuellen Schritt ver�ndert wurden
	list<face>			update_faces; //      - " -   Fl�chen,                       - " -
	bool				next_is_node; // wurde im aktuellen Schritt ein Knoten ausgew�hlt ?
	node				v1, v2;       // vorgegebene v1, v2 (beiden untern Knoten des Layout)

	Undirected_Graph *g;
	bool prefer_nodes;
};

// Bestimme Knoten v der Fl�che f, der an die Au�enfl�che grenzt und im aktuellen Teilgraph den Grad 2
// besitzt (v != v2, oder v = v1)
node CompOrder::get_outer_deg_2 (face f, Undirected_Graph &G,
	node_array<edge> &e_pred, node_array<edge> &e_succ)
// die Felder e_pred und e_succ bestimmen die Verkettung der Knoten auf der Au�enfl�che
{
	list<node> &L = outer_nodes [f];
	list_item it;
	node v;

	forall_items (it, L) {
		v = L[it];
		if (v == v2) continue;
		if (v == v1) return v;
		// Hat v Grad 2 ? (da keine Knoten in G gel�scht werden, kann nicht getestet werden, ob deg(v) = 2 ist)
		if (e_pred[v] == G.cyclic_adj_pred(e_succ[v]))
			return v;
		}
	//cerr << "Kein Knoten mit Grad 2 in f->outer_nodes!"; // Dieser Fehler sollte nicht vorkommen!
	return nil;
}

// Initialisiere Knoten der Au�enflache, initialisere v1, v2
void CompOrder::init_outer_nodes (face F_out, node v1_ini, node v2_ini)
{
	node v;
	edge e, e2;
	face f;

	v1 = v1_ini; v2 = v2_ini;
	// F�r alle v in F_out erh�he outv[f] f�r alle f != F_out mit v in f
	forall_face_edges (e, F_out) {
		v = g->source(e);
		forall_out_edges (e2, v) {
			f = g->face_of(e2);
			if (f != F_out) {
				outv [f] ++;
				outer_nodes[f].append (v); // aktualisiere f->outer_nodes
			}
		}
	}
}

// Initialisere Kanten der Au�enfl�che
void CompOrder::init_outer_edges (face F_out, edge e_2_1)
{
	edge e;

	// F�r alle e in F_out mit e != (v1,v2) erh�he oute[f] f�r alle f != F_out mit e in f
	forall_face_edges (e, F_out)
		if (e != e_2_1) {
			oute [g->face_of(g->reversal(e))] ++;
		}

}

// Falls v noch nicht in update-Liste, f�ge v in update-Liste ein
void CompOrder::set_update (node v)
{
	if (v_update [v] == false) {
		update_nodes.append (v);
		v_update [v] = true;
	}
}

// Falls f noch nicht in update-Liste, f�ge f in update-Liste ein
void CompOrder::set_update (face f)
{
	if (f_update [f] == false) {
		update_faces.append (f);
		f_update [f] = true;
	}
}

// Fuhre Update durch: Teste, ob
//		a) v bzw. f nach dem aktuellen Schritt in  die possible Liste genommen werden mu�
//		b) v bzw. f nach dem aktuellen Schritt aus der possible Liste genommen werden mu�
//		c) f im aktuellen Schritt zur Seperations-Fl�che geworden ist
void CompOrder::do_update ()
{
	bool can_take, is_sep;
	node v;
	face f;

	// Test f�r Fl�chen mu� zuerst gemacht werden, Variablen von Knoten ge�ndert werden k�nnen!
	while (!update_faces.empty()) {
		f = update_faces.pop ();
		f_update [f] = false;
		can_take = (outv[f] == oute[f] + 1 && oute[f] >= 2);	// ist f m�gliche Kante ?
		if (f_link[f] == nil) {  // ist f noch nicht in possible-Liste
			if (can_take) f_link[f] = possible_faces.append (f);  // eventuell einf�gen
		} else
			if (!can_take) {  // eventuell wieder herausnehmen
				possible_faces.del_item (f_link[f]);
				f_link[f] = nil;
			}
		is_sep = (outv[f] >= 3 || (outv[f] == 2 && oute[f] == 0));  // is f Seperations-Fl�che ?
		if (is_sep_face[f] == false) {  // f war vor diesem Schritt noch keine Sep.-Fl�che
			if (is_sep == true) {  // und ist jetzt eine geworden
				is_sep_face [f] = true;
				forall (v, outer_nodes[f])  // erh�he sepf[v] f�r alle v in f der Au�enfl�che
					inc_sepf (v);
			}
		} else  // Falls jetzt keine mehr, dann nur is_sep_face korrigieren, der Rest (ernidrigen von sepf) wurde
			if (is_sep == false) is_sep_face [f] = false;  // schon in canonical_order() erledigt
	}

	while (!update_nodes.empty()) {
		v = update_nodes.pop ();
		v_update [v] = false;
		can_take = (visited [v] >= 1 && sepf [v] == 0 && v != v1 && v != v2); // ist v m�glicher Knoten ? (vermeide,
																									 // v1 und v2 zu nehemn)
		if (v_link [v] == nil) {  // ist v noch nicht in possible-Liste
			if (can_take) v_link [v] = possible_nodes.append (v);  // eventuell einf�gen
		} else
			if (!can_take) {  // eventuell wieder herausnehmen
				possible_nodes.del_item (v_link [v]);
				v_link [v] = nil;
			}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Berechnung der kanonischen Ordnung f�r dreizusammenh�ngende Graphen (Kant)

void Canonical_Order::comp_tric_co (Undirected_Graph &G, list<Order_Set> &c_order,
	bool max_outer, bool prefer_nodes)
{
	node_array<edge>	e_pred (G), // F�r Au�enfl�che c_1,...,c_q ist e_pred[c_i] = (c_i,c_i-1)
						e_succ (G); //   e_succ[c_i] = (c_i,c_i+1)

	face F_out;			// Au�enfl�che
	node v1, v2, vn;	// entsprechende Knoten der kan. Ordnung
	edge e_2_1;			// Kante (v2,v1)

	node		vk, u, cl, cr;
	edge		e, e2;
	face		f, Fk;
	Order_Set	V(1);

	// Berechne alle Fl�chen von G (Initialisierung der Variablen der Fl�chen im Konstruktor von FACE_STRUCT)
	G.compute_faces();
	F_out = G.max_face();
	if (F_out == nil) return;

	// Definition eines Objektes der Hifsklasse CompOrder (Aufruf des Konstruktors)
	CompOrder	cpo (G, prefer_nodes);

	if (max_outer == false)
		F_out = G.first_face(); //&all_faces[all_faces.first()];

	// Bestimme v1, v2, vn, e_2_1 = (v2,v1)
	e     = G.first_face_edge (F_out);
	v1	  = G.source (e);
	vn	  = G.target (e);
	e_2_1 = G.face_cycle_pred (e);
	v2	  = G.source (e_2_1);

	// Initialisierung von e_pred und e_succ f�r Au�enfl�che von G
	while (G.target(e) != v1) {
		e_succ [G.source(e)] = e;
		e_pred [G.target(e)] = G.rev(e);
		e = G.face_cycle_succ (e);
	}
	e_pred [v1] = e_succ [v2] = nil;

	// Aktualisiere outv, oute
	cpo.init_outer_nodes (F_out, v1, v2);
	cpo.init_outer_edges (F_out, e_2_1);

	// einziger m�glicher Knoten ist anfangs vn
	cpo.init_possible (vn);

	// For k := K downto 2
	while (cpo.is_possible()) {
		// W�hle n�chsten m�glichen Knoten oder Fl�che
		cpo.get_next_possible (vk, Fk);
		if (cpo.is_node ()) {  // Falls Knoten
			V = Order_Set (1);  // Erzeuge V-Menge mit einem Element {vk}
			V.left  (cl = G.target (e_pred [vk]));   // left- und rightvertex
			V.right (cr = G.target (e_succ [vk]));
			V [1] = vk;
			c_order.push (V);   // F�ge die neue Menge am Anfang der c_order-Liste ein
		} else {  // Falls Fl�che
			V = Order_Set (cpo.get_outv(Fk)-2);  // Erzeuge V-Menge {z1,...,zl} mit l = outv[Fk]-2 (cl und cr bleiben)
			// Bestimme Anfang und Ende der Kette (cl,cr) :
			// Suche bel. Knoten mit Grad 2 von Fk auf Ck und wandere nach links, solange Grad = 2
			cl = cpo.get_outer_deg_2 (Fk, G, e_pred, e_succ);
			while (cl != v1 && e_pred[cl] == G.cyclic_adj_pred(e_succ[cl]))
				cl = G.target(e_pred[cl]);
			cr = G.target(e_succ[cl]);
			int i = 1;
			// Wandere von cl �ber Knoten vom Grad 2 nach rechts bis zu Knoten mit Grad > 2 (= cr)
			while (cr != v2 && e_pred[cr] == G.cyclic_adj_pred(e_succ[cr])) {
				V [i++] = cr;        // trage Knoten (mit Grad 2) in V_Menge ein
				cr = G.target(e_succ[cr]);
			}
			// Eniedrige sepf f�r die beiden Knoten cl, cr, die auf der Au�enfl�che bleiben (da Fk Sep.-Fl�che war)
			cpo.dec_sepf (cl); cpo.dec_sepf (cr);
			V.left  (cl);
			V.right (cr);
			c_order.push (V);   // F�ge die neue Menge am Anfang der c_order-Liste ein
		}
		// Aktualisiere e_succ[cl] und e_pred[cr]
		e_succ [cl] = G.cyclic_adj_pred (e_succ [cl]);
		e_pred [cr] = G.cyclic_adj_succ (e_pred [cr]);
		// Durchlaufe alle Knoten u auf C_k-1 zwischen cl und cr
		cpo.inc_oute (G.face_of(e_pred [cr]));	// (Diese Kante wird in unterer Schleife nicht betrachtet)
		cpo.inc_visited (cl);  // da cl und cr Nachbar in Vk haben, erh�he visited
		cpo.inc_visited (cr);
		e = e_succ [cl];
		for (u = G.target (e); u != cr; u = G.target (e)) {
			// F�r neue Kante auf Au�enfl�che erh�he oute
			cpo.inc_oute (G.face_of(G.rev(e)));

			e_pred [u] = G.rev (e);
			e = G.face_cycle_succ (e);

			if (G.target (e) == vk) {   // Falls Kante von vk nach u
				cpo.inc_visited (u);     // dann erh�he visited[u]
				e = G.cyclic_adj_pred (e);
			}
			e_succ [u] = e;

			for (e2 = e_pred[u]; e2 != e_succ[u]; e2 = G.cyclic_adj_succ (e2)) {
				// aktualisiere outv[f], outer_nodes[f], sepf[v]
				f = G.face_of(e2);
				cpo.add_outer_node (u, f);
			}

		}
		if (!cpo.is_node())
			// Falls (cl,cr) in G ist, dann F' sei andere Fl�che von (cl,cr)
			// Teste ob (cl,cr) einzige Kante von F' auf der Au�enfl�che ist
			if (G.target (e_succ [cl]) == cr &&
				cpo.is_only_edge (G.face_of(G.rev(e_succ [cl]))))
			{
				cpo.dec_sepf (cl); cpo.dec_sepf (cr);  // dann erniedrige sepf[cl] und sepf[cr] nochmals
			}
		cpo.do_update ();  // F�hre Update durch
	}
	V = Order_Set (2);   // Trage noch Menge V1 = {v1,v2} nach
	V [1] = v1;
	V [2] = v2;
	c_order.push (V);
}


///////////////////////////////////////////////////////////////////////////////

struct face_item {
	face_item ()
		{ f = nil; it = nil; }
	face_item (face f_ini, list_item it_ini)
		{ f = f_ini; it = it_ini; }
	face f;
	list_item it;
};

//
// I/O Operators for struct face_item as required by LEDA 3.4 (dummy only)
//


ostream& operator<< (ostream& out, face_item)
{
	return out;
}

istream& operator>> (istream& in, face_item)
{
	return in;
}


enum NT { type_face, type_node, type_edge };

#define INIT_VAR(x,var,val) \
   var[x] = (val);               \
   set_update(x);

#define DEC_VAR(x,var)      \
   var[x] --;                    \
   set_update(x);

#define INC_VAR(x,var)      \
   var[x] ++;                    \
   set_update(x);

class CompOrder2 {
public:
	CompOrder2 (Undirected_Graph &G, bool max_outer);

	face F_out()
		{ return Fout; }
	face left (edge e)
		{ return g->face_of(e); }
	face right (edge e)
		{ return g->face_of(g->reversal(e)); }
	face right (node v) {
		return left(next_succ[v]);
	}
	face left (node v) {
		return right(prev_pred[v]);
	}
	int virte (node v);
	node next (node v) {
		return the_next[v];
	}
	node prev (node v) {
		return the_prev[v];
	}
	bool cutv (face f)
		{ return (virt_src [f] != nil); }

	bool is_poss_face (face f) {
		return (f != F_out() && outv[f] >= 3 && outv[f] == oute[f]+1);
	}
	bool is_poss_node (node v) {  // Vorbed.: v auf C_k'
		return (v != v1 && v != v2 && cutf[v] <= 1 &&
			cutf[v] == virte(v) && numsf[v] == 0 && deg[v] >= 3);
	}
	bool is_poss_virt (node v) {  // Vorbed.: v auf C_k'
		return virt_edge[v] && ((deg[v] == 2 && v != v1) || (deg[next(v)] == 2 && next(v) != v2));
	}

	bool get_possible();
	NT next_poss()
		{ return next_type; }

	void set_V1 (Order_Set &V) {
		V [1] = v1;
		V [2] = v2;
	}
	void init_possibles();
	void remove_next_face (Order_Set &V);
	void remove_next_node (Order_Set &V);
	void remove_next_virt (Order_Set &V);

	void do_update();

private:
	void edge_to_contour (edge e);
	void virt_to_contour (node v, node w, edge e_n_s, edge e_p_p);
	void virt_to_contour (node v, node w);

	void mark (node v, bool val);
	node get_face_cl(face f);
	void set_outv (node v);
	void set_seqp (node cl, node cr);
	void del_outer_node(node v);
	void dec_seqp(node v);
	void put_on_outer (node v, face f);
	void del_outer_ref (face f);
	void get_adj_faces (node v, list<face>& L);
	void get_adj_nodes (node v, list<node>& L);

	void set_update (face f);
	void set_update (node v);

	Undirected_Graph *g;
	face Fout;
	node v1, v2;
	edge e21;

	NT next_type;
	face next_f;
	node next_v;
	node next_e;

	// Variablen der Knoten
	node_array<int>       deg;      // Grad von v in G_k'
	node_array<int>       cutf;     // Anzahl Fl�chen von v mit cutv(F)=true
	node_array<int>       numsf;    // Anzahl Fl�chen F von v mit outv(F)>seqp(F)+1
	node_array<bool>      on_outer; // true <=> v auf C_k'

	node_array<list_item> v_link;	// Item in poss_nodes, das v enth�lt, bzw. nil
	node_array<list_item> link_virt;
	node_array<bool>	v_update;
	node_array<list<face_item> > in_out_nodes;

	//Variablen der Flaechen
	face_array<int>		outv,		// Anzahl Knoten von F auf C_k'
						oute,		// Anzahl Kanten von F auf C_k'
						seqp;		// Anzahl aufeinanderfolgender Paare c_i,c_i+1 von F
	face_array<node>	virt_src;	// falls F virt. Kante e enth�lt, dann source(e), sonst nil
	face_array<list_item>	f_link;	// link ist das Item in possible_faces, das diese Fl�che enth�lt,
									// falls sie in possible_faces ist, sonst nil
	face_array<bool>	f_update;
	face_array<bool>    f_mark;		// markieren bei Berechnung von seqp
	face_array<bool>    is_sf;		// true <=> outv(F) < seqp(F)+1
	face_array<list<nd> > outer_nodes;	// Liste aller Knoten diesr Face auf der Au�enfl�che

	// Darstellung der Aussenflaeche
	node_array<node>	the_next, the_prev;
	node_array<edge>	next_succ, prev_pred;
	node_array<bool>	virt_edge;	// virt_edge[c_i] = true <=> (c_i,c_i+1) virtuelle Kante

	// Listen der m�glichen Fl�chen, Knoten und Kanten
	list<face>     poss_faces;    // Fl�chen mit outv(F)>= 3 und outv(F)=oute(F)+1
	list<node>     poss_nodes;    // Knoten mit cutf(v) <= 1, cutf(v) = virte(v), numsf(v)=0 und deg(v)>= 3
	list<node>     poss_virt;     // Knoten v bezeichne virtuelle Kante e = (v,next[v]), die erf�llt:
								 // (deg[v]=2 und v!=v1) oder (deg[next[v]]=2 und next[v]!=v2)
	list<node>     update_nodes;
	list<face>     update_faces;
	list<edge>     rem_edges;
};

void CompOrder2::edge_to_contour (edge e)
{
	node v = g->source(e), w = g->target(e);

	the_next  [v] = w;
	the_prev  [w] = v;
	next_succ [v] = g->cyclic_adj_pred(e);
	prev_pred [w] = g->cyclic_adj_succ(g->reversal(e));
	virt_edge [v] = false;
}

void CompOrder2::virt_to_contour (node v, node w, edge e_n_s, edge e_p_p)
{
	the_next  [v] = w;
	the_prev  [w] = v;
	next_succ [v] = e_n_s;
	prev_pred [w] = e_p_p;
	virt_edge [v] = true;
}

void CompOrder2::virt_to_contour (node v, node w)
{
	the_next  [v] = w;
	the_prev  [w] = v;
	virt_edge [v] = true;
}

void CompOrder2::put_on_outer (node v, face f)
{
	list_item it;

	it = outer_nodes[f].append (nd(v));
	(outer_nodes[f])[it].it = in_out_nodes[v].append(face_item(f, it));
}

void CompOrder2::del_outer_ref (face f)
{
	list<nd> &L = outer_nodes[f];
	nd x;

	while (!L.empty()) {
		x = L.pop();
		in_out_nodes[x.v].del_item(x.it);
	}
}

int CompOrder2::virte (node v) {
	int num = 0;

	if (on_outer[v] == true) {
		if (virt_edge[v] == true) num++;
		if (v != v1 && virt_edge[prev(v)] == true) num++;
	}
	return num;
}

void print_v1_v2 (graph& G, node v1, node v2)
{
  node v;
  int i = 1;
  node_array<int> id(G);

  forall_nodes (v, G) id[v] = i++;

  cerr << "v1 = " << id[v1] << " v2 = " << id[v2] << "\n";
}

CompOrder2::CompOrder2 (Undirected_Graph &G, bool max_outer)
{
	node v, w;
	edge e, e2;
	face f;

	g = &G;
	v_link  .init(G, nil);
	link_virt.init (G, nil);

	G.compute_faces();
	Fout = (max_outer) ? G.max_face() : G.first_face();
	e21  = G.first_face_edge(F_out());
	v1   = G.target(e21);
	v2   = G.source(e21);
	print_v1_v2 (G, v1, v2);

	deg      	.init (G);
	cutf     	.init (G, 0);
	numsf    	.init (G, 0);
	on_outer 	.init (G, false);
	the_next    .init (G);
	the_prev    .init (G);
	next_succ   .init (G);
	prev_pred   .init (G);
	virt_edge	.init (G, false);
	v_update   	.init (G, false);
	in_out_nodes.init (G);
	outv        .init (G, 0);
	oute        .init (G, 0);
	seqp        .init (G, 0);
	virt_src    .init (G, nil);
	f_link      .init (G, nil);
	f_update    .init (G, false);
	f_mark      .init (G, false);
	is_sf       .init (G, false);
	outer_nodes .init (G);

	forall_nodes(v, G)
		deg[v] = G.outdeg(v);

	forall_face_edges (e, F_out()) {
		if (e != e21) oute [right(e)]++;
		v = G.source(e);
		forall_out_edges (e2, v) {
			f = left(e2);
			if (f != Fout) {
				outv [f]++;
				put_on_outer (v, f);
			}
		}
	}

	on_outer [v1] = true;
	prev_pred[v1] = next_succ[v2] = nil;
	the_prev[v1] = the_next[v2] = nil;
	for (e = G.face_cycle_succ(e21); e != e21; e = G.face_cycle_succ(e)) {
		v = G.source(e); w = G.target(e);
		on_outer [w] = true;
		edge_to_contour (e);
		mark (v, true);
		forall_out_edges (e2, w) {
			f = left(e2);
			if (f_mark [f] == true) seqp[f]++;
		}
		mark (v, false);
	}

	for (v = v1; v != nil; v = next(v))
		forall_out_edges (e, v) {
			f = left(e);
			if ((is_sf [f] = (outv[f] > seqp[f]+1)) == true) numsf[v]++;
		}
}

void CompOrder2::init_possibles()
{
	node v;
	face f;

	forall_faces (f, (*g)) {
		if (is_poss_face(f))
			f_link [f] = poss_faces.append(f);
	}
	for (v = next(v1); v != v2; v = next(v))
		if (is_poss_node(v))
			v_link [v] = poss_nodes.append(v);
}

bool CompOrder2::get_possible()
{
	if (!poss_faces.empty()) {
		next_type = type_face;
		next_f = poss_faces.pop();
		return true;
	} else if (!poss_nodes.empty()) {
		next_type = type_node;
		next_v = poss_nodes.pop();
		return true;
	} else if (!poss_virt.empty()) {
		next_type = type_edge;
		next_e = poss_virt.pop();
		link_virt[next_e] = nil;
		return true;
	} else return false;
}

void CompOrder2::mark (node v, bool val)
{
	face f;
	list<face> L;

	get_adj_faces (v, L);
	forall (f, L)
		f_mark [f] = val;
}

node CompOrder2::get_face_cl(face f)
{
	node v;
	edge e;

	if (cutv (f)) {
		v = virt_src [f];
	}
	else {
		forall_face_edges (e, f)
			if (on_outer[v = g->source(e)] == true && deg[v] == 2) break;
	}
	while (v != v1 && deg[v] == 2) v = prev(v);
	return v;
}

void CompOrder2::get_adj_faces (node v, list<face>& L)
{
	edge e,
	  e_start = (v != v1) ? prev_pred[v] : g->cyclic_adj_succ(g->reversal(e21)),
	  e_end   = (v != v2) ? next_succ[v] : g->cyclic_adj_pred(e21);

	L.clear();
	L.append (right(e_start));
	if (deg[v] >= 3) {
		for (e = e_start; e != e_end; e = g->cyclic_adj_succ(e))
			L.append (left(e));

		L.append (left(e_end));
	}
}

void CompOrder2::get_adj_nodes (node v, list<node>& L)
{
	edge e,
	  e_start = (v != v1) ? prev_pred[v] : g->cyclic_adj_succ(g->reversal(e21)),
	  e_end   = (v != v2) ? next_succ[v] : g->cyclic_adj_pred(e21);

	L.clear();
	L.append ((v != v1) ? prev(v) : v2);

	if (deg[v] >= 3) {
		for (e = e_start; e != e_end; e = g->cyclic_adj_succ(e))
			L.append (g->target(e));
		L.append (g->target(e_end));
	}
	L.append ((v != v2) ? next(v) : v1);
}

void CompOrder2::remove_next_face (Order_Set &V)
{
	node cl = get_face_cl(next_f), cr, v;
	edge e;
	int i;

	// Berechnung der order2_set-Menge
	V = Order_Set (outv[next_f]-2);
	V.left (cl);
	for (i = 1, cr = next(cl); cr != v2 && deg[cr] == 2; i++, cr = next(cr))
		V [i] = cr ;
	V.right (cr);
	V.has_left (!virt_edge[cl]);
	V.has_right (!virt_edge[prev(cr)]);

	if (cutv(next_f) && next(virt_src [next_f]) == cr)
		set_update(cr);

	// aktualisieren der Knoten und Fl�chen-Variablen
	if (cutv(next_f)) {
		DEC_VAR(cl,cutf)
		DEC_VAR(cr,cutf)
		v = virt_src [next_f];
		if (v != cr) {
			poss_virt.del_item(link_virt[v]);
			link_virt[v] = nil;
		}
	}
	e = next_succ[cl];
	while (true) {
		edge_to_contour(e);

		if (g->target(e) == cr)
			break;
		else {
			INIT_VAR(g->target(e),on_outer,true)
		}

		e = g->face_cycle_succ(e);
	}
	DEC_VAR (cl,deg)
	DEC_VAR (cr,deg)

	for (v = cl; v != cr; v = next(v)) {
		INC_VAR(right(v),oute)
		if (v != cl)
			set_outv (v);
	}

	set_seqp (cl, cr);

	// falls virtuelle Kante wegf�llt, dann l�sche diese wieder
	if (cutv(next_f)) {
		if (virt_src [next_f] == cl) {
			set_update(cl);
			virt_edge [cl] = false;
		}
		virt_src [next_f] = nil;
	}
	del_outer_ref(next_f);
}

void CompOrder2::remove_next_node (Order_Set &V)
{
	node v, w, v_virt = nil, cl, cr;
	nd u;
	edge e, e2;
	face f, f_virt = nil;
	list<node> neighb;

	cl = prev (next_v); cr = next (next_v);

	// Berechnung der order2_set-Menge
	V = Order_Set(1);
	V [1] = next_v;
	V.left  ((virt_edge[prev(next_v)] == true) ? g->target(prev_pred[next_v]) :
		prev(next_v));
	V.right ((virt_edge[next_v] == true) ? g->target(next_succ[next_v]) :
		next(next_v));

	if (virt_edge[prev(next_v)]) {
		INIT_VAR(prev(next_v), virt_edge, false)
		v_virt = cl;
		f_virt = left(next_v);
		virt_src [f_virt] = nil;
	}
	if (virt_edge[next_v]) {
		if (link_virt[next_v] != nil) {
			poss_virt.del_item(link_virt[next_v]);
			link_virt[next_v] = nil;
		}
		v_virt = cr;
		f_virt = right(next_v);
		virt_src [f_virt] = nil;
	}

	list<face> L;
	get_adj_faces (next_v, L);
	forall (f, L) {
		outv [f]--;
	}
	list<node> L_v;
	get_adj_nodes(next_v, L_v);

	del_outer_node(next_v);
	oute [left (next_v)]--;
	oute [right(next_v)]--;
	dec_seqp (next_v);

	forall (w, L_v) {
		on_outer [w] = true;
		DEC_VAR (w, deg)
	}

	L_v.pop();
	bool first_time = true;
	forall (w, L_v) {

		if (first_time == true) {
			e2 = next_succ [prev(next_v)];
			e = prev_pred[next_v];
			first_time = false;
		} else {
			e2 = g->face_cycle_succ (e);
			e = g->cyclic_adj_succ(e);
		}

		while (true) {
			v = g->target(e2);

			if (v != w && on_outer[v] == true) {
				f = left(e2);

				// neue virtuelle Kante einf�gen
				virt_to_contour(g->source(e2), w, e2, (w == next(next_v)) ?
					prev_pred[w] : g->cyclic_adj_succ(g->reversal(e)));

				set_update(f);

				INC_VAR(g->source(e2),deg)
				INC_VAR(w,deg)

				if (f != f_virt) {
					forall(u, outer_nodes[f]) {
						INC_VAR(u.v, cutf);
					}
				}
				virt_src [f] = g->source(e2);

				break;
			}

			edge_to_contour(e2);

			if (v == w) {
				del_outer_ref (left(e2));
				break;
			}
			INIT_VAR(v,on_outer,true)
			if (g->source(e2) == cl) {
				list_item it;
				list<nd> &L = outer_nodes[left(e2)];
				forall_items (it, L)
					if (L[it].v == cl) {
						in_out_nodes[cl].del_item (L[it].it);
						L.del_item(it);
						break;
					}
				outv [left(e2)]--;
			}
			e2 = g->face_cycle_succ(e2);
		}

	}

	for (v = cl; v != cr; v = next(v)) {
		INC_VAR(right(v),oute)
		if (v != cl)
			set_outv (v);
	}

	set_seqp (cl,cr);

	if (v_virt != nil && virt_src [f_virt] == nil) {
		DEC_VAR(v_virt,cutf)
	}
}

void CompOrder2::dec_seqp(node v)
{
	face f;
	list<face> L;

	mark(v,true);
	get_adj_faces (next(v), L);
	forall (f, L) {
		if (f_mark [f] == true)
		  seqp [f]--;
	}
	get_adj_faces (prev(v), L);
	Forall (f, L) {
		if (f_mark [f] == true)
		  seqp [f]--;
	}

	mark(v, false);
}

void CompOrder2::del_outer_node(node v)
{
	face_item x;

	forall (x, in_out_nodes[v])
		(outer_nodes[x.f]).del_item (x.it);
}

void CompOrder2::set_outv (node v)
{
	face f;
	list<face> L;

	get_adj_faces (v, L);
	forall (f, L) {
		INC_VAR(f,outv)
		put_on_outer (v, f);
		if (cutv(f) == true) {
			INC_VAR(v, cutf)
		}
		if (is_sf [f]) {
			INC_VAR(v, numsf)
		}
	}
	return;
}

void CompOrder2::set_seqp (node cl, node cr)
{
	node v, w;
	face f;
	list<face> L;

	for (v = cl; v != cr; v = w) {
		w = next(v);
		mark (v, true);
		get_adj_faces (w, L);
		forall (f, L) {
			if (f_mark [f] == true) {
				INC_VAR (f,seqp)
			}
		}
		mark (v, false);
	}
}

void CompOrder2::remove_next_virt (Order_Set &V)
{
	node v, cl = next_e, cr = next(next_e);
	face f;
	int i = 0;

	while (deg[cl] == 2 && cl != v1)
		{ cl = prev(cl); i++; }
	while (deg[cr] == 2 && cr != v2)
		{ cr = next(cr); i++; }

	V = Order_Set (i, !virt_edge[cl], !virt_edge[prev(cr)]);
	for (i = 1, v = next(cl); v != cr; v = next(v)) {
		V [i++] = v;
		del_outer_node(v);
	}
	V.left (cl);
	V.right (cr);

	f = right(cl);
	virt_src [f] = cl;

	virt_to_contour(cl, cr);

	INIT_VAR(f,outv,(outv[f] - V.len()))
	INIT_VAR(f,oute,(oute[f] - V.len()))
	INIT_VAR(f,seqp,(seqp [f] - V.len()-1))
	set_seqp(cl,cr);
	set_update(cl);
	set_update(cr);
}

void CompOrder2::set_update (node v)
{
	if (v_update [v] == false) {
		update_nodes.append (v);
		v_update [v] = true;
	}
}

void CompOrder2::set_update (face f)
{
	if (f_update [f] == false) {
		update_faces.append (f);
		f_update [f] = true;
	}
}

void CompOrder2::do_update()
{
	bool possible, sf;
	face f;
	node v;
	nd u;

	while (!update_faces.empty()) {
		f = update_faces.pop();
		f_update [f] = false;
		sf = (outv[f] > seqp[f]+1);
		if (sf != is_sf [f]) {
			forall (u, outer_nodes[f])
				if (sf) {
					INC_VAR(u.v,numsf)
				} else {
					DEC_VAR(u.v,numsf)
				}
			is_sf [f] = sf;
		}
		possible = is_poss_face(f);
		if (possible && f_link [f] == nil)
			f_link [f] = poss_faces.append(f);
		else if (!possible && f_link [f] != nil) {
			poss_faces.del_item(f_link [f]);
			f_link [f] = nil;
		}
	}

	list_item it, it_prev;
	for (it = update_nodes.last(); it != nil; it = it_prev) {
		it_prev = update_nodes.pred(it);
		v = update_nodes[it];
		if (v != v1 && virt_edge[prev(v)] == true) set_update(prev(v));
	}

	while (!update_nodes.empty()) {
		v = update_nodes.pop();
		v_update [v] = false;
		possible = is_poss_node(v);
		if (possible && v_link [v] == nil)
			v_link [v] = poss_nodes.append(v);
		else if (!possible && v_link [v] != nil) {
			poss_nodes.del_item (v_link [v]);
			v_link [v] = nil;
		}
		possible = is_poss_virt(v);
		if (possible && link_virt[v] == nil)
			link_virt[v] = poss_virt.append(v);
		else if (!possible && link_virt[v] != nil) {
			poss_virt.del_item (link_virt[v]);
			link_virt[v] = nil;
		}
	}
}

void Canonical_Order::comp_bic_co (Undirected_Graph &G, list<Order_Set> &c_order,
	bool max_outer, bool /*prefer_nodes*/)
{
  node v;
  int i = 1;
  node_array<int> id(G);

  forall_nodes (v, G) id[v] = i++;

	CompOrder2 cpo(G, max_outer);

	cpo.init_possibles();

	while (cpo.get_possible())
	{
		switch (cpo.next_poss()) {
		case type_face:
			c_order.push (Order_Set());
			cpo.remove_next_face (c_order[c_order.first()]);
			break;
		case type_node:
			c_order.push (Order_Set());
			cpo.remove_next_node (c_order[c_order.first()]);
			break;
		case type_edge:
			c_order.push (Order_Set());
			cpo.remove_next_virt (c_order[c_order.first()]);
			break;
		}

		cpo.do_update();
		const Order_Set& V = c_order[c_order.first()];
		for (i = 1; i <= V.len(); i++)
		  cerr << id[V[i]] << " ";
		cerr << "\n";
	}
	c_order.push (Order_Set(2));
	cpo.set_V1(c_order[c_order.first()]);
}
