#include "bctree.h"

list<edge> result;
bctree BC; //wird spaeter initialisiert
graph *G;
// In dieser map hat jeder cutpoint Zeiger auf die Liste von seinen Pendants.
map <cutpoint, blocklist> pendants_of_cutpoint;
inline int n_sons (cutpoint cp) { return pendants_of_cutpoint[cp].size (); }

// In dieser Map werden alle Pendants aufgelistet. Jeder Pendants hat
// Zeiger auf einen "wahren" cutpoint-father, das heisst einen Cutpoint der
// nach dem Reduce_path der Parent vom block w�re
map <block, cutpoint> true_parent;

//Jeder Cutpoint hat einen Set von Cutpoints zu denen er nicht Planar ist
//Beim diesen Sets werden folgende Regel benutzt:
// 1) Wenn zwei Cutpoints zu einem Zeitpunkt nicht planar sind, bleiben sie auch
// f�r den Rest des Algorithmus nicht planar ( es werden keine Kanten entfernt.)
// 2) Wenn es festgestell wird das 2 Cutpoints Planar zu einander sind, dann kann man
// die Sets von diesen Cutpoints joinen.
non_planar_heaps np_heap;

//****************************************************************
int cmp (cutpoint const &cp1, cutpoint const &cp2)
{
  if ( n_sons (cp1) < n_sons (cp2))   return 1;
  return  (n_sons (cp1) == n_sons (cp2)) ? 0 : -1;
}
//****************************************************************
int cmp_bl (block const &bl1, block const &bl2)
{
  if ( BC.number_of_nodes (bl1) <  BC.number_of_nodes (bl2))   return 1;
  return  (BC.number_of_nodes (bl1) ==  BC.number_of_nodes (bl2)) ? 0 : -1;
}
//***************************************************************
bool PLANAR (node v, node w)
{
  edge e;
  if ( v == w )  // || adjacent (v,w) )
     return true;   //?
  else {
     e = G->new_edge (v,w);
     bool planar = PLANAR0 (*G);
     G->del_edge (e);
     return planar;
  }
}

/*****************************************************************/
inline edge coalesce_pendants (block bl1, block bl2) {
 return G->new_edge ( BC.get_outside_node (bl1), BC.get_outside_node (bl2));
}

//*****************************************************************************
node adj_to_cutpoint_node (block pendant, cutpoint cp = nil) {

node n, cp_node = ( cp == nil) ? BC.head_node (pendant) : BC.vertex (cp);

edge e;
forall_inout_edges (e, cp_node)
	if ( BC.owner (n = G->opposite (cp_node, e)) == pendant )   return n;

return nil;
}
/******************************************************************************/
block coalesce_pendants (list<block>& pendants )
{
  if ( pendants.size () == 1 )
    return pendants.pop();

  int (*pcmp)(block const&, block const&);
  pcmp = &cmp_bl;
  pendants.sort (cmp_bl);
  pendants.append (pendants.pop ());

  block bl2 = pendants.tail (), bl1 = pendants.head ();

  (bl2->outside_nodes).push (adj_to_cutpoint_node (bl2));
  (bl1->outside_nodes).push (adj_to_cutpoint_node (bl1));

  edge e;

  forall ( bl2, pendants) {
     if ( bl2 != bl1 ) {
	if ( bl2 != pendants.tail ())    BC.set_outside_face (bl2);
	e = coalesce_pendants (bl1, bl2);

	result.push (e);
	BC.remove_outside_node (bl2);
    	bl1 = bl2;
     }
  }

  bl1 = BC.union_pendants ( true_parent [bl2], pendants );
  pendants.clear ();
  return bl1;
}
//**************************************************************************
//Diese Funktion selektiert die Knoten von einem Block die zu einem Cutpoint
//(oder zu allen Cutpoints die zu diesem Block geh�ren) adjacent sind. Die
//Knoten werden in der Member-Liste outside_nodes des Blocks gespeichert.
//Diese Knoten werden sp�ter als outside nodes benutzt. Parameter only
//wird ungleich nil gesetzt, nur wenn es f�r diesen cutpoint benachbarte
//Knoten selektiert werden m�ssen, amsonsten wird die Selektion f�r alle
//Cutopints gemacht.
//**************************************************************************

void separate_adj_to_cp_nodes ( block bl, cutpoint only = nil )  {

 list_item li;
 node v, w;
 list<bc_node> cpoints;
 bc_node cp;

 if ( only != nil )
    cpoints.push (only);
 else
    cpoints = BC.all_adj_nodes (bl);

 forall ( cp, cpoints ) {
    w = BC.first_node (cp);
    forall_adj_nodes ( v, w )
       if ( BC.owner (v) == bl )
          if ( (li = (bl->outside_nodes).search (v)) == nil )
             (bl->outside_nodes).push (v);
       else
             (bl->outside_nodes).move_to_front (li);
 }
}
//**************************************************************************
bc_node continue_chain (  bc_node first, bc_node center ) {
	bc_node second;
	forall ( second, BC.all_adj_nodes (center))
		if ( second != first )  return second;
	return nil; //center ist ein Pendant
}
/****************************************************************************
/ Diese Funktion findet f�r einen Pendant ( einen Block mit degree = 1 ) einen
/ "wahren" Vater, das heisst einen Vorfahren mit degree > 2, wobei alle andere
/ bc_nodes auf dem Pfad zwischen dem Block und gefundenem Vorfahren degree = 2
/ haben m�ssen( die k�nnen also nicht ber�cksichtigt werden - eine Kette), und eine Kante
/ zwischen dem Block und gefundem Vorfahren muss nicht Planarit�t verletzen.
/ Wenn gefundener bc_node ein Block ist, wird sein Cutpoint-Sohn auf dem Pfad zum
/ Block genommen. Die Suche geht auch �ber den Root hinaus. */
//*****************************************************************************
void Reduce_Path ( block blok  )
{
bc_node last = blok, bcn = BC.father (blok);
node head = BC.first_node (bcn);
list<bc_node> path_cps;

while ( bcn != nil && BC.degree (bcn) == 2 ) {
        if ( BC.is_cutpoint (bcn) ) path_cps.append (bcn); //Speichere alle CP's in der Liste
        bc_node temp = bcn;
	bcn = continue_chain (last, bcn);
	last = temp;
}

if ( bcn != nil && BC.is_cutpoint (bcn))
	path_cps.append (bcn);

bcn = path_cps.tail ();
if ( !PLANAR (head, BC.first_node (bcn)))  {
	path_cps.Pop ();
	list<bc_node> first_half, scnd_half;
	list_item half;
	cutpoint cp;
	do {
		half = path_cps.item (path_cps.size ()/2);
		path_cps.split (half, first_half, scnd_half);
		cp = cutpoint(path_cps.inf (half));
		if ( PLANAR (BC.vertex (cp), head ))
			path_cps = scnd_half;
		else
			path_cps = first_half;
	} while ( scnd_half.size () != 1 );
	bcn = path_cps.pop ();
	np_heap.add_np_pair ((cutpoint)bcn, (cutpoint)BC.granddad (bcn));
}

  true_parent[blok] = (cutpoint)bcn;
  pendants_of_cutpoint[(cutpoint)bcn].push (blok);
}

//***************************************************************************
//Diese Funktion macht einen evtl. nicht zusammenh�ngenden Graph zusammenh�ngend.
//Der Unterschied vom LEDA-Programm ist es das hier versucht wird Pendants miteinander
//zu verkn�pfen.
//***************************************************************************/
int MAKE_CONNECTED (list <edge> &added)   {
 if ( BC.number_of_components () == 1 )  return 0;

 blocklist alones = BC.all_blocks_with_degree (0);
 blocklist pendants = BC.all_blocks_with_degree (1);
 block bl1, bl2;
 node v, n;
 set <int> included;
 node_array<int> comp_num (*G);
 int result = 0, nComps, nAlones = alones.size ();
 list <block> free_pendants;

 nComps = COMPONENTS (*G, comp_num);

 if ( nComps - nAlones > 1 )  {//Es gibt mehr als 1 BCSubtree

    pendants.permute ();
    bl1 = pendants.pop ();
    included.insert (comp_num [BC.first_node (bl1)]);

    while ( included.size () < nComps - nAlones )  {
		for (;;) {
			bl2 = pendants.pop ();
			if ( included.member (comp_num [BC.first_node (bl2)]))
				free_pendants.push (bl2);
			else {
			    added.push (G->new_edge (BC.first_node (bl1), BC.first_node (bl2)));
			    result++; break; }
		}

    included.insert (comp_num [BC.first_node (bl2)]);
    if ( included.size () != nComps - nAlones )
	forall (bl1, pendants)
	    if ( comp_num [BC.first_node (bl1)] == comp_num [BC.first_node (bl2)] ) break;
  }
 }

 if ( free_pendants.size () < nAlones )
    free_pendants.conc (pendants);

 if ( nAlones > free_pendants.size ())  {
	list  <block> odds;

	while ( alones.size () >= free_pendants.size () && alones.size () > 0)
		odds.push (alones.pop());

	v = BC.first_node (odds.pop ());

    while ( !odds.empty ())   {
	   bl1 = odds.pop ();
	   n = BC.first_node (bl1);

	   added.push (G->new_edge (n, v));
	   result++;

	   if ( BC.number_of_nodes (bl1) != 1 )
	       v = G->opposite (n, G->first_adj_edge (n));
	   else
	       v = n;
	}//while  !block...

	if (free_pendants.size ()) {
		added.push (G->new_edge (v, BC.first_node (free_pendants.pop ())));
		result++;
	}
 }

while ( !free_pendants.empty() && !alones.empty ())  {
  added.push (G->new_edge (BC.first_node (free_pendants.pop ()), BC.first_node (alones.pop ())));
  result++;
 }
 return result;
}
//*******************************************************************************
list<edge> onehalf (graph &GO )  {

G = &GO;
if ( !PLANAR0 (*G)) {
	cout << "Onehalf: Input Graph is not Planat. Onehalf must exit\n";
	exit (1);
}

list<cutpoint> fathers;
block blok;
cutpoint cp, first;
blocklist  blocks;
edge e;

int (*pcmp)(cutpoint const&, cutpoint const&);
pcmp = &cmp;

BC.init (G,true);

if ( MAKE_CONNECTED (result)) BC.update (true);
G->write ( "con.g" );

forall (blok, blocks = BC.all_blocks_with_degree (1))
     Reduce_Path (blok);

//Jetzt konstuiere ich eine Liste von Schnittpunkten die Pendants als S�hne haben
 forall ( cp, BC.all_cutpoints ())
   if ( pendants_of_cutpoint.defined (cp))
      fathers.push (cp);

  np_heap.init (fathers);

while ( fathers.size () >= 1 ) {
 int max_found = 0;   // H�chste Anzahl von S�hnen von einem Pendant
 int best_depth = MAXINT;
 cutpoint best_cp;

// Suche jetzt in der Liste fathers einen Cutpoint der die h�chste Anzahl von Pendants hat
 fathers.sort (pcmp);
 first = fathers.pop (); //Unterm first habe ich jetzt einen Cp mit Maximaler #Pendants

 set <cutpoint> found_planars, found_non_planars;
// Suche jetzt einen anderen father der zum first planar ist hoechste p(v) hat und
// auch hoechsten lca mit first hat (= kleinste depth)
     forall ( cp, fathers )
     if ( n_sons (cp) >= max_found ) {
         int depth = BC.depth (BC.common_ancestor (cp, first));
	 if ( depth < best_depth && !np_heap.are_non_planar (first, cp))
	     if ( PLANAR (BC.vertex(first), BC.vertex (cp))) {
	         max_found = n_sons (cp);
		     best_depth = depth;
	         best_cp = cp;
		     found_planars.insert (cp);
		     np_heap.increase_heap (first, cp);
	     }
	     else  found_non_planars.insert (cp);
     }
     else
          break;

   np_heap.add_info (first, found_planars, found_non_planars);

   if ( max_found == 0 )  { // Der first ist zu keinem Cutpoint PLANAR oder es gibt keine mehr
//    if ( BC.root () == first )  BC.DFS_num ( fathers.head ());

// Verknuepfe Pendants vom blok miteinander
    blok = coalesce_pendants ( pendants_of_cutpoint [first]);

    if ( BC.number_of_blocks () == 1 )   break; //Done - Graph is Biconnected

    BC.DFS_num (fathers.head ());

// Suche hoechsten Vorfahren-Block ( = highest_planar) der zum blok Planar ist
    cutpoint planar_cp = first, ancestor = (cutpoint)BC.granddad (first);

    while ( ancestor != nil && !np_heap.are_non_planar (first, ancestor))
		if (PLANAR ( BC.vertex (first), BC.vertex (ancestor))) {
			planar_cp = ancestor;
			ancestor = (cutpoint)BC.granddad (ancestor);  }
		else {
			np_heap.add_np_pair (first, ancestor);
			break;	}

//
    block ancestor_block = (block)(BC.father (planar_cp));

    e = G->new_edge (adj_to_cutpoint_node (ancestor_block, planar_cp), adj_to_cutpoint_node (blok));
    result.push (e);
    blok = BC.union_nodes ( ancestor_block, blok );
  }
   else {  // Es wurde einer gefunden
 /* Jetzt verknuepfe ich die Pendants vom first und best_cp miteinander und
 update BCtree = nach dem Verkn�pfen bekomme ich ein neues Block der aus allen
 BC-Nodes zwischen Pendants vom first und best_cp und lca vom first und best_cp  besteht. */
     block pendant1, pendant2 ;

     while ( n_sons (best_cp) )  {
       pendant1 = (pendants_of_cutpoint[best_cp]).pop ();
       pendant2 = (pendants_of_cutpoint[first]).pop ();
       e = G->new_edge ( adj_to_cutpoint_node (pendant1), adj_to_cutpoint_node (pendant2));
       result.push (e);

       blok = BC.union_nodes ( pendant1, pendant2 );
     }
     fathers.del_item (fathers.search (best_cp));
     if ( n_sons (first))  fathers.push ( first );

     BC.DFS_num ();

  }
  /*  Updating : Neu nach dem ein neuer Block erzeugt wurde, kann auch er Pendant
  // werden und in diesem Fall soll er in weitere Processing miteinbezogen werden
  // (in pendants eingefuegt werden, und die */
  if ( BC.degree (blok) == 1 && BC.number_of_cutpoints () > 0 ) {
    Reduce_Path ( blok );
    if ( fathers.search (true_parent[blok]) == nil ) {
       fathers.append ( true_parent[blok] );
	   np_heap.add_cutpoint (fathers.tail ());
    }
  }
}
 return result;
}
