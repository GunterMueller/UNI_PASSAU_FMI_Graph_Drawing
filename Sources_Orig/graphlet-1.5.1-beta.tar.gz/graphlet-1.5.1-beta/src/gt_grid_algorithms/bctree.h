#ifndef BCTREE
#define BCTREE
#include <time.h>
#include <LEDA/stack.h>
#include <LEDA/set.h>
#include <LEDA/list.h>
#include <LEDA/p_queue.h>
#include <LEDA/map.h>
#include <LEDA/array2.h>
#include <LEDA/node_set.h>
#include <LEDA/graph.h>
#include <LEDA/graph_alg.h>

class block_struct;
class cutpoint_struct;
class bc_node_struct;
class bctree;
typedef bc_node_struct* bc_node;
typedef cutpoint_struct* cutpoint;
typedef block_struct* block;

typedef list<node> nodelist;
typedef list<block> blocklist;
typedef list<cutpoint> cutpointlist;
typedef set<cutpoint> cutpointset;

class bc_node_struct {
   friend class bctree;

   list<bc_node> adj_nodes;
   int dfs_number;

   inline int degree () { return adj_nodes.size(); }
   int continue_DFS (int);
   bc_node father ();
   bc_node sohn ();
   inline bc_node first_adj_node () { return ( !degree ()) ? nil : adj_nodes.head (); }
   inline void add_bc_node ( bc_node bcn) { adj_nodes.push (bcn); }
   inline void del_bc_node ( bc_node bcn);

 protected:
   virtual node first_node () { return nil; }
   virtual bool is_cutpoint () { return true; }
   virtual list<node> all_nodes () { list<node> nodes; return nodes; }
   virtual int number_of_nodes () { return 1; }
};

class cutpoint_struct : public bc_node_struct {
  friend bctree;
  node knoten;

  cutpoint_struct (node v) { knoten = v; }
  inline bool is_cutpoint () { return true; }
  inline node first_node () { return knoten; }
  inline list<node> all_nodes () { list<node> result; result.push (knoten); return result; }
  inline int number_of_nodes () { return 1; }
};

class block_struct : public bc_node_struct {
   friend class bctree;
   list<node> nodes;

   inline bool is_cutpoint () { return false; }
   inline int number_of_nodes () { return nodes.size (); }
   inline node first_node () { return (nodes.empty ()) ? nil : nodes.head (); }
   inline list<node> all_nodes () { return nodes; }
   inline node first_outside_node () { return outside_nodes.head ();}
  public:
   list<node> outside_nodes;
};

class bctree {
   list<cutpoint> cutpoints;
   list<block> blocks;
   bc_node root_;
   graph* G;
   node_map<bc_node> node_owner;
   int num_connected_comps;

   int compute_SubBCTree (node start = nil);
   void compute_bcTree ();
   node find_unchecked (node v,edge_array<bool> &, bool only_check = false );

   cutpoint new_cutpoint (node v);
   cutpoint new_cutpoint (node, block);
   block new_block (stack<node>&, node);
   inline block new_block (node n) { block bl = new_block (); add_node (n, bl);  return bl; }
   inline block new_block () { block bl = new block_struct; blocks.push (bl); return bl; }

   inline void add_node ( node v, block bl ) { (bl->nodes).push (v); node_owner[v] = bl; }
   void del_node (node v, block bl);

   void del_bc_node (bc_node);

   inline void make_nodes_adj (bc_node bcn1, bc_node bcn2 );

   void copy_block (block bl, GRAPH <node, int>& copy, node_array<node>& orig2copy );
   void coalesce_path (bc_node, bc_node, list<bc_node>&);

 public:
   bctree () {}
   bctree (graph* G, bool construct = false, bool DFS_num = false);
   ~bctree ();
   void init (graph* G, bool DFS = false);
   void update (bool DFS = false);

   void DFS_num (cutpoint rut = nil);
   inline int dfs_number (bc_node bcn) { return bcn->dfs_number; }
   inline bc_node root () { return root_;}
   inline bc_node father (bc_node bcn ) { return bcn->father (); }
   inline bc_node sohn (bc_node bcn) { return bcn->sohn (); }
//   inline cutpoint granddad (cutpoint cp) { return (cutpoint)granddad (cp); }
//   inline block granddad (block bl) { return (block)granddad(bl); }
   bc_node granddad ( bc_node );
   
   bc_node common_ancestor (bc_node, bc_node);
   int depth (bc_node);

   inline int degree (bc_node bcn )  { return (bcn->adj_nodes).size (); }
   inline bc_node first_adj_bcnode (bc_node bcn)  { return bcn->first_adj_node (); }
   inline list<bc_node>& all_adj_nodes (bc_node bcn) { return bcn->adj_nodes; }
   bool is_adj_cutpoint (node v, block bl);
   inline bool are_adj (bc_node, bc_node);
   node head_node ( block );

   inline bool is_cutpoint (bc_node bcn) { return bcn->is_cutpoint(); }
   inline cutpoint is_cutpoint (node v);
   inline node vertex (cutpoint cp) { return cp->knoten; }

   inline node first_node ( bc_node bcn ) { return bcn->first_node (); }
   inline list<node> all_nodes ( bc_node bcn ) { return bcn->all_nodes (); }
   inline int number_of_nodes ( bc_node bcn ) { return bcn->number_of_nodes (); }

   bool is_valid (bc_node );
   inline bc_node owner (node v) { return node_owner[v]; }

   inline int number_of_blocks () { return blocks.length(); }
   inline int number_of_cutpoints () { return cutpoints.length(); }
   inline int number_of_bcnodes () { return blocks.length()+ cutpoints.length(); }
   inline int number_of_components () { return num_connected_comps; }
   int number_blocks_with_degree (int deg );

   inline list<node>& all_nodes (block bl) { return bl->nodes; }
   inline list<block>& all_blocks() { return blocks; }
   inline list<cutpoint>& all_cutpoints() { return cutpoints; }
   list<bc_node> all_bcnodes ();
   list<block> all_blocks_with_degree (int deg );

   bool set_outside_face (block, cutpoint cp = nil);
   inline node get_outside_node (block bl) { return (bl->outside_nodes).head (); }
   bool remove_outside_node ( block );
   void print_node (bc_node);

   block union_nodes (bc_node, bc_node);
   block union_pendants (cutpoint, list<block>&);
   void connect_components (edge e);
   bool get_outside_face (block, cutpoint cp = nil);
};

//***************************************************************************
class non_planar_heaps  {
  set<cutpoint>  cpoints;
  map<cutpoint, cutpointset*> non_planars;

public:
  ~non_planar_heaps ();
  void init (list<cutpoint>);
  void add_cutpoint (cutpoint);
  inline cutpointset* heap_of (cutpoint cp)
                  { if (!non_planars.defined (cp))  return nil; else return non_planars [cp]; }

  bool are_non_planar (cutpoint, cutpoint);
  void add_info (cutpoint, set<cutpoint>, set<cutpoint>);
  void add_np_pair (cutpoint, cutpoint);
  inline void increase_heap ( cutpoint to_increase, cutpoint new_info)
                            { *non_planars[to_increase] += *non_planars [new_info]; }
};
#endif
