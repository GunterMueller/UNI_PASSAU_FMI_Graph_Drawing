
#include <LEDA/graph.h>
#include <LEDA/node_array.h>
#include <LEDA/edge_array.h>
#include <LEDA/array.h>

#include "Undirected_Graph.h"


#ifndef Canonical_Order_h
#define Canonical_Order_h



// Darstellung f�r die Mengen der kanonischen Ordnung (V1,...,Vk)

class Order_Set : public array<node> {
public:
	Order_Set () : array<node>() {
		left (nil); right (nil);
		has_left (false); has_right (false);
	}
	Order_Set (int l, bool h_l = true, bool h_r = true) : array<node> (1,l) {
		left (nil); right (nil);
		has_left (h_l); has_right (h_r);
	}
	~Order_Set ()
		{ }

	node left() const {
		return leftvertex;
	}
	node right() const {
		return rightvertex;
	}
	void left (node cl) {
		leftvertex = cl;
	}
	void right (node cr) {
		rightvertex = cr;
	}
	bool has_left() const {
		return the_has_left;
	}
	bool has_right() const {
		return the_has_right;
	}
	void has_left (bool h_l) {
		the_has_left = h_l;
	}
	void has_right (bool h_r) {
		the_has_right = h_r;
	}

	int len() const {
		return high();
	}
	node operator[] (const int i) const {
		return array<node>::operator[](i);
	}
	node& operator[] (const int i) {
		return array<node>::operator[](i);
	}
	void operator= (const Order_Set& S) {
		array<node>::operator= (S);
		left      (S.left());
		right     (S.right());
		has_left  (S.has_left());
		has_right (S.has_right());
	}

private:
	node leftvertex, rightvertex;		// leftvertex, rightvertex
	bool the_has_left, the_has_right;
};


enum Canonical_Order_Type { CO_TRICONNECTED, CO_BICONNECTED };

class Canonical_Order {
public:
	Canonical_Order (Undirected_Graph &g,
		Canonical_Order_Type co_type = CO_TRICONNECTED,
		bool max_outer = true, bool prefer_nodes = false);
	Canonical_Order ()
		{ }
	~Canonical_Order ()
		{ }

	int length () {
		return V.high();
	}
	int len (int i) {
		return V[i].len();
	}
	node operator() (int i, int j) {
		return (V[i])[j];
	}
	const Order_Set& operator[](int i) {
		return V[i];
	}
	node left (int i) {
		return V[i].left();
	}
	node right (int i) {
		return V[i].right();
	}
	int rank (node v) {
		return the_rank[v];
	}

protected:
	static void comp_tric_co (Undirected_Graph& g, list<Order_Set> &c_order,
		bool max_outer = true, bool prefer_nodes = false);
	static void comp_bic_co (Undirected_Graph& g, list<Order_Set> &c_order,
		bool max_outer = true, bool prefer_nodes = false);

	void init_rank (Undirected_Graph& g);

	array<Order_Set> V;
	node_array<int> the_rank;
};


class Lmc_Order : public Canonical_Order {
public:
	Lmc_Order (Undirected_Graph &g,
		Canonical_Order_Type co_type = CO_TRICONNECTED,
		bool max_outer = true, bool prefer_nodes = false);
	Lmc_Order () : Canonical_Order ()
		{ }

};

//
// auxiliary structures
//
// Paar aus Knoten v und list_item it
//

struct nd {
	nd ()
		{ }
	nd (node v_ini, list_item it_ini = NULL)
		{ v = v_ini; it = it_ini; }
	node v;
	list_item it;
};

ostream& operator<< (ostream& out, nd);
istream& operator>> (istream& in, nd);


#endif
