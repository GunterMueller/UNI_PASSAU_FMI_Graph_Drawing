
#include "convex_draw_layout.h"


///////////////////////////////////////////////////////
// GT_Layout_ConvexDraw_Algorithm
//
// This is the ConvexDraw (Chrobak/Kant) algorithm
///////////////////////////////////////////////////////


int GT_Layout_ConvexDraw_Algorithm::check (GT_Graph &g, string& message)
{
	if (g.leda().number_of_nodes() < 3) {
		message = "The graph must have at least three nodes!";
		return TCL_ERROR;
	}
	if (Is_Simple (g.leda()) == false) {
		message = "The graph must be simple!";
		return TCL_ERROR;
	}

	Undirected_Graph ug (g.leda());
	if (is_triconnected (ug) == false) {
		message = "The graph must be triconnected!";
		return TCL_ERROR;
	}
	if (ug.is_planar() == false) {
		message = "The graph must be planar!";
		return TCL_ERROR;
	}
	message = "everything ok";
	return GT_OK;
}


bool GT_Layout_ConvexDraw_Algorithm::compute_layout (Undirected_Graph& G)
{
	G.embed_planar();

	Canonical_Order c_o(G);
	// F�r Au�enfl�che c_1,...,c_q ist next[c_i] = c_i+1, prev[c_i] = c_i-1
	node_array<node> next(G), prev(G),
	// upper[v] = w bedeutet x-Koord. von v ist relativ zu w (abs. x-Koord.
					 upper(G, nil); // von v = x[v] + abs. x-Koord von w)

	node_array<int>	max_neighbour(G, 0);

	node v1 = c_o (1,1),	// v1 und v2 der Grundlinie
		 v2 = c_o (1,2),
		 right_side = v2;

	node v, z1, cl, cr, alpha, beta;
	edge e;
	int	 k, i, sum;
	bool is_outer;

	forall_nodes (v, G)
		forall_out_edges (e, v) {
			int r = c_o.rank (G.target(e));
			if (r > max_neighbour[v]) max_neighbour[v] = r;
		}

	// Beginne mit Geraden (v1, v2) (v1 auf (0,0), v2 auf (1,0))
	x [v1] = y [v1] = y [v2] = 0; x [v2] = 1;

	// Initialisierung der Au�enfl�che
	next [v1] = v2;  next [v2] = nil;
	prev [v1] = nil; prev [v2] = v1;

	for (k = 2; k <= c_o.length(); k++) {
		// Referenz auf aktuelle Menge Vk (als Abk�rzung)
		const Order_Set &Vk = c_o[k];
		int l = Vk.len(), offset, eps, x_cr, y_z;    // Vk = { z_1,...,z_l }

		z1 = Vk[1];
		// left- und rightvertex in Menge gespeichert
		cl = Vk.left(); cr = Vk.right();
		if (side_opt() && cr == right_side && max_neighbour[cr] <= k) {
			is_outer = true; right_side = Vk[l];
		} else
			is_outer = false;

		// Berechne relativen x-Abstand con ci zu cl f�r i = l+1, ..., r
		for (sum = 0, v = next[cl]; v != cr; v = next[v]) {
			sum += x[v]; x[v] = sum;
		}
		x[cr] += sum;

		eps = (max_neighbour [cl] <= k && k > 2) ? 0 : 1;

		if (size_opt()) {
			int y_max;
			if (is_outer) {
				y_max = Max (y[cl]+1-eps,
							 y[cr] + ((x[cr]==1 && eps==1) ? 1 : 0));
				for (v = next[cl]; v != cr; v = next[v])
					if (x[v] < x[cr]) {
						int y1 = (y[cr]-y[v])*(eps-x[cr])/(x[cr]-x[v])+y[cr];
						if (y1 >= y_max) y_max = 1+y1;
					}
				for (v = cr; v != cl; v = prev[v])
					if (y[prev[v]] > y[v] && max_neighbour[v] >= k) {
						if (y_max <= y[v] + x[v] - eps) {
							eps = 1; y_max = y[v] + x[v];
						}
						break;
					}
				x_cr = Max (x[cr]-eps-l+1, (y[cr]==y_max) ? 1 : 0);
				y_z  = y_max;
			} else {
				// y_max = max { y[c_i] | l <= i <= r }
				y_max = y[cl] - eps;
				for (v = cr; v != cl; v = prev[v])
					if (y[v] > y_max) y_max = y[v];
				offset = Max (y_max-x[cr]+l+eps-y[cr],
							  (y[prev[cr]] > y[cr]) ? 1 : 0);
				y_z  = y[cr] + x[cr] + offset - l + 1 - eps;
				x_cr = y_z - y[cr];
			}
		}
		else {
			y_z  = y[cr] + x[cr] + 1 - eps;
			x_cr = y_z - y[cr];
		}

		alpha = cl;
		for (v = next[cl]; max_neighbour[v] <= k-1; v = next[v])
			if (c_o.rank (v) < c_o.rank (alpha)) alpha = v;
		beta = prev [cr];
		for (v = prev[cr]; max_neighbour[v] <= k-1; ) {
			v = prev[v];
			if (c_o.rank (v) <= c_o.rank (beta))
				beta = v;
		}

		for (i = 1; i <= l; i++) {
			x[Vk[i]] = 1;
			y[Vk[i]] = y_z;
		}
		x[z1] = eps;

		for (v = alpha; v != cl; v = prev [v])
			upper [v] = cl;
		for (v = next [beta]; v != cr; v = next [v]) {
			upper [v] = cr; x [v] -= x[cr];
		}
		for (v = beta; v != alpha; v = prev[v]) {
			upper [v] = z1; x [v] -= x[z1];
		}

		x[cr] = x_cr;

		// Aktualisiere Au�enregion nach Einf�gen von z1,...,zl
		for (i = 1; i <= l; i++) {
			if (i < l) next[Vk[i]] = Vk[i+1];
			if (i > 1) prev[Vk[i]] = Vk[i-1];
		}
		next [cl] = z1;    next [Vk[l]] = cr;
		prev [cr] = Vk[l]; prev [z1] = cl;
	}
	// Berechne die endg�ltigen x-Koordinaten f�r die Knoten der (endg�ltigen)
	// Au�enregion
	for (sum = 0, v = v1; v != nil; v = next[v])
		x [v] = (sum += x[v]);

	// Berechne endgultige x-Koordinaten f�r die inneren Knoten
	for (k = c_o.length(); k >= 2; k--)
		for (i = 1; i <= c_o.len(k); i++) {
			node zi = c_o (k, i);
			if (upper[zi] != nil)
				x[zi] += x[upper[zi]]; // f�r weitere Knoten auf der Au�en-
		}                    // region (neben v1,v2, vn gilt upper[zi] = nil

	return true;
}


///////////////////////////////////////////////////////
// GT_Tcl_Layout_ConvexDraw_Algorithm
//
///////////////////////////////////////////////////////

GT_Tcl_Layout_ConvexDraw_Algorithm::GT_Tcl_Layout_ConvexDraw_Algorithm (
	const string& name) :
	GT_Tcl_Algorithm<GT_Layout_ConvexDraw_Algorithm> (name)
{
}


GT_Tcl_Layout_ConvexDraw_Algorithm::~GT_Tcl_Layout_ConvexDraw_Algorithm ()
{
}


int GT_Tcl_Layout_ConvexDraw_Algorithm::parse (GT_Tcl_info& info, int& index,
	GT_Tcl_Graph* /*g*/)
{
	int code;

	if (streq (info[index], "-size_opt") && !info.is_last_arg(index)) {
		index++;

		int do_size_opt;
		code = Tcl_GetBoolean (info.interp(), info[index++],
			&do_size_opt);
		if (code != TCL_ERROR) {
			size_opt (bool(do_size_opt));
		} else {
			return code;
		}

	} else if (streq (info[index], "-triangle") && !info.is_last_arg(index)) {
		index++;

		int do_side_opt;
		code = Tcl_GetBoolean (info.interp(), info[index++],
			&do_side_opt);
		if (code != TCL_ERROR) {
			side_opt (!bool(do_side_opt));
		} else {
			return code;
		}

	} else {
		string msg ("Unrecognized argument %s", info[index]);
		info.msg (msg);
		return TCL_ERROR;
	}

	return TCL_OK;
}

