//
// grid_algorithms.cc
//
// This file initializes the grid_algorithms module.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_grid_algorithms/gt_grid_algorithms.cpp,v $
// $Author: himsolt $
// $Revision: 1.1 $
// $Date: 1996/10/31 18:13:31 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

#include <gt_base/Graphlet.h>

#include <gt_tcl/Tcl_Graph.h>
#include <gt_tcl/Tcl_Algorithm.h>
#include <gt_tcl/GraphScript.h>

#include "gt_grid_algorithms.h"

int GT_gt_grid_algorithms_init (Tcl_Interp* interp, GT_GraphScript*)
{
    int code;
	
    GT_Tcl_Algorithm<GT_Layout_Fpp_Algorithm>* layout_fpp =
	new GT_Tcl_Layout_Fpp_Algorithm ("layout_fpp");
    code = layout_fpp->install (interp);
    if (code == TCL_ERROR) {
	return code;
    }
	
    GT_Tcl_Algorithm<GT_Layout_ConvexDraw_Algorithm>* layout_convex_draw =
	new  GT_Tcl_Layout_ConvexDraw_Algorithm ("layout_convex_draw");
    code = layout_convex_draw->install (interp);
    if (code == TCL_ERROR) {
	return code;
    }
	
    GT_Tcl_Algorithm<GT_Layout_Convex_Algorithm>* layout_convex =
	new  GT_Tcl_Layout_Convex_Algorithm ("layout_convex");
    code = layout_convex->install (interp);
    if (code == TCL_ERROR) {
	return code;
    }
	
    GT_Tcl_Algorithm<GT_Layout_MixedModel_Algorithm>* layout_mixed_model =
	new GT_Tcl_Layout_MixedModel_Algorithm ("layout_mixed_model");
    code = layout_mixed_model->install (interp);
    if (code == TCL_ERROR) {
	return code;
    }

    code = Tcl_Eval (interp, "GT_init_grid_algorithms");
    if (code == TCL_ERROR) {
	return code;
    }

    return code;
}
