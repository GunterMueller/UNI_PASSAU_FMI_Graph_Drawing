#include "bctree.h"

//*******************************************************************************
//*******************************************************************************
non_planar_heaps::~non_planar_heaps ()  {
 cutpoint cp;
 forall (cp, cpoints)
 	if ( non_planars.defined (cp))
		delete non_planars [cp];
}
//*******************************************************************************
void non_planar_heaps::init (list<cutpoint> lcp)  {
 cutpoint cp;
 forall (cp, lcp)
 	if ( !cpoints.member (cp)) {
 		cpoints.insert (cp);
		non_planars [cp] = new set<cutpoint>();
	}
}
//*********************************************************************************
void non_planar_heaps::add_cutpoint (cutpoint new_cp)   {
 if (!non_planars.defined (new_cp))
 	non_planars [new_cp] = new set<cutpoint>();

 cpoints.insert (new_cp);
}
//*********************************************************************************
bool non_planar_heaps::are_non_planar (cutpoint cp1, cutpoint cp2)  {

 if ( non_planars.defined (cp1) && non_planars[cp1]->member (cp2)) return true;
 if ( non_planars.defined (cp2) && non_planars[cp2]->member (cp1)) return true;
 return false;
}
//*********************************************************************************
void non_planar_heaps::add_info (cutpoint main_cp, cutpointset planars, cutpointset n_planars)  {
   cutpoint cp;
   forall (cp, planars)
   		*non_planars[cp] += *non_planars [main_cp];

   planars.insert (main_cp);
   forall (cp, n_planars)
   		*non_planars[cp] += planars;
}
//*********************************************************************************
void non_planar_heaps::add_np_pair (cutpoint cp1, cutpoint cp2)  {
  if (!non_planars.defined (cp1))
 	non_planars [cp1] = new set<cutpoint>();
  cpoints.insert (cp1);

  if (!non_planars.defined (cp2))
 	non_planars [cp2] = new set<cutpoint>();
  cpoints.insert (cp2);

  non_planars[cp1]->insert (cp2);
  non_planars[cp2]->insert (cp1);
}
/**************************************************************
		CLASS BC-node
***************************************************************/
int bc_node_struct::continue_DFS (int i) {
 int num = dfs_number = ++i;
 bc_node bcn;

 forall (bcn, adj_nodes)
   if (!bcn->dfs_number) num = bcn->continue_DFS (num);

 return num;
}
//************************************************************
bc_node bc_node_struct::father () {
 bc_node bcn;
 forall (bcn, adj_nodes)
   if ( bcn->dfs_number < dfs_number)  return bcn;
 return nil;  //*this is  root or stand-alone block
}
//************************************************************
bc_node bc_node_struct::sohn ()  {
 bc_node bcn;
 forall (bcn, adj_nodes)
   if ( bcn->dfs_number > dfs_number)  return bcn;
 return nil;  //*this is a pendant or stand-alone block
}
//************************************************************
inline void bc_node_struct::del_bc_node ( bc_node bcn) {
	list_item li = adj_nodes.search (bcn);
	if ( li != nil ) adj_nodes.del_item (li);
}
//***************************************************************
int compare (cutpoint const &cp1, cutpoint const &cp2)  { return compare ((int)cp1, (int)cp2); }
//***************************************************************
int compare (block const &bl1, block const &bl2) {  return compare ((int)bl1, (int)bl2); }
//***************************************************************
int compare (bc_node const &bcn1, bc_node const &bcn2) { return compare ((int)bcn1, (int)bcn2);}

/****************************************************************
    CLASS Block-and-Cutpoint Tree = bctree
*************************************************************/
bctree::bctree (graph* pG, bool construct, bool DFS)
{
 G = pG;
 node_owner.init (*pG, nil);
 num_connected_comps = 0;
 if (construct)
	compute_bcTree();
 if (DFS)
	DFS_num ();
}
//**************************************************************
bctree::~bctree ()
{
  cutpoint cp;
  forall ( cp, cutpoints )
	delete cp;

  block bl;
  forall ( bl, blocks )
	delete bl;
}
//**************************************************************
void bctree::init (graph* pG, bool DFS) {
 G = pG;
 node_owner.init (*G, nil);
 blocks.clear ();
 cutpoints.clear ();

 compute_bcTree();
 if (DFS) DFS_num ();
}
//***************************************************************
void bctree::update (bool DFS)  {
 cutpoints.clear ();
 blocks.clear ();
 node_owner.init (*G, nil);
 num_connected_comps = 0;
 compute_bcTree();
 if (DFS)  DFS_num ();
}
//**************************************************************
list<block> bctree::all_blocks_with_degree (int deg )  {
	list<block> result;
	block bl;
	forall (bl, blocks)
		if ( bl->degree () == deg )  result.push (bl);

	return result;
}
//**************************************************************
int bctree::number_blocks_with_degree (int deg )  {
	int result = 0;
	block bl;
	forall (bl, blocks)
		if ( bl->degree() == deg )  result++;

	return result;
}
//***************************************************************
list<bc_node> bctree::all_bcnodes ()  {
  list<bc_node> result;
  cutpoint cp;
  forall (cp, cutpoints) result.push (cp);
  block bl;
  forall (bl, blocks) result.push (bl);

  return result;
}
//**************************************************************
bc_node bctree::granddad (bc_node bcn) {
  bc_node vater = bcn->father ();
  return ( vater == nil )  ?  nil  :  vater->father ();
}
//***************************************************************
cutpoint bctree::new_cutpoint (node v) {
  cutpoint cp = is_cutpoint (v);
  if ( cp != nil ) return cp;

  cp = new cutpoint_struct (v);
  cutpoints.push (cp);
  node_owner[v] = cp;
  return cp;
}

//***************************************************************
cutpoint bctree::new_cutpoint (node v, block bl)
{
  cutpoint pcp = is_cutpoint (v);
  if ( pcp != nil ) {
    if ( !are_adj (pcp, bl) ) make_nodes_adj (pcp, bl);
    return pcp;
  }

  pcp = new_cutpoint (v);
  make_nodes_adj (pcp, bl);
  return pcp;
}

//***************************************************************
bool bctree::is_valid (bc_node nod)  {
if ( cutpoints.search ((cutpoint)nod) != nil || blocks.search ((block)nod) != nil )
	return true;
return false;
}
//****************************************************************
cutpoint bctree::is_cutpoint (node v) {
  bc_node owner = node_owner[v];
  if (owner != nil && owner->is_cutpoint())
     return (cutpoint)owner;

  return nil;
}
//*****************************************************************
bool bctree::is_adj_cutpoint (node v, block bl) {
  bc_node bcn = node_owner [v];
  if ( bcn == nil || !bcn->is_cutpoint ())  return false;
  return are_adj ( bcn, bl );
}
//****************************************************************
inline bool bctree::are_adj (bc_node bcn1, bc_node bcn2) {
   return ((bcn1->adj_nodes).search (bcn2) == nil ) ? false : true;
}
//*****************************************************************
node bctree::head_node ( block bl ) {
	if ( degree (bl))  return (first_adj_bcnode (bl))->first_node ();
	return nil;
}
//****************************************************************
inline void bctree::make_nodes_adj (bc_node bcn1, bc_node bcn2 ) {
	bcn1->add_bc_node (bcn2);
	bcn2->add_bc_node (bcn1);
}
//****************************************************************
void bctree::del_node (node v, block bl) {
 list_item li = (bl->nodes).search (v);
 if ( li != nil ) {
	 node_owner [v] = nil;
	 (bl->nodes).del_item (li);
 }
}
//*****************************************************************
block bctree::new_block (stack<node>& Stack, node v) {
 node nod;
 cutpoint cpoint;
 block Block = new_block ();
 do {
   nod = Stack.pop();
   if ((cpoint = is_cutpoint(nod)) != nil && !are_adj (cpoint, Block))
   		 make_nodes_adj (Block, cpoint);
   else  add_node (nod, Block);
} while ( nod != v );

 return Block;
}
//*****************************************************************
void bctree::DFS_num (cutpoint rut)   {
 int Max_number = 0;
 cutpoint cp;
 block bl;
 bc_node bcn;

 forall (cp, cutpoints) ((bc_node)cp)->dfs_number = 0;
 forall (bl, blocks)	((bc_node)bl)->dfs_number = 0;

  if ( rut != nil ) {
    root_ = rut;
    Max_number = root_->continue_DFS (0);
  }

  if  ( Max_number < number_of_bcnodes () )  {
	  p_queue <int, bc_node> cp_degrees;
	  forall ( cp, cutpoints)
		if ( !cp->dfs_number )  cp_degrees.insert ( degree (cp), cp );

	  while  ( !cp_degrees.empty () )  {
		 bcn = cp_degrees.inf (cp_degrees.find_min ());
		 cp_degrees.del_item (cp_degrees.find_min ());
		 if ( !dfs_number (bcn) ) {
			if ( root_ == nil ) root_ = cp;
			Max_number = bcn->continue_DFS (Max_number);
  		 }
	  }

	 if ( Max_number < number_of_bcnodes () ) // Es sind noch Stand-Alone Bl�cke geblieben
	    forall ( bl, blocks )
		if ( !dfs_number (bl))  bl->dfs_number = ++Max_number;
	 if ( root_ == nil )
		root_ = blocks.head ();
  }
}

//*********************************************************************
bc_node bctree::common_ancestor (bc_node bcn1, bc_node bcn2) {
  list<bc_node> parents;

  do
   parents.push (bcn1);
  while ( (bcn1 = bcn1->father()) != nil );

  while ( parents.search (bcn2) == nil && (bcn2 = bcn2->father()) != nil )
   ;

  return bcn2;
}

//****************************************************************
// root hat depth = 1
int bctree::depth (bc_node bcn)
{
  int result = 1;
  while ( bcn->dfs_number != 1 ) {
	bcn = bcn->father ();
	result++;
  }
  return result;
}
//****************************************************************
void bctree::del_bc_node (bc_node bcn)  {
   bc_node adj;
   forall ( adj, bcn->adj_nodes)
   		adj->del_bc_node (bcn);

   list_item li;
   if ( is_cutpoint (bcn)) {
   		li = cutpoints.search ((cutpoint)bcn);
		if ( li != nil )
			cutpoints.del_item (li);
		delete (cutpoint)bcn;
   }
   else {
	     li = blocks.search((block)bcn);
		 if ( li != nil )
		 	blocks.del_item (li);
		 delete (block)bcn;
   }
}

//****************************************************************
// This function searches for an edge e, which is adjcent to v,
//checked[e]=false and there are no already checked edges parallel to
node bctree::find_unchecked (node v, edge_array<bool> &checked, bool only_check)
{
  edge e;
  node w = nil;
  forall_inout_edges ( e, v )
    if ( !checked [e] ) {
      if ( only_check )
        return G->opposite (v, e);
      if ( w == nil ) {
        checked[e] = true;
        w = G->opposite (v, e);
      }
     else   // Check for parallel edges.
         if ( G->opposite (v,e) == w )
            checked [e] = true;
     }
 return w;
}

//*****************************************************************
//
void bctree::compute_bcTree ()
{
 node v;
 list<node> all_nodes = G->all_nodes ();

 forall ( v, all_nodes )
	if ( node_owner [v] == nil ) {
		num_connected_comps++;
		compute_SubBCTree (v);
	}
}
//*****************************************************************
// This function computes bc-tree for subgraph of G ( for whole G, if G is connected ),
// and returns the number of processed nodes ( G->number_of_nodes(), if *G is connected ).
//*****************************************************************
int bctree::compute_SubBCTree (node start)
{
 int i=1;
 node v, w;

 if ( start == nil )	v = G->first_node ();
 else {
	if ( !G->degree (start))  {
	   new_block (start);
	   return i;
	}
       v = start;
 }

 node_array<int> DFS_numb (*G,0);
 node_array<node> parent (*G,nil);
 node_array<int> low_point (*G, G->number_of_nodes()+1);
 edge_array<bool> checked (*G,false);
 stack<node> Stack;

 edge e;

 DFS_numb[v] = 1;
 Stack.push (v);

 forall_edges (e, *G) {
   if ( G->source(e) == G->target (e) )
     checked[e] = true;
 }

 do {
   while ( (w = find_unchecked (v, checked)) != nil)
      if ( DFS_numb [w] )
       low_point [v] = Min (DFS_numb [w], low_point [v]);
      else {
         parent [w] = v;
         DFS_numb [w] = ++i;
         low_point [w] = i;
         Stack.push (w);
         v = w;
       }

    if ( parent[v] != start )
      if ( low_point [v] < DFS_numb [parent[v]] )
       low_point [parent[v]] = Min(low_point [v],low_point [parent[v]]);
      else
         new_cutpoint (parent[v], new_block (Stack, v));
    else {
      if ( find_unchecked (start, checked, true) != nil )
         new_cutpoint (start);
      Stack.push (start);
      new_block (Stack, v);
    }
  v = parent [v];

 } while ( (parent[v] != nil) || (find_unchecked (v, checked, true) != nil) );

 return i;
}

/***************************************************************************
 Diese Funktion selektiert die outside Nodes f�r einen Block. Voraussetzung daf�r ist, das
 der Block planar sein mu�, sonst wird false zur�ckgeliefert. Wenn dieser Block ein
 Stand-Alone ist wird ein Face selektiert (kleinster Face), wenn er Pendant ist wird ein Face mit Cutpoint-Knoten selektiert, amsonsten separiert die Funktion einen Face mit cp.vertex () oder einfach einen Face falls cp nicht  �bergeben wird. Der Face = Liste von Knoten, wird unter block.outside_nodes gespeichert*/

bool bctree::set_outside_face (block bl, cutpoint cp)   {
 list<node> result;
 (bl->outside_nodes).clear();

 if ( bl->degree() + bl->number_of_nodes () <= 4 ) {
 	bl->outside_nodes = all_nodes (bl);
    return true;
 }

 GRAPH<node, int> copy;
 node_array<node> orig2copy (*G, nil);
 copy_block (bl, copy, orig2copy );
 if (!PLANAR0 (copy))  return false;
 Make_Bidirected (copy);
 copy.make_planar_map ();
// copy.compute_faces ();

 face fa;
 node n, v;
 list<node> nodes;
 if ( !bl->degree () ) {
	fa = (copy.all_faces ()).head ();
	nodes = copy.adj_nodes (fa);
	forall ( n, nodes )
		if ( (bl->outside_nodes).search (copy[n]) == nil )
			(bl->outside_nodes).push (copy[n]);
	return true;
 }

  v = (cp == nil) ? orig2copy [head_node (bl)] : orig2copy [vertex (cp)];

// edge e = copy.first_adj_edge (v);
// list<face> faces = copy.adj_faces (v);
 fa = copy.face_of (copy.first_adj_edge (v));
 nodes = copy.adj_nodes (fa);
 forall ( n, nodes )
   if (n != v && (bl->outside_nodes).search(copy[n]) == nil && (bl->nodes).search(copy[n]) != nil) // n muss kein Cutpoint sein und muss nicht mehrfach in outside_nodes vorkommen
		(bl->outside_nodes).push (copy[n]);
 return true;

}
//*********************************************************************
bool bctree::remove_outside_node ( block bl )  {
	if ((bl->outside_nodes).size () > 1 ) {
		(bl->outside_nodes).pop ();
		return true;
	}
  return false;
}
//***************************************************************************
void bctree::copy_block (block bl, GRAPH <node, int>& copy, node_array<node>& orig2copy )  {
node n, v;
edge e;
bc_node bcn;
list<node> cpoints;
forall ( bcn, bl->adj_nodes )
 	cpoints.push (bcn->first_node ());

forall (n, bl->nodes)
	orig2copy [n] = copy.new_node (n);

forall (n, cpoints)
	orig2copy [n] = copy.new_node (n);

forall (n, bl->nodes)
 	forall_out_edges (e, n ) {
	        v = G->opposite (n, e);
		copy.new_edge (orig2copy[n], orig2copy[v], 0);
	}
forall (n, cpoints)
 	forall_out_edges (e, n) {
		v = G->opposite (n, e);
		if ( orig2copy[v] != nil )  //v geh�rt zum Block
			copy.new_edge (orig2copy [n], orig2copy [v], 0);
	}
}

//************************************************************
void bctree::print_node (bc_node bcn)
{
  if (bcn->is_cutpoint ()) {
    cout << "Cutpoint, DFS-N=" << bcn->dfs_number << ", ";
    cout << bcn->degree () << " Blocks adj, vertex: ";
    G->print_node (bcn->first_node());
    cout << "\n";
  }
  else {
    node v;
    list<node> nodes = bcn->all_nodes ();
    cout << "Block, DFS-N=" << bcn->dfs_number << ", ";
    cout << bcn->degree () << " Cutpoints adj, Knoten: ";
    forall ( v, nodes )
       G->print_node (v);
    cout << ", Face:";
    forall ( v, ((block)bcn)->outside_nodes)
       G->print_node (v);
    cout << "\n";
  }
}

//******************************************************************
// Diese Funktion
void bctree::coalesce_path (bc_node start,bc_node stop, list<bc_node> &cycl_blocks )
{
 while ( start != stop && start != nil ) {
    if ( !start->is_cutpoint () )
      cycl_blocks.push (start);
    start = father (start);
 }
 if ( start == nil )
    coalesce_path (stop, root_, cycl_blocks );
}

//******************************************************************
block bctree::union_nodes (bc_node bcn1, bc_node bcn2)
{
  bc_node bcn, cp, lca = common_ancestor (bcn1, bcn2);//Gemeinsamer Vorfahren
  if ( lca == nil )
  	return nil; //bcn1 und bcn2 sind nicht connected
  block newb;
  list<bc_node> adj_blocks; //Hier werden alle Blocks auf dem Pfad vom bcn1 zu bcn2 gesammelt
  set<bc_node> adj_cpoints; // Dasselbe f�r Cutpoints, ausserdem sind dabei auch CP's, die
  			    // adj zu den Bl�cken aus der oberen Liste sind.
  node v;

  newb = new_block ();       // Konstruiere einen Leeren Block
  if (is_cutpoint (lca))  {  //Falls der lca ein CP ist, wird der neuer Block ein Sohn
      newb->dfs_number = MAXINT; // von ihm sein. dfs_number vom neuen Block wird minimale
      adj_cpoints.insert (lca); // Num von allen BC_nodes die in diesem Kreis liegen.
   }
  else {		    	// lca = Block - unser neuer Block wird gleiche DFS_num
    adj_blocks.push (lca);  // wie der lca haben
    newb->dfs_number = lca->dfs_number;
  }

  coalesce_path (bcn1, lca, adj_blocks); // sammele alle Blocks auf dem Pfad bcn1-lca
  coalesce_path (bcn2, lca, adj_blocks);

  list<node> nodes;
  forall ( bcn, adj_blocks ) {
	if ( bcn->dfs_number < newb->dfs_number ) newb->dfs_number = bcn->dfs_number;

	forall ( v, (nodes = all_nodes (bcn))) // Addiere alle nodes zum neuen Block
 	   add_node (v, newb);

	forall ( cp, bcn->adj_nodes) adj_cpoints.insert (cp);
	del_bc_node (bcn);
   }

   forall ( bcn, adj_cpoints )
     if ( !bcn->degree ()) {
	  add_node (first_node (bcn), newb); //Jetzt haben einige "Ketten"-CP's (beide adj
		                 //Blocks liegen im Kreis ) zu normalen Knoten degradiert.
	  del_bc_node (bcn);
     }
     else make_nodes_adj (bcn, newb); // oder eben nicht...

  return newb;
}
//******************************************************************
block bctree::union_pendants (cutpoint father, list<block> &pendants)
{
  block newb;
  block blck;
  bc_node cp, bl;
  list<bc_node> adj_blocks;
  set<bc_node> adj_cpoints;
  list <node> nodes;
  node v;

  newb = new_block ();
  newb->dfs_number = MAXINT;
  adj_cpoints.insert (father);

  forall ( blck, pendants )
     coalesce_path (blck, father, adj_blocks);

  forall ( bl, adj_blocks ) {
	 if ( bl->dfs_number < newb->dfs_number ) newb->dfs_number = bl->dfs_number;

	forall ( v, nodes = all_nodes (bl))
 	   add_node (v, newb);

	forall ( cp, bl->adj_nodes) adj_cpoints.insert (cp);
    del_bc_node (bl);
   }

   forall ( cp, adj_cpoints )
      if ( !degree (cp)) {
	   	add_node (cp->first_node (), newb);
	    del_bc_node (cp);
      }
      else  make_nodes_adj (cp, newb);

  return newb;
}
//*******************************************************************************
void bctree::connect_components (edge e)  {
  bc_node source = node_owner[G->source (e)], target = node_owner[G->source (e)];
  block newb = new_block ();

  if ( is_cutpoint (source)) make_nodes_adj (source, newb);
  else {
	  del_node (G->source (e), (block)source);
	  cutpoint cp = new_cutpoint (G->source (e));
	  make_nodes_adj (source, cp);
	  make_nodes_adj (newb, cp);
  }
  if ( is_cutpoint (target)) make_nodes_adj (target, newb);
  else {
	  del_node (G->target (e),(block)target);
	  cutpoint cp = new_cutpoint (G->target (e));
	  make_nodes_adj (target, cp);
	  make_nodes_adj (newb, cp);
  }
//  DFS_num ();
  num_connected_comps--;
}
