

#ifndef Grid_Algorithm_Base_h
#define Grid_Algorithm_Base_h

#include <gt_base/Graphlet.h>
#include <gt_base/Graph.h>

#include <gt_tcl/Tcl_Algorithm.h>
#include <gt_tcl/Tcl_Graph.h>

#include "IGeometry.h"
#include "Undirected_Graph.h"

#include <LEDA/node_array.h>
#include <LEDA/edge_array.h>
#include <LEDA/array.h>


enum Grid_Mapping_Mode { MAX_ALL, MAX_IN_LINE };

class Grid_Algorithm_Base : public GT_Algorithm {

  // parameters
       GT_VARIABLE (bool, max_all_mapping)
       GT_VARIABLE (double, col_sep)
       GT_VARIABLE (double, row_sep)

public:
	Grid_Algorithm_Base (const string& name) : GT_Algorithm(name) {
		col_sep (16.0); row_sep (16.0);
		max_all_mapping (true);
	}

	int run (GT_Graph& g);
	virtual bool compute_layout (Undirected_Graph& G) = 0;

	void init_grid_mapping(GT_Graph &G, Undirected_Graph &my_G, Grid_Mapping_Mode mode = MAX_ALL);
	double map_x_grid (const int column) {
		return col_x [column];
	}
	double map_y_grid (const int row) {
		return row_y [row];
	}
	GT_Point map_grid (const IPoint p) {
		return GT_Point (col_x[p.x], row_y[p.y]);
	}

protected:
	node_array<int> x, y;            // Koordinaten der Knoten
	edge_map<list<IPoint> > bends; // Liste der Knickpunkte der Kante

	// mapping the grid points to graphlet coordinates
	//double col_sep, row_sep;         // Abstand zwischen zwei Spalten bzw. Zeilen
	int max_x, max_y;                // max {x(v) (resp. y(v)) for all nodes v}
	array<double> row_y, col_x;
};


class InOutPoint {
public:
	InOutPoint ()
		{ dx = dy = 0; e = NULL; }
	InOutPoint (edge e1)
		{ e = e1; dx = dy = 0; }
	int  dx, dy;
	edge e;
};

ostream& operator<< (ostream& out, InOutPoint);
istream& operator>> (istream& in, InOutPoint);


struct pair_v_d {
	pair_v_d() { v = NULL; d = 0; }
	pair_v_d(node v_ini, int d_ini) {
		v = v_ini; d = d_ini;
	}

	node v;
	int d;
};

ostream& operator<< (ostream& out, pair_v_d);
istream& operator>> (istream& in, pair_v_d);

template<class E>
list_item get (list<E> &L, list_item it_start, int pos)
{
   if (L.empty()) return nil;
	list_item it = it_start;
	int k = pos % L.length();

	for (int i = 1; i <= k; i++, it = L.cyclic_succ (it)) ;
	return it;
}

template<class E>
list_item get (list<E> &L, int pos) {
   return get (L, L.first(), pos);
}


#endif

