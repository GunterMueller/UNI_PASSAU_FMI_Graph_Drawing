
#ifndef fpp_layout_h
#define fpp_layout_h


#include "Grid_Algorithm_Base.h"
#include <gt_tcl/Tcl_Algorithm.h>
#include <gt_tcl/Tcl_Graph.h>


class GT_Layout_Fpp_Algorithm : public Grid_Algorithm_Base {

	GT_CLASS (GT_Layout_Fpp_Algorithm, GT_Algorithm);

	// parameters
	//GT_VARIABLE (bool, max_all_mapping)

public:
	GT_Layout_Fpp_Algorithm (const string& name) : Grid_Algorithm_Base (name) {
		//the_max_all_mapping = true;
	}

	virtual bool compute_layout (Undirected_Graph& G);
	virtual int check (GT_Graph &g, string& message);

private:
	void compute_coordinates (Undirected_Graph &G,
		node_array<int> &num, node_array<edge> &e_wp,
		node_array<edge> &e_wq);
	void compute_order (Undirected_Graph &G, node_array<int> &num,
		node_array<edge> &e_wp,	node_array<edge> &e_wq,
		edge e_12, edge e_2n, edge e_n1);

};


class GT_Tcl_Layout_Fpp_Algorithm :
	public GT_Tcl_Algorithm<GT_Layout_Fpp_Algorithm>
{
public:
	GT_Tcl_Layout_Fpp_Algorithm (const string& name);
	virtual ~GT_Tcl_Layout_Fpp_Algorithm ();

	virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
};


#endif
