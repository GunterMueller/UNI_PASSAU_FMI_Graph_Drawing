//
// Grid_Algorithm_Base.cpp
//
// This file implements the Grid_Algorithm_Base class.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/grid_algorithms/
//	Grid_Algorithm_Base.cpp,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/09 18:28:38 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

#include "Grid_Algorithm_Base.h"


int Grid_Algorithm_Base::run (GT_Graph& G)
{
    node v;
    edge e, my_e;
    int result = GT_OK;

    Undirected_Graph my_G (G.leda());
    x.init (my_G);
    y.init (my_G);
    bends.init (my_G);

    if (compute_layout (my_G) == true) {
	init_grid_mapping (G, my_G,
	    (max_all_mapping()) ? MAX_ALL : MAX_IN_LINE);

	// Berechne Knoten-Koordinaten
	forall_nodes (v, my_G) {
	    G.gt(my_G.my_to_G(v)).graphics()->x(map_x_grid(x[v]));
	    G.gt(my_G.my_to_G(v)).graphics()->y(map_y_grid(y[v]));
	}

	// Berechne Kanten-Verlauf
	forall_edges (my_e, my_G) {
	    e = my_G.my_to_G (my_e);
	    if (e != nil) {
		GT_Polyline l;
		edge m_e;
		bool is_rev;
		IPoint p;

		if (bends[my_e].empty() == true) {
		    m_e = my_G.rev(my_e); is_rev = true;
		} else {
		    m_e = my_e; is_rev = false;
		}
		bends [m_e].push (
		    IPoint(x[my_G.source(m_e)],y[my_G.source(m_e)]));
		bends [m_e].append
		    (IPoint(x[my_G.target(m_e)],y[my_G.target(m_e)]));

		forall (p, bends[m_e] ) {
		    if (is_rev == true) 
			l.push (map_grid(p));
		    else
			l.append (map_grid(p));
		}
				
		G.gt(e).graphics()->line(l);
	    }
	}

	result = GT_OK;
    } else {
	result = GT_ERROR;
    }
    
    // L�sche Felder wieder
    x = y = node_array<int>();
    bends = edge_map<list<IPoint> >();
	
    return result;
}



void Grid_Algorithm_Base::init_grid_mapping (GT_Graph &G,
    Undirected_Graph &my_G,
    Grid_Mapping_Mode mode)
{
    node v;
    edge e;
    IPoint p;
    int i;

    // Bestimme max_x und max_y
    max_x = max_y = 0;
    forall_nodes (v, my_G) {
	if (x[v] > max_x) max_x = x[v];
	if (y[v] > max_y) max_y = y[v];
    }
    forall_edges (e, my_G)
	forall (p, bends[e]) {
	if (p.x > max_x) max_x = p.x;
	if (p.y > max_y) max_y = p.y;
    }

    // Bestimme row_width[v] und col_width[v] gem�� mode
    row_y = array<double> (0, max_y);
    col_x = array<double> (0, max_x);
    for (i = 0; i <= max_y; i++)
	row_y [i] = 0.0;
    for (i = 0; i <= max_x; i++)
	col_x [i] = 0.0;

    switch (mode) {
	case MAX_ALL:
	    double width;

	    forall_nodes (v, my_G) {
		const GT_Node_Graphics &graphics =
		    *(G.gt(my_G.my_to_G(v)).graphics());
		if (graphics.w() > width) width = graphics.w();
		if (graphics.h() > width) width = graphics.h();
	    }
	    for (i = 0; i <= max_x; i++)
		col_x[i] = width + i*(width+col_sep()) + width/2;
	    for (i = 0; i <= max_y; i++)
		row_y[i] = i*(width+row_sep()) + width/2;
	    for (i = 0; i <= max_y; i++)
		row_y[i] = (row_y[max_y]+width) - row_y[i];

	    break;

	case MAX_IN_LINE:
	    forall_nodes (v, my_G) {
		GT_Node_Graphics &graphics =
		    *(G.gt(my_G.my_to_G(v)).graphics());
		if (graphics.w() > col_x[x[v]])
		    col_x[x[v]] = graphics.w();
		if (graphics.h() > row_y[y[v]])
		    row_y[y[v]] = graphics.h();
	    }

	    double w, sum = col_sep();

	    for (i = 0; i <= max_x; i++) {
		w = col_x[i];
		col_x[i] = sum + w/2;
		sum += w + col_sep();
	    }
	    sum = row_sep();
	    for (i = max_y; i >= 0; i--) {
		w = row_y[i];
		row_y[i] = sum + w/2;
		sum += w + row_sep();
	    }

	    break;
    }
}

//
// I/O Operators as required by LEDA 3.4 (dummy only)
//

ostream& operator<< (ostream& out, InOutPoint)
{
    return out;
}

istream& operator>> (istream& in, InOutPoint)
{
    return in;
}


//
// I/O Operators as required by LEDA 3.4 (dummy only)
//

ostream& operator<< (ostream& out, pair_v_d)
{
    return out;
}

istream& operator>> (istream& in, pair_v_d)
{
    return in;
}
