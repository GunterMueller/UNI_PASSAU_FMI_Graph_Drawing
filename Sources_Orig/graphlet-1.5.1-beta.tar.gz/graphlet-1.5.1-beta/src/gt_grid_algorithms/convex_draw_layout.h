
#ifndef convex_draw_layout_h
#define convex_draw_layout_h


#include "Grid_Algorithm_Base.h"
#include "Canonical_Order.h"
#include <gt_tcl/Tcl_Algorithm.h>
#include <gt_tcl/Tcl_Graph.h>


class GT_Layout_ConvexDraw_Algorithm : public Grid_Algorithm_Base {

	GT_CLASS (GT_Layout_ConvexDraw_Algorithm, GT_Algorithm);

	// parameters
	//GT_VARIABLE (bool, max_all_mapping)
	GT_VARIABLE (bool, size_opt)
	GT_VARIABLE (bool, side_opt)

public:
	GT_Layout_ConvexDraw_Algorithm (const string& name) :
		Grid_Algorithm_Base (name) {
		//the_max_all_mapping = true;
		the_size_opt = true;
		the_side_opt = false;
	}

	virtual bool compute_layout (Undirected_Graph& G);
	virtual int check (GT_Graph &g, string& message);

};


class GT_Tcl_Layout_ConvexDraw_Algorithm :
	public GT_Tcl_Algorithm<GT_Layout_ConvexDraw_Algorithm>
{
public:
	GT_Tcl_Layout_ConvexDraw_Algorithm (const string& name);
	virtual ~GT_Tcl_Layout_ConvexDraw_Algorithm ();

	virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
};


#endif
