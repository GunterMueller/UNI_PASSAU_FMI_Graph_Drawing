
#ifndef Undirected_Graph_h
#define Undirected_Graph_h

#include <LEDA/graph.h>
#include <LEDA/graph_alg.h>
#include <LEDA/node_array.h>
#include <LEDA/edge_array.h>
#include <LEDA/edge_map.h>


class Undirected_Graph : public GRAPH<node,edge> {
public:
	Undirected_Graph (const graph& G);

	// Zugriffsfunktionen
	edge rev (edge e) {
		return reversal(e);
	}
	node G_to_my (node v) {
		return map_v_to_G [v];
	}
	edge G_to_my (edge e) {
		return map_e_to_G [e];
	}
	node my_to_G (node v) {
		return inf(v);
	}
	edge my_to_G (edge e) {
		return inf(e);
	}

	bool is_original (edge e) {
		return (my_to_G(e) != nil);
	}

	edge new_u_edge (node v, node w);
	edge new_u_edge (edge e1, edge e2, int d1, int d2);

	bool is_planar() {
		return PLANAR (*this, false);
	}
	bool is_simple() {
		return Is_Simple (*this);
	}
	bool is_biconnected();

	bool embed_planar() {
		return PLANAR (*this, true);
	}
	void make_bic_planar();

	void my_triangulate (list<edge> &L);
	list<edge> triangulate();

	face max_face ();

private:
	bool visit (node v, node_array<int> &num, int num_count, int &min);

	node_array<node> map_v_to_G;
	edge_array<edge> map_e_to_G;
	//edge_map<edge> rev_edge;
};


bool is_triconnected (Undirected_Graph& g);


#endif
