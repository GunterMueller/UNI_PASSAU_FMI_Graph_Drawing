//
// mixed_model_layout.cpp
//
// This file implements the GT_Layout_MixedModel_Algorithm and
// GT_Tcl_Layout_MixedModel_Algorithm classes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/grid_algorithms/
//	mixed_model_layout.cpp,v $
// $Author: himsolt $
// $Revision: 1.4 $
// $Date: 1996/11/09 18:28:41 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

#include "mixed_model_layout.h"


///////////////////////////////////////////////////////
// GT_Layout_MixedModel_Algorithm
//
// This is the Mixed-Model (Kant) algorithm
///////////////////////////////////////////////////////


int GT_Layout_MixedModel_Algorithm::check (GT_Graph &g, string& message)
{
	if (g.leda().number_of_nodes() < 3) {
		message = "The graph must have at least three nodes!";
		return TCL_ERROR;
	}
	if (Is_Simple (g.leda()) == false) {
		message = "The graph must be simple!";
		return TCL_ERROR;
	}

	Undirected_Graph ug (g.leda());
	if (is_triconnected (ug) == false) {
		message = "The graph must be triconnected!";
		return TCL_ERROR;
	}
	if (ug.is_planar() == false) {
		message = "The graph must be planar!";
		return TCL_ERROR;
	}
	message = "everything ok";
	return GT_OK;
}


bool GT_Layout_MixedModel_Algorithm::compute_layout (Undirected_Graph& G)
{
	G.embed_planar();

	Lmc_Order lmc (G, CO_TRICONNECTED, max_outer(), prefer_nodes());
	node_array<list_item> next_left(G), next_right(G);

	iop.init(G);

	const int m = lmc.length();

	node		v, cl, cr, z1;
	edge		e, e1;
	int			i, k, p;
	list_item	it;

	the_bb_upper.init(G);

	node v1 = lmc(1,1), v2 = lmc(1,2);

	forall_out_edges (e1, v1)
		if (G.target(e1) == v2) break;
	iop.append_in_point (e1);

	iop.append_in_point (G.reversal(e1));

	for (e = G.cyclic_adj_pred(e1); e != e1; e = G.cyclic_adj_pred(e))
		iop.append_out_point (e);
	for (e = G.face_cycle_succ(e1); e != G.reversal(e1); e = G.cyclic_adj_pred(e))
		iop.append_out_point (e);
	for (k = 2; k <= m; k++) {
		const Order_Set &V = lmc[k];
		p = V.len();
		cl = V.left(); cr = V.right();
		for (i = 1; i <= p; i++) {
			v = V[i];
			node v_r = (i == p) ? cr : V[i+1],
			v_l = (i == 1) ? cl : V[i-1];
			edge el = nil, er = nil;
			forall_out_edges (e, v) {
				if (G.target(e) == v_l) el = e;
				if (G.target(e) == v_r) er = e;
			}
			if (el == nil) el = er;
			if (er == nil) er = el;
			for (e = G.cyclic_adj_pred(el); e != er; e = G.cyclic_adj_pred(e))
				iop.append_out_point (e);
			e = er;
			while (true) {
				iop.push_in_point (e);
				if (e == el)
					break;
				e = G.cyclic_adj_pred(e);
			}
		}
	}

	forall_nodes (v, G) {
		const list<InOutPoint> &L_out = iop.out_points (v),
			&L_in = iop.in_points (v);
		it = next_left [v] = L_out.first();
		next_right [v] = L_out.last();

		if (v == v1) {
			set_out_coord (v, OS_left);
		} else if (v == v2) {
			set_out_coord (v, OS_right);
		} else {
			const Order_Set &V  = lmc[lmc.rank(v)];
			if (v == V[1] && V.has_left() == false) {
				set_out_coord (v, OS_left);
			} else if (v == V[V.len()] && V.has_right() == false) {
				set_out_coord (v, OS_right);
			} else {
				set_out_coord (v, OS_middle);
			}
		}
		if (in(v) > 3) {
			it = L_in.first();
			iop.set_in_coord (v, it, -in_l(v), 0);
			for (i = 1, it = L_in.succ(it); i <= in_l(v); i++, it =
				L_in.succ(it))
			{
				iop.set_in_coord (v, it, -in_l(v)+i-1, -i);
			}
			iop.set_in_coord (v, it, 0, -in_r(v));
			for (i = 1, it = L_in.succ(it); i <= in_r(v); i++, it =
				L_in.succ(it))
			{
				iop.set_in_coord (v, it, i, -in_r(v)+i-1);
			}
			iop.set_in_coord (v, it, in_r(v), 0);
		}
	}

	space = array<int>(1, m);
	for (i = 1; i <= m; i++)
		space[i] = 0;
	comp .init(G, 0);
	shift.init(G, 0);
	compL.init(G);
	prev .init(G);
	next .init(G);
	upper.init(G, nil);

	node w, c_start;
	int  sum, u1dx, u1dy, u2dx, u2dy;
	bool has_left, has_right;

	y [v1] = y [v2] = 0;
	x [v1] = bb_ul(v1); x [v2] = bb_ur(v1) + bb_ul(v2) + 1;

	next [v1] = v2;  next [v2] = nil;
	prev [v1] = nil; prev [v2] = v1;
	c_start = v1;

	for (k = 2; k <= m; k++) {
		const Order_Set &Vk = lmc[k];
		p  = Vk.len();
		z1 = Vk[1];
		cl = lmc.left(k); cr = lmc.right(k);
		has_left  = Vk.has_left();
		has_right = Vk.has_right();

		if (has_left == true) {
			const InOutPoint &u = iop.out_points (cl, next_right [cl]);
			u1dx = u.dx; u1dy = u.dy;
		} else {
			u1dx = (next_right[cl] == nil) ? -bb_ul(cl) :
				iop.out_points (cl, next_right[cl]).dx+1;
			u1dy = 1;
		}

		if (has_right == true) {
			const InOutPoint &u = iop.out_points (cr, next_left [cr]);
			u2dx = u.dx; u2dy = u.dy;
		} else {
			 u2dx = (next_left[cr] == nil) ? bb_ur(cr) :
				iop.out_points(cr, next_left[cr]).dx-1;
			 u2dy = 1;
		}

		if (backshift() == true) {
			 perform_backshift (c_start, cr, lmc);
			 c_start = z1;
		}

		// compute relative x-distance from ci to cl for i = p+1, ..., r
		for (sum = 0, v = next[cl]; v != cr; v = next[v]) {
			sum += x[v]; x[v] = sum;
		}
		x[cr] += sum;

		int y_max = Max ( (u1dx > 0) ? y[cl]+u1dy : (y[cl] + Max(1,u1dy)) ,
						  (u2dx < 0) ? y[cr]+u2dy : (y[cr] + Max(1,u2dy)));

		for (v = next[cl]; v != cr; v = next[v]) {
			if (y[v]+bb_upper(v)+1 > y_max) {
				y_max = y[v]+bb_upper(v)+1;
			}
		}
		w = (in(z1) >= 3) ? G.target (iop.in_points (z1, get (iop.in_points(
			z1), in_l(z1)+1)).e) : cl;

		for (i = 2, sum = 0; i <= p; i++) {
			sum += (x[Vk[i]] = bb_ur(Vk[i-1]) + bb_ul(Vk[i]) + 1);
			y [Vk[i]] = y_max;
		}

		if (in(z1) >= 3) {
			const InOutPoint &u_w = iop.out_points(w, next_right [w]);
			x[z1] = Max (x[w]+u_w.dx, Max(bb_ll(z1),bb_ul(z1))+u1dx);
			int delta = x[z1] - (x[w]+u_w.dx);
			x[cr] = Max (Max(bb_lr(z1), bb_ur(z1))-u2dx, x[cr]+delta-x[z1]);
			int x_w = x[w];
			for (v = next[cl]; v != w; v = next[v]) {
				upper[v] = z1; x[v] -= x[z1];
			}
			for ( ; v != cr; v = next[v]) {
				upper[v] = z1; x[v] -= x_w + u_w.dx;
			}
		} else {
			x[z1] = bb_ul(z1) + u1dx;
			int s1 = bb_ur(Vk[p])-u2dx, s2 = x[cr]-x[z1]-sum;
			x[cr] = Max (s1, s2);
			space [k] = Max (0, x[cr]-s1);
			if (s1-s2 > 0) {
				shift[cr] += (s1-s2);
			}
			for (v = next[cl]; v != cr; v = next[v]) {
				upper[v] = z1; x[v] -= x[z1];
			}
		}
		y[z1] = y_max + bb_lower(z1);

		// update contour after insertion of z1,...,zp
		for (i = 1; i <= p; i++) {
			if (i < p) next[Vk[i]] = Vk[i+1];
			if (i > 1) prev[Vk[i]] = Vk[i-1];
		}

		next [cl] = z1;    next [Vk[p]] = cr;
		prev [cr] = Vk[p]; prev [z1]    = cl;

		if (has_left == true) {
			next_right [cl] = iop.out_points (cl).pred (next_right[cl]);
		}
		if (has_right == true) {
			next_left  [cr] = iop.out_points (cr).succ (next_left [cr]);
		}
	}

	if (backshift() == true) {
		perform_backshift (c_start, v2, lmc);
	}

	// compute final comp values:
	if (backshift() == true) {
		compute_comp (G, lmc);
	}

	// compute final x-coordinates for nodes on final contour
	for (sum = 0, v = v1; v != nil; v = next[v]) {
		x [v] = (sum += x[v]);
	}

	// compute final x-coordinates for inner nodes
	for (k = m; k >= 2; k--) {
		for (i = 1; i <= lmc.len(k); i++) {
			node zi = lmc(k,i);
			if (upper[zi] != nil) {
				x[zi] += (x[upper[zi]] - comp[upper[zi]]);
			}
		}
	}

	if (do_postprocessing() == true) {
		postprocessing (G);
	}

	init_bends (G);

	iop.clear();
	space = array<int>();
	comp  = shift = node_array<int>();
	prev  = next = upper = node_array<node>();
	compL = node_array<list<pair_v_d> >();
	S = list<node>();

	return true;
}

// bounding box of node v
int GT_Layout_MixedModel_Algorithm::bb_upper (node v) {
	return the_bb_upper [v];
}

int GT_Layout_MixedModel_Algorithm::bb_lower (node v) {
	return in_r(v);
}

int GT_Layout_MixedModel_Algorithm::bb_ll (node v) {
	const list<InOutPoint> &L = iop.in_points(v);
	return (L.empty()) ? 0 : -L[L.first()].dx;
}

int GT_Layout_MixedModel_Algorithm::bb_lr (node v) {
	const list<InOutPoint> &L = iop.in_points(v);
	return (L.empty()) ? 0 : L[L.last()].dx;
}

int GT_Layout_MixedModel_Algorithm::bb_ul (node v) {
	const list<InOutPoint> &L = iop.out_points(v);
	return (L.empty()) ? 0 : -L[L.first()].dx;
}

int GT_Layout_MixedModel_Algorithm::bb_ur (node v) {
	const list<InOutPoint> &L = iop.out_points(v);
	return (L.empty()) ? 0 : L[L.last()].dx;
}

void GT_Layout_MixedModel_Algorithm::set_out_coord (node v,
	Outpoint_Style style)
{
	const list<InOutPoint> &L = iop.out_points(v);
	int on_left, on_right;
	int i, y_mid, y_left, y_right;
	list_item it;

	switch (style) {
	case OS_left:
		on_left = out_r(v);
		y_mid = out_l(v);
		y_left = 0;
		y_right = 1;
		break;
	case OS_middle:
		on_left = out_l(v);
		y_mid = out_r(v);
		y_left = 1;
		y_right = 1;
		break;
	case OS_right:
		on_left = out_l(v);
		y_mid = out_l(v);
		y_left = 1;
		y_right = 0;
		break;
	}
	the_bb_upper [v] = y_mid;
	on_right = out(v) - on_left - 1;

	if (out(v) == 0) return;
	for (i = 0, it = L.first(); i < on_left; i++, it = L.succ(it)) {
		iop.set_out_coord (v, it, -on_left + i, y_left + i);
	}
	iop.set_out_coord (v, it, 0, y_mid);
	for (i = 1, it = L.succ(it); i <= on_right; i++, it = L.succ(it)) {
		iop.set_out_coord (v, it, i, on_right - i + y_right);
	}
}

void GT_Layout_MixedModel_Algorithm::perform_backshift (node from, node to,
	Lmc_Order& lmc)
{
	int d;
	node v;

	for (v = from; v != to; v = next[v]) {
		if (shift[v] > 0) S.push(v);
		while (!S.empty() && lmc.rank(v) <= lmc.rank(S.head()) && in(v) >= 3) {
			S.pop();
		}
		while (!S.empty() && lmc.rank(v) <= lmc.rank(S.head()) &&
			space[lmc.rank(v)] > 0) {
			d = Min(shift[S.head()], space[lmc.rank(v)]);
			compL [S.head()].append (pair_v_d(v,d));
			shift[S.head()] -= d; space[lmc.rank(v)] -= d;
			x[lmc[lmc.rank(v)].right()] -= d;
			if (shift[S.head()] == 0) S.pop();
		}
	}
}

void GT_Layout_MixedModel_Algorithm::compute_comp (Undirected_Graph &G,
	Lmc_Order& lmc)
{
	const int m = lmc.length();
	node_array<int> sum (G, 0);
	node_array<list<pair_v_d> > L(G);
	array<list<pair_v_d> > compLR (1, m);
	list<pair_v_d> LR;
	int i, j, s, d;
	node v;
	pair_v_d vd;

	forall_nodes (v, G)
		forall (vd, compL [v])
			sum[v] += vd.d;

	for (i = m; i >= 1; i--) {
		const Order_Set &Vi = lmc[i];
		if (lmc.right(i) != nil) {
			s = d = 0;
			for (j = Vi.len(); j >= 1; j--) {
				list<pair_v_d> &L1 = compL [Vi[j]];
				L1.conc (L[Vi[j]]);
				while (!L1.empty() && L1.head().v == Vi[j])
					d += L1.pop().d;
				LR.conc(L1);
			}
			for (j = 1; j <= Vi.len(); j++) {
				s += sum[Vi[j]];
				comp[Vi[j]] += s;
			}
			L[lmc.right(i)].conc (LR);
			sum[lmc.right(i)] += s - d;
		}
	}
}

void GT_Layout_MixedModel_Algorithm::postprocessing (Undirected_Graph &G)
{
	node v;

	forall_nodes (v, G) {
		const list<InOutPoint> &L_in = iop.in_points(v);
		if (in(v) == 2 && out(v) == 2) {
			const InOutPoint
				&p_in1  = L_in [L_in.first()],
				&p_in2  = L_in [L_in.last()],
				&p_out1 = iop.point_of (G.reversal(p_in1.e)),
				&p_out2 = iop.point_of (G.reversal(p_in2.e));

			if (x[G.source(p_out1.e)]+p_out1.dx < x[v]+p_in1.dx &&
				y[G.source(p_out2.e)] < y[v])
			{
				const list<InOutPoint> &L_out = iop.out_points(v);
				x[v] += 1;
				iop.out_dx (v, L_out.first()) -= 1;
				iop.out_dx (v, L_out.last ()) -= 1;
			}
		}
	}
}

void GT_Layout_MixedModel_Algorithm::make_edge_seg (Undirected_Graph& G,
	const InOutPoint& p_s, InOutPoint& p_t, list<IPoint>& seg)
{
	const edge e = p_s.e;
	node v_s = G.source(e), v_t = G.target(e);
	IPoint p1 = IPoint (x[v_s] + p_s.dx, y[v_s] + p_s.dy),
		   p2 = IPoint (x[v_t] + p_t.dx, y[v_t] + p_t.dy);

	if (p1 != IPoint(x[v_s],y[v_s]) && p1 != IPoint(x[v_t],y[v_t])) {
		seg.append (p1);
	}
	if (p1.x != p2.x && p1.y != p2.y) {
		seg.append (IPoint(p1.x,p2.y));
	}
	if (p1 != p2 && p2 != IPoint(x[v_t],y[v_t])) {
		seg.append (p2);
	}
}

void GT_Layout_MixedModel_Algorithm::init_bends (Undirected_Graph &G)
{
	node v;
	list_item it;
	edge_array<InOutPoint *> in_point (G);

	forall_nodes (v, G) {
		list<InOutPoint> &L_in = iop.in_points(v);
		forall_items (it, L_in) {
			in_point [L_in[it].e] = &L_in[it];
		}
	}

	forall_nodes (v, G) {
		const list<InOutPoint> &L_out = iop.out_points(v);
		forall_items (it, L_out) {
			const InOutPoint &p = L_out[it];
			make_edge_seg (G, p, *in_point[G.rev(p.e)], bends[p.e]);
		}
	}
}


///////////////////////////////////////////////////////
// GT_Tcl_Layout_MixedModel_Algorithm
//
///////////////////////////////////////////////////////

GT_Tcl_Layout_MixedModel_Algorithm::GT_Tcl_Layout_MixedModel_Algorithm (
	const string& name) :
	GT_Tcl_Algorithm<GT_Layout_MixedModel_Algorithm> (name)
{
}


GT_Tcl_Layout_MixedModel_Algorithm::~GT_Tcl_Layout_MixedModel_Algorithm ()
{
}


int GT_Tcl_Layout_MixedModel_Algorithm::parse (GT_Tcl_info& info, int& index,
	GT_Tcl_Graph* /*g*/)
{
	int code;

	if (streq (info[index], "-backshift") && !info.is_last_arg(index)) {
		index++;

		int do_backshift;
		code = Tcl_GetBoolean (info.interp(), info[index++],
			&do_backshift);
		if (code != TCL_ERROR) {
			backshift (bool(do_backshift));
		} else {
			return code;
		}

	} else if (streq (info[index], "-max_outer") && !info.is_last_arg(index)) {
		index++;

		int do_max_outer;
		code = Tcl_GetBoolean (info.interp(), info[index++],
			&do_max_outer);
		if (code != TCL_ERROR) {
			max_outer (bool(do_max_outer));
		} else {
			return code;
		}

	} else if (streq (info[index], "-prefer_nodes") && !info.is_last_arg(
		index))
	{
		index++;

		int do_prefer_nodes;
		code = Tcl_GetBoolean (info.interp(), info[index++],
			&do_prefer_nodes);
		if (code != TCL_ERROR) {
			prefer_nodes (bool(do_prefer_nodes));
		} else {
			return code;
		}

	} else {
		string msg ("Unrecognized argument %s", info[index]);
		info.msg (msg);
		return TCL_ERROR;
	}

	return TCL_OK;
}
