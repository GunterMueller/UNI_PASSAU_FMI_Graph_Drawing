
#ifndef oh_h
#define oh_h

list<edge> onehalf (graph &GO );

#endif
