//
// mixed_model_layout.cpp
//
// This file defines the GT_Layout_MixedModel_Algorithm and
// GT_Tcl_Layout_MixedModel_Algorithm classes.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/gt_grid_algorithms/
//	mixed_model_layout.h,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/09 18:28:41 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

#ifndef mixed_model_layout_h
#define mixed_model_layout_h


#include "Grid_Algorithm_Base.h"
#include "Canonical_Order.h"
//#include <gt_tcl/Tcl_Algorithm.h>
//#include <gt_tcl/Tcl_Graph.h>


///////////////////////////////////////////////////////////
//                 auxiliary classes
///////////////////////////////////////////////////////////

// represantation of in- and outpoint lists

class IOPoints {
public:
	IOPoints () { }
	IOPoints (Undirected_Graph& G) {
		g = &G;
		in.init (G);
		out.init (G);
		the_point_of.init (G);
	}
	~IOPoints () { }

	void init (Undirected_Graph& G) {
		g = &G;
		in.init (G);
		out.init (G);
		the_point_of.init (G);
	}

	void clear () {
	  in = out = node_array<list<InOutPoint> >();
		the_point_of = edge_array<InOutPoint *>();
	}

	void append_in_point (edge e) {
		node v = g->source(e);
		the_point_of [e] = &(in[v] [in[v].append (InOutPoint(e))]);
	}
	void append_out_point (edge e) {
		node v = g->source(e);
		the_point_of [e] = &(out[v] [out[v].append (InOutPoint(e))]);
	}
	void push_in_point (edge e) {
		node v = g->source(e);
		the_point_of [e] = &(in[v] [in[v].push (InOutPoint(e))]);
	}
	void push_out_point (edge e) {
		node v = g->source(e);
		the_point_of [e] = &(out[v] [out[v].push (InOutPoint(e))]);
	}

	void set_out_coord (node v, list_item it, int x, int y) {
		out[v][it].dx = x;
		out[v][it].dy = y;
	}
	void set_in_coord (node v, list_item it, int x, int y) {
		in[v][it].dx = x;
		in[v][it].dy = y;
	}

	int& out_dx (node v, list_item it) {
		return out[v][it].dx;
	}
	int& out_dy (node v, list_item it) {
		return out[v][it].dy;
	}
	int& in_dx (node v, list_item it) {
		return in[v][it].dx;
	}
	int& in_dy (node v, list_item it) {
		return in[v][it].dy;
	}

	list<InOutPoint>& in_points (node v) {
		return in [v];
	}
	const list<InOutPoint>& out_points (node v) {
		return out [v];
	}
	const InOutPoint& in_points (node v, list_item it) {
		return in [v] [it];
	}
	const InOutPoint& out_points (node v, list_item it) {
		return out [v] [it];
	}

	InOutPoint point_of (edge e) {
		return *(the_point_of [e]);
	}

private:
	Undirected_Graph *g;
	node_array<list<InOutPoint> > in, out;
	edge_array<InOutPoint *> the_point_of;
};


///////////////////////////////////////////////////////////
//            GT_Layout_MixedModel_Algorithm
///////////////////////////////////////////////////////////

class GT_Layout_MixedModel_Algorithm : public Grid_Algorithm_Base {

	GT_CLASS (GT_Layout_MixedModel_Algorithm, GT_Algorithm);

	// parameters
	GT_VARIABLE (bool, backshift)
	GT_VARIABLE (bool, max_outer)
	GT_VARIABLE (bool, prefer_nodes)
	GT_VARIABLE (bool, do_postprocessing)

public:
	GT_Layout_MixedModel_Algorithm (const string& name) :
		Grid_Algorithm_Base (name)
	{
		backshift (true);
		max_outer (true);
		prefer_nodes (false);
		do_postprocessing (true);
	}

	virtual bool compute_layout (Undirected_Graph& G);
	virtual int check (GT_Graph &g, string& message);

private:
	enum Outpoint_Style { OS_left, OS_middle, OS_right };

	int out (node v) {
		return iop.out_points(v).length();
	}
	int in (node v) {
		return iop.in_points(v).length();
	}

	int out_l (node v) {
		int l = out(v)-1;
		return (l < 0) ? 0 : l/2;
	}
	int out_r (node v) {
		return out(v) / 2;
	}
	int in_l (node v) {
		int l = in(v)-3;
		return (l < 0) ? 0 : l/2;
	}
	int in_r (node v) {
		int l = in(v)-2;
		return (l < 0) ? 0 : l/2;
	}

	// bounding box of node v
	int bb_upper (node v);
	int bb_lower (node v);
	int bb_ll (node v);
	int bb_lr (node v);
	int bb_ul (node v);
	int bb_ur (node v);

	void set_out_coord (node v, Outpoint_Style style);
	void postprocessing (Undirected_Graph &G);

	void make_edge_seg (Undirected_Graph& G, const InOutPoint& p_s,
		InOutPoint& p_t, list<IPoint>& seg);
	void init_bends (Undirected_Graph &G);

	void perform_backshift (node from, node to, Lmc_Order& lmc);
	void compute_comp (Undirected_Graph &G, Lmc_Order& lmc);

	IOPoints                    iop;
	array<int>                  space;
	node_array<int>             shift, comp;
	node_array<list<pair_v_d> > compL;
	node_array<node>            prev, next, upper;
	list<node>                  S;
	node_array<int>             the_bb_upper;
};


class GT_Tcl_Layout_MixedModel_Algorithm :
	public GT_Tcl_Algorithm<GT_Layout_MixedModel_Algorithm>
{
public:
	GT_Tcl_Layout_MixedModel_Algorithm (const string& name);
	virtual ~GT_Tcl_Layout_MixedModel_Algorithm ();

	virtual int parse (GT_Tcl_info& info, int& index, GT_Tcl_Graph* g);
};


#endif
