//
// Undirected_Graph.cpp
//
// This file implements the Undirected_Graph class.
//
//------------------------------------------
//
// $Source: /home/br/CVS/graphlet/src/grid_algorithms/
//	Undirected_Graph.cpp,v $
// $Author: himsolt $
// $Revision: 1.3 $
// $Date: 1996/11/09 18:28:38 $
// $Locker:  $
// $State: Exp $
//
//------------------------------------------
//

#include "Undirected_Graph.h"
#include "oh.h"


Undirected_Graph::Undirected_Graph (const graph &G) : GRAPH<node,edge>() {
   node v;
   edge e;

   map_v_to_G.init(G,nil);
   map_e_to_G.init(G,nil);

   // Kopie anfertigen
   forall_nodes (v, G)
	  map_v_to_G [v] = new_node(v);
   forall_edges (e, G)
	  map_e_to_G [e] = new_edge(G_to_my(source(e)), G_to_my(target(e)), e);

   // erforderliche Eigenschaften des Graphen herstellen
   Make_Bidirected(*this);

   //reverse Kanten berechnen
   make_map();
}


edge Undirected_Graph::new_u_edge (node v, node w)
{
	edge e1, e2;

	e1 = new_edge (v, w, (edge) nil);
	e2 = new_edge (w, v, (edge) nil);

	set_reversal (e1, e2);

	return e1;
}


list<edge> Undirected_Graph::triangulate()
{
	list<edge> added_edges;

	added_edges = TRIANGULATE_PLANAR_MAP (*this);
	make_map();
	//my_triangulate (added_edges);
	return added_edges;
}


void Undirected_Graph::make_bic_planar()
{

	onehalf (*this);
   
   Make_Bidirected(*this);
   make_map();

}


bool Undirected_Graph::visit (node v, node_array<int> &num, int num_count,
	int &min)
{
	node w;
	edge e;
	int m;

	min = num[v] = ++num_count;
	forall_out_edges (e, v) {
		w = target(e);
		if (num[w] == 0) {
			if (visit(w, num, num_count, m) == false) return false;
			if (m < min) min = m;
			if (m >= num [v]) return false;
		} else
			if (num [w] < min) min = num [w];
	}
	return true;
}

bool Undirected_Graph::is_biconnected()
{
	node_array<int> num ((*this), 0);
	node v, w;
	edge e;
	int sons, m, num_count = 0;

	v = first_node();
	sons = 0;
	num[v] = ++num_count;
	forall_out_edges (e, v) {
		w = target(e);
		if (num[w] == 0) {
			sons++;
			if (visit(w, num, num_count, m) == false) return false;
		}
	}
	if (sons > 1) return false;
	forall_nodes (v, (*this))
		if (num [v] == 0) return false;
	return true;
}


bool is_triconnected (Undirected_Graph& g)
{
	Undirected_Graph G (g);
	node  v;
	edge  e;
	list<node> vertices;
	list<node> L_in, L_out;

	if (g.is_biconnected() == false)
		return false;

	forall_nodes (v, G)
		vertices.append (v);

	while (!vertices.empty()) {
		v = vertices.pop();
		// Merke alle adjazenten Knoten in L_in und L_out
		forall_in_edges (e, v)
			L_in.append (G.source(e));
		forall_out_edges (e, v)
			L_out.append (G.target(e));

		// Teste, ob G nach L�schen von v noch 2-zshgd. ist
		G.del_node (v);

		if (G.is_biconnected() == false) {
			return false;
		}

		// F�ge Knoten v und Kanten wieder ein
		v = G.new_node();
		while (!L_in.empty())
			G.new_edge (L_in.pop(), v);
		while (!L_out.empty())
			G.new_edge (v, L_out.pop());
	}
	return true;
}


edge Undirected_Graph::new_u_edge (edge e1, edge e2, int d1, int d2)
{
   edge en1, en2;

   en1 = new_edge (e1, e2, d1, d2);
   en2 = new_edge (rev(e2), rev(e1), d2, d1);
   set_reversal(en1, en2);

   return en1;
}

void init_adjacent (node v, node_array<bool> &adjacent, Undirected_Graph &G)
{
   edge e;

   forall_out_edges (e, v)
	  adjacent [G.target(e)] = true;
}

void reset_adjacent (node v, node_array<bool> &adjacent, Undirected_Graph &G)
{
   edge e;

   forall_out_edges (e, v)
	  adjacent [G.target(e)] = false;
}

void Undirected_Graph::my_triangulate (list<edge> &L)
{
   list<edge> edges;
   edge_map<bool> visited (*this, false);
   node_array<bool> adjacent (*this, false);
   edge e, e1, e2, e_start;

   edges = all_edges();
   forall (e1, edges)
	  if (visited [e1] == false) {
	 visited [e1] = true;
		 e_start = e1;
		 init_adjacent (source(e_start), adjacent, *this);
		 e = cyclic_adj_succ(rev(e_start));
		 visited [e] = true;
		 while (cyclic_adj_succ(rev(e)) != rev(cyclic_adj_pred(e_start))) {
			if (source(e_start) != target(e) && adjacent[target(e)] == false) {
			   adjacent[target(e)] = true;
			   e2 = e; e = cyclic_adj_succ(rev(e));
			   e_start = new_u_edge (e_start, e2, before, after);
			   L.append(e_start); L.append(rev(e_start));
			} else {
			   reset_adjacent(source(e_start), adjacent, *this);
			   e_start = e;
			   e = cyclic_adj_succ (rev(e));
			   init_adjacent(source(e_start), adjacent, *this);
			}
			visited[e] = true;
		 }
		 visited [cyclic_adj_succ(rev(e))] = true;
		 reset_adjacent (source(e_start), adjacent, *this);
	  }
}

face Undirected_Graph::max_face ()
{
	int max = 0;
	face f, f_max = nil;

	forall_faces (f, (*this)) {
		if (size(f) >= max) {
			max = size(f);
			f_max = f;
		}
	}
	return f_max;
}

