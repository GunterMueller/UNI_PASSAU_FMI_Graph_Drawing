
#ifndef IGeometry_h
#define IGeometry_h


class IPoint {
public:
	IPoint () {
		x = y = 0;
	}
	IPoint (const int x_ini, const int y_ini) {
		x = x_ini;
		y = y_ini;
	}
	IPoint (const IPoint& p) {
		x = p.x;
		y = p.y;
	}

	bool operator!= (const IPoint& p) {
		return (x != p.x || y != p.y);
	}

	int x, y;
};



//
// I/O Operators as required by LEDA 3.4 (dummy only)
//

inline ostream& operator<< (ostream& out, IPoint)
{
    return out;
}

inline istream& operator>> (istream& in, IPoint)
{
    return in;
}

#endif
