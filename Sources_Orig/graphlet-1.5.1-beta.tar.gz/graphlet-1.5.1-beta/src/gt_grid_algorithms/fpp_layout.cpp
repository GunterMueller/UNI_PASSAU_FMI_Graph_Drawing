
#include "fpp_layout.h"


///////////////////////////////////////////////////////
// GT_Layout_Fpp_Algorithm
//
// This is the de Fraysseix, Pach, Pollack algorithm
///////////////////////////////////////////////////////

int GT_Layout_Fpp_Algorithm::check (GT_Graph &g, string& message)
{
	if (g.leda().number_of_nodes() < 3) {
		message = "The graph must have at least three nodes!";
		return TCL_ERROR;
	}
	if (Is_Simple(g.leda()) == false) {
		message = "The graph must be simple!";
		return TCL_ERROR;
	}

	if (Is_Connected(g.leda()) == false) {
		message = "The graph must be connected!";
		return TCL_ERROR;
	}
	
	
	Undirected_Graph ug (g.leda());

	if (ug.is_planar() == false) {
    	message = "The graph must be planar!";
    	return TCL_ERROR;
	} 
	
	message = "everything ok";
	return GT_OK;
}


bool GT_Layout_Fpp_Algorithm::compute_layout (Undirected_Graph& G)
{
  G.make_bic_planar();
	G.embed_planar();
	G.triangulate();
	
	edge e_12 = G.first_edge(),
		e_2n = G.cyclic_adj_pred(G.rev(e_12));

	node_array<int>  num (G);
	node_array<edge> e_wp (G), e_wq (G);

	compute_order (G, num , e_wp, e_wq, e_12, e_2n, G.cyclic_adj_pred(
		G.rev(e_2n)));
	compute_coordinates (G, num, e_wp, e_wq);

	return true;
}

void GT_Layout_Fpp_Algorithm::compute_order (Undirected_Graph &G,
	node_array<int> &num, node_array<edge> &e_wp,
	node_array<edge> &e_wq, edge e_12, edge e_2n, edge e_n1)
{
	node_array<int>       num_diag (G, 0);	// Anzahl der Diagonalen
	node_array<list_item> link (G, NULL);	// link[v] = Listitem in possible, das v enth�lt, falls diag[v] = 0 und outer[v] = true
	node_array<int>       outer (G, false);	// outer[v] = true <=> v ist Knoten der aktuellen Au�enregion

	list<node> possible;	// Liste aller Knoten v mit outer[v] = true
							// und diag[v] = 0
	// Knoten der Au�enregion ( = Dreieck(v_1,v_2,v_n) )
	node v_1 = G.source (e_12), v_2 = G.target (e_12), v_n = G.target (e_2n);
	node v_k, wp, wq, u;
	edge e, e2;
	int k;

	// Initialisierung (Beginne mit Au�enfl�che (v_1,v_2,v_n) und v_n einziger
	// m�glicher n�chster Knoten
	num [v_1] = 1;
	num [v_2] = 2;
	outer [v_1] = outer [v_2] = outer [v_n] = true;
	link [v_n] = possible.append (v_n);
	e_wq [v_1] = G.rev(e_n1); e_wp [v_2] = e_2n;
	e_wp [v_n] = e_n1; e_wq [v_n] = G.rev(e_2n);

	// W�hle nacheinander v_k und entferne v_k
	for (k = G.number_of_nodes(); k >= 3; k--) {
		v_k = possible.pop();	// W�hle beliebigen Knoten aus possible als v_k
		num [v_k] = k;

		// Bestimme Vorg�nger wp und Nachfolger wq von vk in C_k (= aktuelle
		// Au�enregion)
		wp = G.target (e_wp [v_k]);
		wq = G.target (e_wq [v_k]);

		// v_k nicht mehr in C_k-1 (= neue Au�enregion)
		outer [v_k] = false;

		// Wegfall einer Diagonalen ?
		if (G.target (G.cyclic_adj_pred (e_wp[v_k])) == wq) {
			// wp, wq einzige Nachfolger von vk in G_k
			// dann: wp, wq verlieren eine Diagonale
			if (--num_diag[wp] == 0) link [wp] = possible.append (wp);
			if (--num_diag[wq] == 0) link [wq] = possible.append (wq);
		}

		// Aktualisiere bzw. initialisiere e_wq, e_wp
		e_wq [wp] = G.cyclic_adj_succ (e_wq[wp]);
		e_wp [wq] = G.cyclic_adj_pred (e_wp[wq]);
		e = e_wq[wp];
		for (u = G.target(e); u != wq; u = G.target(e)) {
			outer [u] = true;
			e_wp [u] = G.rev(e);
			e = e_wq [u] = G.cyclic_adj_succ (G.cyclic_adj_succ(e_wp[u]));

			// Suche neue Diagonalen
			for (e2 = G.cyclic_adj_pred(e_wp[u]); e2 != e_wq[u]; e2 =
				G.cyclic_adj_pred(e2)) {

				node w = G.target(e2);
				if (outer [w] == true) {
					++num_diag [u];
					if (w != v_1 && w != v_2)
						if (++num_diag [w] == 1) possible.del_item (link[w]);
				}
			}
			if (num_diag [u] == 0) link [u] = possible.append (u);
		}

	}
}

void GT_Layout_Fpp_Algorithm::compute_coordinates (Undirected_Graph &G,
	node_array<int> &num, node_array<edge> &e_wp,
	node_array<edge> &e_wq)
{
	const int n = G.number_of_nodes();
	node_array<int>  x_rel (G);
	node_array<node> upper (G);
	node_array<node> next (G);
	array<node> v (1, n);
	node w, vk, wp, wq;
	int k, xq, dx;

	// Initialisierung
	forall_nodes (w, G)
		v [num [w]] = w;

	x_rel [v[1]] = x_rel [v[2]] = y [v[1]] = y [v[2]] = 0;
	next [v[1]] = v[2]; next [v[2]] = NULL;

	// Hauptschleife
	for (k = 3; k <= n; k++) {
		vk = v[k];
		wp = G.target (e_wp [vk]);
		wq = G.target (e_wq [vk]);

		xq = 2;
		w = wp;
		do {
			w = next [w];
			xq += x_rel [w];
		} while (w != wq);

		x_rel [vk] = (xq + y[wq] - y[wp]) / 2;
		y     [vk] = (xq + y[wq] + y[wp]) / 2;
		x_rel [wq] = xq - x_rel[vk];

		dx = 1;
		for (w = next[wp]; w != wq; w = next[w]) {
			dx += x_rel[w];
			x [w] = dx-x_rel[vk]; upper [w] = vk;
		}

		next [wp] = vk; next [vk] = wq;
	}

	// Bestimme absolute x-Koordinate auf Au�enregion
	x [v[n]] = x_rel[v[n]]; x[v[2]] = x[v[n]] + x_rel[v[2]]; x[v[1]] = 0;

	// Bestimme absolute x-Koordinate f�r alle anderen (inneren) Knoten
	for (k = n-1; k >= 3; k--)
		x [v[k]] += x [upper[v[k]]];

}


///////////////////////////////////////////////////////
// GT_Tcl_Layout_Fpp_Algorithm
//
///////////////////////////////////////////////////////

GT_Tcl_Layout_Fpp_Algorithm::GT_Tcl_Layout_Fpp_Algorithm (
	const string& name) :
	GT_Tcl_Algorithm<GT_Layout_Fpp_Algorithm> (name)
{
}


GT_Tcl_Layout_Fpp_Algorithm::~GT_Tcl_Layout_Fpp_Algorithm ()
{
}


int GT_Tcl_Layout_Fpp_Algorithm::parse (GT_Tcl_info& info, int& index,
	GT_Tcl_Graph* /*g*/)
{
	int code;

	if (streq (info.argv(index), "-sep") && !info.is_last_arg(index)) {
		index++;

		double sep;
		code = Tcl_GetDouble (info.interp(), info.argv(index++),
			&sep);
		if (code != TCL_ERROR) {
			col_sep (sep); row_sep (sep);
		} else {
			return code;
		}

	} else {
		string msg ("Unrecognized argument %s", info.argv(index));
		info.msg (msg);
		return TCL_ERROR;
	}

	return TCL_OK;
}


