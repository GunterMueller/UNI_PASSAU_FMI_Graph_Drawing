
#include "convex_layout.h"


///////////////////////////////////////////////////////
// GT_Layout_Convex_Algorithm
//
// This is the Convex (Kant) algorithm
///////////////////////////////////////////////////////


int GT_Layout_Convex_Algorithm::check (GT_Graph &g, string& message)
{
	if (g.leda().number_of_nodes() < 3) {
		message = "The graph must have at least three nodes!";
		return TCL_ERROR;
	}
	if (Is_Simple (g.leda()) == false) {
		message = "The graph must be simple!";
		return TCL_ERROR;
	}

	Undirected_Graph ug (g.leda());
	if (is_triconnected (ug) == false) {
		message = "The graph must be triconnected!";
		return TCL_ERROR;
	}
	if (ug.is_planar() == false) {
		message = "The graph must be planar!";
		return TCL_ERROR;
	}
	message = "everything ok";
	return GT_OK;
}

bool GT_Layout_Convex_Algorithm::compute_layout (Undirected_Graph& G)
{
	G.embed_planar();

	Lmc_Order lmc(G);
	
	node_array<int>  shift(G);			// abs. x-Koord. von v ist x[v] + shift[v]
	node_array<bool> correct(G);		// correct[v] = true <=> x[v] wurde neu berechnet
	node_array<node> next(G), prev(G),	// F�r Au�enfl�che c_1,...,c_q ist next[c_i] = c_i+1, prev[c_i] = c_i-1
					 upper(G, nil);	// upper[v] = w bedeutet x-Koord. von v ist relativ zu w
									// (abs. x-Koord. von v = x[v] + abs. x-Koord von w)
	
	node v1 = lmc (1,1),	// v1 und v2 der Grundlinie
		 v2 = lmc (1,2);

	node		v, z1, cl, cr;
	const int	n = lmc.length();
	int			k, i, sum;

	// Beginne mit Geraden (v1, v2) (beide auf Punkt (0,0))
	x [v1] = x [v2] = y [v1] = y [v2] = 0;
	shift [v1] = shift [v2] = 0;
	correct [v1] = true;		// x[v1] bleibt immer 0; verhindert, da� update �ber v1 hinausl�uft

	// Initialisierung der Au�enfl�che
	next [v1] = v2;  next [v2] = nil;
	prev [v1] = nil; prev [v2] = v1;

	for (k = 2; k <= n; k++) {
		const Order_Set &Vk = lmc[k];		// Referenz auf aktuelle Menge Vk (als Abk�rzung)
		int l = Vk.len(), offset;	// Vk = { z_1,...,z_l }
		z1 = Vk[1];
		cl = Vk.left(); cr = Vk.right();	// left- und rightvertex in Menge gespeichert

		// Initialisiere correct[zi] und shift[zi]
		for (i = 1; i <= l; i++) {
			correct [Vk[i]] = false; shift [Vk[i]] = 0;
		}

		// update x[cl] und shift[cr]
		// wandere solange nach links, bis v mit correct[v] = true gefunden
		for (v = prev[cr]; correct[v] == false; v = prev [v]) ;
		sum = 0;
		// wandere von v zur�ck nach cr und berechne x-Werte neu
		for (v = next [v]; v != cr; v = next [v]) {
			sum += shift [v];
			x [v] += sum;
			correct [v] = true;
		}
		shift [cr] += sum;	// F�r cr wird nur der shift korrigiert (so da� x-Koord von cr = x[cr] + shift[cr])

		if (size_opt()) {
			// Optimierung: Berechne minimalen Wert offset, um den cr nach rechts verschoben werden mu�
			int y_max = y[cr];
			// Falls von cl Kante mit Steigung +1 nach rechts bzw von cr Kante mit Steigung -1 nach links geht,
			// dann offset ist mind. 2, sonst offset ist mind. 0
			offset = (y[cl] < y[next[cl]] || y[cr] < y[prev[cr]]) ? 2 : 0;

			for (v = cl; v != cr; v = next[v])	// y_max = max { y[c_i] | l <= i <= r }
				if (y[v] > y_max) y_max = y[v];
			// offset mu� mind. so gro� gew�hlt werden, da� y-Koord. der zi > y_max ist
			offset = Max (offset, 2*(y_max+l)+x[cl]-(x[cr]+shift[cr])-y[cl]-y[cr]);
		} else
			offset = 2*l;

		shift[cr] += offset;	// Verschiebe cr um offset nach rechts

		// Berechne die Einf�ge-Koordinaten der zi
		x [z1] = (x[cl] + x[cr] + shift[cr] - y[cl] + y[cr]) / 2 - l + 1;
		y [z1] = (x[cr] + shift[cr] - x[cl] + y[cl] + y[cr]) / 2 - l + 1;
		for (i = 2; i <= l; i++) {
			x[Vk[i]] = x[z1]+2*(i-1);
			y[Vk[i]] = y[z1];
		}

		// Berechne Verschiebewerte f�r cl,...,cr und relative x-Koord. und relativen Knoten f�r innere Knoten
		// Sei l <= c_alpha <= c_beta <= r max. mit
		//		y[cl] > ... > y[c_alpha] und y[c_beta] < ... < y[cr]
		// Verschiebe c_alpha,...,c_beta um offset/2 (c_alpha,c_beta nur falls != cl,cr)
		//    -"-     c_beta+1,...,cr um offset
		// x-Koord. von c_l+1,    ...,c_alpha  relativ zu cl
		//       -"-    c_alpha+1,...,c_beta-1 relativ zu z1
		//       -"-    c_beta,   ...,cr       relativ zu cr
		node ca, cb;
		if (y[cl] <= y[next[cl]]) ca = cl;
		else {
			for (ca = next[cl], v = next[ca]; ca != cr && y[v] < y[ca]; ca = v, v = next[v])
				{ x[ca] += 0 - x[cl]; upper[ca] = cl; }
			if (ca != cr)
				{ x[ca] += (offset/2) -x[cl]; upper[ca] = cl; }
		}
		if (y[cr] <= y[prev[cr]]) cb = cr;
		else {
			for (cb = prev[cr], v = prev[cb]; cb != cl && y[v] < y[cb]; cb = v, v = prev[v])
				{ x[cb] += offset - (x[cr]+shift[cr]); upper[cb] = cr; }
			if (cb != cl && cb != ca)
				{ x[cb] += (offset/2) - (x[cr]+shift[cr]); upper[cb] = cr; }
		}
		if (ca != cb)
			for (v = next[ca]; v != cb; v = next[v])
				{ x[v] += (offset/2) - x[z1]; upper[v] = z1; }

		// Aktualisiere Au�enregion nach Einf�gen von z1,...,zl
		for (i = 1; i <= l; i++) {
			if (i < l) next[Vk[i]] = Vk[i+1];
			if (i > 1) prev[Vk[i]] = Vk[i-1];
		}
		next [cl] = z1;    next [Vk[l]] = cr;
		prev [cr] = Vk[l]; prev [z1] = cl;
	}
	// Berechne die endg�ltigen x-Koordinaten f�r die Knoten der (endg�ltigen) Au�enregion
	for (sum = 0, v = v1; v != nil; v = next[v]) {
		sum += shift[v];
		x[v] += sum;
	}

	// Berechne endgultige x-Koordinaten f�r die inneren Knoten
	for (k = n-1; k >= 2; k--)
		for (i = 1; i <= lmc.len(k); i++) {
			node zi = lmc (k,i);
			if (upper[zi] != nil) x[zi] += x[upper[zi]]; // f�r weitere Knoten auf der Au�enregion (neben v1,
		}                                                // v2, vn gilt upper[zi] = nil

	return true;
}


///////////////////////////////////////////////////////
// GT_Tcl_Layout_Convex_Algorithm
//
///////////////////////////////////////////////////////

GT_Tcl_Layout_Convex_Algorithm::GT_Tcl_Layout_Convex_Algorithm (
	const string& name) :
	GT_Tcl_Algorithm<GT_Layout_Convex_Algorithm> (name)
{
}


GT_Tcl_Layout_Convex_Algorithm::~GT_Tcl_Layout_Convex_Algorithm ()
{
}


int GT_Tcl_Layout_Convex_Algorithm::parse (GT_Tcl_info& info, int& index,
	GT_Tcl_Graph* /*g*/)
{
	int code;

	if (streq (info[index], "-size_opt") && !info.is_last_arg(index)) {
		index++;

		int do_size_opt;
		code = Tcl_GetBoolean (info.interp(), info[index++],
			&do_size_opt);
		if (code != TCL_ERROR) {
			size_opt (bool(do_size_opt));
		} else {
			return code;
		}

	} else {
		string msg ("Unrecognized argument %s", info[index]);
		info.msg (msg);
		return TCL_ERROR;
	}

	return TCL_OK;
}

